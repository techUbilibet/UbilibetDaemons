#!/bin/bash

CLASSPATH=/usr/share/java/postgresql.jar:/usr/share/java/wsdl4j.jar
CLASSPATH=$CLASSPATH:/usr/share/java/commons-logging.jar:/usr/share/java/commons-logging-adapters.jar
CLASSPATH=$CLASSPATH:/usr/share/java/commons-logging-api.jar:/usr/share/java/commons-discovery.jar
CLASSPATH=$CLASSPATH:/usr/share/java/axis.jar:/usr/share/java/axis-jaxrpc.jar:/usr/share/java/axis-saaj.jar
CLASSPATH=$CLASSPATH:/usr/share/java/mailapi.jar:/usr/share/java/javax.mail.jar:/usr/share/java/javax.mail-api.jar:/usr/share/java/imap.jar:/usr/share/java/pop3.jar:/usr/share/java/smtp.jar

CLASSPATH=$CLASSPATH:hibernate/lib/required/*:hibernate/lib/optional/c3p0/*:itext/*:jsonSimple/*
CLASSPATH=$CLASSPATH:/usr/lib/jvm/java-8-openjdk

CLASSPATH=$CLASSPATH:bin:xml-hibernate
export CLASSPATH

export LANG=ca_ES.UTF-8

cd /Ubilibet

./back.sh> /dev/null

#### MARKS ####
java partnerDaemon.PartnerCertificate $@ &> /dev/null
if [ -s certificate.warning.log ]; then
	cat certificate.warning.log|mail tech@ubilibet.com -a "Content-type: text/plain; charset=UTF-8" -s "Cron: reenviaCert.sh"
fi

truncate -s 0 certificate.warning.log

cd - >/dev/null

