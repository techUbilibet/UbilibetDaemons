#!/bin/bash

CLASSPATH=/usr/share/java/axis-ant.jar:/usr/share/java/axis-jaxrpc.jar:/usr/share/java/axis-saaj.jar:/usr/share/java/axis.jar
CLASSPATH=$CLASSPATH:/usr/share/java/dom4j.jar:/usr/share/java/wsdl4j.jar

CLASSPATH=$CLASSPATH:componentes-1.1.7/core/*:componentes-1.1.7/deps/*

CLASSPATH=$CLASSPATH:/usr/lib/jvm/java-8-openjdk

CLASSPATH=$CLASSPATH:bin
export CLASSPATH

export LANG=ca_ES.UTF-8

cd /Ubilibet

./back.sh> /dev/null

java firmaFace.FirmaFace $@ 2> /dev/null
if [ $? == 0 ];
then
       echo "OK"
else
        echo "ERROR"
        if [ $# != 0 ]; then
   echo "Error firma"|mail tech@ubilibet.com -a "Content-type: text/plain; charset=UTF-8" -s "firma.sh"
        fi
fi

for d in firmaface.warning.log*; do
if [ -s ${d} ]; then
cat ${d}|mail tech@ubilibet.com -a "Content-type: text/plain; charset=UTF-8" -s "Cron: firma.sh"
	truncate -s 0 ${d}
fi
done
 
cd - >/dev/null

