#!/bin/bash

CLASSPATH=/usr/share/java/postgresql.jar:/usr/share/java/wsdl4j.jar
CLASSPATH=$CLASSPATH:/usr/share/java/commons-logging.jar:/usr/share/java/commons-logging-adapters.jar
CLASSPATH=$CLASSPATH:/usr/share/java/commons-logging-api.jar:/usr/share/java/commons-discovery.jar
CLASSPATH=$CLASSPATH:/usr/share/java/axis.jar:/usr/share/java/axis-jaxrpc.jar:/usr/share/java/axis-saaj.jar
CLASSPATH=$CLASSPATH:/usr/share/java/mailapi.jar:/usr/share/java/javax.mail.jar:/usr/share/java/javax.mail-api.jar:/usr/share/java/imap.jar:/usr/share/java/pop3.jar:/usr/share/java/smtp.jar

CLASSPATH=$CLASSPATH:hibernate/lib/required/*:hibernate/lib/optional/c3p0/*:itext/*:jsonSimple/*
CLASSPATH=$CLASSPATH:/usr/lib/jvm/java-8-openjdk

CLASSPATH=$CLASSPATH:bin:xml-hibernate
export CLASSPATH

function execute {
        java partnerDaemon.Partner$1 -partner $2 &> /dev/null
        if [ $? != 0 ]; then
           echo "CONN FAULT in Partner$1 $2"|mail tech@ubilibet.com -a "Content-type: text/plain; charset=UTF-8" -s "CONN FAULT"
        fi
}

min=$((10#`date +"%M"`%10))

cd /Ubilibet

if [ -a PARTNERACTIVE ]; then
        echo FLAG ACTIVATE
else
        touch PARTNERACTIVE
		./back.sh> /dev/null

        #### DOMAINS ####
        # Per executar tots els partners
        #java partnerDaemon.PartnerDomain
        execute Domain 1 &> /dev/null
        execute Domain 3 &> /dev/null
        execute Domain 4 &> /dev/null
        execute Domain 7 &> /dev/null
        execute Domain 10 &> /dev/null
        execute Domain 11 &> /dev/null
        execute Domain 16 &> /dev/null
        execute Domain 18 &> /dev/null
        execute Domain 19 &> /dev/null
        execute Domain 38 &> /dev/null
        execute Domain 41 &> /dev/null
        execute Domain 44 &> /dev/null
        execute Domain 48 &> /dev/null
        execute Domain 50 &> /dev/null
        execute Domain 55 &> /dev/null
        execute Domain 56 &> /dev/null
        execute Domain 64 &> /dev/null
        execute Domain 76 &> /dev/null
        execute Domain 82 &> /dev/null
        execute Domain 84 &> /dev/null
        execute Domain 92 &> /dev/null
        execute Domain 105 &> /dev/null
        execute Domain 110 &> /dev/null
        execute Domain 114 &> /dev/null
        execute Domain 134 &> /dev/null
        execute Domain 188 &> /dev/null
        execute Domain 198 &> /dev/null
        execute Domain 204 &> /dev/null
        execute Domain 205 &> /dev/null

        #### CERTS ####
        execute Certificate 53 &> /dev/null

        if [ $min == 0 ]; then
	   #### MARKS ####
           execute Mark 6 &> /dev/null
        else
	   #### MONITOR ####
	   execute Monitor 200 &> /dev/null
        fi

        #### Zone ####
        execute Zone 2 &> /dev/null
        
        rm PARTNERACTIVE
        if [ -s domain.warning.log ]; then
            cat domain.warning.log
        fi
        truncate -s 0 domain.warning.log

        if [ -s mark.warning.log ]; then
            cat mark.warning.log
        fi
        truncate -s 0 mark.warning.log

        if [ -s certificate.warning.log ]; then
            cat certificate.warning.log
        fi
        truncate -s 0 certificate.warning.log

        if [ -s monitor.warning.log ]; then
            cat monitor.warning.log
        fi
        truncate -s 0 zone.warning.log

        if [ -s zone.warning.log ]; then
            cat zone.warning.log
        fi
        truncate -s 0 zone.warning.log
fi

cd - >/dev/null

