if [ -a datapak.flag ]; then
        tar -xzvf datapak.tar.gz        
        rm datapak.tar.gz datapak.flag
        chown -R root:root *
fi
if [ -a jvpak.flag ]; then
        rm back.tar.gz
        tar -czvf back.tar.gz --exclude=*.tar.gz --exclude=upload*/*/* --exclude=newtld* *
        tar -xzvf jvpak.tar.gz    
        rm jvpak.tar.gz jvpak.flag
        chown -R root:root *
fi
SBD=*
for x in `seq 1 8`;
do
		rm -r $SBD/CVS 2> /dev/null
		rm $SBD/.#* 2> /dev/null
		rm $SBD/*~ 2> /dev/null
		SBD=*/$SBD
done

