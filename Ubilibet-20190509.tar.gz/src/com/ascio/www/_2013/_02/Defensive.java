/**
 * Defensive.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ascio.www._2013._02;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class Defensive  implements java.io.Serializable {
    private java.lang.String handle;

    private java.lang.String name;

    private java.lang.String markHandle;

    private java.lang.String authInfo;

    private java.lang.String encoding;

    private com.ascio.www._2013._02.Registrant owner;

    private com.ascio.www._2013._02.Contact admin;

    private com.ascio.www._2013._02.Contact tech;

    private com.ascio.www._2013._02.Contact billing;

    private com.ascio.www._2013._02.Contact reseller;

    public Defensive() {
    }

    public Defensive(
           java.lang.String handle,
           java.lang.String name,
           java.lang.String markHandle,
           java.lang.String authInfo,
           java.lang.String encoding,
           com.ascio.www._2013._02.Registrant owner,
           com.ascio.www._2013._02.Contact admin,
           com.ascio.www._2013._02.Contact tech,
           com.ascio.www._2013._02.Contact billing,
           com.ascio.www._2013._02.Contact reseller) {
           this.handle = handle;
           this.name = name;
           this.markHandle = markHandle;
           this.authInfo = authInfo;
           this.encoding = encoding;
           this.owner = owner;
           this.admin = admin;
           this.tech = tech;
           this.billing = billing;
           this.reseller = reseller;
    }


    /**
     * Gets the handle value for this Defensive.
     * 
     * @return handle
     */
    public java.lang.String getHandle() {
        return handle;
    }


    /**
     * Sets the handle value for this Defensive.
     * 
     * @param handle
     */
    public void setHandle(java.lang.String handle) {
        this.handle = handle;
    }


    /**
     * Gets the name value for this Defensive.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this Defensive.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the markHandle value for this Defensive.
     * 
     * @return markHandle
     */
    public java.lang.String getMarkHandle() {
        return markHandle;
    }


    /**
     * Sets the markHandle value for this Defensive.
     * 
     * @param markHandle
     */
    public void setMarkHandle(java.lang.String markHandle) {
        this.markHandle = markHandle;
    }


    /**
     * Gets the authInfo value for this Defensive.
     * 
     * @return authInfo
     */
    public java.lang.String getAuthInfo() {
        return authInfo;
    }


    /**
     * Sets the authInfo value for this Defensive.
     * 
     * @param authInfo
     */
    public void setAuthInfo(java.lang.String authInfo) {
        this.authInfo = authInfo;
    }


    /**
     * Gets the encoding value for this Defensive.
     * 
     * @return encoding
     */
    public java.lang.String getEncoding() {
        return encoding;
    }


    /**
     * Sets the encoding value for this Defensive.
     * 
     * @param encoding
     */
    public void setEncoding(java.lang.String encoding) {
        this.encoding = encoding;
    }


    /**
     * Gets the owner value for this Defensive.
     * 
     * @return owner
     */
    public com.ascio.www._2013._02.Registrant getOwner() {
        return owner;
    }


    /**
     * Sets the owner value for this Defensive.
     * 
     * @param owner
     */
    public void setOwner(com.ascio.www._2013._02.Registrant owner) {
        this.owner = owner;
    }


    /**
     * Gets the admin value for this Defensive.
     * 
     * @return admin
     */
    public com.ascio.www._2013._02.Contact getAdmin() {
        return admin;
    }


    /**
     * Sets the admin value for this Defensive.
     * 
     * @param admin
     */
    public void setAdmin(com.ascio.www._2013._02.Contact admin) {
        this.admin = admin;
    }


    /**
     * Gets the tech value for this Defensive.
     * 
     * @return tech
     */
    public com.ascio.www._2013._02.Contact getTech() {
        return tech;
    }


    /**
     * Sets the tech value for this Defensive.
     * 
     * @param tech
     */
    public void setTech(com.ascio.www._2013._02.Contact tech) {
        this.tech = tech;
    }


    /**
     * Gets the billing value for this Defensive.
     * 
     * @return billing
     */
    public com.ascio.www._2013._02.Contact getBilling() {
        return billing;
    }


    /**
     * Sets the billing value for this Defensive.
     * 
     * @param billing
     */
    public void setBilling(com.ascio.www._2013._02.Contact billing) {
        this.billing = billing;
    }


    /**
     * Gets the reseller value for this Defensive.
     * 
     * @return reseller
     */
    public com.ascio.www._2013._02.Contact getReseller() {
        return reseller;
    }


    /**
     * Sets the reseller value for this Defensive.
     * 
     * @param reseller
     */
    public void setReseller(com.ascio.www._2013._02.Contact reseller) {
        this.reseller = reseller;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Defensive)) return false;
        Defensive other = (Defensive) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.handle==null && other.getHandle()==null) || 
             (this.handle!=null &&
              this.handle.equals(other.getHandle()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.markHandle==null && other.getMarkHandle()==null) || 
             (this.markHandle!=null &&
              this.markHandle.equals(other.getMarkHandle()))) &&
            ((this.authInfo==null && other.getAuthInfo()==null) || 
             (this.authInfo!=null &&
              this.authInfo.equals(other.getAuthInfo()))) &&
            ((this.encoding==null && other.getEncoding()==null) || 
             (this.encoding!=null &&
              this.encoding.equals(other.getEncoding()))) &&
            ((this.owner==null && other.getOwner()==null) || 
             (this.owner!=null &&
              this.owner.equals(other.getOwner()))) &&
            ((this.admin==null && other.getAdmin()==null) || 
             (this.admin!=null &&
              this.admin.equals(other.getAdmin()))) &&
            ((this.tech==null && other.getTech()==null) || 
             (this.tech!=null &&
              this.tech.equals(other.getTech()))) &&
            ((this.billing==null && other.getBilling()==null) || 
             (this.billing!=null &&
              this.billing.equals(other.getBilling()))) &&
            ((this.reseller==null && other.getReseller()==null) || 
             (this.reseller!=null &&
              this.reseller.equals(other.getReseller())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getHandle() != null) {
            _hashCode += getHandle().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getMarkHandle() != null) {
            _hashCode += getMarkHandle().hashCode();
        }
        if (getAuthInfo() != null) {
            _hashCode += getAuthInfo().hashCode();
        }
        if (getEncoding() != null) {
            _hashCode += getEncoding().hashCode();
        }
        if (getOwner() != null) {
            _hashCode += getOwner().hashCode();
        }
        if (getAdmin() != null) {
            _hashCode += getAdmin().hashCode();
        }
        if (getTech() != null) {
            _hashCode += getTech().hashCode();
        }
        if (getBilling() != null) {
            _hashCode += getBilling().hashCode();
        }
        if (getReseller() != null) {
            _hashCode += getReseller().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Defensive.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Defensive"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("handle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Handle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("markHandle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "MarkHandle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("authInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "AuthInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("encoding");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Encoding"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("owner");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Owner"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Registrant"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("admin");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Admin"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Contact"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tech");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Tech"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Contact"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("billing");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Billing"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Contact"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("reseller");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Reseller"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Contact"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
