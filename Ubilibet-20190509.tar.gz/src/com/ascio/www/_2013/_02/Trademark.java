/**
 * Trademark.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ascio.www._2013._02;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class Trademark  extends com.ascio.www._2013._02.AbstractMark  implements java.io.Serializable {
    /* Application number as provided by the trademark office */
    private java.lang.String applicationId;

    /* The registration number of the trademark */
    private java.lang.String registrationNumber;

    /* Date on which the trademark was applied */
    private java.util.Calendar applicationDate;

    /* Date on which the registered trademark was registered */
    private java.util.Calendar registrationDate;

    /* Date on which the registered trademark expires */
    private java.util.Calendar expirationDate;

    /* Nice classification of the goods and/or services for which
     * a registered trademark is protected */
    private int[] goodsAndServicesClasses;

    /* National or regional territory in which the registered trademark
     * is protected */
    private java.lang.String jurisdiction;

    public Trademark() {
    }

    public Trademark(
           java.lang.String handle,
           java.lang.String markName,
           java.lang.String markId,
           java.lang.String authInfo,
           com.ascio.www._2013._02.MarkServiceType serviceType,
           java.lang.String goodsAndServicesDescription,
           java.lang.String[] labels,
           java.lang.String claimEmailNotification1,
           java.lang.String claimEmailNotification2,
           java.lang.String claimEmailNotification3,
           java.lang.String claimEmailNotification4,
           java.lang.String claimEmailNotification5,
           com.ascio.www._2013._02.NotificationFrequencyType notificationFrequency,
           com.ascio.www._2013._02.Registrant owner,
           com.ascio.www._2013._02.Contact reseller,
           com.ascio.www._2013._02.ExtensionsKeyValue[] extensions,
           java.lang.String applicationId,
           java.lang.String registrationNumber,
           java.util.Calendar applicationDate,
           java.util.Calendar registrationDate,
           java.util.Calendar expirationDate,
           int[] goodsAndServicesClasses,
           java.lang.String jurisdiction) {
        super(
            handle,
            markName,
            markId,
            authInfo,
            serviceType,
            goodsAndServicesDescription,
            labels,
            claimEmailNotification1,
            claimEmailNotification2,
            claimEmailNotification3,
            claimEmailNotification4,
            claimEmailNotification5,
            notificationFrequency,
            owner,
            reseller,
            extensions);
        this.applicationId = applicationId;
        this.registrationNumber = registrationNumber;
        this.applicationDate = applicationDate;
        this.registrationDate = registrationDate;
        this.expirationDate = expirationDate;
        this.goodsAndServicesClasses = goodsAndServicesClasses;
        this.jurisdiction = jurisdiction;
    }


    /**
     * Gets the applicationId value for this Trademark.
     * 
     * @return applicationId   * Application number as provided by the trademark office
     */
    public java.lang.String getApplicationId() {
        return applicationId;
    }


    /**
     * Sets the applicationId value for this Trademark.
     * 
     * @param applicationId   * Application number as provided by the trademark office
     */
    public void setApplicationId(java.lang.String applicationId) {
        this.applicationId = applicationId;
    }


    /**
     * Gets the registrationNumber value for this Trademark.
     * 
     * @return registrationNumber   * The registration number of the trademark
     */
    public java.lang.String getRegistrationNumber() {
        return registrationNumber;
    }


    /**
     * Sets the registrationNumber value for this Trademark.
     * 
     * @param registrationNumber   * The registration number of the trademark
     */
    public void setRegistrationNumber(java.lang.String registrationNumber) {
        this.registrationNumber = registrationNumber;
    }


    /**
     * Gets the applicationDate value for this Trademark.
     * 
     * @return applicationDate   * Date on which the trademark was applied
     */
    public java.util.Calendar getApplicationDate() {
        return applicationDate;
    }


    /**
     * Sets the applicationDate value for this Trademark.
     * 
     * @param applicationDate   * Date on which the trademark was applied
     */
    public void setApplicationDate(java.util.Calendar applicationDate) {
        this.applicationDate = applicationDate;
    }


    /**
     * Gets the registrationDate value for this Trademark.
     * 
     * @return registrationDate   * Date on which the registered trademark was registered
     */
    public java.util.Calendar getRegistrationDate() {
        return registrationDate;
    }


    /**
     * Sets the registrationDate value for this Trademark.
     * 
     * @param registrationDate   * Date on which the registered trademark was registered
     */
    public void setRegistrationDate(java.util.Calendar registrationDate) {
        this.registrationDate = registrationDate;
    }


    /**
     * Gets the expirationDate value for this Trademark.
     * 
     * @return expirationDate   * Date on which the registered trademark expires
     */
    public java.util.Calendar getExpirationDate() {
        return expirationDate;
    }


    /**
     * Sets the expirationDate value for this Trademark.
     * 
     * @param expirationDate   * Date on which the registered trademark expires
     */
    public void setExpirationDate(java.util.Calendar expirationDate) {
        this.expirationDate = expirationDate;
    }


    /**
     * Gets the goodsAndServicesClasses value for this Trademark.
     * 
     * @return goodsAndServicesClasses   * Nice classification of the goods and/or services for which
     * a registered trademark is protected
     */
    public int[] getGoodsAndServicesClasses() {
        return goodsAndServicesClasses;
    }


    /**
     * Sets the goodsAndServicesClasses value for this Trademark.
     * 
     * @param goodsAndServicesClasses   * Nice classification of the goods and/or services for which
     * a registered trademark is protected
     */
    public void setGoodsAndServicesClasses(int[] goodsAndServicesClasses) {
        this.goodsAndServicesClasses = goodsAndServicesClasses;
    }


    /**
     * Gets the jurisdiction value for this Trademark.
     * 
     * @return jurisdiction   * National or regional territory in which the registered trademark
     * is protected
     */
    public java.lang.String getJurisdiction() {
        return jurisdiction;
    }


    /**
     * Sets the jurisdiction value for this Trademark.
     * 
     * @param jurisdiction   * National or regional territory in which the registered trademark
     * is protected
     */
    public void setJurisdiction(java.lang.String jurisdiction) {
        this.jurisdiction = jurisdiction;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Trademark)) return false;
        Trademark other = (Trademark) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.applicationId==null && other.getApplicationId()==null) || 
             (this.applicationId!=null &&
              this.applicationId.equals(other.getApplicationId()))) &&
            ((this.registrationNumber==null && other.getRegistrationNumber()==null) || 
             (this.registrationNumber!=null &&
              this.registrationNumber.equals(other.getRegistrationNumber()))) &&
            ((this.applicationDate==null && other.getApplicationDate()==null) || 
             (this.applicationDate!=null &&
              this.applicationDate.equals(other.getApplicationDate()))) &&
            ((this.registrationDate==null && other.getRegistrationDate()==null) || 
             (this.registrationDate!=null &&
              this.registrationDate.equals(other.getRegistrationDate()))) &&
            ((this.expirationDate==null && other.getExpirationDate()==null) || 
             (this.expirationDate!=null &&
              this.expirationDate.equals(other.getExpirationDate()))) &&
            ((this.goodsAndServicesClasses==null && other.getGoodsAndServicesClasses()==null) || 
             (this.goodsAndServicesClasses!=null &&
              java.util.Arrays.equals(this.goodsAndServicesClasses, other.getGoodsAndServicesClasses()))) &&
            ((this.jurisdiction==null && other.getJurisdiction()==null) || 
             (this.jurisdiction!=null &&
              this.jurisdiction.equals(other.getJurisdiction())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getApplicationId() != null) {
            _hashCode += getApplicationId().hashCode();
        }
        if (getRegistrationNumber() != null) {
            _hashCode += getRegistrationNumber().hashCode();
        }
        if (getApplicationDate() != null) {
            _hashCode += getApplicationDate().hashCode();
        }
        if (getRegistrationDate() != null) {
            _hashCode += getRegistrationDate().hashCode();
        }
        if (getExpirationDate() != null) {
            _hashCode += getExpirationDate().hashCode();
        }
        if (getGoodsAndServicesClasses() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getGoodsAndServicesClasses());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getGoodsAndServicesClasses(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getJurisdiction() != null) {
            _hashCode += getJurisdiction().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Trademark.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Trademark"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("applicationId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "ApplicationId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("registrationNumber");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "RegistrationNumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("applicationDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "ApplicationDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("registrationDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "RegistrationDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("expirationDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "ExpirationDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("goodsAndServicesClasses");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "GoodsAndServicesClasses"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://schemas.microsoft.com/2003/10/Serialization/Arrays", "int"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("jurisdiction");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Jurisdiction"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
