/**
 * OrderType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ascio.www._2013._02;

@SuppressWarnings({ "unused", "serial", "unchecked", "rawtypes" })
public class OrderType implements java.io.Serializable {
    private java.lang.String _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    protected OrderType(java.lang.String value) {
        _value_ = value;
        _table_.put(_value_,this);
    }

    public static final java.lang.String _NotSet = "NotSet";
    public static final java.lang.String _ContactUpdate = "ContactUpdate";
    public static final java.lang.String _ChangeLocks = "ChangeLocks";
    public static final java.lang.String _Delete = "Delete";
    public static final java.lang.String _RegistrantDetailsUpdate = "RegistrantDetailsUpdate";
    public static final java.lang.String _Expire = "Expire";
    public static final java.lang.String _NameserverUpdate = "NameserverUpdate";
    public static final java.lang.String _OwnerChange = "OwnerChange";
    public static final java.lang.String _Queue = "Queue";
    public static final java.lang.String _Register = "Register";
    public static final java.lang.String _Renew = "Renew";
    public static final java.lang.String _Restore = "Restore";
    public static final java.lang.String _Transfer = "Transfer";
    public static final java.lang.String _Unexpire = "Unexpire";
    public static final java.lang.String _TransferAway = "TransferAway";
    public static final java.lang.String _AutoRenew = "AutoRenew";
    public static final java.lang.String _AutoDelete = "AutoDelete";
    public static final java.lang.String _DetailsUpdate = "DetailsUpdate";
    public static final java.lang.String _Import = "Import";
    public static final java.lang.String _PartnerChange = "PartnerChange";
    public static final java.lang.String _DeQueue = "DeQueue";
    public static final java.lang.String _UpdateAuthInfo = "UpdateAuthInfo";
    public static final OrderType NotSet = new OrderType(_NotSet);
    public static final OrderType ContactUpdate = new OrderType(_ContactUpdate);
    public static final OrderType ChangeLocks = new OrderType(_ChangeLocks);
    public static final OrderType Delete = new OrderType(_Delete);
    public static final OrderType RegistrantDetailsUpdate = new OrderType(_RegistrantDetailsUpdate);
    public static final OrderType Expire = new OrderType(_Expire);
    public static final OrderType NameserverUpdate = new OrderType(_NameserverUpdate);
    public static final OrderType OwnerChange = new OrderType(_OwnerChange);
    public static final OrderType Queue = new OrderType(_Queue);
    public static final OrderType Register = new OrderType(_Register);
    public static final OrderType Renew = new OrderType(_Renew);
    public static final OrderType Restore = new OrderType(_Restore);
    public static final OrderType Transfer = new OrderType(_Transfer);
    public static final OrderType Unexpire = new OrderType(_Unexpire);
    public static final OrderType TransferAway = new OrderType(_TransferAway);
    public static final OrderType AutoRenew = new OrderType(_AutoRenew);
    public static final OrderType AutoDelete = new OrderType(_AutoDelete);
    public static final OrderType DetailsUpdate = new OrderType(_DetailsUpdate);
    public static final OrderType Import = new OrderType(_Import);
    public static final OrderType PartnerChange = new OrderType(_PartnerChange);
    public static final OrderType DeQueue = new OrderType(_DeQueue);
    public static final OrderType UpdateAuthInfo = new OrderType(_UpdateAuthInfo);
    public java.lang.String getValue() { return _value_;}
    public static OrderType fromValue(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        OrderType enumeration = (OrderType)
            _table_.get(value);
        if (enumeration==null) throw new java.lang.IllegalArgumentException();
        return enumeration;
    }
    public static OrderType fromString(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        return fromValue(value);
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_;}
    public java.lang.Object readResolve() throws java.io.ObjectStreamException { return fromValue(_value_);}
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumSerializer(
            _javaType, _xmlType);
    }
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumDeserializer(
            _javaType, _xmlType);
    }
    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(OrderType.class);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "OrderType"));
    }
    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

}
