/**
 * QueueMessage.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ascio.www._2013._02;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class QueueMessage  implements java.io.Serializable {
    private com.ascio.www._2013._02.Attachment[] attachments;

    private com.ascio.www._2013._02.ErrorCode[] errorCodes;

    private java.lang.Integer id;

    private java.lang.String message;

    private com.ascio.www._2013._02.MessageType messageType;

    private java.lang.String objectHandle;

    private java.lang.String objectName;

    private com.ascio.www._2013._02.ObjectType objectType;

    private java.lang.String orderId;

    private com.ascio.www._2013._02.OrderStatusType orderStatus;

    private com.ascio.www._2013._02.OrderType orderType;

    public QueueMessage() {
    }

    public QueueMessage(
           com.ascio.www._2013._02.Attachment[] attachments,
           com.ascio.www._2013._02.ErrorCode[] errorCodes,
           java.lang.Integer id,
           java.lang.String message,
           com.ascio.www._2013._02.MessageType messageType,
           java.lang.String objectHandle,
           java.lang.String objectName,
           com.ascio.www._2013._02.ObjectType objectType,
           java.lang.String orderId,
           com.ascio.www._2013._02.OrderStatusType orderStatus,
           com.ascio.www._2013._02.OrderType orderType) {
           this.attachments = attachments;
           this.errorCodes = errorCodes;
           this.id = id;
           this.message = message;
           this.messageType = messageType;
           this.objectHandle = objectHandle;
           this.objectName = objectName;
           this.objectType = objectType;
           this.orderId = orderId;
           this.orderStatus = orderStatus;
           this.orderType = orderType;
    }


    /**
     * Gets the attachments value for this QueueMessage.
     * 
     * @return attachments
     */
    public com.ascio.www._2013._02.Attachment[] getAttachments() {
        return attachments;
    }


    /**
     * Sets the attachments value for this QueueMessage.
     * 
     * @param attachments
     */
    public void setAttachments(com.ascio.www._2013._02.Attachment[] attachments) {
        this.attachments = attachments;
    }


    /**
     * Gets the errorCodes value for this QueueMessage.
     * 
     * @return errorCodes
     */
    public com.ascio.www._2013._02.ErrorCode[] getErrorCodes() {
        return errorCodes;
    }


    /**
     * Sets the errorCodes value for this QueueMessage.
     * 
     * @param errorCodes
     */
    public void setErrorCodes(com.ascio.www._2013._02.ErrorCode[] errorCodes) {
        this.errorCodes = errorCodes;
    }


    /**
     * Gets the id value for this QueueMessage.
     * 
     * @return id
     */
    public java.lang.Integer getId() {
        return id;
    }


    /**
     * Sets the id value for this QueueMessage.
     * 
     * @param id
     */
    public void setId(java.lang.Integer id) {
        this.id = id;
    }


    /**
     * Gets the message value for this QueueMessage.
     * 
     * @return message
     */
    public java.lang.String getMessage() {
        return message;
    }


    /**
     * Sets the message value for this QueueMessage.
     * 
     * @param message
     */
    public void setMessage(java.lang.String message) {
        this.message = message;
    }


    /**
     * Gets the messageType value for this QueueMessage.
     * 
     * @return messageType
     */
    public com.ascio.www._2013._02.MessageType getMessageType() {
        return messageType;
    }


    /**
     * Sets the messageType value for this QueueMessage.
     * 
     * @param messageType
     */
    public void setMessageType(com.ascio.www._2013._02.MessageType messageType) {
        this.messageType = messageType;
    }


    /**
     * Gets the objectHandle value for this QueueMessage.
     * 
     * @return objectHandle
     */
    public java.lang.String getObjectHandle() {
        return objectHandle;
    }


    /**
     * Sets the objectHandle value for this QueueMessage.
     * 
     * @param objectHandle
     */
    public void setObjectHandle(java.lang.String objectHandle) {
        this.objectHandle = objectHandle;
    }


    /**
     * Gets the objectName value for this QueueMessage.
     * 
     * @return objectName
     */
    public java.lang.String getObjectName() {
        return objectName;
    }


    /**
     * Sets the objectName value for this QueueMessage.
     * 
     * @param objectName
     */
    public void setObjectName(java.lang.String objectName) {
        this.objectName = objectName;
    }


    /**
     * Gets the objectType value for this QueueMessage.
     * 
     * @return objectType
     */
    public com.ascio.www._2013._02.ObjectType getObjectType() {
        return objectType;
    }


    /**
     * Sets the objectType value for this QueueMessage.
     * 
     * @param objectType
     */
    public void setObjectType(com.ascio.www._2013._02.ObjectType objectType) {
        this.objectType = objectType;
    }


    /**
     * Gets the orderId value for this QueueMessage.
     * 
     * @return orderId
     */
    public java.lang.String getOrderId() {
        return orderId;
    }


    /**
     * Sets the orderId value for this QueueMessage.
     * 
     * @param orderId
     */
    public void setOrderId(java.lang.String orderId) {
        this.orderId = orderId;
    }


    /**
     * Gets the orderStatus value for this QueueMessage.
     * 
     * @return orderStatus
     */
    public com.ascio.www._2013._02.OrderStatusType getOrderStatus() {
        return orderStatus;
    }


    /**
     * Sets the orderStatus value for this QueueMessage.
     * 
     * @param orderStatus
     */
    public void setOrderStatus(com.ascio.www._2013._02.OrderStatusType orderStatus) {
        this.orderStatus = orderStatus;
    }


    /**
     * Gets the orderType value for this QueueMessage.
     * 
     * @return orderType
     */
    public com.ascio.www._2013._02.OrderType getOrderType() {
        return orderType;
    }


    /**
     * Sets the orderType value for this QueueMessage.
     * 
     * @param orderType
     */
    public void setOrderType(com.ascio.www._2013._02.OrderType orderType) {
        this.orderType = orderType;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof QueueMessage)) return false;
        QueueMessage other = (QueueMessage) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.attachments==null && other.getAttachments()==null) || 
             (this.attachments!=null &&
              java.util.Arrays.equals(this.attachments, other.getAttachments()))) &&
            ((this.errorCodes==null && other.getErrorCodes()==null) || 
             (this.errorCodes!=null &&
              java.util.Arrays.equals(this.errorCodes, other.getErrorCodes()))) &&
            ((this.id==null && other.getId()==null) || 
             (this.id!=null &&
              this.id.equals(other.getId()))) &&
            ((this.message==null && other.getMessage()==null) || 
             (this.message!=null &&
              this.message.equals(other.getMessage()))) &&
            ((this.messageType==null && other.getMessageType()==null) || 
             (this.messageType!=null &&
              this.messageType.equals(other.getMessageType()))) &&
            ((this.objectHandle==null && other.getObjectHandle()==null) || 
             (this.objectHandle!=null &&
              this.objectHandle.equals(other.getObjectHandle()))) &&
            ((this.objectName==null && other.getObjectName()==null) || 
             (this.objectName!=null &&
              this.objectName.equals(other.getObjectName()))) &&
            ((this.objectType==null && other.getObjectType()==null) || 
             (this.objectType!=null &&
              this.objectType.equals(other.getObjectType()))) &&
            ((this.orderId==null && other.getOrderId()==null) || 
             (this.orderId!=null &&
              this.orderId.equals(other.getOrderId()))) &&
            ((this.orderStatus==null && other.getOrderStatus()==null) || 
             (this.orderStatus!=null &&
              this.orderStatus.equals(other.getOrderStatus()))) &&
            ((this.orderType==null && other.getOrderType()==null) || 
             (this.orderType!=null &&
              this.orderType.equals(other.getOrderType())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getAttachments() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getAttachments());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getAttachments(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getErrorCodes() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getErrorCodes());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getErrorCodes(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getId() != null) {
            _hashCode += getId().hashCode();
        }
        if (getMessage() != null) {
            _hashCode += getMessage().hashCode();
        }
        if (getMessageType() != null) {
            _hashCode += getMessageType().hashCode();
        }
        if (getObjectHandle() != null) {
            _hashCode += getObjectHandle().hashCode();
        }
        if (getObjectName() != null) {
            _hashCode += getObjectName().hashCode();
        }
        if (getObjectType() != null) {
            _hashCode += getObjectType().hashCode();
        }
        if (getOrderId() != null) {
            _hashCode += getOrderId().hashCode();
        }
        if (getOrderStatus() != null) {
            _hashCode += getOrderStatus().hashCode();
        }
        if (getOrderType() != null) {
            _hashCode += getOrderType().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(QueueMessage.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "QueueMessage"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attachments");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Attachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Attachment"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Attachment"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("errorCodes");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "ErrorCodes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "ErrorCode"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "ErrorCode"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("id");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("message");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Message"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("messageType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "MessageType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "MessageType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("objectHandle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "ObjectHandle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("objectName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "ObjectName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("objectType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "ObjectType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "ObjectType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "OrderId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "OrderStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "OrderStatusType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "OrderType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "OrderType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
