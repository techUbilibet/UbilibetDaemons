/**
 * OrderStatusType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ascio.www._2013._02;

@SuppressWarnings({ "unused", "serial", "unchecked", "rawtypes" })
public class OrderStatusType implements java.io.Serializable {
    private java.lang.String _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    protected OrderStatusType(java.lang.String value) {
        _value_ = value;
        _table_.put(_value_,this);
    }

    public static final java.lang.String _NotSet = "NotSet";
    public static final java.lang.String _Received = "Received";
    public static final java.lang.String _Validated = "Validated";
    public static final java.lang.String _Invalid = "Invalid";
    public static final java.lang.String _PendingDocumentation = "PendingDocumentation";
    public static final java.lang.String _PendingEndUserAction = "PendingEndUserAction";
    public static final java.lang.String _DocumentationReceived = "DocumentationReceived";
    public static final java.lang.String _DocumentationApproved = "DocumentationApproved";
    public static final java.lang.String _DocumentationNotApproved = "DocumentationNotApproved";
    public static final java.lang.String _PendingNicProcessing = "PendingNicProcessing";
    public static final java.lang.String _PendingNicDocumentApproval = "PendingNicDocumentApproval";
    public static final java.lang.String _PendingPostProcessing = "PendingPostProcessing";
    public static final java.lang.String _PendingInternalProcessing = "PendingInternalProcessing";
    public static final java.lang.String _Completed = "Completed";
    public static final java.lang.String _Failed = "Failed";
    public static final java.lang.String _AuthenticationFailed = "AuthenticationFailed";
    public static final OrderStatusType NotSet = new OrderStatusType(_NotSet);
    public static final OrderStatusType Received = new OrderStatusType(_Received);
    public static final OrderStatusType Validated = new OrderStatusType(_Validated);
    public static final OrderStatusType Invalid = new OrderStatusType(_Invalid);
    public static final OrderStatusType PendingDocumentation = new OrderStatusType(_PendingDocumentation);
    public static final OrderStatusType PendingEndUserAction = new OrderStatusType(_PendingEndUserAction);
    public static final OrderStatusType DocumentationReceived = new OrderStatusType(_DocumentationReceived);
    public static final OrderStatusType DocumentationApproved = new OrderStatusType(_DocumentationApproved);
    public static final OrderStatusType DocumentationNotApproved = new OrderStatusType(_DocumentationNotApproved);
    public static final OrderStatusType PendingNicProcessing = new OrderStatusType(_PendingNicProcessing);
    public static final OrderStatusType PendingNicDocumentApproval = new OrderStatusType(_PendingNicDocumentApproval);
    public static final OrderStatusType PendingPostProcessing = new OrderStatusType(_PendingPostProcessing);
    public static final OrderStatusType PendingInternalProcessing = new OrderStatusType(_PendingInternalProcessing);
    public static final OrderStatusType Completed = new OrderStatusType(_Completed);
    public static final OrderStatusType Failed = new OrderStatusType(_Failed);
    public static final OrderStatusType AuthenticationFailed = new OrderStatusType(_AuthenticationFailed);
    public java.lang.String getValue() { return _value_;}
    public static OrderStatusType fromValue(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        OrderStatusType enumeration = (OrderStatusType)
            _table_.get(value);
        if (enumeration==null) throw new java.lang.IllegalArgumentException();
        return enumeration;
    }
    public static OrderStatusType fromString(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        return fromValue(value);
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_;}
    public java.lang.Object readResolve() throws java.io.ObjectStreamException { return fromValue(_value_);}
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumSerializer(
            _javaType, _xmlType);
    }
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumDeserializer(
            _javaType, _xmlType);
    }
    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(OrderStatusType.class);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "OrderStatusType"));
    }
    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

}
