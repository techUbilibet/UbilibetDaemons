/**
 * NameWatchInfo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ascio.www._2013._02;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class NameWatchInfo  implements java.io.Serializable {
    private java.lang.String handle;

    private java.lang.String status;

    private java.util.Calendar created;

    private java.util.Calendar expires;

    private java.lang.String name;

    private com.ascio.www._2013._02.NotificationFrequencyType notificationFrequency;

    private java.lang.Integer tier;

    private java.lang.String emailNotification1;

    private java.lang.String emailNotification2;

    private java.lang.String emailNotification3;

    private java.lang.String emailNotification4;

    private java.lang.String emailNotification5;

    private com.ascio.www._2013._02.Registrant owner;

    private com.ascio.www._2013._02.Contact reseller;

    /* List of labels) */
    private java.lang.String[] labels;

    public NameWatchInfo() {
    }

    public NameWatchInfo(
           java.lang.String handle,
           java.lang.String status,
           java.util.Calendar created,
           java.util.Calendar expires,
           java.lang.String name,
           com.ascio.www._2013._02.NotificationFrequencyType notificationFrequency,
           java.lang.Integer tier,
           java.lang.String emailNotification1,
           java.lang.String emailNotification2,
           java.lang.String emailNotification3,
           java.lang.String emailNotification4,
           java.lang.String emailNotification5,
           com.ascio.www._2013._02.Registrant owner,
           com.ascio.www._2013._02.Contact reseller,
           java.lang.String[] labels) {
           this.handle = handle;
           this.status = status;
           this.created = created;
           this.expires = expires;
           this.name = name;
           this.notificationFrequency = notificationFrequency;
           this.tier = tier;
           this.emailNotification1 = emailNotification1;
           this.emailNotification2 = emailNotification2;
           this.emailNotification3 = emailNotification3;
           this.emailNotification4 = emailNotification4;
           this.emailNotification5 = emailNotification5;
           this.owner = owner;
           this.reseller = reseller;
           this.labels = labels;
    }


    /**
     * Gets the handle value for this NameWatchInfo.
     * 
     * @return handle
     */
    public java.lang.String getHandle() {
        return handle;
    }


    /**
     * Sets the handle value for this NameWatchInfo.
     * 
     * @param handle
     */
    public void setHandle(java.lang.String handle) {
        this.handle = handle;
    }


    /**
     * Gets the status value for this NameWatchInfo.
     * 
     * @return status
     */
    public java.lang.String getStatus() {
        return status;
    }


    /**
     * Sets the status value for this NameWatchInfo.
     * 
     * @param status
     */
    public void setStatus(java.lang.String status) {
        this.status = status;
    }


    /**
     * Gets the created value for this NameWatchInfo.
     * 
     * @return created
     */
    public java.util.Calendar getCreated() {
        return created;
    }


    /**
     * Sets the created value for this NameWatchInfo.
     * 
     * @param created
     */
    public void setCreated(java.util.Calendar created) {
        this.created = created;
    }


    /**
     * Gets the expires value for this NameWatchInfo.
     * 
     * @return expires
     */
    public java.util.Calendar getExpires() {
        return expires;
    }


    /**
     * Sets the expires value for this NameWatchInfo.
     * 
     * @param expires
     */
    public void setExpires(java.util.Calendar expires) {
        this.expires = expires;
    }


    /**
     * Gets the name value for this NameWatchInfo.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this NameWatchInfo.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the notificationFrequency value for this NameWatchInfo.
     * 
     * @return notificationFrequency
     */
    public com.ascio.www._2013._02.NotificationFrequencyType getNotificationFrequency() {
        return notificationFrequency;
    }


    /**
     * Sets the notificationFrequency value for this NameWatchInfo.
     * 
     * @param notificationFrequency
     */
    public void setNotificationFrequency(com.ascio.www._2013._02.NotificationFrequencyType notificationFrequency) {
        this.notificationFrequency = notificationFrequency;
    }


    /**
     * Gets the tier value for this NameWatchInfo.
     * 
     * @return tier
     */
    public java.lang.Integer getTier() {
        return tier;
    }


    /**
     * Sets the tier value for this NameWatchInfo.
     * 
     * @param tier
     */
    public void setTier(java.lang.Integer tier) {
        this.tier = tier;
    }


    /**
     * Gets the emailNotification1 value for this NameWatchInfo.
     * 
     * @return emailNotification1
     */
    public java.lang.String getEmailNotification1() {
        return emailNotification1;
    }


    /**
     * Sets the emailNotification1 value for this NameWatchInfo.
     * 
     * @param emailNotification1
     */
    public void setEmailNotification1(java.lang.String emailNotification1) {
        this.emailNotification1 = emailNotification1;
    }


    /**
     * Gets the emailNotification2 value for this NameWatchInfo.
     * 
     * @return emailNotification2
     */
    public java.lang.String getEmailNotification2() {
        return emailNotification2;
    }


    /**
     * Sets the emailNotification2 value for this NameWatchInfo.
     * 
     * @param emailNotification2
     */
    public void setEmailNotification2(java.lang.String emailNotification2) {
        this.emailNotification2 = emailNotification2;
    }


    /**
     * Gets the emailNotification3 value for this NameWatchInfo.
     * 
     * @return emailNotification3
     */
    public java.lang.String getEmailNotification3() {
        return emailNotification3;
    }


    /**
     * Sets the emailNotification3 value for this NameWatchInfo.
     * 
     * @param emailNotification3
     */
    public void setEmailNotification3(java.lang.String emailNotification3) {
        this.emailNotification3 = emailNotification3;
    }


    /**
     * Gets the emailNotification4 value for this NameWatchInfo.
     * 
     * @return emailNotification4
     */
    public java.lang.String getEmailNotification4() {
        return emailNotification4;
    }


    /**
     * Sets the emailNotification4 value for this NameWatchInfo.
     * 
     * @param emailNotification4
     */
    public void setEmailNotification4(java.lang.String emailNotification4) {
        this.emailNotification4 = emailNotification4;
    }


    /**
     * Gets the emailNotification5 value for this NameWatchInfo.
     * 
     * @return emailNotification5
     */
    public java.lang.String getEmailNotification5() {
        return emailNotification5;
    }


    /**
     * Sets the emailNotification5 value for this NameWatchInfo.
     * 
     * @param emailNotification5
     */
    public void setEmailNotification5(java.lang.String emailNotification5) {
        this.emailNotification5 = emailNotification5;
    }


    /**
     * Gets the owner value for this NameWatchInfo.
     * 
     * @return owner
     */
    public com.ascio.www._2013._02.Registrant getOwner() {
        return owner;
    }


    /**
     * Sets the owner value for this NameWatchInfo.
     * 
     * @param owner
     */
    public void setOwner(com.ascio.www._2013._02.Registrant owner) {
        this.owner = owner;
    }


    /**
     * Gets the reseller value for this NameWatchInfo.
     * 
     * @return reseller
     */
    public com.ascio.www._2013._02.Contact getReseller() {
        return reseller;
    }


    /**
     * Sets the reseller value for this NameWatchInfo.
     * 
     * @param reseller
     */
    public void setReseller(com.ascio.www._2013._02.Contact reseller) {
        this.reseller = reseller;
    }


    /**
     * Gets the labels value for this NameWatchInfo.
     * 
     * @return labels   * List of labels)
     */
    public java.lang.String[] getLabels() {
        return labels;
    }


    /**
     * Sets the labels value for this NameWatchInfo.
     * 
     * @param labels   * List of labels)
     */
    public void setLabels(java.lang.String[] labels) {
        this.labels = labels;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof NameWatchInfo)) return false;
        NameWatchInfo other = (NameWatchInfo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.handle==null && other.getHandle()==null) || 
             (this.handle!=null &&
              this.handle.equals(other.getHandle()))) &&
            ((this.status==null && other.getStatus()==null) || 
             (this.status!=null &&
              this.status.equals(other.getStatus()))) &&
            ((this.created==null && other.getCreated()==null) || 
             (this.created!=null &&
              this.created.equals(other.getCreated()))) &&
            ((this.expires==null && other.getExpires()==null) || 
             (this.expires!=null &&
              this.expires.equals(other.getExpires()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.notificationFrequency==null && other.getNotificationFrequency()==null) || 
             (this.notificationFrequency!=null &&
              this.notificationFrequency.equals(other.getNotificationFrequency()))) &&
            ((this.tier==null && other.getTier()==null) || 
             (this.tier!=null &&
              this.tier.equals(other.getTier()))) &&
            ((this.emailNotification1==null && other.getEmailNotification1()==null) || 
             (this.emailNotification1!=null &&
              this.emailNotification1.equals(other.getEmailNotification1()))) &&
            ((this.emailNotification2==null && other.getEmailNotification2()==null) || 
             (this.emailNotification2!=null &&
              this.emailNotification2.equals(other.getEmailNotification2()))) &&
            ((this.emailNotification3==null && other.getEmailNotification3()==null) || 
             (this.emailNotification3!=null &&
              this.emailNotification3.equals(other.getEmailNotification3()))) &&
            ((this.emailNotification4==null && other.getEmailNotification4()==null) || 
             (this.emailNotification4!=null &&
              this.emailNotification4.equals(other.getEmailNotification4()))) &&
            ((this.emailNotification5==null && other.getEmailNotification5()==null) || 
             (this.emailNotification5!=null &&
              this.emailNotification5.equals(other.getEmailNotification5()))) &&
            ((this.owner==null && other.getOwner()==null) || 
             (this.owner!=null &&
              this.owner.equals(other.getOwner()))) &&
            ((this.reseller==null && other.getReseller()==null) || 
             (this.reseller!=null &&
              this.reseller.equals(other.getReseller()))) &&
            ((this.labels==null && other.getLabels()==null) || 
             (this.labels!=null &&
              java.util.Arrays.equals(this.labels, other.getLabels())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getHandle() != null) {
            _hashCode += getHandle().hashCode();
        }
        if (getStatus() != null) {
            _hashCode += getStatus().hashCode();
        }
        if (getCreated() != null) {
            _hashCode += getCreated().hashCode();
        }
        if (getExpires() != null) {
            _hashCode += getExpires().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getNotificationFrequency() != null) {
            _hashCode += getNotificationFrequency().hashCode();
        }
        if (getTier() != null) {
            _hashCode += getTier().hashCode();
        }
        if (getEmailNotification1() != null) {
            _hashCode += getEmailNotification1().hashCode();
        }
        if (getEmailNotification2() != null) {
            _hashCode += getEmailNotification2().hashCode();
        }
        if (getEmailNotification3() != null) {
            _hashCode += getEmailNotification3().hashCode();
        }
        if (getEmailNotification4() != null) {
            _hashCode += getEmailNotification4().hashCode();
        }
        if (getEmailNotification5() != null) {
            _hashCode += getEmailNotification5().hashCode();
        }
        if (getOwner() != null) {
            _hashCode += getOwner().hashCode();
        }
        if (getReseller() != null) {
            _hashCode += getReseller().hashCode();
        }
        if (getLabels() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getLabels());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getLabels(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(NameWatchInfo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "NameWatchInfo"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("handle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Handle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("status");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Status"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("created");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Created"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("expires");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Expires"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("notificationFrequency");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "NotificationFrequency"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "NotificationFrequencyType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tier");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Tier"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("emailNotification1");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "EmailNotification1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("emailNotification2");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "EmailNotification2"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("emailNotification3");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "EmailNotification3"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("emailNotification4");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "EmailNotification4"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("emailNotification5");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "EmailNotification5"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("owner");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Owner"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Registrant"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("reseller");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Reseller"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Contact"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("labels");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Labels"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://schemas.microsoft.com/2003/10/Serialization/Arrays", "string"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
