/**
 * AbstractOrderRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ascio.www._2013._02;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public abstract class AbstractOrderRequest  implements java.io.Serializable {
    private com.ascio.www._2013._02.OrderType type;

    private java.lang.Integer period;

    private java.lang.String transactionComment;

    private java.lang.String comments;

    private java.lang.String documentation;

    private java.lang.String options;

    public AbstractOrderRequest() {
    }

    public AbstractOrderRequest(
           com.ascio.www._2013._02.OrderType type,
           java.lang.Integer period,
           java.lang.String transactionComment,
           java.lang.String comments,
           java.lang.String documentation,
           java.lang.String options) {
           this.type = type;
           this.period = period;
           this.transactionComment = transactionComment;
           this.comments = comments;
           this.documentation = documentation;
           this.options = options;
    }


    /**
     * Gets the type value for this AbstractOrderRequest.
     * 
     * @return type
     */
    public com.ascio.www._2013._02.OrderType getType() {
        return type;
    }


    /**
     * Sets the type value for this AbstractOrderRequest.
     * 
     * @param type
     */
    public void setType(com.ascio.www._2013._02.OrderType type) {
        this.type = type;
    }


    /**
     * Gets the period value for this AbstractOrderRequest.
     * 
     * @return period
     */
    public java.lang.Integer getPeriod() {
        return period;
    }


    /**
     * Sets the period value for this AbstractOrderRequest.
     * 
     * @param period
     */
    public void setPeriod(java.lang.Integer period) {
        this.period = period;
    }


    /**
     * Gets the transactionComment value for this AbstractOrderRequest.
     * 
     * @return transactionComment
     */
    public java.lang.String getTransactionComment() {
        return transactionComment;
    }


    /**
     * Sets the transactionComment value for this AbstractOrderRequest.
     * 
     * @param transactionComment
     */
    public void setTransactionComment(java.lang.String transactionComment) {
        this.transactionComment = transactionComment;
    }


    /**
     * Gets the comments value for this AbstractOrderRequest.
     * 
     * @return comments
     */
    public java.lang.String getComments() {
        return comments;
    }


    /**
     * Sets the comments value for this AbstractOrderRequest.
     * 
     * @param comments
     */
    public void setComments(java.lang.String comments) {
        this.comments = comments;
    }


    /**
     * Gets the documentation value for this AbstractOrderRequest.
     * 
     * @return documentation
     */
    public java.lang.String getDocumentation() {
        return documentation;
    }


    /**
     * Sets the documentation value for this AbstractOrderRequest.
     * 
     * @param documentation
     */
    public void setDocumentation(java.lang.String documentation) {
        this.documentation = documentation;
    }


    /**
     * Gets the options value for this AbstractOrderRequest.
     * 
     * @return options
     */
    public java.lang.String getOptions() {
        return options;
    }


    /**
     * Sets the options value for this AbstractOrderRequest.
     * 
     * @param options
     */
    public void setOptions(java.lang.String options) {
        this.options = options;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof AbstractOrderRequest)) return false;
        AbstractOrderRequest other = (AbstractOrderRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.type==null && other.getType()==null) || 
             (this.type!=null &&
              this.type.equals(other.getType()))) &&
            ((this.period==null && other.getPeriod()==null) || 
             (this.period!=null &&
              this.period.equals(other.getPeriod()))) &&
            ((this.transactionComment==null && other.getTransactionComment()==null) || 
             (this.transactionComment!=null &&
              this.transactionComment.equals(other.getTransactionComment()))) &&
            ((this.comments==null && other.getComments()==null) || 
             (this.comments!=null &&
              this.comments.equals(other.getComments()))) &&
            ((this.documentation==null && other.getDocumentation()==null) || 
             (this.documentation!=null &&
              this.documentation.equals(other.getDocumentation()))) &&
            ((this.options==null && other.getOptions()==null) || 
             (this.options!=null &&
              this.options.equals(other.getOptions())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getType() != null) {
            _hashCode += getType().hashCode();
        }
        if (getPeriod() != null) {
            _hashCode += getPeriod().hashCode();
        }
        if (getTransactionComment() != null) {
            _hashCode += getTransactionComment().hashCode();
        }
        if (getComments() != null) {
            _hashCode += getComments().hashCode();
        }
        if (getDocumentation() != null) {
            _hashCode += getDocumentation().hashCode();
        }
        if (getOptions() != null) {
            _hashCode += getOptions().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(AbstractOrderRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "AbstractOrderRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("type");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Type"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "OrderType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("period");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Period"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transactionComment");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "TransactionComment"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("comments");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Comments"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("documentation");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Documentation"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("options");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Options"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
