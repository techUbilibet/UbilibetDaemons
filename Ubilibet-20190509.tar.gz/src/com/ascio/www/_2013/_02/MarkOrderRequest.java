/**
 * MarkOrderRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ascio.www._2013._02;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class MarkOrderRequest  extends com.ascio.www._2013._02.AbstractOrderRequest  implements java.io.Serializable {
    private com.ascio.www._2013._02.AbstractMark mark;

    private com.ascio.www._2013._02.MarkOrderDocument[] documents;

    public MarkOrderRequest() {
    }

    public MarkOrderRequest(
           com.ascio.www._2013._02.OrderType type,
           java.lang.Integer period,
           java.lang.String transactionComment,
           java.lang.String comments,
           java.lang.String documentation,
           java.lang.String options,
           com.ascio.www._2013._02.AbstractMark mark,
           com.ascio.www._2013._02.MarkOrderDocument[] documents) {
        super(
            type,
            period,
            transactionComment,
            comments,
            documentation,
            options);
        this.mark = mark;
        this.documents = documents;
    }


    /**
     * Gets the mark value for this MarkOrderRequest.
     * 
     * @return mark
     */
    public com.ascio.www._2013._02.AbstractMark getMark() {
        return mark;
    }


    /**
     * Sets the mark value for this MarkOrderRequest.
     * 
     * @param mark
     */
    public void setMark(com.ascio.www._2013._02.AbstractMark mark) {
        this.mark = mark;
    }


    /**
     * Gets the documents value for this MarkOrderRequest.
     * 
     * @return documents
     */
    public com.ascio.www._2013._02.MarkOrderDocument[] getDocuments() {
        return documents;
    }


    /**
     * Sets the documents value for this MarkOrderRequest.
     * 
     * @param documents
     */
    public void setDocuments(com.ascio.www._2013._02.MarkOrderDocument[] documents) {
        this.documents = documents;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof MarkOrderRequest)) return false;
        MarkOrderRequest other = (MarkOrderRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.mark==null && other.getMark()==null) || 
             (this.mark!=null &&
              this.mark.equals(other.getMark()))) &&
            ((this.documents==null && other.getDocuments()==null) || 
             (this.documents!=null &&
              java.util.Arrays.equals(this.documents, other.getDocuments())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getMark() != null) {
            _hashCode += getMark().hashCode();
        }
        if (getDocuments() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDocuments());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDocuments(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(MarkOrderRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "MarkOrderRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("mark");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Mark"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "AbstractMark"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("documents");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Documents"));
// 2013-09-13 Aquest error continúa viu si actualitzeu les classes WS vigileu si encara hi és.
//        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "MarkOrderDocument"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "MarkOrderDocument"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
