/**
 * NameWatch.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ascio.www._2013._02;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class NameWatch  implements java.io.Serializable {
    private java.lang.String handle;

    private java.lang.String name;

    private com.ascio.www._2013._02.NotificationFrequencyType notificationFrequency;

    private java.lang.Integer tier;

    private java.lang.String emailNotification1;

    private java.lang.String emailNotification2;

    private java.lang.String emailNotification3;

    private java.lang.String emailNotification4;

    private java.lang.String emailNotification5;

    private com.ascio.www._2013._02.Registrant owner;

    private com.ascio.www._2013._02.Contact reseller;

    public NameWatch() {
    }

    public NameWatch(
           java.lang.String handle,
           java.lang.String name,
           com.ascio.www._2013._02.NotificationFrequencyType notificationFrequency,
           java.lang.Integer tier,
           java.lang.String emailNotification1,
           java.lang.String emailNotification2,
           java.lang.String emailNotification3,
           java.lang.String emailNotification4,
           java.lang.String emailNotification5,
           com.ascio.www._2013._02.Registrant owner,
           com.ascio.www._2013._02.Contact reseller) {
           this.handle = handle;
           this.name = name;
           this.notificationFrequency = notificationFrequency;
           this.tier = tier;
           this.emailNotification1 = emailNotification1;
           this.emailNotification2 = emailNotification2;
           this.emailNotification3 = emailNotification3;
           this.emailNotification4 = emailNotification4;
           this.emailNotification5 = emailNotification5;
           this.owner = owner;
           this.reseller = reseller;
    }


    /**
     * Gets the handle value for this NameWatch.
     * 
     * @return handle
     */
    public java.lang.String getHandle() {
        return handle;
    }


    /**
     * Sets the handle value for this NameWatch.
     * 
     * @param handle
     */
    public void setHandle(java.lang.String handle) {
        this.handle = handle;
    }


    /**
     * Gets the name value for this NameWatch.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this NameWatch.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the notificationFrequency value for this NameWatch.
     * 
     * @return notificationFrequency
     */
    public com.ascio.www._2013._02.NotificationFrequencyType getNotificationFrequency() {
        return notificationFrequency;
    }


    /**
     * Sets the notificationFrequency value for this NameWatch.
     * 
     * @param notificationFrequency
     */
    public void setNotificationFrequency(com.ascio.www._2013._02.NotificationFrequencyType notificationFrequency) {
        this.notificationFrequency = notificationFrequency;
    }


    /**
     * Gets the tier value for this NameWatch.
     * 
     * @return tier
     */
    public java.lang.Integer getTier() {
        return tier;
    }


    /**
     * Sets the tier value for this NameWatch.
     * 
     * @param tier
     */
    public void setTier(java.lang.Integer tier) {
        this.tier = tier;
    }


    /**
     * Gets the emailNotification1 value for this NameWatch.
     * 
     * @return emailNotification1
     */
    public java.lang.String getEmailNotification1() {
        return emailNotification1;
    }


    /**
     * Sets the emailNotification1 value for this NameWatch.
     * 
     * @param emailNotification1
     */
    public void setEmailNotification1(java.lang.String emailNotification1) {
        this.emailNotification1 = emailNotification1;
    }


    /**
     * Gets the emailNotification2 value for this NameWatch.
     * 
     * @return emailNotification2
     */
    public java.lang.String getEmailNotification2() {
        return emailNotification2;
    }


    /**
     * Sets the emailNotification2 value for this NameWatch.
     * 
     * @param emailNotification2
     */
    public void setEmailNotification2(java.lang.String emailNotification2) {
        this.emailNotification2 = emailNotification2;
    }


    /**
     * Gets the emailNotification3 value for this NameWatch.
     * 
     * @return emailNotification3
     */
    public java.lang.String getEmailNotification3() {
        return emailNotification3;
    }


    /**
     * Sets the emailNotification3 value for this NameWatch.
     * 
     * @param emailNotification3
     */
    public void setEmailNotification3(java.lang.String emailNotification3) {
        this.emailNotification3 = emailNotification3;
    }


    /**
     * Gets the emailNotification4 value for this NameWatch.
     * 
     * @return emailNotification4
     */
    public java.lang.String getEmailNotification4() {
        return emailNotification4;
    }


    /**
     * Sets the emailNotification4 value for this NameWatch.
     * 
     * @param emailNotification4
     */
    public void setEmailNotification4(java.lang.String emailNotification4) {
        this.emailNotification4 = emailNotification4;
    }


    /**
     * Gets the emailNotification5 value for this NameWatch.
     * 
     * @return emailNotification5
     */
    public java.lang.String getEmailNotification5() {
        return emailNotification5;
    }


    /**
     * Sets the emailNotification5 value for this NameWatch.
     * 
     * @param emailNotification5
     */
    public void setEmailNotification5(java.lang.String emailNotification5) {
        this.emailNotification5 = emailNotification5;
    }


    /**
     * Gets the owner value for this NameWatch.
     * 
     * @return owner
     */
    public com.ascio.www._2013._02.Registrant getOwner() {
        return owner;
    }


    /**
     * Sets the owner value for this NameWatch.
     * 
     * @param owner
     */
    public void setOwner(com.ascio.www._2013._02.Registrant owner) {
        this.owner = owner;
    }


    /**
     * Gets the reseller value for this NameWatch.
     * 
     * @return reseller
     */
    public com.ascio.www._2013._02.Contact getReseller() {
        return reseller;
    }


    /**
     * Sets the reseller value for this NameWatch.
     * 
     * @param reseller
     */
    public void setReseller(com.ascio.www._2013._02.Contact reseller) {
        this.reseller = reseller;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof NameWatch)) return false;
        NameWatch other = (NameWatch) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.handle==null && other.getHandle()==null) || 
             (this.handle!=null &&
              this.handle.equals(other.getHandle()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.notificationFrequency==null && other.getNotificationFrequency()==null) || 
             (this.notificationFrequency!=null &&
              this.notificationFrequency.equals(other.getNotificationFrequency()))) &&
            ((this.tier==null && other.getTier()==null) || 
             (this.tier!=null &&
              this.tier.equals(other.getTier()))) &&
            ((this.emailNotification1==null && other.getEmailNotification1()==null) || 
             (this.emailNotification1!=null &&
              this.emailNotification1.equals(other.getEmailNotification1()))) &&
            ((this.emailNotification2==null && other.getEmailNotification2()==null) || 
             (this.emailNotification2!=null &&
              this.emailNotification2.equals(other.getEmailNotification2()))) &&
            ((this.emailNotification3==null && other.getEmailNotification3()==null) || 
             (this.emailNotification3!=null &&
              this.emailNotification3.equals(other.getEmailNotification3()))) &&
            ((this.emailNotification4==null && other.getEmailNotification4()==null) || 
             (this.emailNotification4!=null &&
              this.emailNotification4.equals(other.getEmailNotification4()))) &&
            ((this.emailNotification5==null && other.getEmailNotification5()==null) || 
             (this.emailNotification5!=null &&
              this.emailNotification5.equals(other.getEmailNotification5()))) &&
            ((this.owner==null && other.getOwner()==null) || 
             (this.owner!=null &&
              this.owner.equals(other.getOwner()))) &&
            ((this.reseller==null && other.getReseller()==null) || 
             (this.reseller!=null &&
              this.reseller.equals(other.getReseller())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getHandle() != null) {
            _hashCode += getHandle().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getNotificationFrequency() != null) {
            _hashCode += getNotificationFrequency().hashCode();
        }
        if (getTier() != null) {
            _hashCode += getTier().hashCode();
        }
        if (getEmailNotification1() != null) {
            _hashCode += getEmailNotification1().hashCode();
        }
        if (getEmailNotification2() != null) {
            _hashCode += getEmailNotification2().hashCode();
        }
        if (getEmailNotification3() != null) {
            _hashCode += getEmailNotification3().hashCode();
        }
        if (getEmailNotification4() != null) {
            _hashCode += getEmailNotification4().hashCode();
        }
        if (getEmailNotification5() != null) {
            _hashCode += getEmailNotification5().hashCode();
        }
        if (getOwner() != null) {
            _hashCode += getOwner().hashCode();
        }
        if (getReseller() != null) {
            _hashCode += getReseller().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(NameWatch.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "NameWatch"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("handle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Handle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("notificationFrequency");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "NotificationFrequency"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "NotificationFrequencyType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tier");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Tier"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("emailNotification1");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "EmailNotification1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("emailNotification2");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "EmailNotification2"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("emailNotification3");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "EmailNotification3"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("emailNotification4");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "EmailNotification4"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("emailNotification5");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "EmailNotification5"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("owner");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Owner"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Registrant"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("reseller");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Reseller"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Contact"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
