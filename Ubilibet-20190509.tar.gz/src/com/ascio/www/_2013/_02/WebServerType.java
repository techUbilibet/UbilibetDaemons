/**
 * WebServerType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ascio.www._2013._02;

@SuppressWarnings({ "unused", "serial", "unchecked", "rawtypes" })
public class WebServerType implements java.io.Serializable {
    private java.lang.String _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    protected WebServerType(java.lang.String value) {
        _value_ = value;
        _table_.put(_value_,this);
    }

    public static final java.lang.String _ApacheSsl = "ApacheSsl";
    public static final java.lang.String _ApacheRaven = "ApacheRaven";
    public static final java.lang.String _ApacheSsleay = "ApacheSsleay";
    public static final java.lang.String _C2net = "C2net";
    public static final java.lang.String _IbmHttp = "IbmHttp";
    public static final java.lang.String _Iplanet = "Iplanet";
    public static final java.lang.String _DominoGo4625 = "DominoGo4625";
    public static final java.lang.String _DominoGo4626 = "DominoGo4626";
    public static final java.lang.String _Domino = "Domino";
    public static final java.lang.String _Iis4 = "Iis4";
    public static final java.lang.String _Iis5 = "Iis5";
    public static final java.lang.String _Netscape = "Netscape";
    public static final java.lang.String _Zeusv3 = "Zeusv3";
    public static final java.lang.String _Other = "Other";
    public static final java.lang.String _ApacheOpenSsl = "ApacheOpenSsl";
    public static final java.lang.String _Apache2 = "Apache2";
    public static final java.lang.String _ApacheApacheSsl = "ApacheApacheSsl";
    public static final java.lang.String _CobaltSeries = "CobaltSeries";
    public static final java.lang.String _Cpanel = "Cpanel";
    public static final java.lang.String _Ensim = "Ensim";
    public static final java.lang.String _Hsphere = "Hsphere";
    public static final java.lang.String _IpSwitch = "IpSwitch";
    public static final java.lang.String _Plesk = "Plesk";
    public static final java.lang.String _Tomcat = "Tomcat";
    public static final java.lang.String _WebLogic = "WebLogic";
    public static final java.lang.String _WebSite = "WebSite";
    public static final java.lang.String _WebStar = "WebStar";
    public static final java.lang.String _Iis = "Iis";
    public static final WebServerType ApacheSsl = new WebServerType(_ApacheSsl);
    public static final WebServerType ApacheRaven = new WebServerType(_ApacheRaven);
    public static final WebServerType ApacheSsleay = new WebServerType(_ApacheSsleay);
    public static final WebServerType C2net = new WebServerType(_C2net);
    public static final WebServerType IbmHttp = new WebServerType(_IbmHttp);
    public static final WebServerType Iplanet = new WebServerType(_Iplanet);
    public static final WebServerType DominoGo4625 = new WebServerType(_DominoGo4625);
    public static final WebServerType DominoGo4626 = new WebServerType(_DominoGo4626);
    public static final WebServerType Domino = new WebServerType(_Domino);
    public static final WebServerType Iis4 = new WebServerType(_Iis4);
    public static final WebServerType Iis5 = new WebServerType(_Iis5);
    public static final WebServerType Netscape = new WebServerType(_Netscape);
    public static final WebServerType Zeusv3 = new WebServerType(_Zeusv3);
    public static final WebServerType Other = new WebServerType(_Other);
    public static final WebServerType ApacheOpenSsl = new WebServerType(_ApacheOpenSsl);
    public static final WebServerType Apache2 = new WebServerType(_Apache2);
    public static final WebServerType ApacheApacheSsl = new WebServerType(_ApacheApacheSsl);
    public static final WebServerType CobaltSeries = new WebServerType(_CobaltSeries);
    public static final WebServerType Cpanel = new WebServerType(_Cpanel);
    public static final WebServerType Ensim = new WebServerType(_Ensim);
    public static final WebServerType Hsphere = new WebServerType(_Hsphere);
    public static final WebServerType IpSwitch = new WebServerType(_IpSwitch);
    public static final WebServerType Plesk = new WebServerType(_Plesk);
    public static final WebServerType Tomcat = new WebServerType(_Tomcat);
    public static final WebServerType WebLogic = new WebServerType(_WebLogic);
    public static final WebServerType WebSite = new WebServerType(_WebSite);
    public static final WebServerType WebStar = new WebServerType(_WebStar);
    public static final WebServerType Iis = new WebServerType(_Iis);
    public java.lang.String getValue() { return _value_;}
    public static WebServerType fromValue(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        WebServerType enumeration = (WebServerType)
            _table_.get(value);
        if (enumeration==null) throw new java.lang.IllegalArgumentException();
        return enumeration;
    }
    public static WebServerType fromString(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        return fromValue(value);
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_;}
    public java.lang.Object readResolve() throws java.io.ObjectStreamException { return fromValue(_value_);}
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumSerializer(
            _javaType, _xmlType);
    }
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumDeserializer(
            _javaType, _xmlType);
    }
    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(WebServerType.class);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "WebServerType"));
    }
    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

}
