package com.ascio.www._2013._02.AscioService;


public class IAscioServiceProxy implements com.ascio.www._2013._02.AscioService.IAscioService {
  private String _endpoint = null;
  private com.ascio.www._2013._02.AscioService.IAscioService iAscioService = null;
  
  public IAscioServiceProxy() {
    _initIAscioServiceProxy();
  }
  
  public IAscioServiceProxy(String endpoint) {
    _endpoint = endpoint;
    _initIAscioServiceProxy();
  }
  
  private void _initIAscioServiceProxy() {
    try {
      iAscioService = (new com.ascio.www._2013._02.AscioService.AscioServiceLocator()).getAscioServicePort();
      if (iAscioService != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)iAscioService)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)iAscioService)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (iAscioService != null)
      ((javax.xml.rpc.Stub)iAscioService)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.ascio.www._2013._02.AscioService.IAscioService getIAscioService() {
    if (iAscioService == null)
      _initIAscioServiceProxy();
    return iAscioService;
  }
  
  public com.ascio.www._2013._02.CreateOrderResponse createOrder(com.ascio.www._2013._02.AbstractOrderRequest request) throws java.rmi.RemoteException{
    if (iAscioService == null)
      _initIAscioServiceProxy();
    return iAscioService.createOrder(request);
  }
  
  public com.ascio.www._2013._02.ValidateOrderResponse validateOrder(com.ascio.www._2013._02.AbstractOrderRequest request) throws java.rmi.RemoteException{
    if (iAscioService == null)
      _initIAscioServiceProxy();
    return iAscioService.validateOrder(request);
  }
  
  public com.ascio.www._2013._02.GetOrderResponse getOrder(com.ascio.www._2013._02.GetOrderRequest request) throws java.rmi.RemoteException{
    if (iAscioService == null)
      _initIAscioServiceProxy();
    return iAscioService.getOrder(request);
  }
  
  public com.ascio.www._2013._02.GetOrdersResponse getOrders(com.ascio.www._2013._02.GetOrdersRequest request) throws java.rmi.RemoteException{
    if (iAscioService == null)
      _initIAscioServiceProxy();
    return iAscioService.getOrders(request);
  }
  
  public com.ascio.www._2013._02.GetMarkResponse getMark(com.ascio.www._2013._02.GetMarkRequest request) throws java.rmi.RemoteException{
    if (iAscioService == null)
      _initIAscioServiceProxy();
    return iAscioService.getMark(request);
  }
  
  public com.ascio.www._2013._02.GetDefensiveResponse getDefensive(com.ascio.www._2013._02.GetDefensiveRequest request) throws java.rmi.RemoteException{
    if (iAscioService == null)
      _initIAscioServiceProxy();
    return iAscioService.getDefensive(request);
  }
  
  public com.ascio.www._2013._02.GetNameWatchResponse getNameWatch(com.ascio.www._2013._02.GetNameWatchRequest request) throws java.rmi.RemoteException{
    if (iAscioService == null)
      _initIAscioServiceProxy();
    return iAscioService.getNameWatch(request);
  }
  
  public com.ascio.www._2013._02.GetSslCertificateResponse getSslCertificate(com.ascio.www._2013._02.GetSslCertificateRequest request) throws java.rmi.RemoteException{
    if (iAscioService == null)
      _initIAscioServiceProxy();
    return iAscioService.getSslCertificate(request);
  }
  
  public com.ascio.www._2013._02.GetAutoInstallSslResponse getAutoInstallSsl(com.ascio.www._2013._02.GetAutoInstallSslRequest request) throws java.rmi.RemoteException{
    if (iAscioService == null)
      _initIAscioServiceProxy();
    return iAscioService.getAutoInstallSsl(request);
  }
  
  public com.ascio.www._2013._02.GetMessagesResponse getMessages(com.ascio.www._2013._02.GetMessagesRequest request) throws java.rmi.RemoteException{
    if (iAscioService == null)
      _initIAscioServiceProxy();
    return iAscioService.getMessages(request);
  }
  
  public com.ascio.www._2013._02.PollQueueResponse pollQueue(com.ascio.www._2013._02.PollQueueRequest request) throws java.rmi.RemoteException{
    if (iAscioService == null)
      _initIAscioServiceProxy();
    return iAscioService.pollQueue(request);
  }
  
  public com.ascio.www._2013._02.AckQueueMessageResponse ackQueueMessage(com.ascio.www._2013._02.AckQueueMessageRequest request) throws java.rmi.RemoteException{
    if (iAscioService == null)
      _initIAscioServiceProxy();
    return iAscioService.ackQueueMessage(request);
  }
  
  public com.ascio.www._2013._02.GetQueueMessageResponse getQueueMessage(com.ascio.www._2013._02.GetQueueMessageRequest request) throws java.rmi.RemoteException{
    if (iAscioService == null)
      _initIAscioServiceProxy();
    return iAscioService.getQueueMessage(request);
  }
  
  public com.ascio.www._2013._02.UploadDocumentationResponse uploadDocumentation(com.ascio.www._2013._02.UploadDocumentationRequest request) throws java.rmi.RemoteException{
    if (iAscioService == null)
      _initIAscioServiceProxy();
    return iAscioService.uploadDocumentation(request);
  }
  
  public com.ascio.www._2013._02.UploadMessageResponse uploadMessage(com.ascio.www._2013._02.UploadMessageRequest request) throws java.rmi.RemoteException{
    if (iAscioService == null)
      _initIAscioServiceProxy();
    return iAscioService.uploadMessage(request);
  }
  
  
}