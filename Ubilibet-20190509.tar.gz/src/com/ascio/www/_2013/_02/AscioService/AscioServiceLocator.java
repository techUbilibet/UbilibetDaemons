/**
 * AscioServiceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ascio.www._2013._02.AscioService;

@SuppressWarnings({ "serial", "rawtypes", "unchecked" })
public class AscioServiceLocator extends org.apache.axis.client.Service implements com.ascio.www._2013._02.AscioService.AscioService {

    public AscioServiceLocator() {
    }


    public AscioServiceLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public AscioServiceLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for AscioServicePort
    private java.lang.String AscioServicePort_address = "https://aws.ascio.com/v3/AscioService.svc";

    public java.lang.String getAscioServicePortAddress() {
        return AscioServicePort_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String AscioServicePortWSDDServiceName = "AscioServicePort";

    public java.lang.String getAscioServicePortWSDDServiceName() {
        return AscioServicePortWSDDServiceName;
    }

    public void setAscioServicePortWSDDServiceName(java.lang.String name) {
        AscioServicePortWSDDServiceName = name;
    }

    public com.ascio.www._2013._02.AscioService.IAscioService getAscioServicePort() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(AscioServicePort_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getAscioServicePort(endpoint);
    }

    public com.ascio.www._2013._02.AscioService.IAscioService getAscioServicePort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            com.ascio.www._2013._02.AscioService.AscioServiceBindingStub _stub = new com.ascio.www._2013._02.AscioService.AscioServiceBindingStub(portAddress, this);
            _stub.setPortName(getAscioServicePortWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setAscioServicePortEndpointAddress(java.lang.String address) {
        AscioServicePort_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (com.ascio.www._2013._02.AscioService.IAscioService.class.isAssignableFrom(serviceEndpointInterface)) {
                com.ascio.www._2013._02.AscioService.AscioServiceBindingStub _stub = new com.ascio.www._2013._02.AscioService.AscioServiceBindingStub(new java.net.URL(AscioServicePort_address), this);
                _stub.setPortName(getAscioServicePortWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("AscioServicePort".equals(inputPortName)) {
            return getAscioServicePort();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://www.ascio.com/2013/02/AscioService", "AscioService");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://www.ascio.com/2013/02/AscioService", "AscioServicePort"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("AscioServicePort".equals(portName)) {
            setAscioServicePortEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
