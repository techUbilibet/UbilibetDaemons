/**
 * AscioServiceBindingStub.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ascio.www._2013._02.AscioService;

@SuppressWarnings({ "unused", "rawtypes", "unchecked" })
public class AscioServiceBindingStub extends org.apache.axis.client.Stub implements com.ascio.www._2013._02.AscioService.IAscioService {
    private java.util.Vector cachedSerClasses = new java.util.Vector();
    private java.util.Vector cachedSerQNames = new java.util.Vector();
    private java.util.Vector cachedSerFactories = new java.util.Vector();
    private java.util.Vector cachedDeserFactories = new java.util.Vector();

    static org.apache.axis.description.OperationDesc [] _operations;

    static {
        _operations = new org.apache.axis.description.OperationDesc[15];
        _initOperationDesc1();
        _initOperationDesc2();
    }

    private static void _initOperationDesc1(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("CreateOrder");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2013/02/AscioService", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "AbstractOrderRequest"), com.ascio.www._2013._02.AbstractOrderRequest.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "CreateOrderResponse"));
        oper.setReturnClass(com.ascio.www._2013._02.CreateOrderResponse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02/AscioService", "CreateOrderResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[0] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("ValidateOrder");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2013/02/AscioService", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "AbstractOrderRequest"), com.ascio.www._2013._02.AbstractOrderRequest.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "ValidateOrderResponse"));
        oper.setReturnClass(com.ascio.www._2013._02.ValidateOrderResponse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02/AscioService", "ValidateOrderResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[1] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetOrder");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2013/02/AscioService", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "GetOrderRequest"), com.ascio.www._2013._02.GetOrderRequest.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "GetOrderResponse"));
        oper.setReturnClass(com.ascio.www._2013._02.GetOrderResponse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02/AscioService", "GetOrderResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[2] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetOrders");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2013/02/AscioService", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "GetOrdersRequest"), com.ascio.www._2013._02.GetOrdersRequest.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "GetOrdersResponse"));
        oper.setReturnClass(com.ascio.www._2013._02.GetOrdersResponse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02/AscioService", "GetOrdersResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[3] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetMark");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2013/02/AscioService", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "GetMarkRequest"), com.ascio.www._2013._02.GetMarkRequest.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "GetMarkResponse"));
        oper.setReturnClass(com.ascio.www._2013._02.GetMarkResponse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02/AscioService", "GetMarkResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[4] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetDefensive");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2013/02/AscioService", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "GetDefensiveRequest"), com.ascio.www._2013._02.GetDefensiveRequest.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "GetDefensiveResponse"));
        oper.setReturnClass(com.ascio.www._2013._02.GetDefensiveResponse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02/AscioService", "GetDefensiveResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[5] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetNameWatch");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2013/02/AscioService", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "GetNameWatchRequest"), com.ascio.www._2013._02.GetNameWatchRequest.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "GetNameWatchResponse"));
        oper.setReturnClass(com.ascio.www._2013._02.GetNameWatchResponse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02/AscioService", "GetNameWatchResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[6] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetSslCertificate");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2013/02/AscioService", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "GetSslCertificateRequest"), com.ascio.www._2013._02.GetSslCertificateRequest.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "GetSslCertificateResponse"));
        oper.setReturnClass(com.ascio.www._2013._02.GetSslCertificateResponse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02/AscioService", "GetSslCertificateResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[7] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetAutoInstallSsl");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2013/02/AscioService", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "GetAutoInstallSslRequest"), com.ascio.www._2013._02.GetAutoInstallSslRequest.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "GetAutoInstallSslResponse"));
        oper.setReturnClass(com.ascio.www._2013._02.GetAutoInstallSslResponse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02/AscioService", "GetAutoInstallSslResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[8] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetMessages");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2013/02/AscioService", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "GetMessagesRequest"), com.ascio.www._2013._02.GetMessagesRequest.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "GetMessagesResponse"));
        oper.setReturnClass(com.ascio.www._2013._02.GetMessagesResponse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02/AscioService", "GetMessagesResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[9] = oper;

    }

    private static void _initOperationDesc2(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("PollQueue");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2013/02/AscioService", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "PollQueueRequest"), com.ascio.www._2013._02.PollQueueRequest.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "PollQueueResponse"));
        oper.setReturnClass(com.ascio.www._2013._02.PollQueueResponse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02/AscioService", "PollQueueResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[10] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("AckQueueMessage");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2013/02/AscioService", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "AckQueueMessageRequest"), com.ascio.www._2013._02.AckQueueMessageRequest.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "AckQueueMessageResponse"));
        oper.setReturnClass(com.ascio.www._2013._02.AckQueueMessageResponse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02/AscioService", "AckQueueMessageResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[11] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetQueueMessage");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2013/02/AscioService", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "GetQueueMessageRequest"), com.ascio.www._2013._02.GetQueueMessageRequest.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "GetQueueMessageResponse"));
        oper.setReturnClass(com.ascio.www._2013._02.GetQueueMessageResponse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02/AscioService", "GetQueueMessageResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[12] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("UploadDocumentation");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2013/02/AscioService", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "UploadDocumentationRequest"), com.ascio.www._2013._02.UploadDocumentationRequest.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "UploadDocumentationResponse"));
        oper.setReturnClass(com.ascio.www._2013._02.UploadDocumentationResponse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02/AscioService", "UploadDocumentationResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[13] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("UploadMessage");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2013/02/AscioService", "request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "UploadMessageRequest"), com.ascio.www._2013._02.UploadMessageRequest.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "UploadMessageResponse"));
        oper.setReturnClass(com.ascio.www._2013._02.UploadMessageResponse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02/AscioService", "UploadMessageResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[14] = oper;

    }

    public AscioServiceBindingStub() throws org.apache.axis.AxisFault {
         this(null);
    }

    public AscioServiceBindingStub(java.net.URL endpointURL, javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
         this(service);
         super.cachedEndpoint = endpointURL;
    }

	public AscioServiceBindingStub(javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
        if (service == null) {
            super.service = new org.apache.axis.client.Service();
        } else {
            super.service = service;
        }
        ((org.apache.axis.client.Service)super.service).setTypeMappingVersion("1.2");
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
            qName = new javax.xml.namespace.QName("http://schemas.microsoft.com/2003/10/Serialization/Arrays", "ArrayOfint");
            cachedSerQNames.add(qName);
            cls = int[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int");
            qName2 = new javax.xml.namespace.QName("http://schemas.microsoft.com/2003/10/Serialization/Arrays", "int");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://schemas.microsoft.com/2003/10/Serialization/Arrays", "ArrayOfstring");
            cachedSerQNames.add(qName);
            cls = java.lang.String[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string");
            qName2 = new javax.xml.namespace.QName("http://schemas.microsoft.com/2003/10/Serialization/Arrays", "string");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", ">Extensions>KeyValue");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.ExtensionsKeyValue.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "AbstractMark");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.AbstractMark.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "AbstractOrderRequest");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.AbstractOrderRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "AbstractResponse");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.AbstractResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "AckQueueMessageRequest");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.AckQueueMessageRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "AckQueueMessageResponse");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.AckQueueMessageResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "ArrayOfAttachment");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.Attachment[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Attachment");
            qName2 = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Attachment");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "ArrayOfErrorCode");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.ErrorCode[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "ErrorCode");
            qName2 = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "ErrorCode");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "ArrayOfMarkOrderDocument");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.MarkOrderDocument[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "MarkOrderDocument");
            qName2 = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "MarkOrderDocument");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "ArrayOfMessage");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.Message[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Message");
            qName2 = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Message");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "ArrayOfObjectType");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.ObjectType[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "ObjectType");
            qName2 = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "ObjectType");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "ArrayOfOrderInfo");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.OrderInfo[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "OrderInfo");
            qName2 = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "OrderInfo");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "ArrayOfOrderStatusType");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.OrderStatusType[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "OrderStatusType");
            qName2 = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "OrderStatusType");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "ArrayOfOrderType");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.OrderType[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "OrderType");
            qName2 = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "OrderType");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Attachment");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.Attachment.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "AutoInstallSsl");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.AutoInstallSsl.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "AutoInstallSslInfo");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.AutoInstallSslInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "AutoInstallSslOrderRequest");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.AutoInstallSslOrderRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Contact");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.Contact.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "CourtValidatedMark");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.CourtValidatedMark.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "CreateOrderResponse");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.CreateOrderResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Defensive");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.Defensive.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "DefensiveInfo");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.DefensiveInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "DefensiveOrderRequest");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.DefensiveOrderRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "ErrorCode");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.ErrorCode.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Extensions");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.ExtensionsKeyValue[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", ">Extensions>KeyValue");
            qName2 = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "KeyValue");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "GetAutoInstallSslRequest");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.GetAutoInstallSslRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "GetAutoInstallSslResponse");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.GetAutoInstallSslResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "GetDefensiveRequest");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.GetDefensiveRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "GetDefensiveResponse");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.GetDefensiveResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "GetMarkRequest");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.GetMarkRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "GetMarkResponse");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.GetMarkResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "GetMessagesRequest");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.GetMessagesRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "GetMessagesResponse");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.GetMessagesResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "GetNameWatchRequest");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.GetNameWatchRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "GetNameWatchResponse");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.GetNameWatchResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "GetOrderRequest");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.GetOrderRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "GetOrderResponse");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.GetOrderResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "GetOrdersRequest");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.GetOrdersRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "GetOrdersResponse");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.GetOrdersResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "GetQueueMessageRequest");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.GetQueueMessageRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "GetQueueMessageResponse");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.GetQueueMessageResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "GetSslCertificateRequest");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.GetSslCertificateRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "GetSslCertificateResponse");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.GetSslCertificateResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "MarkInfo");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.MarkInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "MarkOrderDocType");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.MarkOrderDocType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "MarkOrderDocument");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.MarkOrderDocument.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "MarkOrderRequest");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.MarkOrderRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "MarkServiceType");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.MarkServiceType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Message");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.Message.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "MessageType");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.MessageType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "NameWatch");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.NameWatch.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "NameWatchInfo");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.NameWatchInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "NameWatchOrderRequest");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.NameWatchOrderRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "NotificationFrequencyType");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.NotificationFrequencyType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "ObjectType");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.ObjectType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "OrderInfo");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.OrderInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "OrderStatusType");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.OrderStatusType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "OrderType");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.OrderType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "PagingInfo");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.PagingInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "PollQueueRequest");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.PollQueueRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "PollQueueResponse");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.PollQueueResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "QueueMessage");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.QueueMessage.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Registrant");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.Registrant.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "SearchOrderSortType");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.SearchOrderSortType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "SslCertificate");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.SslCertificate.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "SslCertificateInfo");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.SslCertificateInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "SslCertificateOrderRequest");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.SslCertificateOrderRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Trademark");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.Trademark.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "TreatyOrStatuteMark");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.TreatyOrStatuteMark.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "UploadDocumentationRequest");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.UploadDocumentationRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "UploadDocumentationResponse");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.UploadDocumentationResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "UploadMessageRequest");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.UploadMessageRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "UploadMessageResponse");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.UploadMessageResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "ValidateOrderResponse");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.ValidateOrderResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "WebServerType");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2013._02.WebServerType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

    }

    protected org.apache.axis.client.Call createCall() throws java.rmi.RemoteException {
        try {
            org.apache.axis.client.Call _call = super._createCall();
            if (super.maintainSessionSet) {
                _call.setMaintainSession(super.maintainSession);
            }
            if (super.cachedUsername != null) {
                _call.setUsername(super.cachedUsername);
            }
            if (super.cachedPassword != null) {
                _call.setPassword(super.cachedPassword);
            }
            if (super.cachedEndpoint != null) {
                _call.setTargetEndpointAddress(super.cachedEndpoint);
            }
            if (super.cachedTimeout != null) {
                _call.setTimeout(super.cachedTimeout);
            }
            if (super.cachedPortName != null) {
                _call.setPortName(super.cachedPortName);
            }
            java.util.Enumeration keys = super.cachedProperties.keys();
            while (keys.hasMoreElements()) {
                java.lang.String key = (java.lang.String) keys.nextElement();
                _call.setProperty(key, super.cachedProperties.get(key));
            }
            // All the type mapping information is registered
            // when the first call is made.
            // The type mapping information is actually registered in
            // the TypeMappingRegistry of the service, which
            // is the reason why registration is only needed for the first call.
            synchronized (this) {
                if (firstCall()) {
                    // must set encoding style before registering serializers
                    _call.setEncodingStyle(null);
                    for (int i = 0; i < cachedSerFactories.size(); ++i) {
                        java.lang.Class cls = (java.lang.Class) cachedSerClasses.get(i);
                        javax.xml.namespace.QName qName =
                                (javax.xml.namespace.QName) cachedSerQNames.get(i);
                        java.lang.Object x = cachedSerFactories.get(i);
                        if (x instanceof Class) {
                            java.lang.Class sf = (java.lang.Class)
                                 cachedSerFactories.get(i);
                            java.lang.Class df = (java.lang.Class)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                        else if (x instanceof javax.xml.rpc.encoding.SerializerFactory) {
                            org.apache.axis.encoding.SerializerFactory sf = (org.apache.axis.encoding.SerializerFactory)
                                 cachedSerFactories.get(i);
                            org.apache.axis.encoding.DeserializerFactory df = (org.apache.axis.encoding.DeserializerFactory)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                    }
                }
            }
            return _call;
        }
        catch (java.lang.Throwable _t) {
            throw new org.apache.axis.AxisFault("Failure trying to get the Call object", _t);
        }
    }

    public com.ascio.www._2013._02.CreateOrderResponse createOrder(com.ascio.www._2013._02.AbstractOrderRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[0]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("CreateOrder");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02/AscioService", "CreateOrder"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ascio.www._2013._02.CreateOrderResponse) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ascio.www._2013._02.CreateOrderResponse) org.apache.axis.utils.JavaUtils.convert(_resp, com.ascio.www._2013._02.CreateOrderResponse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.ascio.www._2013._02.ValidateOrderResponse validateOrder(com.ascio.www._2013._02.AbstractOrderRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[1]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("ValidateOrder");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02/AscioService", "ValidateOrder"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ascio.www._2013._02.ValidateOrderResponse) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ascio.www._2013._02.ValidateOrderResponse) org.apache.axis.utils.JavaUtils.convert(_resp, com.ascio.www._2013._02.ValidateOrderResponse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.ascio.www._2013._02.GetOrderResponse getOrder(com.ascio.www._2013._02.GetOrderRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[2]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("GetOrder");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02/AscioService", "GetOrder"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ascio.www._2013._02.GetOrderResponse) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ascio.www._2013._02.GetOrderResponse) org.apache.axis.utils.JavaUtils.convert(_resp, com.ascio.www._2013._02.GetOrderResponse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.ascio.www._2013._02.GetOrdersResponse getOrders(com.ascio.www._2013._02.GetOrdersRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[3]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("GetOrders");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02/AscioService", "GetOrders"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ascio.www._2013._02.GetOrdersResponse) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ascio.www._2013._02.GetOrdersResponse) org.apache.axis.utils.JavaUtils.convert(_resp, com.ascio.www._2013._02.GetOrdersResponse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.ascio.www._2013._02.GetMarkResponse getMark(com.ascio.www._2013._02.GetMarkRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[4]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("GetMark");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02/AscioService", "GetMark"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ascio.www._2013._02.GetMarkResponse) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ascio.www._2013._02.GetMarkResponse) org.apache.axis.utils.JavaUtils.convert(_resp, com.ascio.www._2013._02.GetMarkResponse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.ascio.www._2013._02.GetDefensiveResponse getDefensive(com.ascio.www._2013._02.GetDefensiveRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[5]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("GetDefensive");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02/AscioService", "GetDefensive"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ascio.www._2013._02.GetDefensiveResponse) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ascio.www._2013._02.GetDefensiveResponse) org.apache.axis.utils.JavaUtils.convert(_resp, com.ascio.www._2013._02.GetDefensiveResponse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.ascio.www._2013._02.GetNameWatchResponse getNameWatch(com.ascio.www._2013._02.GetNameWatchRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[6]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("GetNameWatch");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02/AscioService", "GetNameWatch"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ascio.www._2013._02.GetNameWatchResponse) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ascio.www._2013._02.GetNameWatchResponse) org.apache.axis.utils.JavaUtils.convert(_resp, com.ascio.www._2013._02.GetNameWatchResponse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.ascio.www._2013._02.GetSslCertificateResponse getSslCertificate(com.ascio.www._2013._02.GetSslCertificateRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[7]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("GetSslCertificate");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02/AscioService", "GetSslCertificate"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ascio.www._2013._02.GetSslCertificateResponse) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ascio.www._2013._02.GetSslCertificateResponse) org.apache.axis.utils.JavaUtils.convert(_resp, com.ascio.www._2013._02.GetSslCertificateResponse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.ascio.www._2013._02.GetAutoInstallSslResponse getAutoInstallSsl(com.ascio.www._2013._02.GetAutoInstallSslRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[8]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("GetAutoInstallSsl");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02/AscioService", "GetAutoInstallSsl"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ascio.www._2013._02.GetAutoInstallSslResponse) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ascio.www._2013._02.GetAutoInstallSslResponse) org.apache.axis.utils.JavaUtils.convert(_resp, com.ascio.www._2013._02.GetAutoInstallSslResponse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.ascio.www._2013._02.GetMessagesResponse getMessages(com.ascio.www._2013._02.GetMessagesRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[9]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("GetMessages");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02/AscioService", "GetMessages"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ascio.www._2013._02.GetMessagesResponse) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ascio.www._2013._02.GetMessagesResponse) org.apache.axis.utils.JavaUtils.convert(_resp, com.ascio.www._2013._02.GetMessagesResponse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.ascio.www._2013._02.PollQueueResponse pollQueue(com.ascio.www._2013._02.PollQueueRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[10]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("PollQueue");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02/AscioService", "PollQueue"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ascio.www._2013._02.PollQueueResponse) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ascio.www._2013._02.PollQueueResponse) org.apache.axis.utils.JavaUtils.convert(_resp, com.ascio.www._2013._02.PollQueueResponse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.ascio.www._2013._02.AckQueueMessageResponse ackQueueMessage(com.ascio.www._2013._02.AckQueueMessageRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[11]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("AckQueueMessage");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02/AscioService", "AckQueueMessage"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ascio.www._2013._02.AckQueueMessageResponse) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ascio.www._2013._02.AckQueueMessageResponse) org.apache.axis.utils.JavaUtils.convert(_resp, com.ascio.www._2013._02.AckQueueMessageResponse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.ascio.www._2013._02.GetQueueMessageResponse getQueueMessage(com.ascio.www._2013._02.GetQueueMessageRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[12]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("GetQueueMessage");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02/AscioService", "GetQueueMessage"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ascio.www._2013._02.GetQueueMessageResponse) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ascio.www._2013._02.GetQueueMessageResponse) org.apache.axis.utils.JavaUtils.convert(_resp, com.ascio.www._2013._02.GetQueueMessageResponse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.ascio.www._2013._02.UploadDocumentationResponse uploadDocumentation(com.ascio.www._2013._02.UploadDocumentationRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[13]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("UploadDocumentation");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02/AscioService", "UploadDocumentation"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ascio.www._2013._02.UploadDocumentationResponse) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ascio.www._2013._02.UploadDocumentationResponse) org.apache.axis.utils.JavaUtils.convert(_resp, com.ascio.www._2013._02.UploadDocumentationResponse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.ascio.www._2013._02.UploadMessageResponse uploadMessage(com.ascio.www._2013._02.UploadMessageRequest request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[14]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("UploadMessage");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02/AscioService", "UploadMessage"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ascio.www._2013._02.UploadMessageResponse) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ascio.www._2013._02.UploadMessageResponse) org.apache.axis.utils.JavaUtils.convert(_resp, com.ascio.www._2013._02.UploadMessageResponse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

}
