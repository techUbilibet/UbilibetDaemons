/**
 * IAscioService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ascio.www._2013._02.AscioService;


public interface IAscioService extends java.rmi.Remote {
    public com.ascio.www._2013._02.CreateOrderResponse createOrder(com.ascio.www._2013._02.AbstractOrderRequest request) throws java.rmi.RemoteException;
    public com.ascio.www._2013._02.ValidateOrderResponse validateOrder(com.ascio.www._2013._02.AbstractOrderRequest request) throws java.rmi.RemoteException;
    public com.ascio.www._2013._02.GetOrderResponse getOrder(com.ascio.www._2013._02.GetOrderRequest request) throws java.rmi.RemoteException;
    public com.ascio.www._2013._02.GetOrdersResponse getOrders(com.ascio.www._2013._02.GetOrdersRequest request) throws java.rmi.RemoteException;
    public com.ascio.www._2013._02.GetMarkResponse getMark(com.ascio.www._2013._02.GetMarkRequest request) throws java.rmi.RemoteException;
    public com.ascio.www._2013._02.GetDefensiveResponse getDefensive(com.ascio.www._2013._02.GetDefensiveRequest request) throws java.rmi.RemoteException;
    public com.ascio.www._2013._02.GetNameWatchResponse getNameWatch(com.ascio.www._2013._02.GetNameWatchRequest request) throws java.rmi.RemoteException;
    public com.ascio.www._2013._02.GetSslCertificateResponse getSslCertificate(com.ascio.www._2013._02.GetSslCertificateRequest request) throws java.rmi.RemoteException;
    public com.ascio.www._2013._02.GetAutoInstallSslResponse getAutoInstallSsl(com.ascio.www._2013._02.GetAutoInstallSslRequest request) throws java.rmi.RemoteException;
    public com.ascio.www._2013._02.GetMessagesResponse getMessages(com.ascio.www._2013._02.GetMessagesRequest request) throws java.rmi.RemoteException;
    public com.ascio.www._2013._02.PollQueueResponse pollQueue(com.ascio.www._2013._02.PollQueueRequest request) throws java.rmi.RemoteException;
    public com.ascio.www._2013._02.AckQueueMessageResponse ackQueueMessage(com.ascio.www._2013._02.AckQueueMessageRequest request) throws java.rmi.RemoteException;
    public com.ascio.www._2013._02.GetQueueMessageResponse getQueueMessage(com.ascio.www._2013._02.GetQueueMessageRequest request) throws java.rmi.RemoteException;
    public com.ascio.www._2013._02.UploadDocumentationResponse uploadDocumentation(com.ascio.www._2013._02.UploadDocumentationRequest request) throws java.rmi.RemoteException;
    public com.ascio.www._2013._02.UploadMessageResponse uploadMessage(com.ascio.www._2013._02.UploadMessageRequest request) throws java.rmi.RemoteException;
}
