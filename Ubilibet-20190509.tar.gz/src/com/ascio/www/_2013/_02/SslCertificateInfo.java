/**
 * SslCertificateInfo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ascio.www._2013._02;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class SslCertificateInfo  implements java.io.Serializable {
    private java.lang.String handle;

    private java.lang.String status;

    private java.util.Calendar created;

    private java.util.Calendar expires;

    private java.lang.String commonName;

    private java.lang.String productCode;

    private com.ascio.www._2013._02.WebServerType webServerType;

    private java.lang.String approverEmail;

    private java.lang.String CSR;

    private java.lang.String certificate;

    private com.ascio.www._2013._02.Registrant owner;

    private com.ascio.www._2013._02.Contact admin;

    private com.ascio.www._2013._02.Contact tech;

    private java.lang.String[] sanNames;

    public SslCertificateInfo() {
    }

    public SslCertificateInfo(
           java.lang.String handle,
           java.lang.String status,
           java.util.Calendar created,
           java.util.Calendar expires,
           java.lang.String commonName,
           java.lang.String productCode,
           com.ascio.www._2013._02.WebServerType webServerType,
           java.lang.String approverEmail,
           java.lang.String CSR,
           java.lang.String certificate,
           com.ascio.www._2013._02.Registrant owner,
           com.ascio.www._2013._02.Contact admin,
           com.ascio.www._2013._02.Contact tech,
           java.lang.String[] sanNames) {
           this.handle = handle;
           this.status = status;
           this.created = created;
           this.expires = expires;
           this.commonName = commonName;
           this.productCode = productCode;
           this.webServerType = webServerType;
           this.approverEmail = approverEmail;
           this.CSR = CSR;
           this.certificate = certificate;
           this.owner = owner;
           this.admin = admin;
           this.tech = tech;
           this.sanNames = sanNames;
    }


    /**
     * Gets the handle value for this SslCertificateInfo.
     * 
     * @return handle
     */
    public java.lang.String getHandle() {
        return handle;
    }


    /**
     * Sets the handle value for this SslCertificateInfo.
     * 
     * @param handle
     */
    public void setHandle(java.lang.String handle) {
        this.handle = handle;
    }


    /**
     * Gets the status value for this SslCertificateInfo.
     * 
     * @return status
     */
    public java.lang.String getStatus() {
        return status;
    }


    /**
     * Sets the status value for this SslCertificateInfo.
     * 
     * @param status
     */
    public void setStatus(java.lang.String status) {
        this.status = status;
    }


    /**
     * Gets the created value for this SslCertificateInfo.
     * 
     * @return created
     */
    public java.util.Calendar getCreated() {
        return created;
    }


    /**
     * Sets the created value for this SslCertificateInfo.
     * 
     * @param created
     */
    public void setCreated(java.util.Calendar created) {
        this.created = created;
    }


    /**
     * Gets the expires value for this SslCertificateInfo.
     * 
     * @return expires
     */
    public java.util.Calendar getExpires() {
        return expires;
    }


    /**
     * Sets the expires value for this SslCertificateInfo.
     * 
     * @param expires
     */
    public void setExpires(java.util.Calendar expires) {
        this.expires = expires;
    }


    /**
     * Gets the commonName value for this SslCertificateInfo.
     * 
     * @return commonName
     */
    public java.lang.String getCommonName() {
        return commonName;
    }


    /**
     * Sets the commonName value for this SslCertificateInfo.
     * 
     * @param commonName
     */
    public void setCommonName(java.lang.String commonName) {
        this.commonName = commonName;
    }


    /**
     * Gets the productCode value for this SslCertificateInfo.
     * 
     * @return productCode
     */
    public java.lang.String getProductCode() {
        return productCode;
    }


    /**
     * Sets the productCode value for this SslCertificateInfo.
     * 
     * @param productCode
     */
    public void setProductCode(java.lang.String productCode) {
        this.productCode = productCode;
    }


    /**
     * Gets the webServerType value for this SslCertificateInfo.
     * 
     * @return webServerType
     */
    public com.ascio.www._2013._02.WebServerType getWebServerType() {
        return webServerType;
    }


    /**
     * Sets the webServerType value for this SslCertificateInfo.
     * 
     * @param webServerType
     */
    public void setWebServerType(com.ascio.www._2013._02.WebServerType webServerType) {
        this.webServerType = webServerType;
    }


    /**
     * Gets the approverEmail value for this SslCertificateInfo.
     * 
     * @return approverEmail
     */
    public java.lang.String getApproverEmail() {
        return approverEmail;
    }


    /**
     * Sets the approverEmail value for this SslCertificateInfo.
     * 
     * @param approverEmail
     */
    public void setApproverEmail(java.lang.String approverEmail) {
        this.approverEmail = approverEmail;
    }


    /**
     * Gets the CSR value for this SslCertificateInfo.
     * 
     * @return CSR
     */
    public java.lang.String getCSR() {
        return CSR;
    }


    /**
     * Sets the CSR value for this SslCertificateInfo.
     * 
     * @param CSR
     */
    public void setCSR(java.lang.String CSR) {
        this.CSR = CSR;
    }


    /**
     * Gets the certificate value for this SslCertificateInfo.
     * 
     * @return certificate
     */
    public java.lang.String getCertificate() {
        return certificate;
    }


    /**
     * Sets the certificate value for this SslCertificateInfo.
     * 
     * @param certificate
     */
    public void setCertificate(java.lang.String certificate) {
        this.certificate = certificate;
    }


    /**
     * Gets the owner value for this SslCertificateInfo.
     * 
     * @return owner
     */
    public com.ascio.www._2013._02.Registrant getOwner() {
        return owner;
    }


    /**
     * Sets the owner value for this SslCertificateInfo.
     * 
     * @param owner
     */
    public void setOwner(com.ascio.www._2013._02.Registrant owner) {
        this.owner = owner;
    }


    /**
     * Gets the admin value for this SslCertificateInfo.
     * 
     * @return admin
     */
    public com.ascio.www._2013._02.Contact getAdmin() {
        return admin;
    }


    /**
     * Sets the admin value for this SslCertificateInfo.
     * 
     * @param admin
     */
    public void setAdmin(com.ascio.www._2013._02.Contact admin) {
        this.admin = admin;
    }


    /**
     * Gets the tech value for this SslCertificateInfo.
     * 
     * @return tech
     */
    public com.ascio.www._2013._02.Contact getTech() {
        return tech;
    }


    /**
     * Sets the tech value for this SslCertificateInfo.
     * 
     * @param tech
     */
    public void setTech(com.ascio.www._2013._02.Contact tech) {
        this.tech = tech;
    }


    /**
     * Gets the sanNames value for this SslCertificateInfo.
     * 
     * @return sanNames
     */
    public java.lang.String[] getSanNames() {
        return sanNames;
    }


    /**
     * Sets the sanNames value for this SslCertificateInfo.
     * 
     * @param sanNames
     */
    public void setSanNames(java.lang.String[] sanNames) {
        this.sanNames = sanNames;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof SslCertificateInfo)) return false;
        SslCertificateInfo other = (SslCertificateInfo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.handle==null && other.getHandle()==null) || 
             (this.handle!=null &&
              this.handle.equals(other.getHandle()))) &&
            ((this.status==null && other.getStatus()==null) || 
             (this.status!=null &&
              this.status.equals(other.getStatus()))) &&
            ((this.created==null && other.getCreated()==null) || 
             (this.created!=null &&
              this.created.equals(other.getCreated()))) &&
            ((this.expires==null && other.getExpires()==null) || 
             (this.expires!=null &&
              this.expires.equals(other.getExpires()))) &&
            ((this.commonName==null && other.getCommonName()==null) || 
             (this.commonName!=null &&
              this.commonName.equals(other.getCommonName()))) &&
            ((this.productCode==null && other.getProductCode()==null) || 
             (this.productCode!=null &&
              this.productCode.equals(other.getProductCode()))) &&
            ((this.webServerType==null && other.getWebServerType()==null) || 
             (this.webServerType!=null &&
              this.webServerType.equals(other.getWebServerType()))) &&
            ((this.approverEmail==null && other.getApproverEmail()==null) || 
             (this.approverEmail!=null &&
              this.approverEmail.equals(other.getApproverEmail()))) &&
            ((this.CSR==null && other.getCSR()==null) || 
             (this.CSR!=null &&
              this.CSR.equals(other.getCSR()))) &&
            ((this.certificate==null && other.getCertificate()==null) || 
             (this.certificate!=null &&
              this.certificate.equals(other.getCertificate()))) &&
            ((this.owner==null && other.getOwner()==null) || 
             (this.owner!=null &&
              this.owner.equals(other.getOwner()))) &&
            ((this.admin==null && other.getAdmin()==null) || 
             (this.admin!=null &&
              this.admin.equals(other.getAdmin()))) &&
            ((this.tech==null && other.getTech()==null) || 
             (this.tech!=null &&
              this.tech.equals(other.getTech()))) &&
            ((this.sanNames==null && other.getSanNames()==null) || 
             (this.sanNames!=null &&
              java.util.Arrays.equals(this.sanNames, other.getSanNames())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getHandle() != null) {
            _hashCode += getHandle().hashCode();
        }
        if (getStatus() != null) {
            _hashCode += getStatus().hashCode();
        }
        if (getCreated() != null) {
            _hashCode += getCreated().hashCode();
        }
        if (getExpires() != null) {
            _hashCode += getExpires().hashCode();
        }
        if (getCommonName() != null) {
            _hashCode += getCommonName().hashCode();
        }
        if (getProductCode() != null) {
            _hashCode += getProductCode().hashCode();
        }
        if (getWebServerType() != null) {
            _hashCode += getWebServerType().hashCode();
        }
        if (getApproverEmail() != null) {
            _hashCode += getApproverEmail().hashCode();
        }
        if (getCSR() != null) {
            _hashCode += getCSR().hashCode();
        }
        if (getCertificate() != null) {
            _hashCode += getCertificate().hashCode();
        }
        if (getOwner() != null) {
            _hashCode += getOwner().hashCode();
        }
        if (getAdmin() != null) {
            _hashCode += getAdmin().hashCode();
        }
        if (getTech() != null) {
            _hashCode += getTech().hashCode();
        }
        if (getSanNames() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getSanNames());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getSanNames(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(SslCertificateInfo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "SslCertificateInfo"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("handle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Handle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("status");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Status"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("created");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Created"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("expires");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Expires"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("commonName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "CommonName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("productCode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "ProductCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("webServerType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "WebServerType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "WebServerType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("approverEmail");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "ApproverEmail"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CSR");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "CSR"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("certificate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Certificate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("owner");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Owner"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Registrant"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("admin");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Admin"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Contact"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tech");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Tech"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Contact"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sanNames");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "SanNames"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://schemas.microsoft.com/2003/10/Serialization/Arrays", "string"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
