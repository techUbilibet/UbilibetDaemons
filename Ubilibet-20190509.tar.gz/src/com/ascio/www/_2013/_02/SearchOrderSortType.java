/**
 * SearchOrderSortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ascio.www._2013._02;

@SuppressWarnings({ "unused", "serial", "unchecked", "rawtypes" })
public class SearchOrderSortType implements java.io.Serializable {
    private java.lang.String _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    protected SearchOrderSortType(java.lang.String value) {
        _value_ = value;
        _table_.put(_value_,this);
    }

    public static final java.lang.String _CreatedAsc = "CreatedAsc";
    public static final java.lang.String _CreatedDesc = "CreatedDesc";
    public static final java.lang.String _OrderIdAsc = "OrderIdAsc";
    public static final java.lang.String _OrderIdDesc = "OrderIdDesc";
    public static final java.lang.String _ObjectNameAsc = "ObjectNameAsc";
    public static final java.lang.String _ObjectNameDesc = "ObjectNameDesc";
    public static final SearchOrderSortType CreatedAsc = new SearchOrderSortType(_CreatedAsc);
    public static final SearchOrderSortType CreatedDesc = new SearchOrderSortType(_CreatedDesc);
    public static final SearchOrderSortType OrderIdAsc = new SearchOrderSortType(_OrderIdAsc);
    public static final SearchOrderSortType OrderIdDesc = new SearchOrderSortType(_OrderIdDesc);
    public static final SearchOrderSortType ObjectNameAsc = new SearchOrderSortType(_ObjectNameAsc);
    public static final SearchOrderSortType ObjectNameDesc = new SearchOrderSortType(_ObjectNameDesc);
    public java.lang.String getValue() { return _value_;}
    public static SearchOrderSortType fromValue(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        SearchOrderSortType enumeration = (SearchOrderSortType)
            _table_.get(value);
        if (enumeration==null) throw new java.lang.IllegalArgumentException();
        return enumeration;
    }
    public static SearchOrderSortType fromString(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        return fromValue(value);
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_;}
    public java.lang.Object readResolve() throws java.io.ObjectStreamException { return fromValue(_value_);}
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumSerializer(
            _javaType, _xmlType);
    }
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumDeserializer(
            _javaType, _xmlType);
    }
    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(SearchOrderSortType.class);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "SearchOrderSortType"));
    }
    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

}
