/**
 * GetOrdersRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ascio.www._2013._02;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class GetOrdersRequest  implements java.io.Serializable {
    private java.lang.String transactionComment;

    private java.lang.String comments;

    private java.lang.String objectName;

    private java.util.Calendar fromDate;

    private java.util.Calendar toDate;

    private com.ascio.www._2013._02.OrderStatusType[] orderStatusTypes;

    private com.ascio.www._2013._02.OrderType[] orderTypes;

    private com.ascio.www._2013._02.ObjectType[] objectTypes;

    private com.ascio.www._2013._02.SearchOrderSortType orderSort;

    private com.ascio.www._2013._02.PagingInfo pageInfo;

    public GetOrdersRequest() {
    }

    public GetOrdersRequest(
           java.lang.String transactionComment,
           java.lang.String comments,
           java.lang.String objectName,
           java.util.Calendar fromDate,
           java.util.Calendar toDate,
           com.ascio.www._2013._02.OrderStatusType[] orderStatusTypes,
           com.ascio.www._2013._02.OrderType[] orderTypes,
           com.ascio.www._2013._02.ObjectType[] objectTypes,
           com.ascio.www._2013._02.SearchOrderSortType orderSort,
           com.ascio.www._2013._02.PagingInfo pageInfo) {
           this.transactionComment = transactionComment;
           this.comments = comments;
           this.objectName = objectName;
           this.fromDate = fromDate;
           this.toDate = toDate;
           this.orderStatusTypes = orderStatusTypes;
           this.orderTypes = orderTypes;
           this.objectTypes = objectTypes;
           this.orderSort = orderSort;
           this.pageInfo = pageInfo;
    }


    /**
     * Gets the transactionComment value for this GetOrdersRequest.
     * 
     * @return transactionComment
     */
    public java.lang.String getTransactionComment() {
        return transactionComment;
    }


    /**
     * Sets the transactionComment value for this GetOrdersRequest.
     * 
     * @param transactionComment
     */
    public void setTransactionComment(java.lang.String transactionComment) {
        this.transactionComment = transactionComment;
    }


    /**
     * Gets the comments value for this GetOrdersRequest.
     * 
     * @return comments
     */
    public java.lang.String getComments() {
        return comments;
    }


    /**
     * Sets the comments value for this GetOrdersRequest.
     * 
     * @param comments
     */
    public void setComments(java.lang.String comments) {
        this.comments = comments;
    }


    /**
     * Gets the objectName value for this GetOrdersRequest.
     * 
     * @return objectName
     */
    public java.lang.String getObjectName() {
        return objectName;
    }


    /**
     * Sets the objectName value for this GetOrdersRequest.
     * 
     * @param objectName
     */
    public void setObjectName(java.lang.String objectName) {
        this.objectName = objectName;
    }


    /**
     * Gets the fromDate value for this GetOrdersRequest.
     * 
     * @return fromDate
     */
    public java.util.Calendar getFromDate() {
        return fromDate;
    }


    /**
     * Sets the fromDate value for this GetOrdersRequest.
     * 
     * @param fromDate
     */
    public void setFromDate(java.util.Calendar fromDate) {
        this.fromDate = fromDate;
    }


    /**
     * Gets the toDate value for this GetOrdersRequest.
     * 
     * @return toDate
     */
    public java.util.Calendar getToDate() {
        return toDate;
    }


    /**
     * Sets the toDate value for this GetOrdersRequest.
     * 
     * @param toDate
     */
    public void setToDate(java.util.Calendar toDate) {
        this.toDate = toDate;
    }


    /**
     * Gets the orderStatusTypes value for this GetOrdersRequest.
     * 
     * @return orderStatusTypes
     */
    public com.ascio.www._2013._02.OrderStatusType[] getOrderStatusTypes() {
        return orderStatusTypes;
    }


    /**
     * Sets the orderStatusTypes value for this GetOrdersRequest.
     * 
     * @param orderStatusTypes
     */
    public void setOrderStatusTypes(com.ascio.www._2013._02.OrderStatusType[] orderStatusTypes) {
        this.orderStatusTypes = orderStatusTypes;
    }


    /**
     * Gets the orderTypes value for this GetOrdersRequest.
     * 
     * @return orderTypes
     */
    public com.ascio.www._2013._02.OrderType[] getOrderTypes() {
        return orderTypes;
    }


    /**
     * Sets the orderTypes value for this GetOrdersRequest.
     * 
     * @param orderTypes
     */
    public void setOrderTypes(com.ascio.www._2013._02.OrderType[] orderTypes) {
        this.orderTypes = orderTypes;
    }


    /**
     * Gets the objectTypes value for this GetOrdersRequest.
     * 
     * @return objectTypes
     */
    public com.ascio.www._2013._02.ObjectType[] getObjectTypes() {
        return objectTypes;
    }


    /**
     * Sets the objectTypes value for this GetOrdersRequest.
     * 
     * @param objectTypes
     */
    public void setObjectTypes(com.ascio.www._2013._02.ObjectType[] objectTypes) {
        this.objectTypes = objectTypes;
    }


    /**
     * Gets the orderSort value for this GetOrdersRequest.
     * 
     * @return orderSort
     */
    public com.ascio.www._2013._02.SearchOrderSortType getOrderSort() {
        return orderSort;
    }


    /**
     * Sets the orderSort value for this GetOrdersRequest.
     * 
     * @param orderSort
     */
    public void setOrderSort(com.ascio.www._2013._02.SearchOrderSortType orderSort) {
        this.orderSort = orderSort;
    }


    /**
     * Gets the pageInfo value for this GetOrdersRequest.
     * 
     * @return pageInfo
     */
    public com.ascio.www._2013._02.PagingInfo getPageInfo() {
        return pageInfo;
    }


    /**
     * Sets the pageInfo value for this GetOrdersRequest.
     * 
     * @param pageInfo
     */
    public void setPageInfo(com.ascio.www._2013._02.PagingInfo pageInfo) {
        this.pageInfo = pageInfo;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof GetOrdersRequest)) return false;
        GetOrdersRequest other = (GetOrdersRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.transactionComment==null && other.getTransactionComment()==null) || 
             (this.transactionComment!=null &&
              this.transactionComment.equals(other.getTransactionComment()))) &&
            ((this.comments==null && other.getComments()==null) || 
             (this.comments!=null &&
              this.comments.equals(other.getComments()))) &&
            ((this.objectName==null && other.getObjectName()==null) || 
             (this.objectName!=null &&
              this.objectName.equals(other.getObjectName()))) &&
            ((this.fromDate==null && other.getFromDate()==null) || 
             (this.fromDate!=null &&
              this.fromDate.equals(other.getFromDate()))) &&
            ((this.toDate==null && other.getToDate()==null) || 
             (this.toDate!=null &&
              this.toDate.equals(other.getToDate()))) &&
            ((this.orderStatusTypes==null && other.getOrderStatusTypes()==null) || 
             (this.orderStatusTypes!=null &&
              java.util.Arrays.equals(this.orderStatusTypes, other.getOrderStatusTypes()))) &&
            ((this.orderTypes==null && other.getOrderTypes()==null) || 
             (this.orderTypes!=null &&
              java.util.Arrays.equals(this.orderTypes, other.getOrderTypes()))) &&
            ((this.objectTypes==null && other.getObjectTypes()==null) || 
             (this.objectTypes!=null &&
              java.util.Arrays.equals(this.objectTypes, other.getObjectTypes()))) &&
            ((this.orderSort==null && other.getOrderSort()==null) || 
             (this.orderSort!=null &&
              this.orderSort.equals(other.getOrderSort()))) &&
            ((this.pageInfo==null && other.getPageInfo()==null) || 
             (this.pageInfo!=null &&
              this.pageInfo.equals(other.getPageInfo())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getTransactionComment() != null) {
            _hashCode += getTransactionComment().hashCode();
        }
        if (getComments() != null) {
            _hashCode += getComments().hashCode();
        }
        if (getObjectName() != null) {
            _hashCode += getObjectName().hashCode();
        }
        if (getFromDate() != null) {
            _hashCode += getFromDate().hashCode();
        }
        if (getToDate() != null) {
            _hashCode += getToDate().hashCode();
        }
        if (getOrderStatusTypes() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getOrderStatusTypes());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getOrderStatusTypes(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getOrderTypes() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getOrderTypes());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getOrderTypes(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getObjectTypes() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getObjectTypes());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getObjectTypes(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getOrderSort() != null) {
            _hashCode += getOrderSort().hashCode();
        }
        if (getPageInfo() != null) {
            _hashCode += getPageInfo().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(GetOrdersRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "GetOrdersRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transactionComment");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "TransactionComment"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("comments");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Comments"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("objectName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "ObjectName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fromDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "FromDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("toDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "ToDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderStatusTypes");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "OrderStatusTypes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "OrderStatusType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "OrderStatusType"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderTypes");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "OrderTypes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "OrderType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "OrderType"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("objectTypes");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "ObjectTypes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "ObjectType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "ObjectType"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderSort");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "OrderSort"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "SearchOrderSortType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("pageInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "PageInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "PagingInfo"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
