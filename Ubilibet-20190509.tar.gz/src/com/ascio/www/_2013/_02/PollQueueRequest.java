/**
 * PollQueueRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ascio.www._2013._02;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class PollQueueRequest  implements java.io.Serializable {
    private com.ascio.www._2013._02.MessageType messageType;

    private com.ascio.www._2013._02.ObjectType objectType;

    public PollQueueRequest() {
    }

    public PollQueueRequest(
           com.ascio.www._2013._02.MessageType messageType,
           com.ascio.www._2013._02.ObjectType objectType) {
           this.messageType = messageType;
           this.objectType = objectType;
    }


    /**
     * Gets the messageType value for this PollQueueRequest.
     * 
     * @return messageType
     */
    public com.ascio.www._2013._02.MessageType getMessageType() {
        return messageType;
    }


    /**
     * Sets the messageType value for this PollQueueRequest.
     * 
     * @param messageType
     */
    public void setMessageType(com.ascio.www._2013._02.MessageType messageType) {
        this.messageType = messageType;
    }


    /**
     * Gets the objectType value for this PollQueueRequest.
     * 
     * @return objectType
     */
    public com.ascio.www._2013._02.ObjectType getObjectType() {
        return objectType;
    }


    /**
     * Sets the objectType value for this PollQueueRequest.
     * 
     * @param objectType
     */
    public void setObjectType(com.ascio.www._2013._02.ObjectType objectType) {
        this.objectType = objectType;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof PollQueueRequest)) return false;
        PollQueueRequest other = (PollQueueRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.messageType==null && other.getMessageType()==null) || 
             (this.messageType!=null &&
              this.messageType.equals(other.getMessageType()))) &&
            ((this.objectType==null && other.getObjectType()==null) || 
             (this.objectType!=null &&
              this.objectType.equals(other.getObjectType())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getMessageType() != null) {
            _hashCode += getMessageType().hashCode();
        }
        if (getObjectType() != null) {
            _hashCode += getObjectType().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(PollQueueRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "PollQueueRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("messageType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "MessageType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "MessageType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("objectType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "ObjectType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "ObjectType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
