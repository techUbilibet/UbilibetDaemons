/**
 * AbstractMark.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ascio.www._2013._02;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public abstract class AbstractMark  implements java.io.Serializable {
    /* Ascio Handle of the mark object */
    private java.lang.String handle;

    /* Name of the mark */
    private java.lang.String markName;

    private java.lang.String markId;

    private java.lang.String authInfo;

    private com.ascio.www._2013._02.MarkServiceType serviceType;

    /* Exact description of the goods and services for which a registered
     * trademark is protected */
    private java.lang.String goodsAndServicesDescription;

    /* List of domain names without its TLD extension) */
    private java.lang.String[] labels;

    private java.lang.String claimEmailNotification1;

    private java.lang.String claimEmailNotification2;

    private java.lang.String claimEmailNotification3;

    private java.lang.String claimEmailNotification4;

    private java.lang.String claimEmailNotification5;

    private com.ascio.www._2013._02.NotificationFrequencyType notificationFrequency;

    /* Mark Holder */
    private com.ascio.www._2013._02.Registrant owner;

    /* Mark Reseller */
    private com.ascio.www._2013._02.Contact reseller;

    private com.ascio.www._2013._02.ExtensionsKeyValue[] extensions;

    public AbstractMark() {
    }

    public AbstractMark(
           java.lang.String handle,
           java.lang.String markName,
           java.lang.String markId,
           java.lang.String authInfo,
           com.ascio.www._2013._02.MarkServiceType serviceType,
           java.lang.String goodsAndServicesDescription,
           java.lang.String[] labels,
           java.lang.String claimEmailNotification1,
           java.lang.String claimEmailNotification2,
           java.lang.String claimEmailNotification3,
           java.lang.String claimEmailNotification4,
           java.lang.String claimEmailNotification5,
           com.ascio.www._2013._02.NotificationFrequencyType notificationFrequency,
           com.ascio.www._2013._02.Registrant owner,
           com.ascio.www._2013._02.Contact reseller,
           com.ascio.www._2013._02.ExtensionsKeyValue[] extensions) {
           this.handle = handle;
           this.markName = markName;
           this.markId = markId;
           this.authInfo = authInfo;
           this.serviceType = serviceType;
           this.goodsAndServicesDescription = goodsAndServicesDescription;
           this.labels = labels;
           this.claimEmailNotification1 = claimEmailNotification1;
           this.claimEmailNotification2 = claimEmailNotification2;
           this.claimEmailNotification3 = claimEmailNotification3;
           this.claimEmailNotification4 = claimEmailNotification4;
           this.claimEmailNotification5 = claimEmailNotification5;
           this.notificationFrequency = notificationFrequency;
           this.owner = owner;
           this.reseller = reseller;
           this.extensions = extensions;
    }


    /**
     * Gets the handle value for this AbstractMark.
     * 
     * @return handle   * Ascio Handle of the mark object
     */
    public java.lang.String getHandle() {
        return handle;
    }


    /**
     * Sets the handle value for this AbstractMark.
     * 
     * @param handle   * Ascio Handle of the mark object
     */
    public void setHandle(java.lang.String handle) {
        this.handle = handle;
    }


    /**
     * Gets the markName value for this AbstractMark.
     * 
     * @return markName   * Name of the mark
     */
    public java.lang.String getMarkName() {
        return markName;
    }


    /**
     * Sets the markName value for this AbstractMark.
     * 
     * @param markName   * Name of the mark
     */
    public void setMarkName(java.lang.String markName) {
        this.markName = markName;
    }


    /**
     * Gets the markId value for this AbstractMark.
     * 
     * @return markId
     */
    public java.lang.String getMarkId() {
        return markId;
    }


    /**
     * Sets the markId value for this AbstractMark.
     * 
     * @param markId
     */
    public void setMarkId(java.lang.String markId) {
        this.markId = markId;
    }


    /**
     * Gets the authInfo value for this AbstractMark.
     * 
     * @return authInfo
     */
    public java.lang.String getAuthInfo() {
        return authInfo;
    }


    /**
     * Sets the authInfo value for this AbstractMark.
     * 
     * @param authInfo
     */
    public void setAuthInfo(java.lang.String authInfo) {
        this.authInfo = authInfo;
    }


    /**
     * Gets the serviceType value for this AbstractMark.
     * 
     * @return serviceType
     */
    public com.ascio.www._2013._02.MarkServiceType getServiceType() {
        return serviceType;
    }


    /**
     * Sets the serviceType value for this AbstractMark.
     * 
     * @param serviceType
     */
    public void setServiceType(com.ascio.www._2013._02.MarkServiceType serviceType) {
        this.serviceType = serviceType;
    }


    /**
     * Gets the goodsAndServicesDescription value for this AbstractMark.
     * 
     * @return goodsAndServicesDescription   * Exact description of the goods and services for which a registered
     * trademark is protected
     */
    public java.lang.String getGoodsAndServicesDescription() {
        return goodsAndServicesDescription;
    }


    /**
     * Sets the goodsAndServicesDescription value for this AbstractMark.
     * 
     * @param goodsAndServicesDescription   * Exact description of the goods and services for which a registered
     * trademark is protected
     */
    public void setGoodsAndServicesDescription(java.lang.String goodsAndServicesDescription) {
        this.goodsAndServicesDescription = goodsAndServicesDescription;
    }


    /**
     * Gets the labels value for this AbstractMark.
     * 
     * @return labels   * List of domain names without its TLD extension)
     */
    public java.lang.String[] getLabels() {
        return labels;
    }


    /**
     * Sets the labels value for this AbstractMark.
     * 
     * @param labels   * List of domain names without its TLD extension)
     */
    public void setLabels(java.lang.String[] labels) {
        this.labels = labels;
    }


    /**
     * Gets the claimEmailNotification1 value for this AbstractMark.
     * 
     * @return claimEmailNotification1
     */
    public java.lang.String getClaimEmailNotification1() {
        return claimEmailNotification1;
    }


    /**
     * Sets the claimEmailNotification1 value for this AbstractMark.
     * 
     * @param claimEmailNotification1
     */
    public void setClaimEmailNotification1(java.lang.String claimEmailNotification1) {
        this.claimEmailNotification1 = claimEmailNotification1;
    }


    /**
     * Gets the claimEmailNotification2 value for this AbstractMark.
     * 
     * @return claimEmailNotification2
     */
    public java.lang.String getClaimEmailNotification2() {
        return claimEmailNotification2;
    }


    /**
     * Sets the claimEmailNotification2 value for this AbstractMark.
     * 
     * @param claimEmailNotification2
     */
    public void setClaimEmailNotification2(java.lang.String claimEmailNotification2) {
        this.claimEmailNotification2 = claimEmailNotification2;
    }


    /**
     * Gets the claimEmailNotification3 value for this AbstractMark.
     * 
     * @return claimEmailNotification3
     */
    public java.lang.String getClaimEmailNotification3() {
        return claimEmailNotification3;
    }


    /**
     * Sets the claimEmailNotification3 value for this AbstractMark.
     * 
     * @param claimEmailNotification3
     */
    public void setClaimEmailNotification3(java.lang.String claimEmailNotification3) {
        this.claimEmailNotification3 = claimEmailNotification3;
    }


    /**
     * Gets the claimEmailNotification4 value for this AbstractMark.
     * 
     * @return claimEmailNotification4
     */
    public java.lang.String getClaimEmailNotification4() {
        return claimEmailNotification4;
    }


    /**
     * Sets the claimEmailNotification4 value for this AbstractMark.
     * 
     * @param claimEmailNotification4
     */
    public void setClaimEmailNotification4(java.lang.String claimEmailNotification4) {
        this.claimEmailNotification4 = claimEmailNotification4;
    }


    /**
     * Gets the claimEmailNotification5 value for this AbstractMark.
     * 
     * @return claimEmailNotification5
     */
    public java.lang.String getClaimEmailNotification5() {
        return claimEmailNotification5;
    }


    /**
     * Sets the claimEmailNotification5 value for this AbstractMark.
     * 
     * @param claimEmailNotification5
     */
    public void setClaimEmailNotification5(java.lang.String claimEmailNotification5) {
        this.claimEmailNotification5 = claimEmailNotification5;
    }


    /**
     * Gets the notificationFrequency value for this AbstractMark.
     * 
     * @return notificationFrequency
     */
    public com.ascio.www._2013._02.NotificationFrequencyType getNotificationFrequency() {
        return notificationFrequency;
    }


    /**
     * Sets the notificationFrequency value for this AbstractMark.
     * 
     * @param notificationFrequency
     */
    public void setNotificationFrequency(com.ascio.www._2013._02.NotificationFrequencyType notificationFrequency) {
        this.notificationFrequency = notificationFrequency;
    }


    /**
     * Gets the owner value for this AbstractMark.
     * 
     * @return owner   * Mark Holder
     */
    public com.ascio.www._2013._02.Registrant getOwner() {
        return owner;
    }


    /**
     * Sets the owner value for this AbstractMark.
     * 
     * @param owner   * Mark Holder
     */
    public void setOwner(com.ascio.www._2013._02.Registrant owner) {
        this.owner = owner;
    }


    /**
     * Gets the reseller value for this AbstractMark.
     * 
     * @return reseller   * Mark Reseller
     */
    public com.ascio.www._2013._02.Contact getReseller() {
        return reseller;
    }


    /**
     * Sets the reseller value for this AbstractMark.
     * 
     * @param reseller   * Mark Reseller
     */
    public void setReseller(com.ascio.www._2013._02.Contact reseller) {
        this.reseller = reseller;
    }


    /**
     * Gets the extensions value for this AbstractMark.
     * 
     * @return extensions
     */
    public com.ascio.www._2013._02.ExtensionsKeyValue[] getExtensions() {
        return extensions;
    }


    /**
     * Sets the extensions value for this AbstractMark.
     * 
     * @param extensions
     */
    public void setExtensions(com.ascio.www._2013._02.ExtensionsKeyValue[] extensions) {
        this.extensions = extensions;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof AbstractMark)) return false;
        AbstractMark other = (AbstractMark) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.handle==null && other.getHandle()==null) || 
             (this.handle!=null &&
              this.handle.equals(other.getHandle()))) &&
            ((this.markName==null && other.getMarkName()==null) || 
             (this.markName!=null &&
              this.markName.equals(other.getMarkName()))) &&
            ((this.markId==null && other.getMarkId()==null) || 
             (this.markId!=null &&
              this.markId.equals(other.getMarkId()))) &&
            ((this.authInfo==null && other.getAuthInfo()==null) || 
             (this.authInfo!=null &&
              this.authInfo.equals(other.getAuthInfo()))) &&
            ((this.serviceType==null && other.getServiceType()==null) || 
             (this.serviceType!=null &&
              this.serviceType.equals(other.getServiceType()))) &&
            ((this.goodsAndServicesDescription==null && other.getGoodsAndServicesDescription()==null) || 
             (this.goodsAndServicesDescription!=null &&
              this.goodsAndServicesDescription.equals(other.getGoodsAndServicesDescription()))) &&
            ((this.labels==null && other.getLabels()==null) || 
             (this.labels!=null &&
              java.util.Arrays.equals(this.labels, other.getLabels()))) &&
            ((this.claimEmailNotification1==null && other.getClaimEmailNotification1()==null) || 
             (this.claimEmailNotification1!=null &&
              this.claimEmailNotification1.equals(other.getClaimEmailNotification1()))) &&
            ((this.claimEmailNotification2==null && other.getClaimEmailNotification2()==null) || 
             (this.claimEmailNotification2!=null &&
              this.claimEmailNotification2.equals(other.getClaimEmailNotification2()))) &&
            ((this.claimEmailNotification3==null && other.getClaimEmailNotification3()==null) || 
             (this.claimEmailNotification3!=null &&
              this.claimEmailNotification3.equals(other.getClaimEmailNotification3()))) &&
            ((this.claimEmailNotification4==null && other.getClaimEmailNotification4()==null) || 
             (this.claimEmailNotification4!=null &&
              this.claimEmailNotification4.equals(other.getClaimEmailNotification4()))) &&
            ((this.claimEmailNotification5==null && other.getClaimEmailNotification5()==null) || 
             (this.claimEmailNotification5!=null &&
              this.claimEmailNotification5.equals(other.getClaimEmailNotification5()))) &&
            ((this.notificationFrequency==null && other.getNotificationFrequency()==null) || 
             (this.notificationFrequency!=null &&
              this.notificationFrequency.equals(other.getNotificationFrequency()))) &&
            ((this.owner==null && other.getOwner()==null) || 
             (this.owner!=null &&
              this.owner.equals(other.getOwner()))) &&
            ((this.reseller==null && other.getReseller()==null) || 
             (this.reseller!=null &&
              this.reseller.equals(other.getReseller()))) &&
            ((this.extensions==null && other.getExtensions()==null) || 
             (this.extensions!=null &&
              java.util.Arrays.equals(this.extensions, other.getExtensions())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getHandle() != null) {
            _hashCode += getHandle().hashCode();
        }
        if (getMarkName() != null) {
            _hashCode += getMarkName().hashCode();
        }
        if (getMarkId() != null) {
            _hashCode += getMarkId().hashCode();
        }
        if (getAuthInfo() != null) {
            _hashCode += getAuthInfo().hashCode();
        }
        if (getServiceType() != null) {
            _hashCode += getServiceType().hashCode();
        }
        if (getGoodsAndServicesDescription() != null) {
            _hashCode += getGoodsAndServicesDescription().hashCode();
        }
        if (getLabels() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getLabels());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getLabels(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getClaimEmailNotification1() != null) {
            _hashCode += getClaimEmailNotification1().hashCode();
        }
        if (getClaimEmailNotification2() != null) {
            _hashCode += getClaimEmailNotification2().hashCode();
        }
        if (getClaimEmailNotification3() != null) {
            _hashCode += getClaimEmailNotification3().hashCode();
        }
        if (getClaimEmailNotification4() != null) {
            _hashCode += getClaimEmailNotification4().hashCode();
        }
        if (getClaimEmailNotification5() != null) {
            _hashCode += getClaimEmailNotification5().hashCode();
        }
        if (getNotificationFrequency() != null) {
            _hashCode += getNotificationFrequency().hashCode();
        }
        if (getOwner() != null) {
            _hashCode += getOwner().hashCode();
        }
        if (getReseller() != null) {
            _hashCode += getReseller().hashCode();
        }
        if (getExtensions() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getExtensions());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getExtensions(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(AbstractMark.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "AbstractMark"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("handle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Handle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("markName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "MarkName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("markId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "MarkId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("authInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "AuthInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("serviceType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "ServiceType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "MarkServiceType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("goodsAndServicesDescription");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "GoodsAndServicesDescription"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("labels");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Labels"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://schemas.microsoft.com/2003/10/Serialization/Arrays", "string"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("claimEmailNotification1");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "ClaimEmailNotification1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("claimEmailNotification2");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "ClaimEmailNotification2"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("claimEmailNotification3");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "ClaimEmailNotification3"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("claimEmailNotification4");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "ClaimEmailNotification4"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("claimEmailNotification5");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "ClaimEmailNotification5"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("notificationFrequency");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "NotificationFrequency"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "NotificationFrequencyType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("owner");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Owner"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Registrant"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("reseller");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Reseller"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Contact"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("extensions");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Extensions"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", ">Extensions>KeyValue"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "KeyValue"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
	public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
