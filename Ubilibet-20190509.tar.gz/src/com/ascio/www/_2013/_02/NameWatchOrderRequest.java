/**
 * NameWatchOrderRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ascio.www._2013._02;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class NameWatchOrderRequest  extends com.ascio.www._2013._02.AbstractOrderRequest  implements java.io.Serializable {
    private com.ascio.www._2013._02.NameWatch nameWatch;

    public NameWatchOrderRequest() {
    }

    public NameWatchOrderRequest(
           com.ascio.www._2013._02.OrderType type,
           java.lang.Integer period,
           java.lang.String transactionComment,
           java.lang.String comments,
           java.lang.String documentation,
           java.lang.String options,
           com.ascio.www._2013._02.NameWatch nameWatch) {
        super(
            type,
            period,
            transactionComment,
            comments,
            documentation,
            options);
        this.nameWatch = nameWatch;
    }


    /**
     * Gets the nameWatch value for this NameWatchOrderRequest.
     * 
     * @return nameWatch
     */
    public com.ascio.www._2013._02.NameWatch getNameWatch() {
        return nameWatch;
    }


    /**
     * Sets the nameWatch value for this NameWatchOrderRequest.
     * 
     * @param nameWatch
     */
    public void setNameWatch(com.ascio.www._2013._02.NameWatch nameWatch) {
        this.nameWatch = nameWatch;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof NameWatchOrderRequest)) return false;
        NameWatchOrderRequest other = (NameWatchOrderRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.nameWatch==null && other.getNameWatch()==null) || 
             (this.nameWatch!=null &&
              this.nameWatch.equals(other.getNameWatch())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getNameWatch() != null) {
            _hashCode += getNameWatch().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(NameWatchOrderRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "NameWatchOrderRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nameWatch");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "NameWatch"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "NameWatch"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
