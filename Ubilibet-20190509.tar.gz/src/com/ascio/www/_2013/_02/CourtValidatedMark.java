/**
 * CourtValidatedMark.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ascio.www._2013._02;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class CourtValidatedMark  extends com.ascio.www._2013._02.AbstractMark  implements java.io.Serializable {
    /* Official title of the court where the court order has been
     * taken */
    private java.lang.String courtName;

    /* Reference number of the court order */
    private java.lang.String referenceNumber;

    /* Country in which the court order is applicable */
    private java.lang.String country;

    /* Region in which the court order is applicable */
    private java.lang.String region;

    /* The date of protection of the mark */
    private java.util.Calendar protectionDate;

    public CourtValidatedMark() {
    }

    public CourtValidatedMark(
           java.lang.String handle,
           java.lang.String markName,
           java.lang.String markId,
           java.lang.String authInfo,
           com.ascio.www._2013._02.MarkServiceType serviceType,
           java.lang.String goodsAndServicesDescription,
           java.lang.String[] labels,
           java.lang.String claimEmailNotification1,
           java.lang.String claimEmailNotification2,
           java.lang.String claimEmailNotification3,
           java.lang.String claimEmailNotification4,
           java.lang.String claimEmailNotification5,
           com.ascio.www._2013._02.NotificationFrequencyType notificationFrequency,
           com.ascio.www._2013._02.Registrant owner,
           com.ascio.www._2013._02.Contact reseller,
           com.ascio.www._2013._02.ExtensionsKeyValue[] extensions,
           java.lang.String courtName,
           java.lang.String referenceNumber,
           java.lang.String country,
           java.lang.String region,
           java.util.Calendar protectionDate) {
        super(
            handle,
            markName,
            markId,
            authInfo,
            serviceType,
            goodsAndServicesDescription,
            labels,
            claimEmailNotification1,
            claimEmailNotification2,
            claimEmailNotification3,
            claimEmailNotification4,
            claimEmailNotification5,
            notificationFrequency,
            owner,
            reseller,
            extensions);
        this.courtName = courtName;
        this.referenceNumber = referenceNumber;
        this.country = country;
        this.region = region;
        this.protectionDate = protectionDate;
    }


    /**
     * Gets the courtName value for this CourtValidatedMark.
     * 
     * @return courtName   * Official title of the court where the court order has been
     * taken
     */
    public java.lang.String getCourtName() {
        return courtName;
    }


    /**
     * Sets the courtName value for this CourtValidatedMark.
     * 
     * @param courtName   * Official title of the court where the court order has been
     * taken
     */
    public void setCourtName(java.lang.String courtName) {
        this.courtName = courtName;
    }


    /**
     * Gets the referenceNumber value for this CourtValidatedMark.
     * 
     * @return referenceNumber   * Reference number of the court order
     */
    public java.lang.String getReferenceNumber() {
        return referenceNumber;
    }


    /**
     * Sets the referenceNumber value for this CourtValidatedMark.
     * 
     * @param referenceNumber   * Reference number of the court order
     */
    public void setReferenceNumber(java.lang.String referenceNumber) {
        this.referenceNumber = referenceNumber;
    }


    /**
     * Gets the country value for this CourtValidatedMark.
     * 
     * @return country   * Country in which the court order is applicable
     */
    public java.lang.String getCountry() {
        return country;
    }


    /**
     * Sets the country value for this CourtValidatedMark.
     * 
     * @param country   * Country in which the court order is applicable
     */
    public void setCountry(java.lang.String country) {
        this.country = country;
    }


    /**
     * Gets the region value for this CourtValidatedMark.
     * 
     * @return region   * Region in which the court order is applicable
     */
    public java.lang.String getRegion() {
        return region;
    }


    /**
     * Sets the region value for this CourtValidatedMark.
     * 
     * @param region   * Region in which the court order is applicable
     */
    public void setRegion(java.lang.String region) {
        this.region = region;
    }


    /**
     * Gets the protectionDate value for this CourtValidatedMark.
     * 
     * @return protectionDate   * The date of protection of the mark
     */
    public java.util.Calendar getProtectionDate() {
        return protectionDate;
    }


    /**
     * Sets the protectionDate value for this CourtValidatedMark.
     * 
     * @param protectionDate   * The date of protection of the mark
     */
    public void setProtectionDate(java.util.Calendar protectionDate) {
        this.protectionDate = protectionDate;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CourtValidatedMark)) return false;
        CourtValidatedMark other = (CourtValidatedMark) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.courtName==null && other.getCourtName()==null) || 
             (this.courtName!=null &&
              this.courtName.equals(other.getCourtName()))) &&
            ((this.referenceNumber==null && other.getReferenceNumber()==null) || 
             (this.referenceNumber!=null &&
              this.referenceNumber.equals(other.getReferenceNumber()))) &&
            ((this.country==null && other.getCountry()==null) || 
             (this.country!=null &&
              this.country.equals(other.getCountry()))) &&
            ((this.region==null && other.getRegion()==null) || 
             (this.region!=null &&
              this.region.equals(other.getRegion()))) &&
            ((this.protectionDate==null && other.getProtectionDate()==null) || 
             (this.protectionDate!=null &&
              this.protectionDate.equals(other.getProtectionDate())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getCourtName() != null) {
            _hashCode += getCourtName().hashCode();
        }
        if (getReferenceNumber() != null) {
            _hashCode += getReferenceNumber().hashCode();
        }
        if (getCountry() != null) {
            _hashCode += getCountry().hashCode();
        }
        if (getRegion() != null) {
            _hashCode += getRegion().hashCode();
        }
        if (getProtectionDate() != null) {
            _hashCode += getProtectionDate().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CourtValidatedMark.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "CourtValidatedMark"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("courtName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "CourtName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("referenceNumber");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "ReferenceNumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("country");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Country"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("region");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "Region"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("protectionDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2013/02", "ProtectionDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
