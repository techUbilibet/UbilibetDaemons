/**
 * QueueItem.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ascio.www._2007._01;

@SuppressWarnings({ "rawtypes", "serial", "unused" })
public class QueueItem  implements java.io.Serializable {
    private com.ascio.www._2007._01.Attachment[] attachments;

    private java.lang.String domainHandle;

    private java.lang.String domainName;

    private java.lang.String msg;

    private java.lang.Integer msgId;

    private com.ascio.www._2007._01.MessageType msgType;

    private java.lang.String orderId;

    private com.ascio.www._2007._01.OrderStatusType orderStatus;

    private com.ascio.www._2007._01.CallbackStatus[] statusList;

    public QueueItem() {
    }

    public QueueItem(
           com.ascio.www._2007._01.Attachment[] attachments,
           java.lang.String domainHandle,
           java.lang.String domainName,
           java.lang.String msg,
           java.lang.Integer msgId,
           com.ascio.www._2007._01.MessageType msgType,
           java.lang.String orderId,
           com.ascio.www._2007._01.OrderStatusType orderStatus,
           com.ascio.www._2007._01.CallbackStatus[] statusList) {
           this.attachments = attachments;
           this.domainHandle = domainHandle;
           this.domainName = domainName;
           this.msg = msg;
           this.msgId = msgId;
           this.msgType = msgType;
           this.orderId = orderId;
           this.orderStatus = orderStatus;
           this.statusList = statusList;
    }


    /**
     * Gets the attachments value for this QueueItem.
     * 
     * @return attachments
     */
    public com.ascio.www._2007._01.Attachment[] getAttachments() {
        return attachments;
    }


    /**
     * Sets the attachments value for this QueueItem.
     * 
     * @param attachments
     */
    public void setAttachments(com.ascio.www._2007._01.Attachment[] attachments) {
        this.attachments = attachments;
    }


    /**
     * Gets the domainHandle value for this QueueItem.
     * 
     * @return domainHandle
     */
    public java.lang.String getDomainHandle() {
        return domainHandle;
    }


    /**
     * Sets the domainHandle value for this QueueItem.
     * 
     * @param domainHandle
     */
    public void setDomainHandle(java.lang.String domainHandle) {
        this.domainHandle = domainHandle;
    }


    /**
     * Gets the domainName value for this QueueItem.
     * 
     * @return domainName
     */
    public java.lang.String getDomainName() {
        return domainName;
    }


    /**
     * Sets the domainName value for this QueueItem.
     * 
     * @param domainName
     */
    public void setDomainName(java.lang.String domainName) {
        this.domainName = domainName;
    }


    /**
     * Gets the msg value for this QueueItem.
     * 
     * @return msg
     */
    public java.lang.String getMsg() {
        return msg;
    }


    /**
     * Sets the msg value for this QueueItem.
     * 
     * @param msg
     */
    public void setMsg(java.lang.String msg) {
        this.msg = msg;
    }


    /**
     * Gets the msgId value for this QueueItem.
     * 
     * @return msgId
     */
    public java.lang.Integer getMsgId() {
        return msgId;
    }


    /**
     * Sets the msgId value for this QueueItem.
     * 
     * @param msgId
     */
    public void setMsgId(java.lang.Integer msgId) {
        this.msgId = msgId;
    }


    /**
     * Gets the msgType value for this QueueItem.
     * 
     * @return msgType
     */
    public com.ascio.www._2007._01.MessageType getMsgType() {
        return msgType;
    }


    /**
     * Sets the msgType value for this QueueItem.
     * 
     * @param msgType
     */
    public void setMsgType(com.ascio.www._2007._01.MessageType msgType) {
        this.msgType = msgType;
    }


    /**
     * Gets the orderId value for this QueueItem.
     * 
     * @return orderId
     */
    public java.lang.String getOrderId() {
        return orderId;
    }


    /**
     * Sets the orderId value for this QueueItem.
     * 
     * @param orderId
     */
    public void setOrderId(java.lang.String orderId) {
        this.orderId = orderId;
    }


    /**
     * Gets the orderStatus value for this QueueItem.
     * 
     * @return orderStatus
     */
    public com.ascio.www._2007._01.OrderStatusType getOrderStatus() {
        return orderStatus;
    }


    /**
     * Sets the orderStatus value for this QueueItem.
     * 
     * @param orderStatus
     */
    public void setOrderStatus(com.ascio.www._2007._01.OrderStatusType orderStatus) {
        this.orderStatus = orderStatus;
    }


    /**
     * Gets the statusList value for this QueueItem.
     * 
     * @return statusList
     */
    public com.ascio.www._2007._01.CallbackStatus[] getStatusList() {
        return statusList;
    }


    /**
     * Sets the statusList value for this QueueItem.
     * 
     * @param statusList
     */
    public void setStatusList(com.ascio.www._2007._01.CallbackStatus[] statusList) {
        this.statusList = statusList;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof QueueItem)) return false;
        QueueItem other = (QueueItem) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.attachments==null && other.getAttachments()==null) || 
             (this.attachments!=null &&
              java.util.Arrays.equals(this.attachments, other.getAttachments()))) &&
            ((this.domainHandle==null && other.getDomainHandle()==null) || 
             (this.domainHandle!=null &&
              this.domainHandle.equals(other.getDomainHandle()))) &&
            ((this.domainName==null && other.getDomainName()==null) || 
             (this.domainName!=null &&
              this.domainName.equals(other.getDomainName()))) &&
            ((this.msg==null && other.getMsg()==null) || 
             (this.msg!=null &&
              this.msg.equals(other.getMsg()))) &&
            ((this.msgId==null && other.getMsgId()==null) || 
             (this.msgId!=null &&
              this.msgId.equals(other.getMsgId()))) &&
            ((this.msgType==null && other.getMsgType()==null) || 
             (this.msgType!=null &&
              this.msgType.equals(other.getMsgType()))) &&
            ((this.orderId==null && other.getOrderId()==null) || 
             (this.orderId!=null &&
              this.orderId.equals(other.getOrderId()))) &&
            ((this.orderStatus==null && other.getOrderStatus()==null) || 
             (this.orderStatus!=null &&
              this.orderStatus.equals(other.getOrderStatus()))) &&
            ((this.statusList==null && other.getStatusList()==null) || 
             (this.statusList!=null &&
              java.util.Arrays.equals(this.statusList, other.getStatusList())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getAttachments() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getAttachments());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getAttachments(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getDomainHandle() != null) {
            _hashCode += getDomainHandle().hashCode();
        }
        if (getDomainName() != null) {
            _hashCode += getDomainName().hashCode();
        }
        if (getMsg() != null) {
            _hashCode += getMsg().hashCode();
        }
        if (getMsgId() != null) {
            _hashCode += getMsgId().hashCode();
        }
        if (getMsgType() != null) {
            _hashCode += getMsgType().hashCode();
        }
        if (getOrderId() != null) {
            _hashCode += getOrderId().hashCode();
        }
        if (getOrderStatus() != null) {
            _hashCode += getOrderStatus().hashCode();
        }
        if (getStatusList() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getStatusList());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getStatusList(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(QueueItem.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "QueueItem"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attachments");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Attachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Attachment"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Attachment"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("domainHandle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "DomainHandle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("domainName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "DomainName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("msg");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Msg"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("msgId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "MsgId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("msgType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "MsgType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "MessageType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "OrderId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "OrderStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "OrderStatusType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("statusList");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "StatusList"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "CallbackStatus"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "CallbackStatus"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
