/**
 * Domain.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ascio.www._2007._01;

@SuppressWarnings({ "rawtypes", "serial", "unused" })
public class Domain  implements java.io.Serializable {
    private java.lang.String domainName;

    private java.lang.String domainHandle;

    private java.lang.Integer regPeriod;

    private java.lang.Integer renewPeriod;

    private java.lang.String status;

    private java.lang.String authInfo;

    private java.util.Calendar creDate;

    private java.util.Calendar expDate;

    private java.lang.String encodingType;

    private java.lang.String domainPurpose;

    private java.lang.String comment;

    private java.lang.String transferLock;

    private java.lang.String deleteLock;

    private java.lang.String updateLock;

    private java.lang.String queueType;

    private com.ascio.www._2007._01.Registrant registrant;

    private com.ascio.www._2007._01.Contact adminContact;

    private com.ascio.www._2007._01.Contact techContact;

    private com.ascio.www._2007._01.Contact billingContact;

    private com.ascio.www._2007._01.Contact resellerContact;

    private com.ascio.www._2007._01.NameServers nameServers;

    private com.ascio.www._2007._01.TradeMark trademark;

    private com.ascio.www._2007._01.DnsSecKeys dnsSecKeys;

    private com.ascio.www._2007._01.PrivacyProxy privacyProxy;

    private java.lang.String domainType;

    private java.lang.String discloseSocialData;

    public Domain() {
    }

    public Domain(
           java.lang.String domainName,
           java.lang.String domainHandle,
           java.lang.Integer regPeriod,
           java.lang.Integer renewPeriod,
           java.lang.String status,
           java.lang.String authInfo,
           java.util.Calendar creDate,
           java.util.Calendar expDate,
           java.lang.String encodingType,
           java.lang.String domainPurpose,
           java.lang.String comment,
           java.lang.String transferLock,
           java.lang.String deleteLock,
           java.lang.String updateLock,
           java.lang.String queueType,
           com.ascio.www._2007._01.Registrant registrant,
           com.ascio.www._2007._01.Contact adminContact,
           com.ascio.www._2007._01.Contact techContact,
           com.ascio.www._2007._01.Contact billingContact,
           com.ascio.www._2007._01.Contact resellerContact,
           com.ascio.www._2007._01.NameServers nameServers,
           com.ascio.www._2007._01.TradeMark trademark,
           com.ascio.www._2007._01.DnsSecKeys dnsSecKeys,
           com.ascio.www._2007._01.PrivacyProxy privacyProxy,
           java.lang.String domainType,
           java.lang.String discloseSocialData) {
           this.domainName = domainName;
           this.domainHandle = domainHandle;
           this.regPeriod = regPeriod;
           this.renewPeriod = renewPeriod;
           this.status = status;
           this.authInfo = authInfo;
           this.creDate = creDate;
           this.expDate = expDate;
           this.encodingType = encodingType;
           this.domainPurpose = domainPurpose;
           this.comment = comment;
           this.transferLock = transferLock;
           this.deleteLock = deleteLock;
           this.updateLock = updateLock;
           this.queueType = queueType;
           this.registrant = registrant;
           this.adminContact = adminContact;
           this.techContact = techContact;
           this.billingContact = billingContact;
           this.resellerContact = resellerContact;
           this.nameServers = nameServers;
           this.trademark = trademark;
           this.dnsSecKeys = dnsSecKeys;
           this.privacyProxy = privacyProxy;
           this.domainType = domainType;
           this.discloseSocialData = discloseSocialData;
    }


    /**
     * Gets the domainName value for this Domain.
     * 
     * @return domainName
     */
    public java.lang.String getDomainName() {
        return domainName;
    }


    /**
     * Sets the domainName value for this Domain.
     * 
     * @param domainName
     */
    public void setDomainName(java.lang.String domainName) {
        this.domainName = domainName;
    }


    /**
     * Gets the domainHandle value for this Domain.
     * 
     * @return domainHandle
     */
    public java.lang.String getDomainHandle() {
        return domainHandle;
    }


    /**
     * Sets the domainHandle value for this Domain.
     * 
     * @param domainHandle
     */
    public void setDomainHandle(java.lang.String domainHandle) {
        this.domainHandle = domainHandle;
    }


    /**
     * Gets the regPeriod value for this Domain.
     * 
     * @return regPeriod
     */
    public java.lang.Integer getRegPeriod() {
        return regPeriod;
    }


    /**
     * Sets the regPeriod value for this Domain.
     * 
     * @param regPeriod
     */
    public void setRegPeriod(java.lang.Integer regPeriod) {
        this.regPeriod = regPeriod;
    }


    /**
     * Gets the renewPeriod value for this Domain.
     * 
     * @return renewPeriod
     */
    public java.lang.Integer getRenewPeriod() {
        return renewPeriod;
    }


    /**
     * Sets the renewPeriod value for this Domain.
     * 
     * @param renewPeriod
     */
    public void setRenewPeriod(java.lang.Integer renewPeriod) {
        this.renewPeriod = renewPeriod;
    }


    /**
     * Gets the status value for this Domain.
     * 
     * @return status
     */
    public java.lang.String getStatus() {
        return status;
    }


    /**
     * Sets the status value for this Domain.
     * 
     * @param status
     */
    public void setStatus(java.lang.String status) {
        this.status = status;
    }


    /**
     * Gets the authInfo value for this Domain.
     * 
     * @return authInfo
     */
    public java.lang.String getAuthInfo() {
        return authInfo;
    }


    /**
     * Sets the authInfo value for this Domain.
     * 
     * @param authInfo
     */
    public void setAuthInfo(java.lang.String authInfo) {
        this.authInfo = authInfo;
    }


    /**
     * Gets the creDate value for this Domain.
     * 
     * @return creDate
     */
    public java.util.Calendar getCreDate() {
        return creDate;
    }


    /**
     * Sets the creDate value for this Domain.
     * 
     * @param creDate
     */
    public void setCreDate(java.util.Calendar creDate) {
        this.creDate = creDate;
    }


    /**
     * Gets the expDate value for this Domain.
     * 
     * @return expDate
     */
    public java.util.Calendar getExpDate() {
        return expDate;
    }


    /**
     * Sets the expDate value for this Domain.
     * 
     * @param expDate
     */
    public void setExpDate(java.util.Calendar expDate) {
        this.expDate = expDate;
    }


    /**
     * Gets the encodingType value for this Domain.
     * 
     * @return encodingType
     */
    public java.lang.String getEncodingType() {
        return encodingType;
    }


    /**
     * Sets the encodingType value for this Domain.
     * 
     * @param encodingType
     */
    public void setEncodingType(java.lang.String encodingType) {
        this.encodingType = encodingType;
    }


    /**
     * Gets the domainPurpose value for this Domain.
     * 
     * @return domainPurpose
     */
    public java.lang.String getDomainPurpose() {
        return domainPurpose;
    }


    /**
     * Sets the domainPurpose value for this Domain.
     * 
     * @param domainPurpose
     */
    public void setDomainPurpose(java.lang.String domainPurpose) {
        this.domainPurpose = domainPurpose;
    }


    /**
     * Gets the comment value for this Domain.
     * 
     * @return comment
     */
    public java.lang.String getComment() {
        return comment;
    }


    /**
     * Sets the comment value for this Domain.
     * 
     * @param comment
     */
    public void setComment(java.lang.String comment) {
        this.comment = comment;
    }


    /**
     * Gets the transferLock value for this Domain.
     * 
     * @return transferLock
     */
    public java.lang.String getTransferLock() {
        return transferLock;
    }


    /**
     * Sets the transferLock value for this Domain.
     * 
     * @param transferLock
     */
    public void setTransferLock(java.lang.String transferLock) {
        this.transferLock = transferLock;
    }


    /**
     * Gets the deleteLock value for this Domain.
     * 
     * @return deleteLock
     */
    public java.lang.String getDeleteLock() {
        return deleteLock;
    }


    /**
     * Sets the deleteLock value for this Domain.
     * 
     * @param deleteLock
     */
    public void setDeleteLock(java.lang.String deleteLock) {
        this.deleteLock = deleteLock;
    }


    /**
     * Gets the updateLock value for this Domain.
     * 
     * @return updateLock
     */
    public java.lang.String getUpdateLock() {
        return updateLock;
    }


    /**
     * Sets the updateLock value for this Domain.
     * 
     * @param updateLock
     */
    public void setUpdateLock(java.lang.String updateLock) {
        this.updateLock = updateLock;
    }


    /**
     * Gets the queueType value for this Domain.
     * 
     * @return queueType
     */
    public java.lang.String getQueueType() {
        return queueType;
    }


    /**
     * Sets the queueType value for this Domain.
     * 
     * @param queueType
     */
    public void setQueueType(java.lang.String queueType) {
        this.queueType = queueType;
    }


    /**
     * Gets the registrant value for this Domain.
     * 
     * @return registrant
     */
    public com.ascio.www._2007._01.Registrant getRegistrant() {
        return registrant;
    }


    /**
     * Sets the registrant value for this Domain.
     * 
     * @param registrant
     */
    public void setRegistrant(com.ascio.www._2007._01.Registrant registrant) {
        this.registrant = registrant;
    }


    /**
     * Gets the adminContact value for this Domain.
     * 
     * @return adminContact
     */
    public com.ascio.www._2007._01.Contact getAdminContact() {
        return adminContact;
    }


    /**
     * Sets the adminContact value for this Domain.
     * 
     * @param adminContact
     */
    public void setAdminContact(com.ascio.www._2007._01.Contact adminContact) {
        this.adminContact = adminContact;
    }


    /**
     * Gets the techContact value for this Domain.
     * 
     * @return techContact
     */
    public com.ascio.www._2007._01.Contact getTechContact() {
        return techContact;
    }


    /**
     * Sets the techContact value for this Domain.
     * 
     * @param techContact
     */
    public void setTechContact(com.ascio.www._2007._01.Contact techContact) {
        this.techContact = techContact;
    }


    /**
     * Gets the billingContact value for this Domain.
     * 
     * @return billingContact
     */
    public com.ascio.www._2007._01.Contact getBillingContact() {
        return billingContact;
    }


    /**
     * Sets the billingContact value for this Domain.
     * 
     * @param billingContact
     */
    public void setBillingContact(com.ascio.www._2007._01.Contact billingContact) {
        this.billingContact = billingContact;
    }


    /**
     * Gets the resellerContact value for this Domain.
     * 
     * @return resellerContact
     */
    public com.ascio.www._2007._01.Contact getResellerContact() {
        return resellerContact;
    }


    /**
     * Sets the resellerContact value for this Domain.
     * 
     * @param resellerContact
     */
    public void setResellerContact(com.ascio.www._2007._01.Contact resellerContact) {
        this.resellerContact = resellerContact;
    }


    /**
     * Gets the nameServers value for this Domain.
     * 
     * @return nameServers
     */
    public com.ascio.www._2007._01.NameServers getNameServers() {
        return nameServers;
    }


    /**
     * Sets the nameServers value for this Domain.
     * 
     * @param nameServers
     */
    public void setNameServers(com.ascio.www._2007._01.NameServers nameServers) {
        this.nameServers = nameServers;
    }


    /**
     * Gets the trademark value for this Domain.
     * 
     * @return trademark
     */
    public com.ascio.www._2007._01.TradeMark getTrademark() {
        return trademark;
    }


    /**
     * Sets the trademark value for this Domain.
     * 
     * @param trademark
     */
    public void setTrademark(com.ascio.www._2007._01.TradeMark trademark) {
        this.trademark = trademark;
    }


    /**
     * Gets the dnsSecKeys value for this Domain.
     * 
     * @return dnsSecKeys
     */
    public com.ascio.www._2007._01.DnsSecKeys getDnsSecKeys() {
        return dnsSecKeys;
    }


    /**
     * Sets the dnsSecKeys value for this Domain.
     * 
     * @param dnsSecKeys
     */
    public void setDnsSecKeys(com.ascio.www._2007._01.DnsSecKeys dnsSecKeys) {
        this.dnsSecKeys = dnsSecKeys;
    }


    /**
     * Gets the privacyProxy value for this Domain.
     * 
     * @return privacyProxy
     */
    public com.ascio.www._2007._01.PrivacyProxy getPrivacyProxy() {
        return privacyProxy;
    }


    /**
     * Sets the privacyProxy value for this Domain.
     * 
     * @param privacyProxy
     */
    public void setPrivacyProxy(com.ascio.www._2007._01.PrivacyProxy privacyProxy) {
        this.privacyProxy = privacyProxy;
    }


    /**
     * Gets the domainType value for this Domain.
     * 
     * @return domainType
     */
    public java.lang.String getDomainType() {
        return domainType;
    }


    /**
     * Sets the domainType value for this Domain.
     * 
     * @param domainType
     */
    public void setDomainType(java.lang.String domainType) {
        this.domainType = domainType;
    }


    /**
     * Gets the discloseSocialData value for this Domain.
     * 
     * @return discloseSocialData
     */
    public java.lang.String getDiscloseSocialData() {
        return discloseSocialData;
    }


    /**
     * Sets the discloseSocialData value for this Domain.
     * 
     * @param discloseSocialData
     */
    public void setDiscloseSocialData(java.lang.String discloseSocialData) {
        this.discloseSocialData = discloseSocialData;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Domain)) return false;
        Domain other = (Domain) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.domainName==null && other.getDomainName()==null) || 
             (this.domainName!=null &&
              this.domainName.equals(other.getDomainName()))) &&
            ((this.domainHandle==null && other.getDomainHandle()==null) || 
             (this.domainHandle!=null &&
              this.domainHandle.equals(other.getDomainHandle()))) &&
            ((this.regPeriod==null && other.getRegPeriod()==null) || 
             (this.regPeriod!=null &&
              this.regPeriod.equals(other.getRegPeriod()))) &&
            ((this.renewPeriod==null && other.getRenewPeriod()==null) || 
             (this.renewPeriod!=null &&
              this.renewPeriod.equals(other.getRenewPeriod()))) &&
            ((this.status==null && other.getStatus()==null) || 
             (this.status!=null &&
              this.status.equals(other.getStatus()))) &&
            ((this.authInfo==null && other.getAuthInfo()==null) || 
             (this.authInfo!=null &&
              this.authInfo.equals(other.getAuthInfo()))) &&
            ((this.creDate==null && other.getCreDate()==null) || 
             (this.creDate!=null &&
              this.creDate.equals(other.getCreDate()))) &&
            ((this.expDate==null && other.getExpDate()==null) || 
             (this.expDate!=null &&
              this.expDate.equals(other.getExpDate()))) &&
            ((this.encodingType==null && other.getEncodingType()==null) || 
             (this.encodingType!=null &&
              this.encodingType.equals(other.getEncodingType()))) &&
            ((this.domainPurpose==null && other.getDomainPurpose()==null) || 
             (this.domainPurpose!=null &&
              this.domainPurpose.equals(other.getDomainPurpose()))) &&
            ((this.comment==null && other.getComment()==null) || 
             (this.comment!=null &&
              this.comment.equals(other.getComment()))) &&
            ((this.transferLock==null && other.getTransferLock()==null) || 
             (this.transferLock!=null &&
              this.transferLock.equals(other.getTransferLock()))) &&
            ((this.deleteLock==null && other.getDeleteLock()==null) || 
             (this.deleteLock!=null &&
              this.deleteLock.equals(other.getDeleteLock()))) &&
            ((this.updateLock==null && other.getUpdateLock()==null) || 
             (this.updateLock!=null &&
              this.updateLock.equals(other.getUpdateLock()))) &&
            ((this.queueType==null && other.getQueueType()==null) || 
             (this.queueType!=null &&
              this.queueType.equals(other.getQueueType()))) &&
            ((this.registrant==null && other.getRegistrant()==null) || 
             (this.registrant!=null &&
              this.registrant.equals(other.getRegistrant()))) &&
            ((this.adminContact==null && other.getAdminContact()==null) || 
             (this.adminContact!=null &&
              this.adminContact.equals(other.getAdminContact()))) &&
            ((this.techContact==null && other.getTechContact()==null) || 
             (this.techContact!=null &&
              this.techContact.equals(other.getTechContact()))) &&
            ((this.billingContact==null && other.getBillingContact()==null) || 
             (this.billingContact!=null &&
              this.billingContact.equals(other.getBillingContact()))) &&
            ((this.resellerContact==null && other.getResellerContact()==null) || 
             (this.resellerContact!=null &&
              this.resellerContact.equals(other.getResellerContact()))) &&
            ((this.nameServers==null && other.getNameServers()==null) || 
             (this.nameServers!=null &&
              this.nameServers.equals(other.getNameServers()))) &&
            ((this.trademark==null && other.getTrademark()==null) || 
             (this.trademark!=null &&
              this.trademark.equals(other.getTrademark()))) &&
            ((this.dnsSecKeys==null && other.getDnsSecKeys()==null) || 
             (this.dnsSecKeys!=null &&
              this.dnsSecKeys.equals(other.getDnsSecKeys()))) &&
            ((this.privacyProxy==null && other.getPrivacyProxy()==null) || 
             (this.privacyProxy!=null &&
              this.privacyProxy.equals(other.getPrivacyProxy()))) &&
            ((this.domainType==null && other.getDomainType()==null) || 
             (this.domainType!=null &&
              this.domainType.equals(other.getDomainType()))) &&
            ((this.discloseSocialData==null && other.getDiscloseSocialData()==null) || 
             (this.discloseSocialData!=null &&
              this.discloseSocialData.equals(other.getDiscloseSocialData())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getDomainName() != null) {
            _hashCode += getDomainName().hashCode();
        }
        if (getDomainHandle() != null) {
            _hashCode += getDomainHandle().hashCode();
        }
        if (getRegPeriod() != null) {
            _hashCode += getRegPeriod().hashCode();
        }
        if (getRenewPeriod() != null) {
            _hashCode += getRenewPeriod().hashCode();
        }
        if (getStatus() != null) {
            _hashCode += getStatus().hashCode();
        }
        if (getAuthInfo() != null) {
            _hashCode += getAuthInfo().hashCode();
        }
        if (getCreDate() != null) {
            _hashCode += getCreDate().hashCode();
        }
        if (getExpDate() != null) {
            _hashCode += getExpDate().hashCode();
        }
        if (getEncodingType() != null) {
            _hashCode += getEncodingType().hashCode();
        }
        if (getDomainPurpose() != null) {
            _hashCode += getDomainPurpose().hashCode();
        }
        if (getComment() != null) {
            _hashCode += getComment().hashCode();
        }
        if (getTransferLock() != null) {
            _hashCode += getTransferLock().hashCode();
        }
        if (getDeleteLock() != null) {
            _hashCode += getDeleteLock().hashCode();
        }
        if (getUpdateLock() != null) {
            _hashCode += getUpdateLock().hashCode();
        }
        if (getQueueType() != null) {
            _hashCode += getQueueType().hashCode();
        }
        if (getRegistrant() != null) {
            _hashCode += getRegistrant().hashCode();
        }
        if (getAdminContact() != null) {
            _hashCode += getAdminContact().hashCode();
        }
        if (getTechContact() != null) {
            _hashCode += getTechContact().hashCode();
        }
        if (getBillingContact() != null) {
            _hashCode += getBillingContact().hashCode();
        }
        if (getResellerContact() != null) {
            _hashCode += getResellerContact().hashCode();
        }
        if (getNameServers() != null) {
            _hashCode += getNameServers().hashCode();
        }
        if (getTrademark() != null) {
            _hashCode += getTrademark().hashCode();
        }
        if (getDnsSecKeys() != null) {
            _hashCode += getDnsSecKeys().hashCode();
        }
        if (getPrivacyProxy() != null) {
            _hashCode += getPrivacyProxy().hashCode();
        }
        if (getDomainType() != null) {
            _hashCode += getDomainType().hashCode();
        }
        if (getDiscloseSocialData() != null) {
            _hashCode += getDiscloseSocialData().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Domain.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Domain"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("domainName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "DomainName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("domainHandle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "DomainHandle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("regPeriod");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "RegPeriod"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("renewPeriod");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "RenewPeriod"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("status");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Status"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("authInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "AuthInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("creDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "CreDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("expDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "ExpDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("encodingType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "EncodingType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("domainPurpose");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "DomainPurpose"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("comment");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Comment"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transferLock");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "TransferLock"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("deleteLock");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "DeleteLock"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("updateLock");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "UpdateLock"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("queueType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "QueueType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("registrant");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Registrant"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Registrant"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("adminContact");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "AdminContact"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Contact"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("techContact");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "TechContact"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Contact"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("billingContact");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "BillingContact"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Contact"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("resellerContact");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "ResellerContact"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Contact"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nameServers");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "NameServers"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "NameServers"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("trademark");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Trademark"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "TradeMark"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dnsSecKeys");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "DnsSecKeys"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "DnsSecKeys"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("privacyProxy");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "PrivacyProxy"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "PrivacyProxy"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("domainType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "DomainType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("discloseSocialData");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "DiscloseSocialData"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
