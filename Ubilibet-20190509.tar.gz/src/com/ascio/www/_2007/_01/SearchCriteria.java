/**
 * SearchCriteria.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ascio.www._2007._01;

@SuppressWarnings({ "rawtypes", "serial", "unused" })
public class SearchCriteria  implements java.io.Serializable {
    private com.ascio.www._2007._01.Clause[] clauses;

    private com.ascio.www._2007._01.SearchModeType mode;

    private java.lang.String[] withoutstates;

    private java.lang.String[] withstates;

    public SearchCriteria() {
    }

    public SearchCriteria(
           com.ascio.www._2007._01.Clause[] clauses,
           com.ascio.www._2007._01.SearchModeType mode,
           java.lang.String[] withoutstates,
           java.lang.String[] withstates) {
           this.clauses = clauses;
           this.mode = mode;
           this.withoutstates = withoutstates;
           this.withstates = withstates;
    }


    /**
     * Gets the clauses value for this SearchCriteria.
     * 
     * @return clauses
     */
    public com.ascio.www._2007._01.Clause[] getClauses() {
        return clauses;
    }


    /**
     * Sets the clauses value for this SearchCriteria.
     * 
     * @param clauses
     */
    public void setClauses(com.ascio.www._2007._01.Clause[] clauses) {
        this.clauses = clauses;
    }


    /**
     * Gets the mode value for this SearchCriteria.
     * 
     * @return mode
     */
    public com.ascio.www._2007._01.SearchModeType getMode() {
        return mode;
    }


    /**
     * Sets the mode value for this SearchCriteria.
     * 
     * @param mode
     */
    public void setMode(com.ascio.www._2007._01.SearchModeType mode) {
        this.mode = mode;
    }


    /**
     * Gets the withoutstates value for this SearchCriteria.
     * 
     * @return withoutstates
     */
    public java.lang.String[] getWithoutstates() {
        return withoutstates;
    }


    /**
     * Sets the withoutstates value for this SearchCriteria.
     * 
     * @param withoutstates
     */
    public void setWithoutstates(java.lang.String[] withoutstates) {
        this.withoutstates = withoutstates;
    }


    /**
     * Gets the withstates value for this SearchCriteria.
     * 
     * @return withstates
     */
    public java.lang.String[] getWithstates() {
        return withstates;
    }


    /**
     * Sets the withstates value for this SearchCriteria.
     * 
     * @param withstates
     */
    public void setWithstates(java.lang.String[] withstates) {
        this.withstates = withstates;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof SearchCriteria)) return false;
        SearchCriteria other = (SearchCriteria) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.clauses==null && other.getClauses()==null) || 
             (this.clauses!=null &&
              java.util.Arrays.equals(this.clauses, other.getClauses()))) &&
            ((this.mode==null && other.getMode()==null) || 
             (this.mode!=null &&
              this.mode.equals(other.getMode()))) &&
            ((this.withoutstates==null && other.getWithoutstates()==null) || 
             (this.withoutstates!=null &&
              java.util.Arrays.equals(this.withoutstates, other.getWithoutstates()))) &&
            ((this.withstates==null && other.getWithstates()==null) || 
             (this.withstates!=null &&
              java.util.Arrays.equals(this.withstates, other.getWithstates())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getClauses() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getClauses());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getClauses(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getMode() != null) {
            _hashCode += getMode().hashCode();
        }
        if (getWithoutstates() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWithoutstates());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWithoutstates(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getWithstates() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWithstates());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWithstates(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(SearchCriteria.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "SearchCriteria"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("clauses");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Clauses"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Clause"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Clause"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("mode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Mode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "SearchModeType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("withoutstates");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Withoutstates"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://schemas.microsoft.com/2003/10/Serialization/Arrays", "string"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("withstates");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Withstates"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://schemas.microsoft.com/2003/10/Serialization/Arrays", "string"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
