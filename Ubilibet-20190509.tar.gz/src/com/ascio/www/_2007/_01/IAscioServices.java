/**
 * IAscioServices.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ascio.www._2007._01;

public interface IAscioServices extends java.rmi.Remote {
    public void logIn(com.ascio.www._2007._01.Session session, com.ascio.www._2007._01.holders.ResponseHolder logInResult, javax.xml.rpc.holders.StringHolder sessionId) throws java.rmi.RemoteException;
    public com.ascio.www._2007._01.Response logOut(java.lang.String sessionId) throws java.rmi.RemoteException;
    public void getOrder(java.lang.String sessionId, java.lang.String orderId, com.ascio.www._2007._01.holders.ResponseHolder getOrderResult, com.ascio.www._2007._01.holders.OrderHolder order) throws java.rmi.RemoteException;
    public com.ascio.www._2007._01.Response createOrder(java.lang.String sessionId, com.ascio.www._2007._01.holders.OrderHolder order) throws java.rmi.RemoteException;
    public void searchOrder(java.lang.String sessionId, com.ascio.www._2007._01.SearchOrderRequest orderRequest, com.ascio.www._2007._01.holders.ResponseHolder searchOrderResult, javax.xml.rpc.holders.IntegerWrapperHolder totalOrders, com.ascio.www._2007._01.holders.ArrayOfOrderHolder orders) throws java.rmi.RemoteException;
    public void getMessages(java.lang.String sessionId, java.lang.String orderId, com.ascio.www._2007._01.holders.ResponseHolder getMessagesResult, com.ascio.www._2007._01.holders.ArrayOfMessageHolder messages) throws java.rmi.RemoteException;
    public com.ascio.www._2007._01.Response validateOrder(java.lang.String sessionId, com.ascio.www._2007._01.Order order) throws java.rmi.RemoteException;
    public com.ascio.www._2007._01.Response uploadDocumentation(java.lang.String sessionId, java.lang.String orderId, java.lang.String fileName, byte[] content) throws java.rmi.RemoteException;
    public void createSupportOrder(java.lang.String sessionId, java.lang.String subject, java.lang.String body, com.ascio.www._2007._01.Attachment[] attachments, com.ascio.www._2007._01.holders.ResponseHolder createSupportOrderResult, javax.xml.rpc.holders.StringHolder orderId) throws java.rmi.RemoteException;
    public com.ascio.www._2007._01.Response uploadMessage(java.lang.String sessionId, java.lang.String orderId, com.ascio.www._2007._01.Message message) throws java.rmi.RemoteException;
    public void getDomain(java.lang.String sessionId, java.lang.String domainHandle, com.ascio.www._2007._01.holders.ResponseHolder getDomainResult, com.ascio.www._2007._01.holders.DomainHolder domain) throws java.rmi.RemoteException;
    public void searchDomain(java.lang.String sessionId, com.ascio.www._2007._01.SearchCriteria criteria, com.ascio.www._2007._01.holders.ResponseHolder searchDomainResult, com.ascio.www._2007._01.holders.ArrayOfDomainHolder domains) throws java.rmi.RemoteException;
    public void whois(java.lang.String sessionId, java.lang.String domainName, com.ascio.www._2007._01.holders.ResponseHolder whoisResult, javax.xml.rpc.holders.StringHolder whoisData) throws java.rmi.RemoteException;
    public void availabilityCheck(java.lang.String sessionId, java.lang.String[] domains, java.lang.String[] tlds, com.ascio.www._2007._01.QualityType quality, com.ascio.www._2007._01.holders.ResponseHolder availabilityCheckResult, com.ascio.www._2007._01.holders.ArrayOfAvailabilityCheckResultHolder results) throws java.rmi.RemoteException;
    public void availabilityInfo(java.lang.String sessionId, java.lang.String domainName, com.ascio.www._2007._01.QualityType quality, com.ascio.www._2007._01.holders.ResponseHolder availabilityInfoResult, com.ascio.www._2007._01.holders.PriceInfoHolder priceInfo) throws java.rmi.RemoteException;
    public void getRegistrant(java.lang.String sessionId, java.lang.String registrantHandle, com.ascio.www._2007._01.holders.ResponseHolder getRegistrantResult, com.ascio.www._2007._01.holders.RegistrantHolder registrant) throws java.rmi.RemoteException;
    public com.ascio.www._2007._01.Response createRegistrant(java.lang.String sessionId, com.ascio.www._2007._01.holders.RegistrantHolder registrant) throws java.rmi.RemoteException;
    public com.ascio.www._2007._01.Response deleteRegistrant(java.lang.String sessionId, java.lang.String registrantHandle) throws java.rmi.RemoteException;
    public void searchRegistrant(java.lang.String sessionId, com.ascio.www._2007._01.SearchCriteria criteria, com.ascio.www._2007._01.holders.ResponseHolder searchRegistrantResult, com.ascio.www._2007._01.holders.ArrayOfRegistrantHolder registrants) throws java.rmi.RemoteException;
    public void getRegistrantVerificationInfo(java.lang.String sessionId, java.lang.String value, com.ascio.www._2007._01.holders.ResponseHolder getRegistrantVerificationInfoResult, com.ascio.www._2007._01.holders.RegistrantVerificationInfoHolder verificationInfo) throws java.rmi.RemoteException;
    public com.ascio.www._2007._01.Response doRegistrantVerification(java.lang.String sessionId, java.lang.String value) throws java.rmi.RemoteException;
    public void getRegistrantVerificationStatus(java.lang.String sessionId, java.lang.String value, com.ascio.www._2007._01.holders.ResponseHolder getRegistrantVerificationStatusResult, com.ascio.www._2007._01.holders.RegistrantVerificationStatusHolder verificationStatus) throws java.rmi.RemoteException;
    public com.ascio.www._2007._01.Response uploadRegistrantVerificationMessage(java.lang.String sessionId, java.lang.String value, com.ascio.www._2007._01.RegistrantVerificationDetails details) throws java.rmi.RemoteException;
    public void getContact(java.lang.String sessionId, java.lang.String contactHandle, com.ascio.www._2007._01.holders.ResponseHolder getContactResult, com.ascio.www._2007._01.holders.ContactHolder contact) throws java.rmi.RemoteException;
    public com.ascio.www._2007._01.Response createContact(java.lang.String sessionId, com.ascio.www._2007._01.holders.ContactHolder contact) throws java.rmi.RemoteException;
    public com.ascio.www._2007._01.Response updateContact(java.lang.String sessionId, com.ascio.www._2007._01.Contact contact) throws java.rmi.RemoteException;
    public com.ascio.www._2007._01.Response deleteContact(java.lang.String sessionId, java.lang.String contactHandle) throws java.rmi.RemoteException;
    public void searchContact(java.lang.String sessionId, com.ascio.www._2007._01.SearchCriteria criteria, com.ascio.www._2007._01.holders.ResponseHolder searchContactResult, com.ascio.www._2007._01.holders.ArrayOfContactHolder contacts) throws java.rmi.RemoteException;
    public void getNameServer(java.lang.String sessionId, java.lang.String nameServerHandle, com.ascio.www._2007._01.holders.ResponseHolder getNameServerResult, com.ascio.www._2007._01.holders.NameServerHolder nameServer) throws java.rmi.RemoteException;
    public com.ascio.www._2007._01.Response createNameServer(java.lang.String sessionId, com.ascio.www._2007._01.holders.NameServerHolder nameServer) throws java.rmi.RemoteException;
    public com.ascio.www._2007._01.Response deleteNameServer(java.lang.String sessionId, java.lang.String nameServerHandle) throws java.rmi.RemoteException;
    public void searchNameServer(java.lang.String sessionId, com.ascio.www._2007._01.SearchCriteria criteria, com.ascio.www._2007._01.holders.ResponseHolder searchNameServerResult, com.ascio.www._2007._01.holders.ArrayOfNameServerHolder nameServers) throws java.rmi.RemoteException;
    public void pollMessage(java.lang.String sessionId, com.ascio.www._2007._01.MessageType msgType, com.ascio.www._2007._01.holders.ResponseHolder pollMessageResult, javax.xml.rpc.holders.IntegerWrapperHolder msgCount, com.ascio.www._2007._01.holders.QueueItemHolder item) throws java.rmi.RemoteException;
    public com.ascio.www._2007._01.Response ackMessage(java.lang.String sessionId, java.lang.Integer msgId) throws java.rmi.RemoteException;
    public void getMessageQueue(java.lang.String sessionId, java.lang.Integer msgId, com.ascio.www._2007._01.holders.ResponseHolder getMessageQueueResult, com.ascio.www._2007._01.holders.QueueItemHolder item) throws java.rmi.RemoteException;
    public void getDnsSecKey(java.lang.String sessionId, java.lang.String dnsSecKeyHandle, com.ascio.www._2007._01.holders.ResponseHolder getDnsSecKeyResult, com.ascio.www._2007._01.holders.DnsSecKeyHolder dnsSecKey) throws java.rmi.RemoteException;
    public com.ascio.www._2007._01.Response createDnsSecKey(java.lang.String sessionId, com.ascio.www._2007._01.holders.DnsSecKeyHolder dnsSecKey) throws java.rmi.RemoteException;
    public void searchDnsSecKey(java.lang.String sessionId, com.ascio.www._2007._01.SearchCriteria criteria, com.ascio.www._2007._01.holders.ResponseHolder searchDnsSecKeyResult, com.ascio.www._2007._01.holders.ArrayOfDnsSecKeyHolder dnsSecKeys) throws java.rmi.RemoteException;
    public void createDocumentation(java.lang.String sessionId, com.ascio.www._2007._01.Attachment[] attachments, com.ascio.www._2007._01.holders.ResponseHolder createDocumentationResult, javax.xml.rpc.holders.IntegerWrapperHolder documentationId) throws java.rmi.RemoteException;
    public void createApprovalDocumentation(java.lang.String sessionId, com.ascio.www._2007._01.ApprovalDocumentation approvalDocumentation, com.ascio.www._2007._01.holders.ResponseHolder createApprovalDocumentationResult, javax.xml.rpc.holders.StringHolder documentationId) throws java.rmi.RemoteException;
}
