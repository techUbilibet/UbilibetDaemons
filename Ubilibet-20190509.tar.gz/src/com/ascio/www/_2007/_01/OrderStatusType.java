/**
 * OrderStatusType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ascio.www._2007._01;

@SuppressWarnings({ "unused", "rawtypes", "serial", "unchecked" })
public class OrderStatusType implements java.io.Serializable {
    private java.lang.String _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    protected OrderStatusType(java.lang.String value) {
        _value_ = value;
        _table_.put(_value_,this);
    }

    public static final java.lang.String _NotSet = "NotSet";
    public static final java.lang.String _Received = "Received";
    public static final java.lang.String _Validated = "Validated";
    public static final java.lang.String _Invalid = "Invalid";
    public static final java.lang.String _Pending = "Pending";
    public static final java.lang.String _Processing = "Processing";
    public static final java.lang.String _Pending_Documentation = "Pending_Documentation";
    public static final java.lang.String _Pending_End_User_Action = "Pending_End_User_Action";
    public static final java.lang.String _Documentation_Received = "Documentation_Received";
    public static final java.lang.String _Documentation_Approved = "Documentation_Approved";
    public static final java.lang.String _Documentation_Not_Approved = "Documentation_Not_Approved";
    public static final java.lang.String _Pending_NIC_Processing = "Pending_NIC_Processing";
    public static final java.lang.String _Pending_NIC_Document_Approval = "Pending_NIC_Document_Approval";
    public static final java.lang.String _Pending_Post_Processing = "Pending_Post_Processing";
    public static final java.lang.String _Pending_Internal_Processing = "Pending_Internal_Processing";
    public static final java.lang.String _Completed = "Completed";
    public static final java.lang.String _Failed = "Failed";
    public static final java.lang.String _Authentication_Failed = "Authentication_Failed";
    public static final OrderStatusType NotSet = new OrderStatusType(_NotSet);
    public static final OrderStatusType Received = new OrderStatusType(_Received);
    public static final OrderStatusType Validated = new OrderStatusType(_Validated);
    public static final OrderStatusType Invalid = new OrderStatusType(_Invalid);
    public static final OrderStatusType Pending = new OrderStatusType(_Pending);
    public static final OrderStatusType Processing = new OrderStatusType(_Processing);
    public static final OrderStatusType Pending_Documentation = new OrderStatusType(_Pending_Documentation);
    public static final OrderStatusType Pending_End_User_Action = new OrderStatusType(_Pending_End_User_Action);
    public static final OrderStatusType Documentation_Received = new OrderStatusType(_Documentation_Received);
    public static final OrderStatusType Documentation_Approved = new OrderStatusType(_Documentation_Approved);
    public static final OrderStatusType Documentation_Not_Approved = new OrderStatusType(_Documentation_Not_Approved);
    public static final OrderStatusType Pending_NIC_Processing = new OrderStatusType(_Pending_NIC_Processing);
    public static final OrderStatusType Pending_NIC_Document_Approval = new OrderStatusType(_Pending_NIC_Document_Approval);
    public static final OrderStatusType Pending_Post_Processing = new OrderStatusType(_Pending_Post_Processing);
    public static final OrderStatusType Pending_Internal_Processing = new OrderStatusType(_Pending_Internal_Processing);
    public static final OrderStatusType Completed = new OrderStatusType(_Completed);
    public static final OrderStatusType Failed = new OrderStatusType(_Failed);
    public static final OrderStatusType Authentication_Failed = new OrderStatusType(_Authentication_Failed);
    public java.lang.String getValue() { return _value_;}
    public static OrderStatusType fromValue(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        OrderStatusType enumeration = (OrderStatusType)
            _table_.get(value);
        if (enumeration==null) throw new java.lang.IllegalArgumentException();
        return enumeration;
    }
    public static OrderStatusType fromString(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        return fromValue(value);
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_;}
    public java.lang.Object readResolve() throws java.io.ObjectStreamException { return fromValue(_value_);}
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumSerializer(
            _javaType, _xmlType);
    }
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumDeserializer(
            _javaType, _xmlType);
    }
    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(OrderStatusType.class);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "OrderStatusType"));
    }
    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

}
