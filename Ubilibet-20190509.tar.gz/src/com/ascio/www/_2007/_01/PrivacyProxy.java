/**
 * PrivacyProxy.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ascio.www._2007._01;

@SuppressWarnings({ "rawtypes", "serial", "unused" })
public class PrivacyProxy  implements java.io.Serializable {
    private com.ascio.www._2007._01.PrivacyProxyType type;

    private java.lang.Boolean privacyAdmin;

    private java.lang.Boolean privacyTech;

    private java.lang.Boolean privacyBilling;

    private com.ascio.www._2007._01.ExtensionsExtension[] extensions;

    public PrivacyProxy() {
    }

    public PrivacyProxy(
           com.ascio.www._2007._01.PrivacyProxyType type,
           java.lang.Boolean privacyAdmin,
           java.lang.Boolean privacyTech,
           java.lang.Boolean privacyBilling,
           com.ascio.www._2007._01.ExtensionsExtension[] extensions) {
           this.type = type;
           this.privacyAdmin = privacyAdmin;
           this.privacyTech = privacyTech;
           this.privacyBilling = privacyBilling;
           this.extensions = extensions;
    }


    /**
     * Gets the type value for this PrivacyProxy.
     * 
     * @return type
     */
    public com.ascio.www._2007._01.PrivacyProxyType getType() {
        return type;
    }


    /**
     * Sets the type value for this PrivacyProxy.
     * 
     * @param type
     */
    public void setType(com.ascio.www._2007._01.PrivacyProxyType type) {
        this.type = type;
    }


    /**
     * Gets the privacyAdmin value for this PrivacyProxy.
     * 
     * @return privacyAdmin
     */
    public java.lang.Boolean getPrivacyAdmin() {
        return privacyAdmin;
    }


    /**
     * Sets the privacyAdmin value for this PrivacyProxy.
     * 
     * @param privacyAdmin
     */
    public void setPrivacyAdmin(java.lang.Boolean privacyAdmin) {
        this.privacyAdmin = privacyAdmin;
    }


    /**
     * Gets the privacyTech value for this PrivacyProxy.
     * 
     * @return privacyTech
     */
    public java.lang.Boolean getPrivacyTech() {
        return privacyTech;
    }


    /**
     * Sets the privacyTech value for this PrivacyProxy.
     * 
     * @param privacyTech
     */
    public void setPrivacyTech(java.lang.Boolean privacyTech) {
        this.privacyTech = privacyTech;
    }


    /**
     * Gets the privacyBilling value for this PrivacyProxy.
     * 
     * @return privacyBilling
     */
    public java.lang.Boolean getPrivacyBilling() {
        return privacyBilling;
    }


    /**
     * Sets the privacyBilling value for this PrivacyProxy.
     * 
     * @param privacyBilling
     */
    public void setPrivacyBilling(java.lang.Boolean privacyBilling) {
        this.privacyBilling = privacyBilling;
    }


    /**
     * Gets the extensions value for this PrivacyProxy.
     * 
     * @return extensions
     */
    public com.ascio.www._2007._01.ExtensionsExtension[] getExtensions() {
        return extensions;
    }


    /**
     * Sets the extensions value for this PrivacyProxy.
     * 
     * @param extensions
     */
    public void setExtensions(com.ascio.www._2007._01.ExtensionsExtension[] extensions) {
        this.extensions = extensions;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof PrivacyProxy)) return false;
        PrivacyProxy other = (PrivacyProxy) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.type==null && other.getType()==null) || 
             (this.type!=null &&
              this.type.equals(other.getType()))) &&
            ((this.privacyAdmin==null && other.getPrivacyAdmin()==null) || 
             (this.privacyAdmin!=null &&
              this.privacyAdmin.equals(other.getPrivacyAdmin()))) &&
            ((this.privacyTech==null && other.getPrivacyTech()==null) || 
             (this.privacyTech!=null &&
              this.privacyTech.equals(other.getPrivacyTech()))) &&
            ((this.privacyBilling==null && other.getPrivacyBilling()==null) || 
             (this.privacyBilling!=null &&
              this.privacyBilling.equals(other.getPrivacyBilling()))) &&
            ((this.extensions==null && other.getExtensions()==null) || 
             (this.extensions!=null &&
              java.util.Arrays.equals(this.extensions, other.getExtensions())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getType() != null) {
            _hashCode += getType().hashCode();
        }
        if (getPrivacyAdmin() != null) {
            _hashCode += getPrivacyAdmin().hashCode();
        }
        if (getPrivacyTech() != null) {
            _hashCode += getPrivacyTech().hashCode();
        }
        if (getPrivacyBilling() != null) {
            _hashCode += getPrivacyBilling().hashCode();
        }
        if (getExtensions() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getExtensions());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getExtensions(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(PrivacyProxy.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "PrivacyProxy"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("type");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Type"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "PrivacyProxyType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("privacyAdmin");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "PrivacyAdmin"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("privacyTech");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "PrivacyTech"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("privacyBilling");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "PrivacyBilling"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("extensions");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Extensions"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", ">Extensions>Extension"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Extension"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
