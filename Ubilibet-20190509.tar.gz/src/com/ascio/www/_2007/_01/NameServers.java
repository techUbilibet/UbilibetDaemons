/**
 * NameServers.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ascio.www._2007._01;

@SuppressWarnings({ "rawtypes", "serial", "unused" })
public class NameServers  implements java.io.Serializable {
    private com.ascio.www._2007._01.NameServer nameServer1;

    private com.ascio.www._2007._01.NameServer nameServer2;

    private com.ascio.www._2007._01.NameServer nameServer3;

    private com.ascio.www._2007._01.NameServer nameServer4;

    private com.ascio.www._2007._01.NameServer nameServer5;

    private com.ascio.www._2007._01.NameServer nameServer6;

    private com.ascio.www._2007._01.NameServer nameServer7;

    private com.ascio.www._2007._01.NameServer nameServer8;

    private com.ascio.www._2007._01.NameServer nameServer9;

    private com.ascio.www._2007._01.NameServer nameServer10;

    private com.ascio.www._2007._01.NameServer nameServer11;

    private com.ascio.www._2007._01.NameServer nameServer12;

    private com.ascio.www._2007._01.NameServer nameServer13;

    public NameServers() {
    }

    public NameServers(
           com.ascio.www._2007._01.NameServer nameServer1,
           com.ascio.www._2007._01.NameServer nameServer2,
           com.ascio.www._2007._01.NameServer nameServer3,
           com.ascio.www._2007._01.NameServer nameServer4,
           com.ascio.www._2007._01.NameServer nameServer5,
           com.ascio.www._2007._01.NameServer nameServer6,
           com.ascio.www._2007._01.NameServer nameServer7,
           com.ascio.www._2007._01.NameServer nameServer8,
           com.ascio.www._2007._01.NameServer nameServer9,
           com.ascio.www._2007._01.NameServer nameServer10,
           com.ascio.www._2007._01.NameServer nameServer11,
           com.ascio.www._2007._01.NameServer nameServer12,
           com.ascio.www._2007._01.NameServer nameServer13) {
           this.nameServer1 = nameServer1;
           this.nameServer2 = nameServer2;
           this.nameServer3 = nameServer3;
           this.nameServer4 = nameServer4;
           this.nameServer5 = nameServer5;
           this.nameServer6 = nameServer6;
           this.nameServer7 = nameServer7;
           this.nameServer8 = nameServer8;
           this.nameServer9 = nameServer9;
           this.nameServer10 = nameServer10;
           this.nameServer11 = nameServer11;
           this.nameServer12 = nameServer12;
           this.nameServer13 = nameServer13;
    }


    /**
     * Gets the nameServer1 value for this NameServers.
     * 
     * @return nameServer1
     */
    public com.ascio.www._2007._01.NameServer getNameServer1() {
        return nameServer1;
    }


    /**
     * Sets the nameServer1 value for this NameServers.
     * 
     * @param nameServer1
     */
    public void setNameServer1(com.ascio.www._2007._01.NameServer nameServer1) {
        this.nameServer1 = nameServer1;
    }


    /**
     * Gets the nameServer2 value for this NameServers.
     * 
     * @return nameServer2
     */
    public com.ascio.www._2007._01.NameServer getNameServer2() {
        return nameServer2;
    }


    /**
     * Sets the nameServer2 value for this NameServers.
     * 
     * @param nameServer2
     */
    public void setNameServer2(com.ascio.www._2007._01.NameServer nameServer2) {
        this.nameServer2 = nameServer2;
    }


    /**
     * Gets the nameServer3 value for this NameServers.
     * 
     * @return nameServer3
     */
    public com.ascio.www._2007._01.NameServer getNameServer3() {
        return nameServer3;
    }


    /**
     * Sets the nameServer3 value for this NameServers.
     * 
     * @param nameServer3
     */
    public void setNameServer3(com.ascio.www._2007._01.NameServer nameServer3) {
        this.nameServer3 = nameServer3;
    }


    /**
     * Gets the nameServer4 value for this NameServers.
     * 
     * @return nameServer4
     */
    public com.ascio.www._2007._01.NameServer getNameServer4() {
        return nameServer4;
    }


    /**
     * Sets the nameServer4 value for this NameServers.
     * 
     * @param nameServer4
     */
    public void setNameServer4(com.ascio.www._2007._01.NameServer nameServer4) {
        this.nameServer4 = nameServer4;
    }


    /**
     * Gets the nameServer5 value for this NameServers.
     * 
     * @return nameServer5
     */
    public com.ascio.www._2007._01.NameServer getNameServer5() {
        return nameServer5;
    }


    /**
     * Sets the nameServer5 value for this NameServers.
     * 
     * @param nameServer5
     */
    public void setNameServer5(com.ascio.www._2007._01.NameServer nameServer5) {
        this.nameServer5 = nameServer5;
    }


    /**
     * Gets the nameServer6 value for this NameServers.
     * 
     * @return nameServer6
     */
    public com.ascio.www._2007._01.NameServer getNameServer6() {
        return nameServer6;
    }


    /**
     * Sets the nameServer6 value for this NameServers.
     * 
     * @param nameServer6
     */
    public void setNameServer6(com.ascio.www._2007._01.NameServer nameServer6) {
        this.nameServer6 = nameServer6;
    }


    /**
     * Gets the nameServer7 value for this NameServers.
     * 
     * @return nameServer7
     */
    public com.ascio.www._2007._01.NameServer getNameServer7() {
        return nameServer7;
    }


    /**
     * Sets the nameServer7 value for this NameServers.
     * 
     * @param nameServer7
     */
    public void setNameServer7(com.ascio.www._2007._01.NameServer nameServer7) {
        this.nameServer7 = nameServer7;
    }


    /**
     * Gets the nameServer8 value for this NameServers.
     * 
     * @return nameServer8
     */
    public com.ascio.www._2007._01.NameServer getNameServer8() {
        return nameServer8;
    }


    /**
     * Sets the nameServer8 value for this NameServers.
     * 
     * @param nameServer8
     */
    public void setNameServer8(com.ascio.www._2007._01.NameServer nameServer8) {
        this.nameServer8 = nameServer8;
    }


    /**
     * Gets the nameServer9 value for this NameServers.
     * 
     * @return nameServer9
     */
    public com.ascio.www._2007._01.NameServer getNameServer9() {
        return nameServer9;
    }


    /**
     * Sets the nameServer9 value for this NameServers.
     * 
     * @param nameServer9
     */
    public void setNameServer9(com.ascio.www._2007._01.NameServer nameServer9) {
        this.nameServer9 = nameServer9;
    }


    /**
     * Gets the nameServer10 value for this NameServers.
     * 
     * @return nameServer10
     */
    public com.ascio.www._2007._01.NameServer getNameServer10() {
        return nameServer10;
    }


    /**
     * Sets the nameServer10 value for this NameServers.
     * 
     * @param nameServer10
     */
    public void setNameServer10(com.ascio.www._2007._01.NameServer nameServer10) {
        this.nameServer10 = nameServer10;
    }


    /**
     * Gets the nameServer11 value for this NameServers.
     * 
     * @return nameServer11
     */
    public com.ascio.www._2007._01.NameServer getNameServer11() {
        return nameServer11;
    }


    /**
     * Sets the nameServer11 value for this NameServers.
     * 
     * @param nameServer11
     */
    public void setNameServer11(com.ascio.www._2007._01.NameServer nameServer11) {
        this.nameServer11 = nameServer11;
    }


    /**
     * Gets the nameServer12 value for this NameServers.
     * 
     * @return nameServer12
     */
    public com.ascio.www._2007._01.NameServer getNameServer12() {
        return nameServer12;
    }


    /**
     * Sets the nameServer12 value for this NameServers.
     * 
     * @param nameServer12
     */
    public void setNameServer12(com.ascio.www._2007._01.NameServer nameServer12) {
        this.nameServer12 = nameServer12;
    }


    /**
     * Gets the nameServer13 value for this NameServers.
     * 
     * @return nameServer13
     */
    public com.ascio.www._2007._01.NameServer getNameServer13() {
        return nameServer13;
    }


    /**
     * Sets the nameServer13 value for this NameServers.
     * 
     * @param nameServer13
     */
    public void setNameServer13(com.ascio.www._2007._01.NameServer nameServer13) {
        this.nameServer13 = nameServer13;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof NameServers)) return false;
        NameServers other = (NameServers) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.nameServer1==null && other.getNameServer1()==null) || 
             (this.nameServer1!=null &&
              this.nameServer1.equals(other.getNameServer1()))) &&
            ((this.nameServer2==null && other.getNameServer2()==null) || 
             (this.nameServer2!=null &&
              this.nameServer2.equals(other.getNameServer2()))) &&
            ((this.nameServer3==null && other.getNameServer3()==null) || 
             (this.nameServer3!=null &&
              this.nameServer3.equals(other.getNameServer3()))) &&
            ((this.nameServer4==null && other.getNameServer4()==null) || 
             (this.nameServer4!=null &&
              this.nameServer4.equals(other.getNameServer4()))) &&
            ((this.nameServer5==null && other.getNameServer5()==null) || 
             (this.nameServer5!=null &&
              this.nameServer5.equals(other.getNameServer5()))) &&
            ((this.nameServer6==null && other.getNameServer6()==null) || 
             (this.nameServer6!=null &&
              this.nameServer6.equals(other.getNameServer6()))) &&
            ((this.nameServer7==null && other.getNameServer7()==null) || 
             (this.nameServer7!=null &&
              this.nameServer7.equals(other.getNameServer7()))) &&
            ((this.nameServer8==null && other.getNameServer8()==null) || 
             (this.nameServer8!=null &&
              this.nameServer8.equals(other.getNameServer8()))) &&
            ((this.nameServer9==null && other.getNameServer9()==null) || 
             (this.nameServer9!=null &&
              this.nameServer9.equals(other.getNameServer9()))) &&
            ((this.nameServer10==null && other.getNameServer10()==null) || 
             (this.nameServer10!=null &&
              this.nameServer10.equals(other.getNameServer10()))) &&
            ((this.nameServer11==null && other.getNameServer11()==null) || 
             (this.nameServer11!=null &&
              this.nameServer11.equals(other.getNameServer11()))) &&
            ((this.nameServer12==null && other.getNameServer12()==null) || 
             (this.nameServer12!=null &&
              this.nameServer12.equals(other.getNameServer12()))) &&
            ((this.nameServer13==null && other.getNameServer13()==null) || 
             (this.nameServer13!=null &&
              this.nameServer13.equals(other.getNameServer13())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getNameServer1() != null) {
            _hashCode += getNameServer1().hashCode();
        }
        if (getNameServer2() != null) {
            _hashCode += getNameServer2().hashCode();
        }
        if (getNameServer3() != null) {
            _hashCode += getNameServer3().hashCode();
        }
        if (getNameServer4() != null) {
            _hashCode += getNameServer4().hashCode();
        }
        if (getNameServer5() != null) {
            _hashCode += getNameServer5().hashCode();
        }
        if (getNameServer6() != null) {
            _hashCode += getNameServer6().hashCode();
        }
        if (getNameServer7() != null) {
            _hashCode += getNameServer7().hashCode();
        }
        if (getNameServer8() != null) {
            _hashCode += getNameServer8().hashCode();
        }
        if (getNameServer9() != null) {
            _hashCode += getNameServer9().hashCode();
        }
        if (getNameServer10() != null) {
            _hashCode += getNameServer10().hashCode();
        }
        if (getNameServer11() != null) {
            _hashCode += getNameServer11().hashCode();
        }
        if (getNameServer12() != null) {
            _hashCode += getNameServer12().hashCode();
        }
        if (getNameServer13() != null) {
            _hashCode += getNameServer13().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(NameServers.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "NameServers"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nameServer1");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "NameServer1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "NameServer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nameServer2");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "NameServer2"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "NameServer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nameServer3");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "NameServer3"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "NameServer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nameServer4");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "NameServer4"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "NameServer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nameServer5");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "NameServer5"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "NameServer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nameServer6");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "NameServer6"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "NameServer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nameServer7");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "NameServer7"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "NameServer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nameServer8");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "NameServer8"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "NameServer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nameServer9");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "NameServer9"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "NameServer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nameServer10");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "NameServer10"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "NameServer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nameServer11");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "NameServer11"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "NameServer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nameServer12");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "NameServer12"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "NameServer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nameServer13");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "NameServer13"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "NameServer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
