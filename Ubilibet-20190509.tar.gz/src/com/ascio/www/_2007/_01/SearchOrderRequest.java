/**
 * SearchOrderRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ascio.www._2007._01;

@SuppressWarnings({ "rawtypes", "serial", "unused" })
public class SearchOrderRequest  implements java.io.Serializable {
    private com.ascio.www._2007._01.OrderType[] orderTypes;

    private com.ascio.www._2007._01.OrderStatusType[] orderStatusTypes;

    private java.util.Calendar fromDate;

    private java.util.Calendar toDate;

    private java.lang.String domainName;

    private java.lang.String transactionComment;

    private java.lang.String comments;

    private java.lang.Boolean includeDomainDetails;

    private com.ascio.www._2007._01.PagingInfo pageInfo;

    private com.ascio.www._2007._01.SearchOrderSortType orderSort;

    public SearchOrderRequest() {
    }

    public SearchOrderRequest(
           com.ascio.www._2007._01.OrderType[] orderTypes,
           com.ascio.www._2007._01.OrderStatusType[] orderStatusTypes,
           java.util.Calendar fromDate,
           java.util.Calendar toDate,
           java.lang.String domainName,
           java.lang.String transactionComment,
           java.lang.String comments,
           java.lang.Boolean includeDomainDetails,
           com.ascio.www._2007._01.PagingInfo pageInfo,
           com.ascio.www._2007._01.SearchOrderSortType orderSort) {
           this.orderTypes = orderTypes;
           this.orderStatusTypes = orderStatusTypes;
           this.fromDate = fromDate;
           this.toDate = toDate;
           this.domainName = domainName;
           this.transactionComment = transactionComment;
           this.comments = comments;
           this.includeDomainDetails = includeDomainDetails;
           this.pageInfo = pageInfo;
           this.orderSort = orderSort;
    }


    /**
     * Gets the orderTypes value for this SearchOrderRequest.
     * 
     * @return orderTypes
     */
    public com.ascio.www._2007._01.OrderType[] getOrderTypes() {
        return orderTypes;
    }


    /**
     * Sets the orderTypes value for this SearchOrderRequest.
     * 
     * @param orderTypes
     */
    public void setOrderTypes(com.ascio.www._2007._01.OrderType[] orderTypes) {
        this.orderTypes = orderTypes;
    }


    /**
     * Gets the orderStatusTypes value for this SearchOrderRequest.
     * 
     * @return orderStatusTypes
     */
    public com.ascio.www._2007._01.OrderStatusType[] getOrderStatusTypes() {
        return orderStatusTypes;
    }


    /**
     * Sets the orderStatusTypes value for this SearchOrderRequest.
     * 
     * @param orderStatusTypes
     */
    public void setOrderStatusTypes(com.ascio.www._2007._01.OrderStatusType[] orderStatusTypes) {
        this.orderStatusTypes = orderStatusTypes;
    }


    /**
     * Gets the fromDate value for this SearchOrderRequest.
     * 
     * @return fromDate
     */
    public java.util.Calendar getFromDate() {
        return fromDate;
    }


    /**
     * Sets the fromDate value for this SearchOrderRequest.
     * 
     * @param fromDate
     */
    public void setFromDate(java.util.Calendar fromDate) {
        this.fromDate = fromDate;
    }


    /**
     * Gets the toDate value for this SearchOrderRequest.
     * 
     * @return toDate
     */
    public java.util.Calendar getToDate() {
        return toDate;
    }


    /**
     * Sets the toDate value for this SearchOrderRequest.
     * 
     * @param toDate
     */
    public void setToDate(java.util.Calendar toDate) {
        this.toDate = toDate;
    }


    /**
     * Gets the domainName value for this SearchOrderRequest.
     * 
     * @return domainName
     */
    public java.lang.String getDomainName() {
        return domainName;
    }


    /**
     * Sets the domainName value for this SearchOrderRequest.
     * 
     * @param domainName
     */
    public void setDomainName(java.lang.String domainName) {
        this.domainName = domainName;
    }


    /**
     * Gets the transactionComment value for this SearchOrderRequest.
     * 
     * @return transactionComment
     */
    public java.lang.String getTransactionComment() {
        return transactionComment;
    }


    /**
     * Sets the transactionComment value for this SearchOrderRequest.
     * 
     * @param transactionComment
     */
    public void setTransactionComment(java.lang.String transactionComment) {
        this.transactionComment = transactionComment;
    }


    /**
     * Gets the comments value for this SearchOrderRequest.
     * 
     * @return comments
     */
    public java.lang.String getComments() {
        return comments;
    }


    /**
     * Sets the comments value for this SearchOrderRequest.
     * 
     * @param comments
     */
    public void setComments(java.lang.String comments) {
        this.comments = comments;
    }


    /**
     * Gets the includeDomainDetails value for this SearchOrderRequest.
     * 
     * @return includeDomainDetails
     */
    public java.lang.Boolean getIncludeDomainDetails() {
        return includeDomainDetails;
    }


    /**
     * Sets the includeDomainDetails value for this SearchOrderRequest.
     * 
     * @param includeDomainDetails
     */
    public void setIncludeDomainDetails(java.lang.Boolean includeDomainDetails) {
        this.includeDomainDetails = includeDomainDetails;
    }


    /**
     * Gets the pageInfo value for this SearchOrderRequest.
     * 
     * @return pageInfo
     */
    public com.ascio.www._2007._01.PagingInfo getPageInfo() {
        return pageInfo;
    }


    /**
     * Sets the pageInfo value for this SearchOrderRequest.
     * 
     * @param pageInfo
     */
    public void setPageInfo(com.ascio.www._2007._01.PagingInfo pageInfo) {
        this.pageInfo = pageInfo;
    }


    /**
     * Gets the orderSort value for this SearchOrderRequest.
     * 
     * @return orderSort
     */
    public com.ascio.www._2007._01.SearchOrderSortType getOrderSort() {
        return orderSort;
    }


    /**
     * Sets the orderSort value for this SearchOrderRequest.
     * 
     * @param orderSort
     */
    public void setOrderSort(com.ascio.www._2007._01.SearchOrderSortType orderSort) {
        this.orderSort = orderSort;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof SearchOrderRequest)) return false;
        SearchOrderRequest other = (SearchOrderRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.orderTypes==null && other.getOrderTypes()==null) || 
             (this.orderTypes!=null &&
              java.util.Arrays.equals(this.orderTypes, other.getOrderTypes()))) &&
            ((this.orderStatusTypes==null && other.getOrderStatusTypes()==null) || 
             (this.orderStatusTypes!=null &&
              java.util.Arrays.equals(this.orderStatusTypes, other.getOrderStatusTypes()))) &&
            ((this.fromDate==null && other.getFromDate()==null) || 
             (this.fromDate!=null &&
              this.fromDate.equals(other.getFromDate()))) &&
            ((this.toDate==null && other.getToDate()==null) || 
             (this.toDate!=null &&
              this.toDate.equals(other.getToDate()))) &&
            ((this.domainName==null && other.getDomainName()==null) || 
             (this.domainName!=null &&
              this.domainName.equals(other.getDomainName()))) &&
            ((this.transactionComment==null && other.getTransactionComment()==null) || 
             (this.transactionComment!=null &&
              this.transactionComment.equals(other.getTransactionComment()))) &&
            ((this.comments==null && other.getComments()==null) || 
             (this.comments!=null &&
              this.comments.equals(other.getComments()))) &&
            ((this.includeDomainDetails==null && other.getIncludeDomainDetails()==null) || 
             (this.includeDomainDetails!=null &&
              this.includeDomainDetails.equals(other.getIncludeDomainDetails()))) &&
            ((this.pageInfo==null && other.getPageInfo()==null) || 
             (this.pageInfo!=null &&
              this.pageInfo.equals(other.getPageInfo()))) &&
            ((this.orderSort==null && other.getOrderSort()==null) || 
             (this.orderSort!=null &&
              this.orderSort.equals(other.getOrderSort())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getOrderTypes() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getOrderTypes());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getOrderTypes(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getOrderStatusTypes() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getOrderStatusTypes());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getOrderStatusTypes(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getFromDate() != null) {
            _hashCode += getFromDate().hashCode();
        }
        if (getToDate() != null) {
            _hashCode += getToDate().hashCode();
        }
        if (getDomainName() != null) {
            _hashCode += getDomainName().hashCode();
        }
        if (getTransactionComment() != null) {
            _hashCode += getTransactionComment().hashCode();
        }
        if (getComments() != null) {
            _hashCode += getComments().hashCode();
        }
        if (getIncludeDomainDetails() != null) {
            _hashCode += getIncludeDomainDetails().hashCode();
        }
        if (getPageInfo() != null) {
            _hashCode += getPageInfo().hashCode();
        }
        if (getOrderSort() != null) {
            _hashCode += getOrderSort().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(SearchOrderRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "SearchOrderRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderTypes");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "OrderTypes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "OrderType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "OrderType"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderStatusTypes");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "OrderStatusTypes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "OrderStatusType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "OrderStatusType"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fromDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "FromDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("toDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "ToDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("domainName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "DomainName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transactionComment");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "TransactionComment"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("comments");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Comments"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("includeDomainDetails");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "IncludeDomainDetails"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("pageInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "PageInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "PagingInfo"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderSort");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "OrderSort"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "SearchOrderSortType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
