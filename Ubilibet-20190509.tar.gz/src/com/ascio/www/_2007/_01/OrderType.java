/**
 * OrderType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ascio.www._2007._01;

@SuppressWarnings({ "unused", "rawtypes", "serial", "unchecked" })
public class OrderType implements java.io.Serializable {
    private java.lang.String _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    protected OrderType(java.lang.String value) {
        _value_ = value;
        _table_.put(_value_,this);
    }

    public static final java.lang.String _NotSet = "NotSet";
    public static final java.lang.String _Contact_Update = "Contact_Update";
    public static final java.lang.String _Change_Locks = "Change_Locks";
    public static final java.lang.String _Delete_Domain = "Delete_Domain";
    public static final java.lang.String _Registrant_Details_Update = "Registrant_Details_Update";
    public static final java.lang.String _Expire_Domain = "Expire_Domain";
    public static final java.lang.String _Nameserver_Update = "Nameserver_Update";
    public static final java.lang.String _Owner_Change = "Owner_Change";
    public static final java.lang.String _Queue_Domain = "Queue_Domain";
    public static final java.lang.String _Register_Domain = "Register_Domain";
    public static final java.lang.String _Renew_Domain = "Renew_Domain";
    public static final java.lang.String _Restore_Domain = "Restore_Domain";
    public static final java.lang.String _Transfer_Domain = "Transfer_Domain";
    public static final java.lang.String _Unexpire_Domain = "Unexpire_Domain";
    public static final java.lang.String _Transfer_Away = "Transfer_Away";
    public static final java.lang.String _Autorenew_Domain = "Autorenew_Domain";
    public static final java.lang.String _Autodelete_Domain = "Autodelete_Domain";
    public static final java.lang.String _Defensive_Registration = "Defensive_Registration";
    public static final java.lang.String _Name_Watch = "Name_Watch";
    public static final java.lang.String _Domain_Details_Update = "Domain_Details_Update";
    public static final java.lang.String _Import_Domain = "Import_Domain";
    public static final java.lang.String _Partner_Change = "Partner_Change";
    public static final java.lang.String _Support = "Support";
    public static final java.lang.String _DeQueue = "DeQueue";
    public static final java.lang.String _Update_AuthInfo = "Update_AuthInfo";
    public static final OrderType NotSet = new OrderType(_NotSet);
    public static final OrderType Contact_Update = new OrderType(_Contact_Update);
    public static final OrderType Change_Locks = new OrderType(_Change_Locks);
    public static final OrderType Delete_Domain = new OrderType(_Delete_Domain);
    public static final OrderType Registrant_Details_Update = new OrderType(_Registrant_Details_Update);
    public static final OrderType Expire_Domain = new OrderType(_Expire_Domain);
    public static final OrderType Nameserver_Update = new OrderType(_Nameserver_Update);
    public static final OrderType Owner_Change = new OrderType(_Owner_Change);
    public static final OrderType Queue_Domain = new OrderType(_Queue_Domain);
    public static final OrderType Register_Domain = new OrderType(_Register_Domain);
    public static final OrderType Renew_Domain = new OrderType(_Renew_Domain);
    public static final OrderType Restore_Domain = new OrderType(_Restore_Domain);
    public static final OrderType Transfer_Domain = new OrderType(_Transfer_Domain);
    public static final OrderType Unexpire_Domain = new OrderType(_Unexpire_Domain);
    public static final OrderType Transfer_Away = new OrderType(_Transfer_Away);
    public static final OrderType Autorenew_Domain = new OrderType(_Autorenew_Domain);
    public static final OrderType Autodelete_Domain = new OrderType(_Autodelete_Domain);
    public static final OrderType Defensive_Registration = new OrderType(_Defensive_Registration);
    public static final OrderType Name_Watch = new OrderType(_Name_Watch);
    public static final OrderType Domain_Details_Update = new OrderType(_Domain_Details_Update);
    public static final OrderType Import_Domain = new OrderType(_Import_Domain);
    public static final OrderType Partner_Change = new OrderType(_Partner_Change);
    public static final OrderType Support = new OrderType(_Support);
    public static final OrderType DeQueue = new OrderType(_DeQueue);
    public static final OrderType Update_AuthInfo = new OrderType(_Update_AuthInfo);
    public java.lang.String getValue() { return _value_;}
    public static OrderType fromValue(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        OrderType enumeration = (OrderType)
            _table_.get(value);
        if (enumeration==null) throw new java.lang.IllegalArgumentException();
        return enumeration;
    }
    public static OrderType fromString(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        return fromValue(value);
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_;}
    public java.lang.Object readResolve() throws java.io.ObjectStreamException { return fromValue(_value_);}
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumSerializer(
            _javaType, _xmlType);
    }
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumDeserializer(
            _javaType, _xmlType);
    }
    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(OrderType.class);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "OrderType"));
    }
    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

}
