/**
 * RegistrantVerificationDetails.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ascio.www._2007._01;

@SuppressWarnings({ "rawtypes", "serial", "unused" })
public class RegistrantVerificationDetails  implements java.io.Serializable {
    private java.lang.String verifiedBy;

    private java.util.Calendar verificationDate;

    private com.ascio.www._2007._01.Message[] messages;

    public RegistrantVerificationDetails() {
    }

    public RegistrantVerificationDetails(
           java.lang.String verifiedBy,
           java.util.Calendar verificationDate,
           com.ascio.www._2007._01.Message[] messages) {
           this.verifiedBy = verifiedBy;
           this.verificationDate = verificationDate;
           this.messages = messages;
    }


    /**
     * Gets the verifiedBy value for this RegistrantVerificationDetails.
     * 
     * @return verifiedBy
     */
    public java.lang.String getVerifiedBy() {
        return verifiedBy;
    }


    /**
     * Sets the verifiedBy value for this RegistrantVerificationDetails.
     * 
     * @param verifiedBy
     */
    public void setVerifiedBy(java.lang.String verifiedBy) {
        this.verifiedBy = verifiedBy;
    }


    /**
     * Gets the verificationDate value for this RegistrantVerificationDetails.
     * 
     * @return verificationDate
     */
    public java.util.Calendar getVerificationDate() {
        return verificationDate;
    }


    /**
     * Sets the verificationDate value for this RegistrantVerificationDetails.
     * 
     * @param verificationDate
     */
    public void setVerificationDate(java.util.Calendar verificationDate) {
        this.verificationDate = verificationDate;
    }


    /**
     * Gets the messages value for this RegistrantVerificationDetails.
     * 
     * @return messages
     */
    public com.ascio.www._2007._01.Message[] getMessages() {
        return messages;
    }


    /**
     * Sets the messages value for this RegistrantVerificationDetails.
     * 
     * @param messages
     */
    public void setMessages(com.ascio.www._2007._01.Message[] messages) {
        this.messages = messages;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof RegistrantVerificationDetails)) return false;
        RegistrantVerificationDetails other = (RegistrantVerificationDetails) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.verifiedBy==null && other.getVerifiedBy()==null) || 
             (this.verifiedBy!=null &&
              this.verifiedBy.equals(other.getVerifiedBy()))) &&
            ((this.verificationDate==null && other.getVerificationDate()==null) || 
             (this.verificationDate!=null &&
              this.verificationDate.equals(other.getVerificationDate()))) &&
            ((this.messages==null && other.getMessages()==null) || 
             (this.messages!=null &&
              java.util.Arrays.equals(this.messages, other.getMessages())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getVerifiedBy() != null) {
            _hashCode += getVerifiedBy().hashCode();
        }
        if (getVerificationDate() != null) {
            _hashCode += getVerificationDate().hashCode();
        }
        if (getMessages() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getMessages());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getMessages(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(RegistrantVerificationDetails.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "RegistrantVerificationDetails"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("verifiedBy");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "VerifiedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("verificationDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "VerificationDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("messages");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Messages"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Message"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Message"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
