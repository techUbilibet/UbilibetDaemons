/**
 * RegistrantHolder.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ascio.www._2007._01.holders;

public final class RegistrantHolder implements javax.xml.rpc.holders.Holder {
    public com.ascio.www._2007._01.Registrant value;

    public RegistrantHolder() {
    }

    public RegistrantHolder(com.ascio.www._2007._01.Registrant value) {
        this.value = value;
    }

}
