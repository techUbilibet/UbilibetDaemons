/**
 * ArrayOfOrderHolder.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ascio.www._2007._01.holders;

public final class ArrayOfOrderHolder implements javax.xml.rpc.holders.Holder {
    public com.ascio.www._2007._01.Order[] value;

    public ArrayOfOrderHolder() {
    }

    public ArrayOfOrderHolder(com.ascio.www._2007._01.Order[] value) {
        this.value = value;
    }

}
