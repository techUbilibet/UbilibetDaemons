/**
 * RegistrantVerificationInfoHolder.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ascio.www._2007._01.holders;

public final class RegistrantVerificationInfoHolder implements javax.xml.rpc.holders.Holder {
    public com.ascio.www._2007._01.RegistrantVerificationInfo value;

    public RegistrantVerificationInfoHolder() {
    }

    public RegistrantVerificationInfoHolder(com.ascio.www._2007._01.RegistrantVerificationInfo value) {
        this.value = value;
    }

}
