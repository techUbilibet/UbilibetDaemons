/**
 * DnsSecKey.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ascio.www._2007._01;

@SuppressWarnings({ "rawtypes", "serial", "unused" })
public class DnsSecKey  implements java.io.Serializable {
    private java.lang.String handle;

    private java.lang.String status;

    private java.lang.String digestAlgorithm;

    private java.lang.String digestType;

    private java.lang.String digest;

    private java.lang.String protocol;

    private java.lang.String keyType;

    private java.lang.String keyAlgorithm;

    private java.lang.String keyTag;

    private java.lang.String publicKey;

    private java.lang.String creDate;

    public DnsSecKey() {
    }

    public DnsSecKey(
           java.lang.String handle,
           java.lang.String status,
           java.lang.String digestAlgorithm,
           java.lang.String digestType,
           java.lang.String digest,
           java.lang.String protocol,
           java.lang.String keyType,
           java.lang.String keyAlgorithm,
           java.lang.String keyTag,
           java.lang.String publicKey,
           java.lang.String creDate) {
           this.handle = handle;
           this.status = status;
           this.digestAlgorithm = digestAlgorithm;
           this.digestType = digestType;
           this.digest = digest;
           this.protocol = protocol;
           this.keyType = keyType;
           this.keyAlgorithm = keyAlgorithm;
           this.keyTag = keyTag;
           this.publicKey = publicKey;
           this.creDate = creDate;
    }


    /**
     * Gets the handle value for this DnsSecKey.
     * 
     * @return handle
     */
    public java.lang.String getHandle() {
        return handle;
    }


    /**
     * Sets the handle value for this DnsSecKey.
     * 
     * @param handle
     */
    public void setHandle(java.lang.String handle) {
        this.handle = handle;
    }


    /**
     * Gets the status value for this DnsSecKey.
     * 
     * @return status
     */
    public java.lang.String getStatus() {
        return status;
    }


    /**
     * Sets the status value for this DnsSecKey.
     * 
     * @param status
     */
    public void setStatus(java.lang.String status) {
        this.status = status;
    }


    /**
     * Gets the digestAlgorithm value for this DnsSecKey.
     * 
     * @return digestAlgorithm
     */
    public java.lang.String getDigestAlgorithm() {
        return digestAlgorithm;
    }


    /**
     * Sets the digestAlgorithm value for this DnsSecKey.
     * 
     * @param digestAlgorithm
     */
    public void setDigestAlgorithm(java.lang.String digestAlgorithm) {
        this.digestAlgorithm = digestAlgorithm;
    }


    /**
     * Gets the digestType value for this DnsSecKey.
     * 
     * @return digestType
     */
    public java.lang.String getDigestType() {
        return digestType;
    }


    /**
     * Sets the digestType value for this DnsSecKey.
     * 
     * @param digestType
     */
    public void setDigestType(java.lang.String digestType) {
        this.digestType = digestType;
    }


    /**
     * Gets the digest value for this DnsSecKey.
     * 
     * @return digest
     */
    public java.lang.String getDigest() {
        return digest;
    }


    /**
     * Sets the digest value for this DnsSecKey.
     * 
     * @param digest
     */
    public void setDigest(java.lang.String digest) {
        this.digest = digest;
    }


    /**
     * Gets the protocol value for this DnsSecKey.
     * 
     * @return protocol
     */
    public java.lang.String getProtocol() {
        return protocol;
    }


    /**
     * Sets the protocol value for this DnsSecKey.
     * 
     * @param protocol
     */
    public void setProtocol(java.lang.String protocol) {
        this.protocol = protocol;
    }


    /**
     * Gets the keyType value for this DnsSecKey.
     * 
     * @return keyType
     */
    public java.lang.String getKeyType() {
        return keyType;
    }


    /**
     * Sets the keyType value for this DnsSecKey.
     * 
     * @param keyType
     */
    public void setKeyType(java.lang.String keyType) {
        this.keyType = keyType;
    }


    /**
     * Gets the keyAlgorithm value for this DnsSecKey.
     * 
     * @return keyAlgorithm
     */
    public java.lang.String getKeyAlgorithm() {
        return keyAlgorithm;
    }


    /**
     * Sets the keyAlgorithm value for this DnsSecKey.
     * 
     * @param keyAlgorithm
     */
    public void setKeyAlgorithm(java.lang.String keyAlgorithm) {
        this.keyAlgorithm = keyAlgorithm;
    }


    /**
     * Gets the keyTag value for this DnsSecKey.
     * 
     * @return keyTag
     */
    public java.lang.String getKeyTag() {
        return keyTag;
    }


    /**
     * Sets the keyTag value for this DnsSecKey.
     * 
     * @param keyTag
     */
    public void setKeyTag(java.lang.String keyTag) {
        this.keyTag = keyTag;
    }


    /**
     * Gets the publicKey value for this DnsSecKey.
     * 
     * @return publicKey
     */
    public java.lang.String getPublicKey() {
        return publicKey;
    }


    /**
     * Sets the publicKey value for this DnsSecKey.
     * 
     * @param publicKey
     */
    public void setPublicKey(java.lang.String publicKey) {
        this.publicKey = publicKey;
    }


    /**
     * Gets the creDate value for this DnsSecKey.
     * 
     * @return creDate
     */
    public java.lang.String getCreDate() {
        return creDate;
    }


    /**
     * Sets the creDate value for this DnsSecKey.
     * 
     * @param creDate
     */
    public void setCreDate(java.lang.String creDate) {
        this.creDate = creDate;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof DnsSecKey)) return false;
        DnsSecKey other = (DnsSecKey) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.handle==null && other.getHandle()==null) || 
             (this.handle!=null &&
              this.handle.equals(other.getHandle()))) &&
            ((this.status==null && other.getStatus()==null) || 
             (this.status!=null &&
              this.status.equals(other.getStatus()))) &&
            ((this.digestAlgorithm==null && other.getDigestAlgorithm()==null) || 
             (this.digestAlgorithm!=null &&
              this.digestAlgorithm.equals(other.getDigestAlgorithm()))) &&
            ((this.digestType==null && other.getDigestType()==null) || 
             (this.digestType!=null &&
              this.digestType.equals(other.getDigestType()))) &&
            ((this.digest==null && other.getDigest()==null) || 
             (this.digest!=null &&
              this.digest.equals(other.getDigest()))) &&
            ((this.protocol==null && other.getProtocol()==null) || 
             (this.protocol!=null &&
              this.protocol.equals(other.getProtocol()))) &&
            ((this.keyType==null && other.getKeyType()==null) || 
             (this.keyType!=null &&
              this.keyType.equals(other.getKeyType()))) &&
            ((this.keyAlgorithm==null && other.getKeyAlgorithm()==null) || 
             (this.keyAlgorithm!=null &&
              this.keyAlgorithm.equals(other.getKeyAlgorithm()))) &&
            ((this.keyTag==null && other.getKeyTag()==null) || 
             (this.keyTag!=null &&
              this.keyTag.equals(other.getKeyTag()))) &&
            ((this.publicKey==null && other.getPublicKey()==null) || 
             (this.publicKey!=null &&
              this.publicKey.equals(other.getPublicKey()))) &&
            ((this.creDate==null && other.getCreDate()==null) || 
             (this.creDate!=null &&
              this.creDate.equals(other.getCreDate())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getHandle() != null) {
            _hashCode += getHandle().hashCode();
        }
        if (getStatus() != null) {
            _hashCode += getStatus().hashCode();
        }
        if (getDigestAlgorithm() != null) {
            _hashCode += getDigestAlgorithm().hashCode();
        }
        if (getDigestType() != null) {
            _hashCode += getDigestType().hashCode();
        }
        if (getDigest() != null) {
            _hashCode += getDigest().hashCode();
        }
        if (getProtocol() != null) {
            _hashCode += getProtocol().hashCode();
        }
        if (getKeyType() != null) {
            _hashCode += getKeyType().hashCode();
        }
        if (getKeyAlgorithm() != null) {
            _hashCode += getKeyAlgorithm().hashCode();
        }
        if (getKeyTag() != null) {
            _hashCode += getKeyTag().hashCode();
        }
        if (getPublicKey() != null) {
            _hashCode += getPublicKey().hashCode();
        }
        if (getCreDate() != null) {
            _hashCode += getCreDate().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(DnsSecKey.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "DnsSecKey"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("handle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Handle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("status");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Status"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("digestAlgorithm");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "DigestAlgorithm"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("digestType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "DigestType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("digest");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Digest"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("protocol");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Protocol"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("keyType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "KeyType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("keyAlgorithm");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "KeyAlgorithm"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("keyTag");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "KeyTag"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("publicKey");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "PublicKey"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("creDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "CreDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
