/**
 * TradeMark.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ascio.www._2007._01;

@SuppressWarnings({ "rawtypes", "serial", "unused" })
public class TradeMark  implements java.io.Serializable {
    private java.lang.String name;

    private java.lang.String country;

    private java.util.Calendar date;

    private java.lang.String number;

    private java.lang.String type;

    private java.lang.String contact;

    private java.lang.String contactLanguage;

    private java.lang.String documentationLanguage;

    private java.lang.String secondContact;

    private java.lang.String thirdContact;

    private java.util.Calendar regDate;

    public TradeMark() {
    }

    public TradeMark(
           java.lang.String name,
           java.lang.String country,
           java.util.Calendar date,
           java.lang.String number,
           java.lang.String type,
           java.lang.String contact,
           java.lang.String contactLanguage,
           java.lang.String documentationLanguage,
           java.lang.String secondContact,
           java.lang.String thirdContact,
           java.util.Calendar regDate) {
           this.name = name;
           this.country = country;
           this.date = date;
           this.number = number;
           this.type = type;
           this.contact = contact;
           this.contactLanguage = contactLanguage;
           this.documentationLanguage = documentationLanguage;
           this.secondContact = secondContact;
           this.thirdContact = thirdContact;
           this.regDate = regDate;
    }


    /**
     * Gets the name value for this TradeMark.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this TradeMark.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the country value for this TradeMark.
     * 
     * @return country
     */
    public java.lang.String getCountry() {
        return country;
    }


    /**
     * Sets the country value for this TradeMark.
     * 
     * @param country
     */
    public void setCountry(java.lang.String country) {
        this.country = country;
    }


    /**
     * Gets the date value for this TradeMark.
     * 
     * @return date
     */
    public java.util.Calendar getDate() {
        return date;
    }


    /**
     * Sets the date value for this TradeMark.
     * 
     * @param date
     */
    public void setDate(java.util.Calendar date) {
        this.date = date;
    }


    /**
     * Gets the number value for this TradeMark.
     * 
     * @return number
     */
    public java.lang.String getNumber() {
        return number;
    }


    /**
     * Sets the number value for this TradeMark.
     * 
     * @param number
     */
    public void setNumber(java.lang.String number) {
        this.number = number;
    }


    /**
     * Gets the type value for this TradeMark.
     * 
     * @return type
     */
    public java.lang.String getType() {
        return type;
    }


    /**
     * Sets the type value for this TradeMark.
     * 
     * @param type
     */
    public void setType(java.lang.String type) {
        this.type = type;
    }


    /**
     * Gets the contact value for this TradeMark.
     * 
     * @return contact
     */
    public java.lang.String getContact() {
        return contact;
    }


    /**
     * Sets the contact value for this TradeMark.
     * 
     * @param contact
     */
    public void setContact(java.lang.String contact) {
        this.contact = contact;
    }


    /**
     * Gets the contactLanguage value for this TradeMark.
     * 
     * @return contactLanguage
     */
    public java.lang.String getContactLanguage() {
        return contactLanguage;
    }


    /**
     * Sets the contactLanguage value for this TradeMark.
     * 
     * @param contactLanguage
     */
    public void setContactLanguage(java.lang.String contactLanguage) {
        this.contactLanguage = contactLanguage;
    }


    /**
     * Gets the documentationLanguage value for this TradeMark.
     * 
     * @return documentationLanguage
     */
    public java.lang.String getDocumentationLanguage() {
        return documentationLanguage;
    }


    /**
     * Sets the documentationLanguage value for this TradeMark.
     * 
     * @param documentationLanguage
     */
    public void setDocumentationLanguage(java.lang.String documentationLanguage) {
        this.documentationLanguage = documentationLanguage;
    }


    /**
     * Gets the secondContact value for this TradeMark.
     * 
     * @return secondContact
     */
    public java.lang.String getSecondContact() {
        return secondContact;
    }


    /**
     * Sets the secondContact value for this TradeMark.
     * 
     * @param secondContact
     */
    public void setSecondContact(java.lang.String secondContact) {
        this.secondContact = secondContact;
    }


    /**
     * Gets the thirdContact value for this TradeMark.
     * 
     * @return thirdContact
     */
    public java.lang.String getThirdContact() {
        return thirdContact;
    }


    /**
     * Sets the thirdContact value for this TradeMark.
     * 
     * @param thirdContact
     */
    public void setThirdContact(java.lang.String thirdContact) {
        this.thirdContact = thirdContact;
    }


    /**
     * Gets the regDate value for this TradeMark.
     * 
     * @return regDate
     */
    public java.util.Calendar getRegDate() {
        return regDate;
    }


    /**
     * Sets the regDate value for this TradeMark.
     * 
     * @param regDate
     */
    public void setRegDate(java.util.Calendar regDate) {
        this.regDate = regDate;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof TradeMark)) return false;
        TradeMark other = (TradeMark) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.country==null && other.getCountry()==null) || 
             (this.country!=null &&
              this.country.equals(other.getCountry()))) &&
            ((this.date==null && other.getDate()==null) || 
             (this.date!=null &&
              this.date.equals(other.getDate()))) &&
            ((this.number==null && other.getNumber()==null) || 
             (this.number!=null &&
              this.number.equals(other.getNumber()))) &&
            ((this.type==null && other.getType()==null) || 
             (this.type!=null &&
              this.type.equals(other.getType()))) &&
            ((this.contact==null && other.getContact()==null) || 
             (this.contact!=null &&
              this.contact.equals(other.getContact()))) &&
            ((this.contactLanguage==null && other.getContactLanguage()==null) || 
             (this.contactLanguage!=null &&
              this.contactLanguage.equals(other.getContactLanguage()))) &&
            ((this.documentationLanguage==null && other.getDocumentationLanguage()==null) || 
             (this.documentationLanguage!=null &&
              this.documentationLanguage.equals(other.getDocumentationLanguage()))) &&
            ((this.secondContact==null && other.getSecondContact()==null) || 
             (this.secondContact!=null &&
              this.secondContact.equals(other.getSecondContact()))) &&
            ((this.thirdContact==null && other.getThirdContact()==null) || 
             (this.thirdContact!=null &&
              this.thirdContact.equals(other.getThirdContact()))) &&
            ((this.regDate==null && other.getRegDate()==null) || 
             (this.regDate!=null &&
              this.regDate.equals(other.getRegDate())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getCountry() != null) {
            _hashCode += getCountry().hashCode();
        }
        if (getDate() != null) {
            _hashCode += getDate().hashCode();
        }
        if (getNumber() != null) {
            _hashCode += getNumber().hashCode();
        }
        if (getType() != null) {
            _hashCode += getType().hashCode();
        }
        if (getContact() != null) {
            _hashCode += getContact().hashCode();
        }
        if (getContactLanguage() != null) {
            _hashCode += getContactLanguage().hashCode();
        }
        if (getDocumentationLanguage() != null) {
            _hashCode += getDocumentationLanguage().hashCode();
        }
        if (getSecondContact() != null) {
            _hashCode += getSecondContact().hashCode();
        }
        if (getThirdContact() != null) {
            _hashCode += getThirdContact().hashCode();
        }
        if (getRegDate() != null) {
            _hashCode += getRegDate().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(TradeMark.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "TradeMark"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("country");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Country"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("date");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Date"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("number");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Number"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("type");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Type"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contact");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Contact"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contactLanguage");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "ContactLanguage"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("documentationLanguage");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "DocumentationLanguage"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("secondContact");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "SecondContact"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("thirdContact");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "ThirdContact"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("regDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "RegDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
