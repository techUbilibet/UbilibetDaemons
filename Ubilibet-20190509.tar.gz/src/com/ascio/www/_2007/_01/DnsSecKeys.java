/**
 * DnsSecKeys.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ascio.www._2007._01;

@SuppressWarnings({ "rawtypes", "serial", "unused" })
public class DnsSecKeys  implements java.io.Serializable {
    private com.ascio.www._2007._01.DnsSecKey dnsSecKey1;

    private com.ascio.www._2007._01.DnsSecKey dnsSecKey2;

    private com.ascio.www._2007._01.DnsSecKey dnsSecKey3;

    private com.ascio.www._2007._01.DnsSecKey dnsSecKey4;

    private com.ascio.www._2007._01.DnsSecKey dnsSecKey5;

    public DnsSecKeys() {
    }

    public DnsSecKeys(
           com.ascio.www._2007._01.DnsSecKey dnsSecKey1,
           com.ascio.www._2007._01.DnsSecKey dnsSecKey2,
           com.ascio.www._2007._01.DnsSecKey dnsSecKey3,
           com.ascio.www._2007._01.DnsSecKey dnsSecKey4,
           com.ascio.www._2007._01.DnsSecKey dnsSecKey5) {
           this.dnsSecKey1 = dnsSecKey1;
           this.dnsSecKey2 = dnsSecKey2;
           this.dnsSecKey3 = dnsSecKey3;
           this.dnsSecKey4 = dnsSecKey4;
           this.dnsSecKey5 = dnsSecKey5;
    }


    /**
     * Gets the dnsSecKey1 value for this DnsSecKeys.
     * 
     * @return dnsSecKey1
     */
    public com.ascio.www._2007._01.DnsSecKey getDnsSecKey1() {
        return dnsSecKey1;
    }


    /**
     * Sets the dnsSecKey1 value for this DnsSecKeys.
     * 
     * @param dnsSecKey1
     */
    public void setDnsSecKey1(com.ascio.www._2007._01.DnsSecKey dnsSecKey1) {
        this.dnsSecKey1 = dnsSecKey1;
    }


    /**
     * Gets the dnsSecKey2 value for this DnsSecKeys.
     * 
     * @return dnsSecKey2
     */
    public com.ascio.www._2007._01.DnsSecKey getDnsSecKey2() {
        return dnsSecKey2;
    }


    /**
     * Sets the dnsSecKey2 value for this DnsSecKeys.
     * 
     * @param dnsSecKey2
     */
    public void setDnsSecKey2(com.ascio.www._2007._01.DnsSecKey dnsSecKey2) {
        this.dnsSecKey2 = dnsSecKey2;
    }


    /**
     * Gets the dnsSecKey3 value for this DnsSecKeys.
     * 
     * @return dnsSecKey3
     */
    public com.ascio.www._2007._01.DnsSecKey getDnsSecKey3() {
        return dnsSecKey3;
    }


    /**
     * Sets the dnsSecKey3 value for this DnsSecKeys.
     * 
     * @param dnsSecKey3
     */
    public void setDnsSecKey3(com.ascio.www._2007._01.DnsSecKey dnsSecKey3) {
        this.dnsSecKey3 = dnsSecKey3;
    }


    /**
     * Gets the dnsSecKey4 value for this DnsSecKeys.
     * 
     * @return dnsSecKey4
     */
    public com.ascio.www._2007._01.DnsSecKey getDnsSecKey4() {
        return dnsSecKey4;
    }


    /**
     * Sets the dnsSecKey4 value for this DnsSecKeys.
     * 
     * @param dnsSecKey4
     */
    public void setDnsSecKey4(com.ascio.www._2007._01.DnsSecKey dnsSecKey4) {
        this.dnsSecKey4 = dnsSecKey4;
    }


    /**
     * Gets the dnsSecKey5 value for this DnsSecKeys.
     * 
     * @return dnsSecKey5
     */
    public com.ascio.www._2007._01.DnsSecKey getDnsSecKey5() {
        return dnsSecKey5;
    }


    /**
     * Sets the dnsSecKey5 value for this DnsSecKeys.
     * 
     * @param dnsSecKey5
     */
    public void setDnsSecKey5(com.ascio.www._2007._01.DnsSecKey dnsSecKey5) {
        this.dnsSecKey5 = dnsSecKey5;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof DnsSecKeys)) return false;
        DnsSecKeys other = (DnsSecKeys) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.dnsSecKey1==null && other.getDnsSecKey1()==null) || 
             (this.dnsSecKey1!=null &&
              this.dnsSecKey1.equals(other.getDnsSecKey1()))) &&
            ((this.dnsSecKey2==null && other.getDnsSecKey2()==null) || 
             (this.dnsSecKey2!=null &&
              this.dnsSecKey2.equals(other.getDnsSecKey2()))) &&
            ((this.dnsSecKey3==null && other.getDnsSecKey3()==null) || 
             (this.dnsSecKey3!=null &&
              this.dnsSecKey3.equals(other.getDnsSecKey3()))) &&
            ((this.dnsSecKey4==null && other.getDnsSecKey4()==null) || 
             (this.dnsSecKey4!=null &&
              this.dnsSecKey4.equals(other.getDnsSecKey4()))) &&
            ((this.dnsSecKey5==null && other.getDnsSecKey5()==null) || 
             (this.dnsSecKey5!=null &&
              this.dnsSecKey5.equals(other.getDnsSecKey5())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getDnsSecKey1() != null) {
            _hashCode += getDnsSecKey1().hashCode();
        }
        if (getDnsSecKey2() != null) {
            _hashCode += getDnsSecKey2().hashCode();
        }
        if (getDnsSecKey3() != null) {
            _hashCode += getDnsSecKey3().hashCode();
        }
        if (getDnsSecKey4() != null) {
            _hashCode += getDnsSecKey4().hashCode();
        }
        if (getDnsSecKey5() != null) {
            _hashCode += getDnsSecKey5().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(DnsSecKeys.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "DnsSecKeys"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dnsSecKey1");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "DnsSecKey1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "DnsSecKey"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dnsSecKey2");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "DnsSecKey2"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "DnsSecKey"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dnsSecKey3");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "DnsSecKey3"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "DnsSecKey"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dnsSecKey4");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "DnsSecKey4"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "DnsSecKey"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dnsSecKey5");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "DnsSecKey5"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "DnsSecKey"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
