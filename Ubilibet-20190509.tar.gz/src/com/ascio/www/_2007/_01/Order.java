/**
 * Order.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ascio.www._2007._01;

@SuppressWarnings({ "rawtypes", "serial", "unused" })
public class Order  implements java.io.Serializable {
    private java.lang.String orderId;

    private com.ascio.www._2007._01.OrderType type;

    private java.lang.String accountReference;

    private com.ascio.www._2007._01.OrderStatusType status;

    private java.lang.String transactionComment;

    private java.lang.String comments;

    private java.lang.String options;

    private java.lang.String localPresence;

    private java.lang.String batch;

    private java.lang.String documentation;

    private com.ascio.www._2007._01.Domain domain;

    private java.util.Calendar creDate;

    private java.lang.Integer agreedPrice;

    public Order() {
    }

    public Order(
           java.lang.String orderId,
           com.ascio.www._2007._01.OrderType type,
           java.lang.String accountReference,
           com.ascio.www._2007._01.OrderStatusType status,
           java.lang.String transactionComment,
           java.lang.String comments,
           java.lang.String options,
           java.lang.String localPresence,
           java.lang.String batch,
           java.lang.String documentation,
           com.ascio.www._2007._01.Domain domain,
           java.util.Calendar creDate,
           java.lang.Integer agreedPrice) {
           this.orderId = orderId;
           this.type = type;
           this.accountReference = accountReference;
           this.status = status;
           this.transactionComment = transactionComment;
           this.comments = comments;
           this.options = options;
           this.localPresence = localPresence;
           this.batch = batch;
           this.documentation = documentation;
           this.domain = domain;
           this.creDate = creDate;
           this.agreedPrice = agreedPrice;
    }


    /**
     * Gets the orderId value for this Order.
     * 
     * @return orderId
     */
    public java.lang.String getOrderId() {
        return orderId;
    }


    /**
     * Sets the orderId value for this Order.
     * 
     * @param orderId
     */
    public void setOrderId(java.lang.String orderId) {
        this.orderId = orderId;
    }


    /**
     * Gets the type value for this Order.
     * 
     * @return type
     */
    public com.ascio.www._2007._01.OrderType getType() {
        return type;
    }


    /**
     * Sets the type value for this Order.
     * 
     * @param type
     */
    public void setType(com.ascio.www._2007._01.OrderType type) {
        this.type = type;
    }


    /**
     * Gets the accountReference value for this Order.
     * 
     * @return accountReference
     */
    public java.lang.String getAccountReference() {
        return accountReference;
    }


    /**
     * Sets the accountReference value for this Order.
     * 
     * @param accountReference
     */
    public void setAccountReference(java.lang.String accountReference) {
        this.accountReference = accountReference;
    }


    /**
     * Gets the status value for this Order.
     * 
     * @return status
     */
    public com.ascio.www._2007._01.OrderStatusType getStatus() {
        return status;
    }


    /**
     * Sets the status value for this Order.
     * 
     * @param status
     */
    public void setStatus(com.ascio.www._2007._01.OrderStatusType status) {
        this.status = status;
    }


    /**
     * Gets the transactionComment value for this Order.
     * 
     * @return transactionComment
     */
    public java.lang.String getTransactionComment() {
        return transactionComment;
    }


    /**
     * Sets the transactionComment value for this Order.
     * 
     * @param transactionComment
     */
    public void setTransactionComment(java.lang.String transactionComment) {
        this.transactionComment = transactionComment;
    }


    /**
     * Gets the comments value for this Order.
     * 
     * @return comments
     */
    public java.lang.String getComments() {
        return comments;
    }


    /**
     * Sets the comments value for this Order.
     * 
     * @param comments
     */
    public void setComments(java.lang.String comments) {
        this.comments = comments;
    }


    /**
     * Gets the options value for this Order.
     * 
     * @return options
     */
    public java.lang.String getOptions() {
        return options;
    }


    /**
     * Sets the options value for this Order.
     * 
     * @param options
     */
    public void setOptions(java.lang.String options) {
        this.options = options;
    }


    /**
     * Gets the localPresence value for this Order.
     * 
     * @return localPresence
     */
    public java.lang.String getLocalPresence() {
        return localPresence;
    }


    /**
     * Sets the localPresence value for this Order.
     * 
     * @param localPresence
     */
    public void setLocalPresence(java.lang.String localPresence) {
        this.localPresence = localPresence;
    }


    /**
     * Gets the batch value for this Order.
     * 
     * @return batch
     */
    public java.lang.String getBatch() {
        return batch;
    }


    /**
     * Sets the batch value for this Order.
     * 
     * @param batch
     */
    public void setBatch(java.lang.String batch) {
        this.batch = batch;
    }


    /**
     * Gets the documentation value for this Order.
     * 
     * @return documentation
     */
    public java.lang.String getDocumentation() {
        return documentation;
    }


    /**
     * Sets the documentation value for this Order.
     * 
     * @param documentation
     */
    public void setDocumentation(java.lang.String documentation) {
        this.documentation = documentation;
    }


    /**
     * Gets the domain value for this Order.
     * 
     * @return domain
     */
    public com.ascio.www._2007._01.Domain getDomain() {
        return domain;
    }


    /**
     * Sets the domain value for this Order.
     * 
     * @param domain
     */
    public void setDomain(com.ascio.www._2007._01.Domain domain) {
        this.domain = domain;
    }


    /**
     * Gets the creDate value for this Order.
     * 
     * @return creDate
     */
    public java.util.Calendar getCreDate() {
        return creDate;
    }


    /**
     * Sets the creDate value for this Order.
     * 
     * @param creDate
     */
    public void setCreDate(java.util.Calendar creDate) {
        this.creDate = creDate;
    }


    /**
     * Gets the agreedPrice value for this Order.
     * 
     * @return agreedPrice
     */
    public java.lang.Integer getAgreedPrice() {
        return agreedPrice;
    }


    /**
     * Sets the agreedPrice value for this Order.
     * 
     * @param agreedPrice
     */
    public void setAgreedPrice(java.lang.Integer agreedPrice) {
        this.agreedPrice = agreedPrice;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Order)) return false;
        Order other = (Order) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.orderId==null && other.getOrderId()==null) || 
             (this.orderId!=null &&
              this.orderId.equals(other.getOrderId()))) &&
            ((this.type==null && other.getType()==null) || 
             (this.type!=null &&
              this.type.equals(other.getType()))) &&
            ((this.accountReference==null && other.getAccountReference()==null) || 
             (this.accountReference!=null &&
              this.accountReference.equals(other.getAccountReference()))) &&
            ((this.status==null && other.getStatus()==null) || 
             (this.status!=null &&
              this.status.equals(other.getStatus()))) &&
            ((this.transactionComment==null && other.getTransactionComment()==null) || 
             (this.transactionComment!=null &&
              this.transactionComment.equals(other.getTransactionComment()))) &&
            ((this.comments==null && other.getComments()==null) || 
             (this.comments!=null &&
              this.comments.equals(other.getComments()))) &&
            ((this.options==null && other.getOptions()==null) || 
             (this.options!=null &&
              this.options.equals(other.getOptions()))) &&
            ((this.localPresence==null && other.getLocalPresence()==null) || 
             (this.localPresence!=null &&
              this.localPresence.equals(other.getLocalPresence()))) &&
            ((this.batch==null && other.getBatch()==null) || 
             (this.batch!=null &&
              this.batch.equals(other.getBatch()))) &&
            ((this.documentation==null && other.getDocumentation()==null) || 
             (this.documentation!=null &&
              this.documentation.equals(other.getDocumentation()))) &&
            ((this.domain==null && other.getDomain()==null) || 
             (this.domain!=null &&
              this.domain.equals(other.getDomain()))) &&
            ((this.creDate==null && other.getCreDate()==null) || 
             (this.creDate!=null &&
              this.creDate.equals(other.getCreDate()))) &&
            ((this.agreedPrice==null && other.getAgreedPrice()==null) || 
             (this.agreedPrice!=null &&
              this.agreedPrice.equals(other.getAgreedPrice())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getOrderId() != null) {
            _hashCode += getOrderId().hashCode();
        }
        if (getType() != null) {
            _hashCode += getType().hashCode();
        }
        if (getAccountReference() != null) {
            _hashCode += getAccountReference().hashCode();
        }
        if (getStatus() != null) {
            _hashCode += getStatus().hashCode();
        }
        if (getTransactionComment() != null) {
            _hashCode += getTransactionComment().hashCode();
        }
        if (getComments() != null) {
            _hashCode += getComments().hashCode();
        }
        if (getOptions() != null) {
            _hashCode += getOptions().hashCode();
        }
        if (getLocalPresence() != null) {
            _hashCode += getLocalPresence().hashCode();
        }
        if (getBatch() != null) {
            _hashCode += getBatch().hashCode();
        }
        if (getDocumentation() != null) {
            _hashCode += getDocumentation().hashCode();
        }
        if (getDomain() != null) {
            _hashCode += getDomain().hashCode();
        }
        if (getCreDate() != null) {
            _hashCode += getCreDate().hashCode();
        }
        if (getAgreedPrice() != null) {
            _hashCode += getAgreedPrice().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Order.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Order"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "OrderId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("type");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Type"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "OrderType"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("accountReference");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "AccountReference"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("status");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Status"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "OrderStatusType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transactionComment");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "TransactionComment"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("comments");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Comments"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("options");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Options"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("localPresence");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "LocalPresence"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("batch");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Batch"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("documentation");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Documentation"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("domain");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Domain"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Domain"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("creDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "CreDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("agreedPrice");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "AgreedPrice"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
