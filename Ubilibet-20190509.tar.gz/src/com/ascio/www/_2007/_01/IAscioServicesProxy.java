package com.ascio.www._2007._01;

public class IAscioServicesProxy implements com.ascio.www._2007._01.IAscioServices {
  private String _endpoint = null;
  private com.ascio.www._2007._01.IAscioServices iAscioServices = null;
  
  public IAscioServicesProxy() {
    _initIAscioServicesProxy();
  }
  
  public IAscioServicesProxy(String endpoint) {
    _endpoint = endpoint;
    _initIAscioServicesProxy();
  }
  
  private void _initIAscioServicesProxy() {
    try {
      iAscioServices = (new com.ascio.www._2012._01._01.AscioService.AscioServicesLocator()).getBasicHttpBinding_IAscioServices();
      if (iAscioServices != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)iAscioServices)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)iAscioServices)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (iAscioServices != null)
      ((javax.xml.rpc.Stub)iAscioServices)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.ascio.www._2007._01.IAscioServices getIAscioServices() {
    if (iAscioServices == null)
      _initIAscioServicesProxy();
    return iAscioServices;
  }
  
  public void logIn(com.ascio.www._2007._01.Session session, com.ascio.www._2007._01.holders.ResponseHolder logInResult, javax.xml.rpc.holders.StringHolder sessionId) throws java.rmi.RemoteException{
    if (iAscioServices == null)
      _initIAscioServicesProxy();
    iAscioServices.logIn(session, logInResult, sessionId);
  }
  
  public com.ascio.www._2007._01.Response logOut(java.lang.String sessionId) throws java.rmi.RemoteException{
    if (iAscioServices == null)
      _initIAscioServicesProxy();
    return iAscioServices.logOut(sessionId);
  }
  
  public void getOrder(java.lang.String sessionId, java.lang.String orderId, com.ascio.www._2007._01.holders.ResponseHolder getOrderResult, com.ascio.www._2007._01.holders.OrderHolder order) throws java.rmi.RemoteException{
    if (iAscioServices == null)
      _initIAscioServicesProxy();
    iAscioServices.getOrder(sessionId, orderId, getOrderResult, order);
  }
  
  public com.ascio.www._2007._01.Response createOrder(java.lang.String sessionId, com.ascio.www._2007._01.holders.OrderHolder order) throws java.rmi.RemoteException{
    if (iAscioServices == null)
      _initIAscioServicesProxy();
    return iAscioServices.createOrder(sessionId, order);
  }
  
  public void searchOrder(java.lang.String sessionId, com.ascio.www._2007._01.SearchOrderRequest orderRequest, com.ascio.www._2007._01.holders.ResponseHolder searchOrderResult, javax.xml.rpc.holders.IntegerWrapperHolder totalOrders, com.ascio.www._2007._01.holders.ArrayOfOrderHolder orders) throws java.rmi.RemoteException{
    if (iAscioServices == null)
      _initIAscioServicesProxy();
    iAscioServices.searchOrder(sessionId, orderRequest, searchOrderResult, totalOrders, orders);
  }
  
  public void getMessages(java.lang.String sessionId, java.lang.String orderId, com.ascio.www._2007._01.holders.ResponseHolder getMessagesResult, com.ascio.www._2007._01.holders.ArrayOfMessageHolder messages) throws java.rmi.RemoteException{
    if (iAscioServices == null)
      _initIAscioServicesProxy();
    iAscioServices.getMessages(sessionId, orderId, getMessagesResult, messages);
  }
  
  public com.ascio.www._2007._01.Response validateOrder(java.lang.String sessionId, com.ascio.www._2007._01.Order order) throws java.rmi.RemoteException{
    if (iAscioServices == null)
      _initIAscioServicesProxy();
    return iAscioServices.validateOrder(sessionId, order);
  }
  
  public com.ascio.www._2007._01.Response uploadDocumentation(java.lang.String sessionId, java.lang.String orderId, java.lang.String fileName, byte[] content) throws java.rmi.RemoteException{
    if (iAscioServices == null)
      _initIAscioServicesProxy();
    return iAscioServices.uploadDocumentation(sessionId, orderId, fileName, content);
  }
  
  public void createSupportOrder(java.lang.String sessionId, java.lang.String subject, java.lang.String body, com.ascio.www._2007._01.Attachment[] attachments, com.ascio.www._2007._01.holders.ResponseHolder createSupportOrderResult, javax.xml.rpc.holders.StringHolder orderId) throws java.rmi.RemoteException{
    if (iAscioServices == null)
      _initIAscioServicesProxy();
    iAscioServices.createSupportOrder(sessionId, subject, body, attachments, createSupportOrderResult, orderId);
  }
  
  public com.ascio.www._2007._01.Response uploadMessage(java.lang.String sessionId, java.lang.String orderId, com.ascio.www._2007._01.Message message) throws java.rmi.RemoteException{
    if (iAscioServices == null)
      _initIAscioServicesProxy();
    return iAscioServices.uploadMessage(sessionId, orderId, message);
  }
  
  public void getDomain(java.lang.String sessionId, java.lang.String domainHandle, com.ascio.www._2007._01.holders.ResponseHolder getDomainResult, com.ascio.www._2007._01.holders.DomainHolder domain) throws java.rmi.RemoteException{
    if (iAscioServices == null)
      _initIAscioServicesProxy();
    iAscioServices.getDomain(sessionId, domainHandle, getDomainResult, domain);
  }
  
  public void searchDomain(java.lang.String sessionId, com.ascio.www._2007._01.SearchCriteria criteria, com.ascio.www._2007._01.holders.ResponseHolder searchDomainResult, com.ascio.www._2007._01.holders.ArrayOfDomainHolder domains) throws java.rmi.RemoteException{
    if (iAscioServices == null)
      _initIAscioServicesProxy();
    iAscioServices.searchDomain(sessionId, criteria, searchDomainResult, domains);
  }
  
  public void whois(java.lang.String sessionId, java.lang.String domainName, com.ascio.www._2007._01.holders.ResponseHolder whoisResult, javax.xml.rpc.holders.StringHolder whoisData) throws java.rmi.RemoteException{
    if (iAscioServices == null)
      _initIAscioServicesProxy();
    iAscioServices.whois(sessionId, domainName, whoisResult, whoisData);
  }
  
  public void availabilityCheck(java.lang.String sessionId, java.lang.String[] domains, java.lang.String[] tlds, com.ascio.www._2007._01.QualityType quality, com.ascio.www._2007._01.holders.ResponseHolder availabilityCheckResult, com.ascio.www._2007._01.holders.ArrayOfAvailabilityCheckResultHolder results) throws java.rmi.RemoteException{
    if (iAscioServices == null)
      _initIAscioServicesProxy();
    iAscioServices.availabilityCheck(sessionId, domains, tlds, quality, availabilityCheckResult, results);
  }
  
  public void availabilityInfo(java.lang.String sessionId, java.lang.String domainName, com.ascio.www._2007._01.QualityType quality, com.ascio.www._2007._01.holders.ResponseHolder availabilityInfoResult, com.ascio.www._2007._01.holders.PriceInfoHolder priceInfo) throws java.rmi.RemoteException{
    if (iAscioServices == null)
      _initIAscioServicesProxy();
    iAscioServices.availabilityInfo(sessionId, domainName, quality, availabilityInfoResult, priceInfo);
  }
  
  public void getRegistrant(java.lang.String sessionId, java.lang.String registrantHandle, com.ascio.www._2007._01.holders.ResponseHolder getRegistrantResult, com.ascio.www._2007._01.holders.RegistrantHolder registrant) throws java.rmi.RemoteException{
    if (iAscioServices == null)
      _initIAscioServicesProxy();
    iAscioServices.getRegistrant(sessionId, registrantHandle, getRegistrantResult, registrant);
  }
  
  public com.ascio.www._2007._01.Response createRegistrant(java.lang.String sessionId, com.ascio.www._2007._01.holders.RegistrantHolder registrant) throws java.rmi.RemoteException{
    if (iAscioServices == null)
      _initIAscioServicesProxy();
    return iAscioServices.createRegistrant(sessionId, registrant);
  }
  
  public com.ascio.www._2007._01.Response deleteRegistrant(java.lang.String sessionId, java.lang.String registrantHandle) throws java.rmi.RemoteException{
    if (iAscioServices == null)
      _initIAscioServicesProxy();
    return iAscioServices.deleteRegistrant(sessionId, registrantHandle);
  }
  
  public void searchRegistrant(java.lang.String sessionId, com.ascio.www._2007._01.SearchCriteria criteria, com.ascio.www._2007._01.holders.ResponseHolder searchRegistrantResult, com.ascio.www._2007._01.holders.ArrayOfRegistrantHolder registrants) throws java.rmi.RemoteException{
    if (iAscioServices == null)
      _initIAscioServicesProxy();
    iAscioServices.searchRegistrant(sessionId, criteria, searchRegistrantResult, registrants);
  }
  
  public void getRegistrantVerificationInfo(java.lang.String sessionId, java.lang.String value, com.ascio.www._2007._01.holders.ResponseHolder getRegistrantVerificationInfoResult, com.ascio.www._2007._01.holders.RegistrantVerificationInfoHolder verificationInfo) throws java.rmi.RemoteException{
    if (iAscioServices == null)
      _initIAscioServicesProxy();
    iAscioServices.getRegistrantVerificationInfo(sessionId, value, getRegistrantVerificationInfoResult, verificationInfo);
  }
  
  public com.ascio.www._2007._01.Response doRegistrantVerification(java.lang.String sessionId, java.lang.String value) throws java.rmi.RemoteException{
    if (iAscioServices == null)
      _initIAscioServicesProxy();
    return iAscioServices.doRegistrantVerification(sessionId, value);
  }
  
  public void getRegistrantVerificationStatus(java.lang.String sessionId, java.lang.String value, com.ascio.www._2007._01.holders.ResponseHolder getRegistrantVerificationStatusResult, com.ascio.www._2007._01.holders.RegistrantVerificationStatusHolder verificationStatus) throws java.rmi.RemoteException{
    if (iAscioServices == null)
      _initIAscioServicesProxy();
    iAscioServices.getRegistrantVerificationStatus(sessionId, value, getRegistrantVerificationStatusResult, verificationStatus);
  }
  
  public com.ascio.www._2007._01.Response uploadRegistrantVerificationMessage(java.lang.String sessionId, java.lang.String value, com.ascio.www._2007._01.RegistrantVerificationDetails details) throws java.rmi.RemoteException{
    if (iAscioServices == null)
      _initIAscioServicesProxy();
    return iAscioServices.uploadRegistrantVerificationMessage(sessionId, value, details);
  }
  
  public void getContact(java.lang.String sessionId, java.lang.String contactHandle, com.ascio.www._2007._01.holders.ResponseHolder getContactResult, com.ascio.www._2007._01.holders.ContactHolder contact) throws java.rmi.RemoteException{
    if (iAscioServices == null)
      _initIAscioServicesProxy();
    iAscioServices.getContact(sessionId, contactHandle, getContactResult, contact);
  }
  
  public com.ascio.www._2007._01.Response createContact(java.lang.String sessionId, com.ascio.www._2007._01.holders.ContactHolder contact) throws java.rmi.RemoteException{
    if (iAscioServices == null)
      _initIAscioServicesProxy();
    return iAscioServices.createContact(sessionId, contact);
  }
  
  public com.ascio.www._2007._01.Response updateContact(java.lang.String sessionId, com.ascio.www._2007._01.Contact contact) throws java.rmi.RemoteException{
    if (iAscioServices == null)
      _initIAscioServicesProxy();
    return iAscioServices.updateContact(sessionId, contact);
  }
  
  public com.ascio.www._2007._01.Response deleteContact(java.lang.String sessionId, java.lang.String contactHandle) throws java.rmi.RemoteException{
    if (iAscioServices == null)
      _initIAscioServicesProxy();
    return iAscioServices.deleteContact(sessionId, contactHandle);
  }
  
  public void searchContact(java.lang.String sessionId, com.ascio.www._2007._01.SearchCriteria criteria, com.ascio.www._2007._01.holders.ResponseHolder searchContactResult, com.ascio.www._2007._01.holders.ArrayOfContactHolder contacts) throws java.rmi.RemoteException{
    if (iAscioServices == null)
      _initIAscioServicesProxy();
    iAscioServices.searchContact(sessionId, criteria, searchContactResult, contacts);
  }
  
  public void getNameServer(java.lang.String sessionId, java.lang.String nameServerHandle, com.ascio.www._2007._01.holders.ResponseHolder getNameServerResult, com.ascio.www._2007._01.holders.NameServerHolder nameServer) throws java.rmi.RemoteException{
    if (iAscioServices == null)
      _initIAscioServicesProxy();
    iAscioServices.getNameServer(sessionId, nameServerHandle, getNameServerResult, nameServer);
  }
  
  public com.ascio.www._2007._01.Response createNameServer(java.lang.String sessionId, com.ascio.www._2007._01.holders.NameServerHolder nameServer) throws java.rmi.RemoteException{
    if (iAscioServices == null)
      _initIAscioServicesProxy();
    return iAscioServices.createNameServer(sessionId, nameServer);
  }
  
  public com.ascio.www._2007._01.Response deleteNameServer(java.lang.String sessionId, java.lang.String nameServerHandle) throws java.rmi.RemoteException{
    if (iAscioServices == null)
      _initIAscioServicesProxy();
    return iAscioServices.deleteNameServer(sessionId, nameServerHandle);
  }
  
  public void searchNameServer(java.lang.String sessionId, com.ascio.www._2007._01.SearchCriteria criteria, com.ascio.www._2007._01.holders.ResponseHolder searchNameServerResult, com.ascio.www._2007._01.holders.ArrayOfNameServerHolder nameServers) throws java.rmi.RemoteException{
    if (iAscioServices == null)
      _initIAscioServicesProxy();
    iAscioServices.searchNameServer(sessionId, criteria, searchNameServerResult, nameServers);
  }
  
  public void pollMessage(java.lang.String sessionId, com.ascio.www._2007._01.MessageType msgType, com.ascio.www._2007._01.holders.ResponseHolder pollMessageResult, javax.xml.rpc.holders.IntegerWrapperHolder msgCount, com.ascio.www._2007._01.holders.QueueItemHolder item) throws java.rmi.RemoteException{
    if (iAscioServices == null)
      _initIAscioServicesProxy();
    iAscioServices.pollMessage(sessionId, msgType, pollMessageResult, msgCount, item);
  }
  
  public com.ascio.www._2007._01.Response ackMessage(java.lang.String sessionId, java.lang.Integer msgId) throws java.rmi.RemoteException{
    if (iAscioServices == null)
      _initIAscioServicesProxy();
    return iAscioServices.ackMessage(sessionId, msgId);
  }
  
  public void getMessageQueue(java.lang.String sessionId, java.lang.Integer msgId, com.ascio.www._2007._01.holders.ResponseHolder getMessageQueueResult, com.ascio.www._2007._01.holders.QueueItemHolder item) throws java.rmi.RemoteException{
    if (iAscioServices == null)
      _initIAscioServicesProxy();
    iAscioServices.getMessageQueue(sessionId, msgId, getMessageQueueResult, item);
  }
  
  public void getDnsSecKey(java.lang.String sessionId, java.lang.String dnsSecKeyHandle, com.ascio.www._2007._01.holders.ResponseHolder getDnsSecKeyResult, com.ascio.www._2007._01.holders.DnsSecKeyHolder dnsSecKey) throws java.rmi.RemoteException{
    if (iAscioServices == null)
      _initIAscioServicesProxy();
    iAscioServices.getDnsSecKey(sessionId, dnsSecKeyHandle, getDnsSecKeyResult, dnsSecKey);
  }
  
  public com.ascio.www._2007._01.Response createDnsSecKey(java.lang.String sessionId, com.ascio.www._2007._01.holders.DnsSecKeyHolder dnsSecKey) throws java.rmi.RemoteException{
    if (iAscioServices == null)
      _initIAscioServicesProxy();
    return iAscioServices.createDnsSecKey(sessionId, dnsSecKey);
  }
  
  public void searchDnsSecKey(java.lang.String sessionId, com.ascio.www._2007._01.SearchCriteria criteria, com.ascio.www._2007._01.holders.ResponseHolder searchDnsSecKeyResult, com.ascio.www._2007._01.holders.ArrayOfDnsSecKeyHolder dnsSecKeys) throws java.rmi.RemoteException{
    if (iAscioServices == null)
      _initIAscioServicesProxy();
    iAscioServices.searchDnsSecKey(sessionId, criteria, searchDnsSecKeyResult, dnsSecKeys);
  }
  
  public void createDocumentation(java.lang.String sessionId, com.ascio.www._2007._01.Attachment[] attachments, com.ascio.www._2007._01.holders.ResponseHolder createDocumentationResult, javax.xml.rpc.holders.IntegerWrapperHolder documentationId) throws java.rmi.RemoteException{
    if (iAscioServices == null)
      _initIAscioServicesProxy();
    iAscioServices.createDocumentation(sessionId, attachments, createDocumentationResult, documentationId);
  }
  
  public void createApprovalDocumentation(java.lang.String sessionId, com.ascio.www._2007._01.ApprovalDocumentation approvalDocumentation, com.ascio.www._2007._01.holders.ResponseHolder createApprovalDocumentationResult, javax.xml.rpc.holders.StringHolder documentationId) throws java.rmi.RemoteException{
    if (iAscioServices == null)
      _initIAscioServicesProxy();
    iAscioServices.createApprovalDocumentation(sessionId, approvalDocumentation, createApprovalDocumentationResult, documentationId);
  }
  
  
}