/**
 * RegistrantVerificationInfo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ascio.www._2007._01;

@SuppressWarnings({ "rawtypes", "serial", "unused" })
public class RegistrantVerificationInfo  implements java.io.Serializable {
    private java.lang.String emailAddress;

    private com.ascio.www._2007._01.RegistrantVerificationStatus verificationStatus;

    private com.ascio.www._2007._01.RegistrantVerificationDetails verificationDetails;

    public RegistrantVerificationInfo() {
    }

    public RegistrantVerificationInfo(
           java.lang.String emailAddress,
           com.ascio.www._2007._01.RegistrantVerificationStatus verificationStatus,
           com.ascio.www._2007._01.RegistrantVerificationDetails verificationDetails) {
           this.emailAddress = emailAddress;
           this.verificationStatus = verificationStatus;
           this.verificationDetails = verificationDetails;
    }


    /**
     * Gets the emailAddress value for this RegistrantVerificationInfo.
     * 
     * @return emailAddress
     */
    public java.lang.String getEmailAddress() {
        return emailAddress;
    }


    /**
     * Sets the emailAddress value for this RegistrantVerificationInfo.
     * 
     * @param emailAddress
     */
    public void setEmailAddress(java.lang.String emailAddress) {
        this.emailAddress = emailAddress;
    }


    /**
     * Gets the verificationStatus value for this RegistrantVerificationInfo.
     * 
     * @return verificationStatus
     */
    public com.ascio.www._2007._01.RegistrantVerificationStatus getVerificationStatus() {
        return verificationStatus;
    }


    /**
     * Sets the verificationStatus value for this RegistrantVerificationInfo.
     * 
     * @param verificationStatus
     */
    public void setVerificationStatus(com.ascio.www._2007._01.RegistrantVerificationStatus verificationStatus) {
        this.verificationStatus = verificationStatus;
    }


    /**
     * Gets the verificationDetails value for this RegistrantVerificationInfo.
     * 
     * @return verificationDetails
     */
    public com.ascio.www._2007._01.RegistrantVerificationDetails getVerificationDetails() {
        return verificationDetails;
    }


    /**
     * Sets the verificationDetails value for this RegistrantVerificationInfo.
     * 
     * @param verificationDetails
     */
    public void setVerificationDetails(com.ascio.www._2007._01.RegistrantVerificationDetails verificationDetails) {
        this.verificationDetails = verificationDetails;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof RegistrantVerificationInfo)) return false;
        RegistrantVerificationInfo other = (RegistrantVerificationInfo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.emailAddress==null && other.getEmailAddress()==null) || 
             (this.emailAddress!=null &&
              this.emailAddress.equals(other.getEmailAddress()))) &&
            ((this.verificationStatus==null && other.getVerificationStatus()==null) || 
             (this.verificationStatus!=null &&
              this.verificationStatus.equals(other.getVerificationStatus()))) &&
            ((this.verificationDetails==null && other.getVerificationDetails()==null) || 
             (this.verificationDetails!=null &&
              this.verificationDetails.equals(other.getVerificationDetails())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getEmailAddress() != null) {
            _hashCode += getEmailAddress().hashCode();
        }
        if (getVerificationStatus() != null) {
            _hashCode += getVerificationStatus().hashCode();
        }
        if (getVerificationDetails() != null) {
            _hashCode += getVerificationDetails().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(RegistrantVerificationInfo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "RegistrantVerificationInfo"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("emailAddress");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "EmailAddress"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("verificationStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "VerificationStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "RegistrantVerificationStatus"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("verificationDetails");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "VerificationDetails"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "RegistrantVerificationDetails"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
