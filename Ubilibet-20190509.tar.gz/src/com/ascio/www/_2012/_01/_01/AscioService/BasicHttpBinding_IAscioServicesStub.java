/**
 * BasicHttpBinding_IAscioServicesStub.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ascio.www._2012._01._01.AscioService;

@SuppressWarnings({ "rawtypes", "unused", "unchecked" })
public class BasicHttpBinding_IAscioServicesStub extends org.apache.axis.client.Stub implements com.ascio.www._2007._01.IAscioServices {
    private java.util.Vector cachedSerClasses = new java.util.Vector();
    private java.util.Vector cachedSerQNames = new java.util.Vector();
    private java.util.Vector cachedSerFactories = new java.util.Vector();
    private java.util.Vector cachedDeserFactories = new java.util.Vector();

    static org.apache.axis.description.OperationDesc [] _operations;

    static {
        _operations = new org.apache.axis.description.OperationDesc[40];
        _initOperationDesc1();
        _initOperationDesc2();
        _initOperationDesc3();
        _initOperationDesc4();
    }

    private static void _initOperationDesc1(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("LogIn");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "session"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Session"), com.ascio.www._2007._01.Session.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "LogInResult"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Response"), com.ascio.www._2007._01.Response.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "sessionId"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[0] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("LogOut");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "sessionId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Response"));
        oper.setReturnClass(com.ascio.www._2007._01.Response.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "LogOutResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[1] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetOrder");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "sessionId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "orderId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "GetOrderResult"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Response"), com.ascio.www._2007._01.Response.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "order"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Order"), com.ascio.www._2007._01.Order.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[2] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("CreateOrder");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "sessionId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "order"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Order"), com.ascio.www._2007._01.Order.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Response"));
        oper.setReturnClass(com.ascio.www._2007._01.Response.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "CreateOrderResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[3] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("SearchOrder");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "sessionId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "orderRequest"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "SearchOrderRequest"), com.ascio.www._2007._01.SearchOrderRequest.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "SearchOrderResult"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Response"), com.ascio.www._2007._01.Response.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "totalOrders"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), java.lang.Integer.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "orders"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "ArrayOfOrder"), com.ascio.www._2007._01.Order[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Order"));
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[4] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetMessages");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "sessionId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "orderId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "GetMessagesResult"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Response"), com.ascio.www._2007._01.Response.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "messages"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "ArrayOfMessage"), com.ascio.www._2007._01.Message[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Message"));
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[5] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("ValidateOrder");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "sessionId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "order"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Order"), com.ascio.www._2007._01.Order.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Response"));
        oper.setReturnClass(com.ascio.www._2007._01.Response.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "ValidateOrderResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[6] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("UploadDocumentation");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "sessionId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "orderId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "fileName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "content"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "base64Binary"), byte[].class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Response"));
        oper.setReturnClass(com.ascio.www._2007._01.Response.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "UploadDocumentationResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[7] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("CreateSupportOrder");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "sessionId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "subject"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "body"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "attachments"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "ArrayOfAttachment"), com.ascio.www._2007._01.Attachment[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Attachment"));
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "CreateSupportOrderResult"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Response"), com.ascio.www._2007._01.Response.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "orderId"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[8] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("UploadMessage");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "sessionId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "orderId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "message"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Message"), com.ascio.www._2007._01.Message.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Response"));
        oper.setReturnClass(com.ascio.www._2007._01.Response.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "UploadMessageResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[9] = oper;

    }

    private static void _initOperationDesc2(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetDomain");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "sessionId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "domainHandle"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "GetDomainResult"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Response"), com.ascio.www._2007._01.Response.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "domain"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Domain"), com.ascio.www._2007._01.Domain.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[10] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("SearchDomain");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "sessionId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "criteria"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "SearchCriteria"), com.ascio.www._2007._01.SearchCriteria.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "SearchDomainResult"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Response"), com.ascio.www._2007._01.Response.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "domains"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "ArrayOfDomain"), com.ascio.www._2007._01.Domain[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Domain"));
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[11] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("Whois");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "sessionId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "domainName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "WhoisResult"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Response"), com.ascio.www._2007._01.Response.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "whoisData"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[12] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("AvailabilityCheck");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "sessionId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "domains"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "ArrayOfString"), java.lang.String[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "string"));
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "tlds"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "ArrayOfString"), java.lang.String[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "string"));
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "quality"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "QualityType"), com.ascio.www._2007._01.QualityType.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "AvailabilityCheckResult"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Response"), com.ascio.www._2007._01.Response.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "results"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "ArrayOfAvailabilityCheckResult"), com.ascio.www._2007._01.AvailabilityCheckResult[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "AvailabilityCheckResult"));
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[13] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("AvailabilityInfo");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "sessionId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "domainName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "quality"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "QualityType"), com.ascio.www._2007._01.QualityType.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "AvailabilityInfoResult"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Response"), com.ascio.www._2007._01.Response.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "PriceInfo"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "PriceInfo"), com.ascio.www._2007._01.PriceInfo.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[14] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetRegistrant");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "sessionId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "registrantHandle"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "GetRegistrantResult"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Response"), com.ascio.www._2007._01.Response.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "registrant"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Registrant"), com.ascio.www._2007._01.Registrant.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[15] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("CreateRegistrant");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "sessionId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "registrant"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Registrant"), com.ascio.www._2007._01.Registrant.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Response"));
        oper.setReturnClass(com.ascio.www._2007._01.Response.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "CreateRegistrantResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[16] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("DeleteRegistrant");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "sessionId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "registrantHandle"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Response"));
        oper.setReturnClass(com.ascio.www._2007._01.Response.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "DeleteRegistrantResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[17] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("SearchRegistrant");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "sessionId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "criteria"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "SearchCriteria"), com.ascio.www._2007._01.SearchCriteria.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "SearchRegistrantResult"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Response"), com.ascio.www._2007._01.Response.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "registrants"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "ArrayOfRegistrant"), com.ascio.www._2007._01.Registrant[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Registrant"));
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[18] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetRegistrantVerificationInfo");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "sessionId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "value"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "GetRegistrantVerificationInfoResult"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Response"), com.ascio.www._2007._01.Response.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "verificationInfo"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "RegistrantVerificationInfo"), com.ascio.www._2007._01.RegistrantVerificationInfo.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[19] = oper;

    }

    private static void _initOperationDesc3(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("DoRegistrantVerification");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "sessionId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "value"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Response"));
        oper.setReturnClass(com.ascio.www._2007._01.Response.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "DoRegistrantVerificationResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[20] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetRegistrantVerificationStatus");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "sessionId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "value"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "GetRegistrantVerificationStatusResult"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Response"), com.ascio.www._2007._01.Response.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "verificationStatus"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "RegistrantVerificationStatus"), com.ascio.www._2007._01.RegistrantVerificationStatus.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[21] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("UploadRegistrantVerificationMessage");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "sessionId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "value"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "details"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "RegistrantVerificationDetails"), com.ascio.www._2007._01.RegistrantVerificationDetails.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Response"));
        oper.setReturnClass(com.ascio.www._2007._01.Response.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "UploadRegistrantVerificationMessageResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[22] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetContact");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "sessionId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "contactHandle"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "GetContactResult"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Response"), com.ascio.www._2007._01.Response.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "contact"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Contact"), com.ascio.www._2007._01.Contact.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[23] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("CreateContact");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "sessionId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "contact"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Contact"), com.ascio.www._2007._01.Contact.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Response"));
        oper.setReturnClass(com.ascio.www._2007._01.Response.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "CreateContactResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[24] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("UpdateContact");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "sessionId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "contact"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Contact"), com.ascio.www._2007._01.Contact.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Response"));
        oper.setReturnClass(com.ascio.www._2007._01.Response.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "UpdateContactResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[25] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("DeleteContact");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "sessionId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "contactHandle"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Response"));
        oper.setReturnClass(com.ascio.www._2007._01.Response.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "DeleteContactResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[26] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("SearchContact");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "sessionId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "criteria"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "SearchCriteria"), com.ascio.www._2007._01.SearchCriteria.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "SearchContactResult"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Response"), com.ascio.www._2007._01.Response.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "contacts"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "ArrayOfContact"), com.ascio.www._2007._01.Contact[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Contact"));
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[27] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetNameServer");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "sessionId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "nameServerHandle"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "GetNameServerResult"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Response"), com.ascio.www._2007._01.Response.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "nameServer"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "NameServer"), com.ascio.www._2007._01.NameServer.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[28] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("CreateNameServer");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "sessionId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "nameServer"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "NameServer"), com.ascio.www._2007._01.NameServer.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Response"));
        oper.setReturnClass(com.ascio.www._2007._01.Response.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "CreateNameServerResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[29] = oper;

    }

    private static void _initOperationDesc4(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("DeleteNameServer");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "sessionId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "nameServerHandle"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Response"));
        oper.setReturnClass(com.ascio.www._2007._01.Response.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "DeleteNameServerResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[30] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("SearchNameServer");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "sessionId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "criteria"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "SearchCriteria"), com.ascio.www._2007._01.SearchCriteria.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "SearchNameServerResult"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Response"), com.ascio.www._2007._01.Response.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "nameServers"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "ArrayOfNameServer"), com.ascio.www._2007._01.NameServer[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "NameServer"));
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[31] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("PollMessage");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "sessionId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "msgType"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "MessageType"), com.ascio.www._2007._01.MessageType.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "PollMessageResult"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Response"), com.ascio.www._2007._01.Response.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "msgCount"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), java.lang.Integer.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "item"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "QueueItem"), com.ascio.www._2007._01.QueueItem.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[32] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("AckMessage");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "sessionId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "msgId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), java.lang.Integer.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Response"));
        oper.setReturnClass(com.ascio.www._2007._01.Response.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "AckMessageResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[33] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetMessageQueue");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "sessionId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "msgId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), java.lang.Integer.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "GetMessageQueueResult"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Response"), com.ascio.www._2007._01.Response.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "item"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "QueueItem"), com.ascio.www._2007._01.QueueItem.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[34] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetDnsSecKey");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "sessionId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "dnsSecKeyHandle"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "GetDnsSecKeyResult"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Response"), com.ascio.www._2007._01.Response.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "dnsSecKey"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "DnsSecKey"), com.ascio.www._2007._01.DnsSecKey.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[35] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("CreateDnsSecKey");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "sessionId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "dnsSecKey"), org.apache.axis.description.ParameterDesc.INOUT, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "DnsSecKey"), com.ascio.www._2007._01.DnsSecKey.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Response"));
        oper.setReturnClass(com.ascio.www._2007._01.Response.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "CreateDnsSecKeyResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[36] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("SearchDnsSecKey");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "sessionId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "criteria"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "SearchCriteria"), com.ascio.www._2007._01.SearchCriteria.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "SearchDnsSecKeyResult"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Response"), com.ascio.www._2007._01.Response.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "dnsSecKeys"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "ArrayOfDnsSecKey"), com.ascio.www._2007._01.DnsSecKey[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "DnsSecKey"));
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[37] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("CreateDocumentation");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "sessionId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "attachments"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "ArrayOfAttachment"), com.ascio.www._2007._01.Attachment[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Attachment"));
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "CreateDocumentationResult"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Response"), com.ascio.www._2007._01.Response.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "documentationId"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), java.lang.Integer.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[38] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("CreateApprovalDocumentation");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "sessionId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "approvalDocumentation"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "ApprovalDocumentation"), com.ascio.www._2007._01.ApprovalDocumentation.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "CreateApprovalDocumentationResult"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Response"), com.ascio.www._2007._01.Response.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "documentationId"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[39] = oper;

    }

    public BasicHttpBinding_IAscioServicesStub() throws org.apache.axis.AxisFault {
         this(null);
    }

    public BasicHttpBinding_IAscioServicesStub(java.net.URL endpointURL, javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
         this(service);
         super.cachedEndpoint = endpointURL;
    }

    public BasicHttpBinding_IAscioServicesStub(javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
        if (service == null) {
            super.service = new org.apache.axis.client.Service();
        } else {
            super.service = service;
        }
        ((org.apache.axis.client.Service)super.service).setTypeMappingVersion("1.2");
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
            qName = new javax.xml.namespace.QName("http://schemas.microsoft.com/2003/10/Serialization/Arrays", "ArrayOfstring");
            cachedSerQNames.add(qName);
            cls = java.lang.String[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string");
            qName2 = new javax.xml.namespace.QName("http://schemas.microsoft.com/2003/10/Serialization/Arrays", "string");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", ">Extensions>Extension");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2007._01.ExtensionsExtension.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "ApprovalDocumentation");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2007._01.ApprovalDocumentation.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "ApprovalDocumentationType");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2007._01.ApprovalDocumentationType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "ArrayOfAttachment");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2007._01.Attachment[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Attachment");
            qName2 = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Attachment");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "ArrayOfAvailabilityCheckResult");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2007._01.AvailabilityCheckResult[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "AvailabilityCheckResult");
            qName2 = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "AvailabilityCheckResult");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "ArrayOfCallbackStatus");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2007._01.CallbackStatus[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "CallbackStatus");
            qName2 = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "CallbackStatus");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "ArrayOfClause");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2007._01.Clause[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Clause");
            qName2 = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Clause");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "ArrayOfContact");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2007._01.Contact[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Contact");
            qName2 = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Contact");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "ArrayOfDnsSecKey");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2007._01.DnsSecKey[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "DnsSecKey");
            qName2 = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "DnsSecKey");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "ArrayOfDomain");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2007._01.Domain[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Domain");
            qName2 = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Domain");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "ArrayOfMessage");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2007._01.Message[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Message");
            qName2 = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Message");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "ArrayOfNameServer");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2007._01.NameServer[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "NameServer");
            qName2 = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "NameServer");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "ArrayOfOrder");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2007._01.Order[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Order");
            qName2 = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Order");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "ArrayOfOrderStatusType");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2007._01.OrderStatusType[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "OrderStatusType");
            qName2 = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "OrderStatusType");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "ArrayOfOrderType");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2007._01.OrderType[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "OrderType");
            qName2 = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "OrderType");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "ArrayOfPrices");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2007._01.Price[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Price");
            qName2 = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Price");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "ArrayOfRegistrant");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2007._01.Registrant[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Registrant");
            qName2 = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Registrant");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "ArrayOfString");
            cachedSerQNames.add(qName);
            cls = java.lang.String[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string");
            qName2 = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "string");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Attachment");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2007._01.Attachment.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "AvailabilityCheckResult");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2007._01.AvailabilityCheckResult.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "CallbackStatus");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2007._01.CallbackStatus.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Clause");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2007._01.Clause.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Contact");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2007._01.Contact.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "DnsSecKey");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2007._01.DnsSecKey.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "DnsSecKeys");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2007._01.DnsSecKeys.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Domain");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2007._01.Domain.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Extensions");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2007._01.ExtensionsExtension[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", ">Extensions>Extension");
            qName2 = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Extension");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Message");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2007._01.Message.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "MessageType");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2007._01.MessageType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "NameServer");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2007._01.NameServer.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "NameServers");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2007._01.NameServers.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Order");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2007._01.Order.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "OrderStatusType");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2007._01.OrderStatusType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "OrderType");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2007._01.OrderType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "PagingInfo");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2007._01.PagingInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Price");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2007._01.Price.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "PriceInfo");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2007._01.PriceInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "PrivacyProxy");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2007._01.PrivacyProxy.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "PrivacyProxyType");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2007._01.PrivacyProxyType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "QualityType");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2007._01.QualityType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "QueueItem");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2007._01.QueueItem.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Registrant");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2007._01.Registrant.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "RegistrantVerificationDetails");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2007._01.RegistrantVerificationDetails.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "RegistrantVerificationInfo");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2007._01.RegistrantVerificationInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "RegistrantVerificationStatus");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2007._01.RegistrantVerificationStatus.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Response");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2007._01.Response.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "SearchCriteria");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2007._01.SearchCriteria.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "SearchModeType");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2007._01.SearchModeType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "SearchOperatorType");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2007._01.SearchOperatorType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "SearchOrderRequest");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2007._01.SearchOrderRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "SearchOrderSortType");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2007._01.SearchOrderSortType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Session");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2007._01.Session.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "TradeMark");
            cachedSerQNames.add(qName);
            cls = com.ascio.www._2007._01.TradeMark.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

    }

    protected org.apache.axis.client.Call createCall() throws java.rmi.RemoteException {
        try {
            org.apache.axis.client.Call _call = super._createCall();
            if (super.maintainSessionSet) {
                _call.setMaintainSession(super.maintainSession);
            }
            if (super.cachedUsername != null) {
                _call.setUsername(super.cachedUsername);
            }
            if (super.cachedPassword != null) {
                _call.setPassword(super.cachedPassword);
            }
            if (super.cachedEndpoint != null) {
                _call.setTargetEndpointAddress(super.cachedEndpoint);
            }
            if (super.cachedTimeout != null) {
                _call.setTimeout(super.cachedTimeout);
            }
            if (super.cachedPortName != null) {
                _call.setPortName(super.cachedPortName);
            }
            java.util.Enumeration keys = super.cachedProperties.keys();
            while (keys.hasMoreElements()) {
                java.lang.String key = (java.lang.String) keys.nextElement();
                _call.setProperty(key, super.cachedProperties.get(key));
            }
            // All the type mapping information is registered
            // when the first call is made.
            // The type mapping information is actually registered in
            // the TypeMappingRegistry of the service, which
            // is the reason why registration is only needed for the first call.
            synchronized (this) {
                if (firstCall()) {
                    // must set encoding style before registering serializers
                    _call.setEncodingStyle(null);
                    for (int i = 0; i < cachedSerFactories.size(); ++i) {
                        java.lang.Class cls = (java.lang.Class) cachedSerClasses.get(i);
                        javax.xml.namespace.QName qName =
                                (javax.xml.namespace.QName) cachedSerQNames.get(i);
                        java.lang.Object x = cachedSerFactories.get(i);
                        if (x instanceof Class) {
                            java.lang.Class sf = (java.lang.Class)
                                 cachedSerFactories.get(i);
                            java.lang.Class df = (java.lang.Class)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                        else if (x instanceof javax.xml.rpc.encoding.SerializerFactory) {
                            org.apache.axis.encoding.SerializerFactory sf = (org.apache.axis.encoding.SerializerFactory)
                                 cachedSerFactories.get(i);
                            org.apache.axis.encoding.DeserializerFactory df = (org.apache.axis.encoding.DeserializerFactory)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                    }
                }
            }
            return _call;
        }
        catch (java.lang.Throwable _t) {
            throw new org.apache.axis.AxisFault("Failure trying to get the Call object", _t);
        }
    }

    public void logIn(com.ascio.www._2007._01.Session session, com.ascio.www._2007._01.holders.ResponseHolder logInResult, javax.xml.rpc.holders.StringHolder sessionId) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[0]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.ascio.com/2007/01/ISessionService/LogIn");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "LogIn"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {session});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                logInResult.value = (com.ascio.www._2007._01.Response) _output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "LogInResult"));
            } catch (java.lang.Exception _exception) {
                logInResult.value = (com.ascio.www._2007._01.Response) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "LogInResult")), com.ascio.www._2007._01.Response.class);
            }
            try {
                sessionId.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "sessionId"));
            } catch (java.lang.Exception _exception) {
                sessionId.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "sessionId")), java.lang.String.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.ascio.www._2007._01.Response logOut(java.lang.String sessionId) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[1]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.ascio.com/2007/01/ISessionService/LogOut");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "LogOut"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {sessionId});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ascio.www._2007._01.Response) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ascio.www._2007._01.Response) org.apache.axis.utils.JavaUtils.convert(_resp, com.ascio.www._2007._01.Response.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void getOrder(java.lang.String sessionId, java.lang.String orderId, com.ascio.www._2007._01.holders.ResponseHolder getOrderResult, com.ascio.www._2007._01.holders.OrderHolder order) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[2]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.ascio.com/2007/01/IOrderService/GetOrder");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "GetOrder"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {sessionId, orderId});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                getOrderResult.value = (com.ascio.www._2007._01.Response) _output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "GetOrderResult"));
            } catch (java.lang.Exception _exception) {
                getOrderResult.value = (com.ascio.www._2007._01.Response) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "GetOrderResult")), com.ascio.www._2007._01.Response.class);
            }
            try {
                order.value = (com.ascio.www._2007._01.Order) _output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "order"));
            } catch (java.lang.Exception _exception) {
                order.value = (com.ascio.www._2007._01.Order) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "order")), com.ascio.www._2007._01.Order.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.ascio.www._2007._01.Response createOrder(java.lang.String sessionId, com.ascio.www._2007._01.holders.OrderHolder order) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[3]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.ascio.com/2007/01/IOrderService/CreateOrder");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "CreateOrder"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {sessionId, order.value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                order.value = (com.ascio.www._2007._01.Order) _output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "order"));
            } catch (java.lang.Exception _exception) {
                order.value = (com.ascio.www._2007._01.Order) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "order")), com.ascio.www._2007._01.Order.class);
            }
            try {
                return (com.ascio.www._2007._01.Response) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ascio.www._2007._01.Response) org.apache.axis.utils.JavaUtils.convert(_resp, com.ascio.www._2007._01.Response.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void searchOrder(java.lang.String sessionId, com.ascio.www._2007._01.SearchOrderRequest orderRequest, com.ascio.www._2007._01.holders.ResponseHolder searchOrderResult, javax.xml.rpc.holders.IntegerWrapperHolder totalOrders, com.ascio.www._2007._01.holders.ArrayOfOrderHolder orders) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[4]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.ascio.com/2007/01/IOrderService/SearchOrder");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "SearchOrder"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {sessionId, orderRequest});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                searchOrderResult.value = (com.ascio.www._2007._01.Response) _output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "SearchOrderResult"));
            } catch (java.lang.Exception _exception) {
                searchOrderResult.value = (com.ascio.www._2007._01.Response) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "SearchOrderResult")), com.ascio.www._2007._01.Response.class);
            }
            try {
                totalOrders.value = (java.lang.Integer) _output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "totalOrders"));
            } catch (java.lang.Exception _exception) {
                totalOrders.value = (java.lang.Integer) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "totalOrders")), java.lang.Integer.class);
            }
            try {
                orders.value = (com.ascio.www._2007._01.Order[]) _output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "orders"));
            } catch (java.lang.Exception _exception) {
                orders.value = (com.ascio.www._2007._01.Order[]) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "orders")), com.ascio.www._2007._01.Order[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void getMessages(java.lang.String sessionId, java.lang.String orderId, com.ascio.www._2007._01.holders.ResponseHolder getMessagesResult, com.ascio.www._2007._01.holders.ArrayOfMessageHolder messages) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[5]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.ascio.com/2007/01/IOrderService/GetMessages");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "GetMessages"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {sessionId, orderId});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                getMessagesResult.value = (com.ascio.www._2007._01.Response) _output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "GetMessagesResult"));
            } catch (java.lang.Exception _exception) {
                getMessagesResult.value = (com.ascio.www._2007._01.Response) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "GetMessagesResult")), com.ascio.www._2007._01.Response.class);
            }
            try {
                messages.value = (com.ascio.www._2007._01.Message[]) _output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "messages"));
            } catch (java.lang.Exception _exception) {
                messages.value = (com.ascio.www._2007._01.Message[]) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "messages")), com.ascio.www._2007._01.Message[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.ascio.www._2007._01.Response validateOrder(java.lang.String sessionId, com.ascio.www._2007._01.Order order) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[6]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.ascio.com/2007/01/IOrderService/ValidateOrder");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "ValidateOrder"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {sessionId, order});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ascio.www._2007._01.Response) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ascio.www._2007._01.Response) org.apache.axis.utils.JavaUtils.convert(_resp, com.ascio.www._2007._01.Response.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.ascio.www._2007._01.Response uploadDocumentation(java.lang.String sessionId, java.lang.String orderId, java.lang.String fileName, byte[] content) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[7]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.ascio.com/2007/01/IOrderService/UploadDocumentation");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "UploadDocumentation"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {sessionId, orderId, fileName, content});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ascio.www._2007._01.Response) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ascio.www._2007._01.Response) org.apache.axis.utils.JavaUtils.convert(_resp, com.ascio.www._2007._01.Response.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void createSupportOrder(java.lang.String sessionId, java.lang.String subject, java.lang.String body, com.ascio.www._2007._01.Attachment[] attachments, com.ascio.www._2007._01.holders.ResponseHolder createSupportOrderResult, javax.xml.rpc.holders.StringHolder orderId) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[8]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.ascio.com/2007/01/IOrderService/CreateSupportOrder");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "CreateSupportOrder"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {sessionId, subject, body, attachments});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                createSupportOrderResult.value = (com.ascio.www._2007._01.Response) _output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "CreateSupportOrderResult"));
            } catch (java.lang.Exception _exception) {
                createSupportOrderResult.value = (com.ascio.www._2007._01.Response) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "CreateSupportOrderResult")), com.ascio.www._2007._01.Response.class);
            }
            try {
                orderId.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "orderId"));
            } catch (java.lang.Exception _exception) {
                orderId.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "orderId")), java.lang.String.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.ascio.www._2007._01.Response uploadMessage(java.lang.String sessionId, java.lang.String orderId, com.ascio.www._2007._01.Message message) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[9]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.ascio.com/2007/01/IOrderService/UploadMessage");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "UploadMessage"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {sessionId, orderId, message});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ascio.www._2007._01.Response) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ascio.www._2007._01.Response) org.apache.axis.utils.JavaUtils.convert(_resp, com.ascio.www._2007._01.Response.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void getDomain(java.lang.String sessionId, java.lang.String domainHandle, com.ascio.www._2007._01.holders.ResponseHolder getDomainResult, com.ascio.www._2007._01.holders.DomainHolder domain) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[10]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.ascio.com/2007/01/IDomainService/GetDomain");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "GetDomain"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {sessionId, domainHandle});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                getDomainResult.value = (com.ascio.www._2007._01.Response) _output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "GetDomainResult"));
            } catch (java.lang.Exception _exception) {
                getDomainResult.value = (com.ascio.www._2007._01.Response) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "GetDomainResult")), com.ascio.www._2007._01.Response.class);
            }
            try {
                domain.value = (com.ascio.www._2007._01.Domain) _output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "domain"));
            } catch (java.lang.Exception _exception) {
                domain.value = (com.ascio.www._2007._01.Domain) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "domain")), com.ascio.www._2007._01.Domain.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void searchDomain(java.lang.String sessionId, com.ascio.www._2007._01.SearchCriteria criteria, com.ascio.www._2007._01.holders.ResponseHolder searchDomainResult, com.ascio.www._2007._01.holders.ArrayOfDomainHolder domains) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[11]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.ascio.com/2007/01/IDomainService/SearchDomain");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "SearchDomain"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {sessionId, criteria});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                searchDomainResult.value = (com.ascio.www._2007._01.Response) _output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "SearchDomainResult"));
            } catch (java.lang.Exception _exception) {
                searchDomainResult.value = (com.ascio.www._2007._01.Response) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "SearchDomainResult")), com.ascio.www._2007._01.Response.class);
            }
            try {
                domains.value = (com.ascio.www._2007._01.Domain[]) _output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "domains"));
            } catch (java.lang.Exception _exception) {
                domains.value = (com.ascio.www._2007._01.Domain[]) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "domains")), com.ascio.www._2007._01.Domain[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void whois(java.lang.String sessionId, java.lang.String domainName, com.ascio.www._2007._01.holders.ResponseHolder whoisResult, javax.xml.rpc.holders.StringHolder whoisData) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[12]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.ascio.com/2007/01/IDomainService/Whois");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "Whois"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {sessionId, domainName});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                whoisResult.value = (com.ascio.www._2007._01.Response) _output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "WhoisResult"));
            } catch (java.lang.Exception _exception) {
                whoisResult.value = (com.ascio.www._2007._01.Response) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "WhoisResult")), com.ascio.www._2007._01.Response.class);
            }
            try {
                whoisData.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "whoisData"));
            } catch (java.lang.Exception _exception) {
                whoisData.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "whoisData")), java.lang.String.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void availabilityCheck(java.lang.String sessionId, java.lang.String[] domains, java.lang.String[] tlds, com.ascio.www._2007._01.QualityType quality, com.ascio.www._2007._01.holders.ResponseHolder availabilityCheckResult, com.ascio.www._2007._01.holders.ArrayOfAvailabilityCheckResultHolder results) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[13]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.ascio.com/2007/01/IDomainService/AvailabilityCheck");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "AvailabilityCheck"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {sessionId, domains, tlds, quality});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                availabilityCheckResult.value = (com.ascio.www._2007._01.Response) _output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "AvailabilityCheckResult"));
            } catch (java.lang.Exception _exception) {
                availabilityCheckResult.value = (com.ascio.www._2007._01.Response) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "AvailabilityCheckResult")), com.ascio.www._2007._01.Response.class);
            }
            try {
                results.value = (com.ascio.www._2007._01.AvailabilityCheckResult[]) _output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "results"));
            } catch (java.lang.Exception _exception) {
                results.value = (com.ascio.www._2007._01.AvailabilityCheckResult[]) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "results")), com.ascio.www._2007._01.AvailabilityCheckResult[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void availabilityInfo(java.lang.String sessionId, java.lang.String domainName, com.ascio.www._2007._01.QualityType quality, com.ascio.www._2007._01.holders.ResponseHolder availabilityInfoResult, com.ascio.www._2007._01.holders.PriceInfoHolder priceInfo) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[14]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.ascio.com/2007/01/IDomainService/AvailabilityInfo");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "AvailabilityInfo"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {sessionId, domainName, quality});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                availabilityInfoResult.value = (com.ascio.www._2007._01.Response) _output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "AvailabilityInfoResult"));
            } catch (java.lang.Exception _exception) {
                availabilityInfoResult.value = (com.ascio.www._2007._01.Response) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "AvailabilityInfoResult")), com.ascio.www._2007._01.Response.class);
            }
            try {
                priceInfo.value = (com.ascio.www._2007._01.PriceInfo) _output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "PriceInfo"));
            } catch (java.lang.Exception _exception) {
                priceInfo.value = (com.ascio.www._2007._01.PriceInfo) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "PriceInfo")), com.ascio.www._2007._01.PriceInfo.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void getRegistrant(java.lang.String sessionId, java.lang.String registrantHandle, com.ascio.www._2007._01.holders.ResponseHolder getRegistrantResult, com.ascio.www._2007._01.holders.RegistrantHolder registrant) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[15]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.ascio.com/2007/01/IRegistrantService/GetRegistrant");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "GetRegistrant"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {sessionId, registrantHandle});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                getRegistrantResult.value = (com.ascio.www._2007._01.Response) _output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "GetRegistrantResult"));
            } catch (java.lang.Exception _exception) {
                getRegistrantResult.value = (com.ascio.www._2007._01.Response) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "GetRegistrantResult")), com.ascio.www._2007._01.Response.class);
            }
            try {
                registrant.value = (com.ascio.www._2007._01.Registrant) _output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "registrant"));
            } catch (java.lang.Exception _exception) {
                registrant.value = (com.ascio.www._2007._01.Registrant) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "registrant")), com.ascio.www._2007._01.Registrant.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.ascio.www._2007._01.Response createRegistrant(java.lang.String sessionId, com.ascio.www._2007._01.holders.RegistrantHolder registrant) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[16]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.ascio.com/2007/01/IRegistrantService/CreateRegistrant");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "CreateRegistrant"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {sessionId, registrant.value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                registrant.value = (com.ascio.www._2007._01.Registrant) _output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "registrant"));
            } catch (java.lang.Exception _exception) {
                registrant.value = (com.ascio.www._2007._01.Registrant) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "registrant")), com.ascio.www._2007._01.Registrant.class);
            }
            try {
                return (com.ascio.www._2007._01.Response) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ascio.www._2007._01.Response) org.apache.axis.utils.JavaUtils.convert(_resp, com.ascio.www._2007._01.Response.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.ascio.www._2007._01.Response deleteRegistrant(java.lang.String sessionId, java.lang.String registrantHandle) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[17]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.ascio.com/2007/01/IRegistrantService/DeleteRegistrant");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "DeleteRegistrant"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {sessionId, registrantHandle});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ascio.www._2007._01.Response) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ascio.www._2007._01.Response) org.apache.axis.utils.JavaUtils.convert(_resp, com.ascio.www._2007._01.Response.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void searchRegistrant(java.lang.String sessionId, com.ascio.www._2007._01.SearchCriteria criteria, com.ascio.www._2007._01.holders.ResponseHolder searchRegistrantResult, com.ascio.www._2007._01.holders.ArrayOfRegistrantHolder registrants) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[18]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.ascio.com/2007/01/IRegistrantService/SearchRegistrant");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "SearchRegistrant"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {sessionId, criteria});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                searchRegistrantResult.value = (com.ascio.www._2007._01.Response) _output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "SearchRegistrantResult"));
            } catch (java.lang.Exception _exception) {
                searchRegistrantResult.value = (com.ascio.www._2007._01.Response) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "SearchRegistrantResult")), com.ascio.www._2007._01.Response.class);
            }
            try {
                registrants.value = (com.ascio.www._2007._01.Registrant[]) _output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "registrants"));
            } catch (java.lang.Exception _exception) {
                registrants.value = (com.ascio.www._2007._01.Registrant[]) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "registrants")), com.ascio.www._2007._01.Registrant[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void getRegistrantVerificationInfo(java.lang.String sessionId, java.lang.String value, com.ascio.www._2007._01.holders.ResponseHolder getRegistrantVerificationInfoResult, com.ascio.www._2007._01.holders.RegistrantVerificationInfoHolder verificationInfo) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[19]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.ascio.com/2007/01/IRegistrantService/GetRegistrantVerificationInfo");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "GetRegistrantVerificationInfo"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {sessionId, value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                getRegistrantVerificationInfoResult.value = (com.ascio.www._2007._01.Response) _output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "GetRegistrantVerificationInfoResult"));
            } catch (java.lang.Exception _exception) {
                getRegistrantVerificationInfoResult.value = (com.ascio.www._2007._01.Response) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "GetRegistrantVerificationInfoResult")), com.ascio.www._2007._01.Response.class);
            }
            try {
                verificationInfo.value = (com.ascio.www._2007._01.RegistrantVerificationInfo) _output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "verificationInfo"));
            } catch (java.lang.Exception _exception) {
                verificationInfo.value = (com.ascio.www._2007._01.RegistrantVerificationInfo) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "verificationInfo")), com.ascio.www._2007._01.RegistrantVerificationInfo.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.ascio.www._2007._01.Response doRegistrantVerification(java.lang.String sessionId, java.lang.String value) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[20]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.ascio.com/2007/01/IRegistrantService/DoRegistrantVerification");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "DoRegistrantVerification"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {sessionId, value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ascio.www._2007._01.Response) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ascio.www._2007._01.Response) org.apache.axis.utils.JavaUtils.convert(_resp, com.ascio.www._2007._01.Response.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void getRegistrantVerificationStatus(java.lang.String sessionId, java.lang.String value, com.ascio.www._2007._01.holders.ResponseHolder getRegistrantVerificationStatusResult, com.ascio.www._2007._01.holders.RegistrantVerificationStatusHolder verificationStatus) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[21]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.ascio.com/2007/01/IRegistrantService/GetRegistrantVerificationStatus");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "GetRegistrantVerificationStatus"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {sessionId, value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                getRegistrantVerificationStatusResult.value = (com.ascio.www._2007._01.Response) _output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "GetRegistrantVerificationStatusResult"));
            } catch (java.lang.Exception _exception) {
                getRegistrantVerificationStatusResult.value = (com.ascio.www._2007._01.Response) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "GetRegistrantVerificationStatusResult")), com.ascio.www._2007._01.Response.class);
            }
            try {
                verificationStatus.value = (com.ascio.www._2007._01.RegistrantVerificationStatus) _output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "verificationStatus"));
            } catch (java.lang.Exception _exception) {
                verificationStatus.value = (com.ascio.www._2007._01.RegistrantVerificationStatus) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "verificationStatus")), com.ascio.www._2007._01.RegistrantVerificationStatus.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.ascio.www._2007._01.Response uploadRegistrantVerificationMessage(java.lang.String sessionId, java.lang.String value, com.ascio.www._2007._01.RegistrantVerificationDetails details) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[22]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.ascio.com/2007/01/IRegistrantService/UploadRegistrantVerificationMessage");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "UploadRegistrantVerificationMessage"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {sessionId, value, details});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ascio.www._2007._01.Response) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ascio.www._2007._01.Response) org.apache.axis.utils.JavaUtils.convert(_resp, com.ascio.www._2007._01.Response.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void getContact(java.lang.String sessionId, java.lang.String contactHandle, com.ascio.www._2007._01.holders.ResponseHolder getContactResult, com.ascio.www._2007._01.holders.ContactHolder contact) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[23]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.ascio.com/2007/01/IContactService/GetContact");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "GetContact"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {sessionId, contactHandle});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                getContactResult.value = (com.ascio.www._2007._01.Response) _output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "GetContactResult"));
            } catch (java.lang.Exception _exception) {
                getContactResult.value = (com.ascio.www._2007._01.Response) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "GetContactResult")), com.ascio.www._2007._01.Response.class);
            }
            try {
                contact.value = (com.ascio.www._2007._01.Contact) _output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "contact"));
            } catch (java.lang.Exception _exception) {
                contact.value = (com.ascio.www._2007._01.Contact) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "contact")), com.ascio.www._2007._01.Contact.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.ascio.www._2007._01.Response createContact(java.lang.String sessionId, com.ascio.www._2007._01.holders.ContactHolder contact) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[24]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.ascio.com/2007/01/IContactService/CreateContact");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "CreateContact"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {sessionId, contact.value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                contact.value = (com.ascio.www._2007._01.Contact) _output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "contact"));
            } catch (java.lang.Exception _exception) {
                contact.value = (com.ascio.www._2007._01.Contact) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "contact")), com.ascio.www._2007._01.Contact.class);
            }
            try {
                return (com.ascio.www._2007._01.Response) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ascio.www._2007._01.Response) org.apache.axis.utils.JavaUtils.convert(_resp, com.ascio.www._2007._01.Response.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.ascio.www._2007._01.Response updateContact(java.lang.String sessionId, com.ascio.www._2007._01.Contact contact) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[25]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.ascio.com/2007/01/IContactService/UpdateContact");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "UpdateContact"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {sessionId, contact});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ascio.www._2007._01.Response) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ascio.www._2007._01.Response) org.apache.axis.utils.JavaUtils.convert(_resp, com.ascio.www._2007._01.Response.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.ascio.www._2007._01.Response deleteContact(java.lang.String sessionId, java.lang.String contactHandle) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[26]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.ascio.com/2007/01/IContactService/DeleteContact");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "DeleteContact"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {sessionId, contactHandle});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ascio.www._2007._01.Response) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ascio.www._2007._01.Response) org.apache.axis.utils.JavaUtils.convert(_resp, com.ascio.www._2007._01.Response.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void searchContact(java.lang.String sessionId, com.ascio.www._2007._01.SearchCriteria criteria, com.ascio.www._2007._01.holders.ResponseHolder searchContactResult, com.ascio.www._2007._01.holders.ArrayOfContactHolder contacts) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[27]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.ascio.com/2007/01/IContactService/SearchContact");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "SearchContact"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {sessionId, criteria});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                searchContactResult.value = (com.ascio.www._2007._01.Response) _output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "SearchContactResult"));
            } catch (java.lang.Exception _exception) {
                searchContactResult.value = (com.ascio.www._2007._01.Response) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "SearchContactResult")), com.ascio.www._2007._01.Response.class);
            }
            try {
                contacts.value = (com.ascio.www._2007._01.Contact[]) _output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "contacts"));
            } catch (java.lang.Exception _exception) {
                contacts.value = (com.ascio.www._2007._01.Contact[]) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "contacts")), com.ascio.www._2007._01.Contact[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void getNameServer(java.lang.String sessionId, java.lang.String nameServerHandle, com.ascio.www._2007._01.holders.ResponseHolder getNameServerResult, com.ascio.www._2007._01.holders.NameServerHolder nameServer) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[28]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.ascio.com/2007/01/INameServerService/GetNameServer");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "GetNameServer"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {sessionId, nameServerHandle});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                getNameServerResult.value = (com.ascio.www._2007._01.Response) _output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "GetNameServerResult"));
            } catch (java.lang.Exception _exception) {
                getNameServerResult.value = (com.ascio.www._2007._01.Response) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "GetNameServerResult")), com.ascio.www._2007._01.Response.class);
            }
            try {
                nameServer.value = (com.ascio.www._2007._01.NameServer) _output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "nameServer"));
            } catch (java.lang.Exception _exception) {
                nameServer.value = (com.ascio.www._2007._01.NameServer) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "nameServer")), com.ascio.www._2007._01.NameServer.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.ascio.www._2007._01.Response createNameServer(java.lang.String sessionId, com.ascio.www._2007._01.holders.NameServerHolder nameServer) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[29]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.ascio.com/2007/01/INameServerService/CreateNameServer");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "CreateNameServer"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {sessionId, nameServer.value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                nameServer.value = (com.ascio.www._2007._01.NameServer) _output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "nameServer"));
            } catch (java.lang.Exception _exception) {
                nameServer.value = (com.ascio.www._2007._01.NameServer) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "nameServer")), com.ascio.www._2007._01.NameServer.class);
            }
            try {
                return (com.ascio.www._2007._01.Response) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ascio.www._2007._01.Response) org.apache.axis.utils.JavaUtils.convert(_resp, com.ascio.www._2007._01.Response.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.ascio.www._2007._01.Response deleteNameServer(java.lang.String sessionId, java.lang.String nameServerHandle) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[30]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.ascio.com/2007/01/INameServerService/DeleteNameServer");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "DeleteNameServer"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {sessionId, nameServerHandle});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ascio.www._2007._01.Response) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ascio.www._2007._01.Response) org.apache.axis.utils.JavaUtils.convert(_resp, com.ascio.www._2007._01.Response.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void searchNameServer(java.lang.String sessionId, com.ascio.www._2007._01.SearchCriteria criteria, com.ascio.www._2007._01.holders.ResponseHolder searchNameServerResult, com.ascio.www._2007._01.holders.ArrayOfNameServerHolder nameServers) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[31]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.ascio.com/2007/01/INameServerService/SearchNameServer");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "SearchNameServer"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {sessionId, criteria});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                searchNameServerResult.value = (com.ascio.www._2007._01.Response) _output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "SearchNameServerResult"));
            } catch (java.lang.Exception _exception) {
                searchNameServerResult.value = (com.ascio.www._2007._01.Response) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "SearchNameServerResult")), com.ascio.www._2007._01.Response.class);
            }
            try {
                nameServers.value = (com.ascio.www._2007._01.NameServer[]) _output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "nameServers"));
            } catch (java.lang.Exception _exception) {
                nameServers.value = (com.ascio.www._2007._01.NameServer[]) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "nameServers")), com.ascio.www._2007._01.NameServer[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void pollMessage(java.lang.String sessionId, com.ascio.www._2007._01.MessageType msgType, com.ascio.www._2007._01.holders.ResponseHolder pollMessageResult, javax.xml.rpc.holders.IntegerWrapperHolder msgCount, com.ascio.www._2007._01.holders.QueueItemHolder item) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[32]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.ascio.com/2007/01/IMessageQueueService/PollMessage");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "PollMessage"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {sessionId, msgType});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                pollMessageResult.value = (com.ascio.www._2007._01.Response) _output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "PollMessageResult"));
            } catch (java.lang.Exception _exception) {
                pollMessageResult.value = (com.ascio.www._2007._01.Response) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "PollMessageResult")), com.ascio.www._2007._01.Response.class);
            }
            try {
                msgCount.value = (java.lang.Integer) _output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "msgCount"));
            } catch (java.lang.Exception _exception) {
                msgCount.value = (java.lang.Integer) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "msgCount")), java.lang.Integer.class);
            }
            try {
                item.value = (com.ascio.www._2007._01.QueueItem) _output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "item"));
            } catch (java.lang.Exception _exception) {
                item.value = (com.ascio.www._2007._01.QueueItem) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "item")), com.ascio.www._2007._01.QueueItem.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.ascio.www._2007._01.Response ackMessage(java.lang.String sessionId, java.lang.Integer msgId) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[33]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.ascio.com/2007/01/IMessageQueueService/AckMessage");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "AckMessage"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {sessionId, msgId});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ascio.www._2007._01.Response) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ascio.www._2007._01.Response) org.apache.axis.utils.JavaUtils.convert(_resp, com.ascio.www._2007._01.Response.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void getMessageQueue(java.lang.String sessionId, java.lang.Integer msgId, com.ascio.www._2007._01.holders.ResponseHolder getMessageQueueResult, com.ascio.www._2007._01.holders.QueueItemHolder item) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[34]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.ascio.com/2007/01/IMessageQueueService/GetMessageQueue");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "GetMessageQueue"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {sessionId, msgId});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                getMessageQueueResult.value = (com.ascio.www._2007._01.Response) _output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "GetMessageQueueResult"));
            } catch (java.lang.Exception _exception) {
                getMessageQueueResult.value = (com.ascio.www._2007._01.Response) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "GetMessageQueueResult")), com.ascio.www._2007._01.Response.class);
            }
            try {
                item.value = (com.ascio.www._2007._01.QueueItem) _output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "item"));
            } catch (java.lang.Exception _exception) {
                item.value = (com.ascio.www._2007._01.QueueItem) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "item")), com.ascio.www._2007._01.QueueItem.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void getDnsSecKey(java.lang.String sessionId, java.lang.String dnsSecKeyHandle, com.ascio.www._2007._01.holders.ResponseHolder getDnsSecKeyResult, com.ascio.www._2007._01.holders.DnsSecKeyHolder dnsSecKey) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[35]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.ascio.com/2007/01/IDnsSecKeyService/GetDnsSecKey");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "GetDnsSecKey"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {sessionId, dnsSecKeyHandle});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                getDnsSecKeyResult.value = (com.ascio.www._2007._01.Response) _output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "GetDnsSecKeyResult"));
            } catch (java.lang.Exception _exception) {
                getDnsSecKeyResult.value = (com.ascio.www._2007._01.Response) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "GetDnsSecKeyResult")), com.ascio.www._2007._01.Response.class);
            }
            try {
                dnsSecKey.value = (com.ascio.www._2007._01.DnsSecKey) _output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "dnsSecKey"));
            } catch (java.lang.Exception _exception) {
                dnsSecKey.value = (com.ascio.www._2007._01.DnsSecKey) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "dnsSecKey")), com.ascio.www._2007._01.DnsSecKey.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.ascio.www._2007._01.Response createDnsSecKey(java.lang.String sessionId, com.ascio.www._2007._01.holders.DnsSecKeyHolder dnsSecKey) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[36]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.ascio.com/2007/01/IDnsSecKeyService/CreateDnsSecKey");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "CreateDnsSecKey"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {sessionId, dnsSecKey.value});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                dnsSecKey.value = (com.ascio.www._2007._01.DnsSecKey) _output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "dnsSecKey"));
            } catch (java.lang.Exception _exception) {
                dnsSecKey.value = (com.ascio.www._2007._01.DnsSecKey) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "dnsSecKey")), com.ascio.www._2007._01.DnsSecKey.class);
            }
            try {
                return (com.ascio.www._2007._01.Response) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ascio.www._2007._01.Response) org.apache.axis.utils.JavaUtils.convert(_resp, com.ascio.www._2007._01.Response.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void searchDnsSecKey(java.lang.String sessionId, com.ascio.www._2007._01.SearchCriteria criteria, com.ascio.www._2007._01.holders.ResponseHolder searchDnsSecKeyResult, com.ascio.www._2007._01.holders.ArrayOfDnsSecKeyHolder dnsSecKeys) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[37]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.ascio.com/2007/01/IDnsSecKeyService/SearchDnsSecKey");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "SearchDnsSecKey"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {sessionId, criteria});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                searchDnsSecKeyResult.value = (com.ascio.www._2007._01.Response) _output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "SearchDnsSecKeyResult"));
            } catch (java.lang.Exception _exception) {
                searchDnsSecKeyResult.value = (com.ascio.www._2007._01.Response) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "SearchDnsSecKeyResult")), com.ascio.www._2007._01.Response.class);
            }
            try {
                dnsSecKeys.value = (com.ascio.www._2007._01.DnsSecKey[]) _output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "dnsSecKeys"));
            } catch (java.lang.Exception _exception) {
                dnsSecKeys.value = (com.ascio.www._2007._01.DnsSecKey[]) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "dnsSecKeys")), com.ascio.www._2007._01.DnsSecKey[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void createDocumentation(java.lang.String sessionId, com.ascio.www._2007._01.Attachment[] attachments, com.ascio.www._2007._01.holders.ResponseHolder createDocumentationResult, javax.xml.rpc.holders.IntegerWrapperHolder documentationId) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[38]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.ascio.com/2007/01/IOrderService/CreateDocumentation");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "CreateDocumentation"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {sessionId, attachments});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                createDocumentationResult.value = (com.ascio.www._2007._01.Response) _output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "CreateDocumentationResult"));
            } catch (java.lang.Exception _exception) {
                createDocumentationResult.value = (com.ascio.www._2007._01.Response) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "CreateDocumentationResult")), com.ascio.www._2007._01.Response.class);
            }
            try {
                documentationId.value = (java.lang.Integer) _output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "documentationId"));
            } catch (java.lang.Exception _exception) {
                documentationId.value = (java.lang.Integer) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "documentationId")), java.lang.Integer.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void createApprovalDocumentation(java.lang.String sessionId, com.ascio.www._2007._01.ApprovalDocumentation approvalDocumentation, com.ascio.www._2007._01.holders.ResponseHolder createApprovalDocumentationResult, javax.xml.rpc.holders.StringHolder documentationId) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[39]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://www.ascio.com/2007/01/IOrderService/CreateApprovalDocumentation");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "CreateApprovalDocumentation"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {sessionId, approvalDocumentation});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                createApprovalDocumentationResult.value = (com.ascio.www._2007._01.Response) _output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "CreateApprovalDocumentationResult"));
            } catch (java.lang.Exception _exception) {
                createApprovalDocumentationResult.value = (com.ascio.www._2007._01.Response) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "CreateApprovalDocumentationResult")), com.ascio.www._2007._01.Response.class);
            }
            try {
                documentationId.value = (java.lang.String) _output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "documentationId"));
            } catch (java.lang.Exception _exception) {
                documentationId.value = (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://www.ascio.com/2007/01", "documentationId")), java.lang.String.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

}
