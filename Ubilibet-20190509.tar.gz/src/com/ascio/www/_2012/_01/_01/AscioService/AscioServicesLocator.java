/**
 * AscioServicesLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ascio.www._2012._01._01.AscioService;

@SuppressWarnings({ "rawtypes", "serial", "unchecked" })
public class AscioServicesLocator extends org.apache.axis.client.Service implements com.ascio.www._2012._01._01.AscioService.AscioServices {

    public AscioServicesLocator() {
    }


    public AscioServicesLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public AscioServicesLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for BasicHttpBinding_IAscioServices
    private java.lang.String BasicHttpBinding_IAscioServices_address = "https://aws.ascio.com/2012/01/01/AscioService.svc";

    public java.lang.String getBasicHttpBinding_IAscioServicesAddress() {
        return BasicHttpBinding_IAscioServices_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String BasicHttpBinding_IAscioServicesWSDDServiceName = "BasicHttpBinding_IAscioServices";

    public java.lang.String getBasicHttpBinding_IAscioServicesWSDDServiceName() {
        return BasicHttpBinding_IAscioServicesWSDDServiceName;
    }

    public void setBasicHttpBinding_IAscioServicesWSDDServiceName(java.lang.String name) {
        BasicHttpBinding_IAscioServicesWSDDServiceName = name;
    }

    public com.ascio.www._2007._01.IAscioServices getBasicHttpBinding_IAscioServices() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(BasicHttpBinding_IAscioServices_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getBasicHttpBinding_IAscioServices(endpoint);
    }

    public com.ascio.www._2007._01.IAscioServices getBasicHttpBinding_IAscioServices(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            com.ascio.www._2012._01._01.AscioService.BasicHttpBinding_IAscioServicesStub _stub = new com.ascio.www._2012._01._01.AscioService.BasicHttpBinding_IAscioServicesStub(portAddress, this);
            _stub.setPortName(getBasicHttpBinding_IAscioServicesWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setBasicHttpBinding_IAscioServicesEndpointAddress(java.lang.String address) {
        BasicHttpBinding_IAscioServices_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (com.ascio.www._2007._01.IAscioServices.class.isAssignableFrom(serviceEndpointInterface)) {
                com.ascio.www._2012._01._01.AscioService.BasicHttpBinding_IAscioServicesStub _stub = new com.ascio.www._2012._01._01.AscioService.BasicHttpBinding_IAscioServicesStub(new java.net.URL(BasicHttpBinding_IAscioServices_address), this);
                _stub.setPortName(getBasicHttpBinding_IAscioServicesWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("BasicHttpBinding_IAscioServices".equals(inputPortName)) {
            return getBasicHttpBinding_IAscioServices();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://www.ascio.com/2012/01/01/AscioService", "AscioServices");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://www.ascio.com/2012/01/01/AscioService", "BasicHttpBinding_IAscioServices"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("BasicHttpBinding_IAscioServices".equals(portName)) {
            setBasicHttpBinding_IAscioServicesEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
