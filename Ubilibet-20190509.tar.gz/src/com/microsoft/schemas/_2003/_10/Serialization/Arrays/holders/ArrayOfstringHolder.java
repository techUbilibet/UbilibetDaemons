/**
 * ArrayOfstringHolder.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.microsoft.schemas._2003._10.Serialization.Arrays.holders;

public final class ArrayOfstringHolder implements javax.xml.rpc.holders.Holder {
    public java.lang.String[] value;

    public ArrayOfstringHolder() {
    }

    public ArrayOfstringHolder(java.lang.String[] value) {
        this.value = value;
    }

}
