/**
 * UserHolder.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.groupnbt._2010._10._30.Dns.DnsService.holders;

public final class UserHolder implements javax.xml.rpc.holders.Holder {
    public com.groupnbt._2010._10._30.Dns.DnsService.User value;

    public UserHolder() {
    }

    public UserHolder(com.groupnbt._2010._10._30.Dns.DnsService.User value) {
        this.value = value;
    }

}
