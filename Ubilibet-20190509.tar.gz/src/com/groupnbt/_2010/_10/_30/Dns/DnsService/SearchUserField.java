/**
 * SearchUserField.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.groupnbt._2010._10._30.Dns.DnsService;

@SuppressWarnings({"unused", "serial","rawtypes","unchecked"})
public class SearchUserField implements java.io.Serializable {
    private java.lang.String _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    protected SearchUserField(java.lang.String value) {
        _value_ = value;
        _table_.put(_value_,this);
    }

    public static final java.lang.String _UserName = "UserName";
    public static final java.lang.String _RoleType = "RoleType";
    public static final java.lang.String _Email = "Email";
    public static final SearchUserField UserName = new SearchUserField(_UserName);
    public static final SearchUserField RoleType = new SearchUserField(_RoleType);
    public static final SearchUserField Email = new SearchUserField(_Email);
    public java.lang.String getValue() { return _value_;}
    public static SearchUserField fromValue(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        SearchUserField enumeration = (SearchUserField)
            _table_.get(value);
        if (enumeration==null) throw new java.lang.IllegalArgumentException();
        return enumeration;
    }
    public static SearchUserField fromString(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        return fromValue(value);
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_;}
    public java.lang.Object readResolve() throws java.io.ObjectStreamException { return fromValue(_value_);}
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumSerializer(
            _javaType, _xmlType);
    }
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumDeserializer(
            _javaType, _xmlType);
    }
    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(SearchUserField.class);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "SearchUserField"));
    }
    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

}
