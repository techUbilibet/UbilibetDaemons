/**
 * ZoneLogEntry.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.groupnbt._2010._10._30.Dns.DnsService;

@SuppressWarnings({"serial","unused","rawtypes"})
public class ZoneLogEntry  implements java.io.Serializable {
    private java.lang.String action;

    private java.lang.String actionBy;

    private java.lang.String actionByIpAddress;

    private java.util.Calendar actionDate;

    private com.groupnbt._2010._10._30.Dns.DnsService.Record record;

    private java.lang.String zoneName;

    public ZoneLogEntry() {
    }

    public ZoneLogEntry(
           java.lang.String action,
           java.lang.String actionBy,
           java.lang.String actionByIpAddress,
           java.util.Calendar actionDate,
           com.groupnbt._2010._10._30.Dns.DnsService.Record record,
           java.lang.String zoneName) {
           this.action = action;
           this.actionBy = actionBy;
           this.actionByIpAddress = actionByIpAddress;
           this.actionDate = actionDate;
           this.record = record;
           this.zoneName = zoneName;
    }


    /**
     * Gets the action value for this ZoneLogEntry.
     * 
     * @return action
     */
    public java.lang.String getAction() {
        return action;
    }


    /**
     * Sets the action value for this ZoneLogEntry.
     * 
     * @param action
     */
    public void setAction(java.lang.String action) {
        this.action = action;
    }


    /**
     * Gets the actionBy value for this ZoneLogEntry.
     * 
     * @return actionBy
     */
    public java.lang.String getActionBy() {
        return actionBy;
    }


    /**
     * Sets the actionBy value for this ZoneLogEntry.
     * 
     * @param actionBy
     */
    public void setActionBy(java.lang.String actionBy) {
        this.actionBy = actionBy;
    }


    /**
     * Gets the actionByIpAddress value for this ZoneLogEntry.
     * 
     * @return actionByIpAddress
     */
    public java.lang.String getActionByIpAddress() {
        return actionByIpAddress;
    }


    /**
     * Sets the actionByIpAddress value for this ZoneLogEntry.
     * 
     * @param actionByIpAddress
     */
    public void setActionByIpAddress(java.lang.String actionByIpAddress) {
        this.actionByIpAddress = actionByIpAddress;
    }


    /**
     * Gets the actionDate value for this ZoneLogEntry.
     * 
     * @return actionDate
     */
    public java.util.Calendar getActionDate() {
        return actionDate;
    }


    /**
     * Sets the actionDate value for this ZoneLogEntry.
     * 
     * @param actionDate
     */
    public void setActionDate(java.util.Calendar actionDate) {
        this.actionDate = actionDate;
    }


    /**
     * Gets the record value for this ZoneLogEntry.
     * 
     * @return record
     */
    public com.groupnbt._2010._10._30.Dns.DnsService.Record getRecord() {
        return record;
    }


    /**
     * Sets the record value for this ZoneLogEntry.
     * 
     * @param record
     */
    public void setRecord(com.groupnbt._2010._10._30.Dns.DnsService.Record record) {
        this.record = record;
    }


    /**
     * Gets the zoneName value for this ZoneLogEntry.
     * 
     * @return zoneName
     */
    public java.lang.String getZoneName() {
        return zoneName;
    }


    /**
     * Sets the zoneName value for this ZoneLogEntry.
     * 
     * @param zoneName
     */
    public void setZoneName(java.lang.String zoneName) {
        this.zoneName = zoneName;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ZoneLogEntry)) return false;
        ZoneLogEntry other = (ZoneLogEntry) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.action==null && other.getAction()==null) || 
             (this.action!=null &&
              this.action.equals(other.getAction()))) &&
            ((this.actionBy==null && other.getActionBy()==null) || 
             (this.actionBy!=null &&
              this.actionBy.equals(other.getActionBy()))) &&
            ((this.actionByIpAddress==null && other.getActionByIpAddress()==null) || 
             (this.actionByIpAddress!=null &&
              this.actionByIpAddress.equals(other.getActionByIpAddress()))) &&
            ((this.actionDate==null && other.getActionDate()==null) || 
             (this.actionDate!=null &&
              this.actionDate.equals(other.getActionDate()))) &&
            ((this.record==null && other.getRecord()==null) || 
             (this.record!=null &&
              this.record.equals(other.getRecord()))) &&
            ((this.zoneName==null && other.getZoneName()==null) || 
             (this.zoneName!=null &&
              this.zoneName.equals(other.getZoneName())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getAction() != null) {
            _hashCode += getAction().hashCode();
        }
        if (getActionBy() != null) {
            _hashCode += getActionBy().hashCode();
        }
        if (getActionByIpAddress() != null) {
            _hashCode += getActionByIpAddress().hashCode();
        }
        if (getActionDate() != null) {
            _hashCode += getActionDate().hashCode();
        }
        if (getRecord() != null) {
            _hashCode += getRecord().hashCode();
        }
        if (getZoneName() != null) {
            _hashCode += getZoneName().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ZoneLogEntry.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "ZoneLogEntry"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("action");
        elemField.setXmlName(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "Action"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("actionBy");
        elemField.setXmlName(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "ActionBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("actionByIpAddress");
        elemField.setXmlName(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "ActionByIpAddress"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("actionDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "ActionDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("record");
        elemField.setXmlName(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "Record"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "Record"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("zoneName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "ZoneName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
