/**
 * DnsService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.groupnbt._2010._10._30.Dns.DnsService;

public interface DnsService extends javax.xml.rpc.Service {
    public java.lang.String getBasicHttpBinding_IDnsServiceAddress();

    public com.groupnbt._2010._10._30.Dns.DnsService.IDnsService getBasicHttpBinding_IDnsService() throws javax.xml.rpc.ServiceException;

    public com.groupnbt._2010._10._30.Dns.DnsService.IDnsService getBasicHttpBinding_IDnsService(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
