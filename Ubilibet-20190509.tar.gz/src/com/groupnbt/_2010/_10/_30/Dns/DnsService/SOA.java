/**
 * SOA.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.groupnbt._2010._10._30.Dns.DnsService;

@SuppressWarnings({"serial","unused","rawtypes"})
public class SOA  extends com.groupnbt._2010._10._30.Dns.DnsService.Record  implements java.io.Serializable {
    private java.lang.Integer expire;

    private java.lang.String hostmasterEmail;

    private java.lang.String primaryNameServer;

    private java.lang.Integer refresh;

    private java.lang.Integer retry;

    private java.lang.Integer serialUsage;

    public SOA() {
    }

    public SOA(
           java.lang.Integer id,
           java.lang.Long serial,
           java.lang.String source,
           java.lang.Long TTL,
           java.lang.String target,
           java.util.Calendar updatedDate,
           java.lang.Integer expire,
           java.lang.String hostmasterEmail,
           java.lang.String primaryNameServer,
           java.lang.Integer refresh,
           java.lang.Integer retry,
           java.lang.Integer serialUsage) {
        super(
            id,
            serial,
            source,
            TTL,
            target,
            updatedDate);
        this.expire = expire;
        this.hostmasterEmail = hostmasterEmail;
        this.primaryNameServer = primaryNameServer;
        this.refresh = refresh;
        this.retry = retry;
        this.serialUsage = serialUsage;
    }


    /**
     * Gets the expire value for this SOA.
     * 
     * @return expire
     */
    public java.lang.Integer getExpire() {
        return expire;
    }


    /**
     * Sets the expire value for this SOA.
     * 
     * @param expire
     */
    public void setExpire(java.lang.Integer expire) {
        this.expire = expire;
    }


    /**
     * Gets the hostmasterEmail value for this SOA.
     * 
     * @return hostmasterEmail
     */
    public java.lang.String getHostmasterEmail() {
        return hostmasterEmail;
    }


    /**
     * Sets the hostmasterEmail value for this SOA.
     * 
     * @param hostmasterEmail
     */
    public void setHostmasterEmail(java.lang.String hostmasterEmail) {
        this.hostmasterEmail = hostmasterEmail;
    }


    /**
     * Gets the primaryNameServer value for this SOA.
     * 
     * @return primaryNameServer
     */
    public java.lang.String getPrimaryNameServer() {
        return primaryNameServer;
    }


    /**
     * Sets the primaryNameServer value for this SOA.
     * 
     * @param primaryNameServer
     */
    public void setPrimaryNameServer(java.lang.String primaryNameServer) {
        this.primaryNameServer = primaryNameServer;
    }


    /**
     * Gets the refresh value for this SOA.
     * 
     * @return refresh
     */
    public java.lang.Integer getRefresh() {
        return refresh;
    }


    /**
     * Sets the refresh value for this SOA.
     * 
     * @param refresh
     */
    public void setRefresh(java.lang.Integer refresh) {
        this.refresh = refresh;
    }


    /**
     * Gets the retry value for this SOA.
     * 
     * @return retry
     */
    public java.lang.Integer getRetry() {
        return retry;
    }


    /**
     * Sets the retry value for this SOA.
     * 
     * @param retry
     */
    public void setRetry(java.lang.Integer retry) {
        this.retry = retry;
    }


    /**
     * Gets the serialUsage value for this SOA.
     * 
     * @return serialUsage
     */
    public java.lang.Integer getSerialUsage() {
        return serialUsage;
    }


    /**
     * Sets the serialUsage value for this SOA.
     * 
     * @param serialUsage
     */
    public void setSerialUsage(java.lang.Integer serialUsage) {
        this.serialUsage = serialUsage;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof SOA)) return false;
        SOA other = (SOA) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.expire==null && other.getExpire()==null) || 
             (this.expire!=null &&
              this.expire.equals(other.getExpire()))) &&
            ((this.hostmasterEmail==null && other.getHostmasterEmail()==null) || 
             (this.hostmasterEmail!=null &&
              this.hostmasterEmail.equals(other.getHostmasterEmail()))) &&
            ((this.primaryNameServer==null && other.getPrimaryNameServer()==null) || 
             (this.primaryNameServer!=null &&
              this.primaryNameServer.equals(other.getPrimaryNameServer()))) &&
            ((this.refresh==null && other.getRefresh()==null) || 
             (this.refresh!=null &&
              this.refresh.equals(other.getRefresh()))) &&
            ((this.retry==null && other.getRetry()==null) || 
             (this.retry!=null &&
              this.retry.equals(other.getRetry()))) &&
            ((this.serialUsage==null && other.getSerialUsage()==null) || 
             (this.serialUsage!=null &&
              this.serialUsage.equals(other.getSerialUsage())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getExpire() != null) {
            _hashCode += getExpire().hashCode();
        }
        if (getHostmasterEmail() != null) {
            _hashCode += getHostmasterEmail().hashCode();
        }
        if (getPrimaryNameServer() != null) {
            _hashCode += getPrimaryNameServer().hashCode();
        }
        if (getRefresh() != null) {
            _hashCode += getRefresh().hashCode();
        }
        if (getRetry() != null) {
            _hashCode += getRetry().hashCode();
        }
        if (getSerialUsage() != null) {
            _hashCode += getSerialUsage().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(SOA.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "SOA"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("expire");
        elemField.setXmlName(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "Expire"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hostmasterEmail");
        elemField.setXmlName(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "HostmasterEmail"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("primaryNameServer");
        elemField.setXmlName(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "PrimaryNameServer"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("refresh");
        elemField.setXmlName(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "Refresh"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("retry");
        elemField.setXmlName(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "Retry"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("serialUsage");
        elemField.setXmlName(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "SerialUsage"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
