/**
 * SearchUserClause.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.groupnbt._2010._10._30.Dns.DnsService;

@SuppressWarnings({"serial","unused","rawtypes"})
public class SearchUserClause  implements java.io.Serializable {
    private com.groupnbt._2010._10._30.Dns.DnsService.SearchOperatorType operator;

    private com.groupnbt._2010._10._30.Dns.DnsService.SearchUserField searchUserField;

    private java.lang.String value;

    public SearchUserClause() {
    }

    public SearchUserClause(
           com.groupnbt._2010._10._30.Dns.DnsService.SearchOperatorType operator,
           com.groupnbt._2010._10._30.Dns.DnsService.SearchUserField searchUserField,
           java.lang.String value) {
           this.operator = operator;
           this.searchUserField = searchUserField;
           this.value = value;
    }


    /**
     * Gets the operator value for this SearchUserClause.
     * 
     * @return operator
     */
    public com.groupnbt._2010._10._30.Dns.DnsService.SearchOperatorType getOperator() {
        return operator;
    }


    /**
     * Sets the operator value for this SearchUserClause.
     * 
     * @param operator
     */
    public void setOperator(com.groupnbt._2010._10._30.Dns.DnsService.SearchOperatorType operator) {
        this.operator = operator;
    }


    /**
     * Gets the searchUserField value for this SearchUserClause.
     * 
     * @return searchUserField
     */
    public com.groupnbt._2010._10._30.Dns.DnsService.SearchUserField getSearchUserField() {
        return searchUserField;
    }


    /**
     * Sets the searchUserField value for this SearchUserClause.
     * 
     * @param searchUserField
     */
    public void setSearchUserField(com.groupnbt._2010._10._30.Dns.DnsService.SearchUserField searchUserField) {
        this.searchUserField = searchUserField;
    }


    /**
     * Gets the value value for this SearchUserClause.
     * 
     * @return value
     */
    public java.lang.String getValue() {
        return value;
    }


    /**
     * Sets the value value for this SearchUserClause.
     * 
     * @param value
     */
    public void setValue(java.lang.String value) {
        this.value = value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof SearchUserClause)) return false;
        SearchUserClause other = (SearchUserClause) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.operator==null && other.getOperator()==null) || 
             (this.operator!=null &&
              this.operator.equals(other.getOperator()))) &&
            ((this.searchUserField==null && other.getSearchUserField()==null) || 
             (this.searchUserField!=null &&
              this.searchUserField.equals(other.getSearchUserField()))) &&
            ((this.value==null && other.getValue()==null) || 
             (this.value!=null &&
              this.value.equals(other.getValue())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getOperator() != null) {
            _hashCode += getOperator().hashCode();
        }
        if (getSearchUserField() != null) {
            _hashCode += getSearchUserField().hashCode();
        }
        if (getValue() != null) {
            _hashCode += getValue().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(SearchUserClause.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "SearchUserClause"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("operator");
        elemField.setXmlName(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "Operator"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "SearchOperatorType"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("searchUserField");
        elemField.setXmlName(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "SearchUserField"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "SearchUserField"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("value");
        elemField.setXmlName(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "Value"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
