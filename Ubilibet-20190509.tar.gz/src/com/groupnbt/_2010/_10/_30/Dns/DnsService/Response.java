/**
 * Response.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.groupnbt._2010._10._30.Dns.DnsService;

@SuppressWarnings({"serial","unused","rawtypes"})
public class Response  implements java.io.Serializable {
    private java.lang.Short statusCode;

    private java.lang.String statusMessage;

    private java.lang.String technicalGuid;

    private java.lang.String trackingReference;

    private java.lang.String[] values;

    public Response() {
    }

    public Response(
           java.lang.Short statusCode,
           java.lang.String statusMessage,
           java.lang.String technicalGuid,
           java.lang.String trackingReference,
           java.lang.String[] values) {
           this.statusCode = statusCode;
           this.statusMessage = statusMessage;
           this.technicalGuid = technicalGuid;
           this.trackingReference = trackingReference;
           this.values = values;
    }


    /**
     * Gets the statusCode value for this Response.
     * 
     * @return statusCode
     */
    public java.lang.Short getStatusCode() {
        return statusCode;
    }


    /**
     * Sets the statusCode value for this Response.
     * 
     * @param statusCode
     */
    public void setStatusCode(java.lang.Short statusCode) {
        this.statusCode = statusCode;
    }


    /**
     * Gets the statusMessage value for this Response.
     * 
     * @return statusMessage
     */
    public java.lang.String getStatusMessage() {
        return statusMessage;
    }


    /**
     * Sets the statusMessage value for this Response.
     * 
     * @param statusMessage
     */
    public void setStatusMessage(java.lang.String statusMessage) {
        this.statusMessage = statusMessage;
    }


    /**
     * Gets the technicalGuid value for this Response.
     * 
     * @return technicalGuid
     */
    public java.lang.String getTechnicalGuid() {
        return technicalGuid;
    }


    /**
     * Sets the technicalGuid value for this Response.
     * 
     * @param technicalGuid
     */
    public void setTechnicalGuid(java.lang.String technicalGuid) {
        this.technicalGuid = technicalGuid;
    }


    /**
     * Gets the trackingReference value for this Response.
     * 
     * @return trackingReference
     */
    public java.lang.String getTrackingReference() {
        return trackingReference;
    }


    /**
     * Sets the trackingReference value for this Response.
     * 
     * @param trackingReference
     */
    public void setTrackingReference(java.lang.String trackingReference) {
        this.trackingReference = trackingReference;
    }


    /**
     * Gets the values value for this Response.
     * 
     * @return values
     */
    public java.lang.String[] getValues() {
        return values;
    }


    /**
     * Sets the values value for this Response.
     * 
     * @param values
     */
    public void setValues(java.lang.String[] values) {
        this.values = values;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Response)) return false;
        Response other = (Response) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.statusCode==null && other.getStatusCode()==null) || 
             (this.statusCode!=null &&
              this.statusCode.equals(other.getStatusCode()))) &&
            ((this.statusMessage==null && other.getStatusMessage()==null) || 
             (this.statusMessage!=null &&
              this.statusMessage.equals(other.getStatusMessage()))) &&
            ((this.technicalGuid==null && other.getTechnicalGuid()==null) || 
             (this.technicalGuid!=null &&
              this.technicalGuid.equals(other.getTechnicalGuid()))) &&
            ((this.trackingReference==null && other.getTrackingReference()==null) || 
             (this.trackingReference!=null &&
              this.trackingReference.equals(other.getTrackingReference()))) &&
            ((this.values==null && other.getValues()==null) || 
             (this.values!=null &&
              java.util.Arrays.equals(this.values, other.getValues())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getStatusCode() != null) {
            _hashCode += getStatusCode().hashCode();
        }
        if (getStatusMessage() != null) {
            _hashCode += getStatusMessage().hashCode();
        }
        if (getTechnicalGuid() != null) {
            _hashCode += getTechnicalGuid().hashCode();
        }
        if (getTrackingReference() != null) {
            _hashCode += getTrackingReference().hashCode();
        }
        if (getValues() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getValues());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getValues(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Response.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "Response"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("statusCode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "StatusCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "short"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("statusMessage");
        elemField.setXmlName(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "StatusMessage"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("technicalGuid");
        elemField.setXmlName(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "TechnicalGuid"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("trackingReference");
        elemField.setXmlName(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "TrackingReference"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("values");
        elemField.setXmlName(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "Values"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://schemas.microsoft.com/2003/10/Serialization/Arrays", "string"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
