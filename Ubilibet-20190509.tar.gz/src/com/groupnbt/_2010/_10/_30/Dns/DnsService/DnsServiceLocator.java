/**
 * DnsServiceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.groupnbt._2010._10._30.Dns.DnsService;

@SuppressWarnings({"serial","unchecked","rawtypes"})
public class DnsServiceLocator extends org.apache.axis.client.Service implements com.groupnbt._2010._10._30.Dns.DnsService.DnsService {

    public DnsServiceLocator() {
    }


    public DnsServiceLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public DnsServiceLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for BasicHttpBinding_IDnsService
    private java.lang.String BasicHttpBinding_IDnsService_address = "https://dnsservice.ascio.com/2010/10/30/DnsService.svc";

    public java.lang.String getBasicHttpBinding_IDnsServiceAddress() {
        return BasicHttpBinding_IDnsService_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String BasicHttpBinding_IDnsServiceWSDDServiceName = "BasicHttpBinding_IDnsService";

    public java.lang.String getBasicHttpBinding_IDnsServiceWSDDServiceName() {
        return BasicHttpBinding_IDnsServiceWSDDServiceName;
    }

    public void setBasicHttpBinding_IDnsServiceWSDDServiceName(java.lang.String name) {
        BasicHttpBinding_IDnsServiceWSDDServiceName = name;
    }

    public com.groupnbt._2010._10._30.Dns.DnsService.IDnsService getBasicHttpBinding_IDnsService() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(BasicHttpBinding_IDnsService_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getBasicHttpBinding_IDnsService(endpoint);
    }

    public com.groupnbt._2010._10._30.Dns.DnsService.IDnsService getBasicHttpBinding_IDnsService(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            com.groupnbt._2010._10._30.Dns.DnsService.BasicHttpBinding_IDnsServiceStub _stub = new com.groupnbt._2010._10._30.Dns.DnsService.BasicHttpBinding_IDnsServiceStub(portAddress, this);
            _stub.setPortName(getBasicHttpBinding_IDnsServiceWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setBasicHttpBinding_IDnsServiceEndpointAddress(java.lang.String address) {
        BasicHttpBinding_IDnsService_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (com.groupnbt._2010._10._30.Dns.DnsService.IDnsService.class.isAssignableFrom(serviceEndpointInterface)) {
                com.groupnbt._2010._10._30.Dns.DnsService.BasicHttpBinding_IDnsServiceStub _stub = new com.groupnbt._2010._10._30.Dns.DnsService.BasicHttpBinding_IDnsServiceStub(new java.net.URL(BasicHttpBinding_IDnsService_address), this);
                _stub.setPortName(getBasicHttpBinding_IDnsServiceWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("BasicHttpBinding_IDnsService".equals(inputPortName)) {
            return getBasicHttpBinding_IDnsService();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "DnsService");
    }

    private java.util.HashSet ports = null;

	public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "BasicHttpBinding_IDnsService"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("BasicHttpBinding_IDnsService".equals(portName)) {
            setBasicHttpBinding_IDnsServiceEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
