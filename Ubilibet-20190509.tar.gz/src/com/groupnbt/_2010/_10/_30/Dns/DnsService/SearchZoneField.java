/**
 * SearchZoneField.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.groupnbt._2010._10._30.Dns.DnsService;

@SuppressWarnings({"unused", "serial","rawtypes","unchecked"})
public class SearchZoneField implements java.io.Serializable {
    private java.lang.String _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    protected SearchZoneField(java.lang.String value) {
        _value_ = value;
        _table_.put(_value_,this);
    }

    public static final java.lang.String _ZoneName = "ZoneName";
    public static final java.lang.String _Owner = "Owner";
    public static final java.lang.String _Source = "Source";
    public static final java.lang.String _Target = "Target";
    public static final java.lang.String _RecordType = "RecordType";
    public static final java.lang.String _CreatedDate = "CreatedDate";
    public static final java.lang.String _TTL = "TTL";
    public static final SearchZoneField ZoneName = new SearchZoneField(_ZoneName);
    public static final SearchZoneField Owner = new SearchZoneField(_Owner);
    public static final SearchZoneField Source = new SearchZoneField(_Source);
    public static final SearchZoneField Target = new SearchZoneField(_Target);
    public static final SearchZoneField RecordType = new SearchZoneField(_RecordType);
    public static final SearchZoneField CreatedDate = new SearchZoneField(_CreatedDate);
    public static final SearchZoneField TTL = new SearchZoneField(_TTL);
    public java.lang.String getValue() { return _value_;}
    public static SearchZoneField fromValue(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        SearchZoneField enumeration = (SearchZoneField)
            _table_.get(value);
        if (enumeration==null) throw new java.lang.IllegalArgumentException();
        return enumeration;
    }
    public static SearchZoneField fromString(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        return fromValue(value);
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_;}
    public java.lang.Object readResolve() throws java.io.ObjectStreamException { return fromValue(_value_);}
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumSerializer(
            _javaType, _xmlType);
    }
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumDeserializer(
            _javaType, _xmlType);
    }
    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(SearchZoneField.class);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "SearchZoneField"));
    }
    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

}
