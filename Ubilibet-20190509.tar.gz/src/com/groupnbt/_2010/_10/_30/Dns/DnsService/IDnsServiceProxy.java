package com.groupnbt._2010._10._30.Dns.DnsService;

public class IDnsServiceProxy implements com.groupnbt._2010._10._30.Dns.DnsService.IDnsService {
  private String _endpoint = null;
  private com.groupnbt._2010._10._30.Dns.DnsService.IDnsService iDnsService = null;
  
  public IDnsServiceProxy() {
    _initIDnsServiceProxy();
  }
  
  public IDnsServiceProxy(String endpoint) {
    _endpoint = endpoint;
    _initIDnsServiceProxy();
  }
  
  private void _initIDnsServiceProxy() {
    try {
      iDnsService = (new com.groupnbt._2010._10._30.Dns.DnsService.DnsServiceLocator()).getBasicHttpBinding_IDnsService();
      if (iDnsService != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)iDnsService)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)iDnsService)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (iDnsService != null)
      ((javax.xml.rpc.Stub)iDnsService)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.groupnbt._2010._10._30.Dns.DnsService.IDnsService getIDnsService() {
    if (iDnsService == null)
      _initIDnsServiceProxy();
    return iDnsService;
  }
  
  public void getRoles(com.groupnbt._2010._10._30.Dns.DnsService.holders.ResponseHolder getRolesResult, com.groupnbt._2010._10._30.Dns.DnsService.holders.ArrayOfRoleItemHolder roles) throws java.rmi.RemoteException{
    if (iDnsService == null)
      _initIDnsServiceProxy();
    iDnsService.getRoles(getRolesResult, roles);
  }
  
  public com.groupnbt._2010._10._30.Dns.DnsService.Response createUser(com.groupnbt._2010._10._30.Dns.DnsService.User user) throws java.rmi.RemoteException{
    if (iDnsService == null)
      _initIDnsServiceProxy();
    return iDnsService.createUser(user);
  }
  
  public com.groupnbt._2010._10._30.Dns.DnsService.Response updateUser(com.groupnbt._2010._10._30.Dns.DnsService.User user) throws java.rmi.RemoteException{
    if (iDnsService == null)
      _initIDnsServiceProxy();
    return iDnsService.updateUser(user);
  }
  
  public com.groupnbt._2010._10._30.Dns.DnsService.Response deleteUser(java.lang.String userName) throws java.rmi.RemoteException{
    if (iDnsService == null)
      _initIDnsServiceProxy();
    return iDnsService.deleteUser(userName);
  }
  
  public void getUser(java.lang.String userName, com.groupnbt._2010._10._30.Dns.DnsService.holders.ResponseHolder getUserResult, com.groupnbt._2010._10._30.Dns.DnsService.holders.UserHolder user) throws java.rmi.RemoteException{
    if (iDnsService == null)
      _initIDnsServiceProxy();
    iDnsService.getUser(userName, getUserResult, user);
  }
  
  public void searchUser(com.groupnbt._2010._10._30.Dns.DnsService.SearchUserClause[] searchUserClauses, com.groupnbt._2010._10._30.Dns.DnsService.holders.ResponseHolder searchUserResult, com.microsoft.schemas._2003._10.Serialization.Arrays.holders.ArrayOfstringHolder userNames) throws java.rmi.RemoteException{
    if (iDnsService == null)
      _initIDnsServiceProxy();
    iDnsService.searchUser(searchUserClauses, searchUserResult, userNames);
  }
  
  public com.groupnbt._2010._10._30.Dns.DnsService.Response changePassword(java.lang.String userName, java.lang.String newPassword) throws java.rmi.RemoteException{
    if (iDnsService == null)
      _initIDnsServiceProxy();
    return iDnsService.changePassword(userName, newPassword);
  }
  
  public com.groupnbt._2010._10._30.Dns.DnsService.Response createZone(java.lang.String zoneName, java.lang.String owner, com.groupnbt._2010._10._30.Dns.DnsService.Record[] records) throws java.rmi.RemoteException{
    if (iDnsService == null)
      _initIDnsServiceProxy();
    return iDnsService.createZone(zoneName, owner, records);
  }
  
  public com.groupnbt._2010._10._30.Dns.DnsService.Response deleteZone(java.lang.String zoneName) throws java.rmi.RemoteException{
    if (iDnsService == null)
      _initIDnsServiceProxy();
    return iDnsService.deleteZone(zoneName);
  }
  
  public void getZoneLog(java.lang.String zoneName, com.groupnbt._2010._10._30.Dns.DnsService.holders.ResponseHolder getZoneLogResult, com.groupnbt._2010._10._30.Dns.DnsService.holders.ArrayOfZoneLogEntryHolder zoneLogEntries) throws java.rmi.RemoteException{
    if (iDnsService == null)
      _initIDnsServiceProxy();
    iDnsService.getZoneLog(zoneName, getZoneLogResult, zoneLogEntries);
  }
  
  public void getZone(java.lang.String zoneName, com.groupnbt._2010._10._30.Dns.DnsService.holders.ResponseHolder getZoneResult, com.groupnbt._2010._10._30.Dns.DnsService.holders.ZoneHolder zone) throws java.rmi.RemoteException{
    if (iDnsService == null)
      _initIDnsServiceProxy();
    iDnsService.getZone(zoneName, getZoneResult, zone);
  }
  
  public void restoreZone(java.lang.String zoneName, com.groupnbt._2010._10._30.Dns.DnsService.holders.ResponseHolder restoreZoneResult, com.groupnbt._2010._10._30.Dns.DnsService.holders.ZoneHolder zone) throws java.rmi.RemoteException{
    if (iDnsService == null)
      _initIDnsServiceProxy();
    iDnsService.restoreZone(zoneName, restoreZoneResult, zone);
  }
  
  public void searchZoneNames(com.groupnbt._2010._10._30.Dns.DnsService.SearchZoneClause[] searchZoneClauses, com.groupnbt._2010._10._30.Dns.DnsService.holders.ResponseHolder searchZoneNamesResult, com.microsoft.schemas._2003._10.Serialization.Arrays.holders.ArrayOfstringHolder zoneNames) throws java.rmi.RemoteException{
    if (iDnsService == null)
      _initIDnsServiceProxy();
    iDnsService.searchZoneNames(searchZoneClauses, searchZoneNamesResult, zoneNames);
  }
  
  public void searchZone(com.groupnbt._2010._10._30.Dns.DnsService.SearchZoneClause[] searchZoneClauses, com.groupnbt._2010._10._30.Dns.DnsService.ZoneInfoLevel zoneInfoLevel, com.groupnbt._2010._10._30.Dns.DnsService.holders.ResponseHolder searchZoneResult, com.groupnbt._2010._10._30.Dns.DnsService.holders.ArrayOfZoneHolder zones) throws java.rmi.RemoteException{
    if (iDnsService == null)
      _initIDnsServiceProxy();
    iDnsService.searchZone(searchZoneClauses, zoneInfoLevel, searchZoneResult, zones);
  }
  
  public com.groupnbt._2010._10._30.Dns.DnsService.Response setZoneOwner(java.lang.String zoneName, java.lang.String owner) throws java.rmi.RemoteException{
    if (iDnsService == null)
      _initIDnsServiceProxy();
    return iDnsService.setZoneOwner(zoneName, owner);
  }
  
  public void createRecord(java.lang.String zoneName, com.groupnbt._2010._10._30.Dns.DnsService.Record record, com.groupnbt._2010._10._30.Dns.DnsService.holders.ResponseHolder createRecordResult, javax.xml.rpc.holders.IntegerWrapperHolder recordId) throws java.rmi.RemoteException{
    if (iDnsService == null)
      _initIDnsServiceProxy();
    iDnsService.createRecord(zoneName, record, createRecordResult, recordId);
  }
  
  public com.groupnbt._2010._10._30.Dns.DnsService.Response updateRecord(com.groupnbt._2010._10._30.Dns.DnsService.Record record) throws java.rmi.RemoteException{
    if (iDnsService == null)
      _initIDnsServiceProxy();
    return iDnsService.updateRecord(record);
  }
  
  public com.groupnbt._2010._10._30.Dns.DnsService.Response deleteRecord(java.lang.Integer recordId) throws java.rmi.RemoteException{
    if (iDnsService == null)
      _initIDnsServiceProxy();
    return iDnsService.deleteRecord(recordId);
  }
  
  public void getRecord(java.lang.Integer recordId, com.groupnbt._2010._10._30.Dns.DnsService.holders.ResponseHolder getRecordResult, com.groupnbt._2010._10._30.Dns.DnsService.holders.RecordHolder record) throws java.rmi.RemoteException{
    if (iDnsService == null)
      _initIDnsServiceProxy();
    iDnsService.getRecord(recordId, getRecordResult, record);
  }
  
  
}