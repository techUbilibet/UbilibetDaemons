/**
 * BasicHttpBinding_IDnsServiceStub.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.groupnbt._2010._10._30.Dns.DnsService;

@SuppressWarnings({"unused","rawtypes","unchecked"})
public class BasicHttpBinding_IDnsServiceStub extends org.apache.axis.client.Stub implements com.groupnbt._2010._10._30.Dns.DnsService.IDnsService {
    private java.util.Vector cachedSerClasses = new java.util.Vector();
    private java.util.Vector cachedSerQNames = new java.util.Vector();
    private java.util.Vector cachedSerFactories = new java.util.Vector();
    private java.util.Vector cachedDeserFactories = new java.util.Vector();

    static org.apache.axis.description.OperationDesc [] _operations;

    static {
        _operations = new org.apache.axis.description.OperationDesc[19];
        _initOperationDesc1();
        _initOperationDesc2();
    }

    private static void _initOperationDesc1(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetRoles");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "GetRolesResult"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "Response"), com.groupnbt._2010._10._30.Dns.DnsService.Response.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "roles"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "ArrayOfRoleItem"), com.groupnbt._2010._10._30.Dns.DnsService.RoleItem[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "RoleItem"));
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[0] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("CreateUser");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "user"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "User"), com.groupnbt._2010._10._30.Dns.DnsService.User.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "Response"));
        oper.setReturnClass(com.groupnbt._2010._10._30.Dns.DnsService.Response.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "CreateUserResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[1] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("UpdateUser");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "user"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "User"), com.groupnbt._2010._10._30.Dns.DnsService.User.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "Response"));
        oper.setReturnClass(com.groupnbt._2010._10._30.Dns.DnsService.Response.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "UpdateUserResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[2] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("DeleteUser");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "userName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "Response"));
        oper.setReturnClass(com.groupnbt._2010._10._30.Dns.DnsService.Response.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "DeleteUserResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[3] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetUser");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "userName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "GetUserResult"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "Response"), com.groupnbt._2010._10._30.Dns.DnsService.Response.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "user"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "User"), com.groupnbt._2010._10._30.Dns.DnsService.User.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[4] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("SearchUser");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "searchUserClauses"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "ArrayOfSearchUserClause"), com.groupnbt._2010._10._30.Dns.DnsService.SearchUserClause[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "SearchUserClause"));
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "SearchUserResult"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "Response"), com.groupnbt._2010._10._30.Dns.DnsService.Response.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "userNames"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://schemas.microsoft.com/2003/10/Serialization/Arrays", "ArrayOfstring"), java.lang.String[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://schemas.microsoft.com/2003/10/Serialization/Arrays", "string"));
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[5] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("ChangePassword");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "userName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "newPassword"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "Response"));
        oper.setReturnClass(com.groupnbt._2010._10._30.Dns.DnsService.Response.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "ChangePasswordResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[6] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("CreateZone");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "zoneName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "owner"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "records"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "ArrayOfRecord"), com.groupnbt._2010._10._30.Dns.DnsService.Record[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "Record"));
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "Response"));
        oper.setReturnClass(com.groupnbt._2010._10._30.Dns.DnsService.Response.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "CreateZoneResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[7] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("DeleteZone");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "zoneName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "Response"));
        oper.setReturnClass(com.groupnbt._2010._10._30.Dns.DnsService.Response.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "DeleteZoneResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[8] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetZoneLog");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "zoneName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "GetZoneLogResult"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "Response"), com.groupnbt._2010._10._30.Dns.DnsService.Response.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "zoneLogEntries"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "ArrayOfZoneLogEntry"), com.groupnbt._2010._10._30.Dns.DnsService.ZoneLogEntry[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "ZoneLogEntry"));
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[9] = oper;

    }

    private static void _initOperationDesc2(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetZone");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "zoneName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "GetZoneResult"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "Response"), com.groupnbt._2010._10._30.Dns.DnsService.Response.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "zone"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "Zone"), com.groupnbt._2010._10._30.Dns.DnsService.Zone.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[10] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("RestoreZone");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "zoneName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "RestoreZoneResult"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "Response"), com.groupnbt._2010._10._30.Dns.DnsService.Response.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "zone"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "Zone"), com.groupnbt._2010._10._30.Dns.DnsService.Zone.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[11] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("SearchZoneNames");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "searchZoneClauses"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "ArrayOfSearchZoneClause"), com.groupnbt._2010._10._30.Dns.DnsService.SearchZoneClause[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "SearchZoneClause"));
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "SearchZoneNamesResult"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "Response"), com.groupnbt._2010._10._30.Dns.DnsService.Response.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "zoneNames"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://schemas.microsoft.com/2003/10/Serialization/Arrays", "ArrayOfstring"), java.lang.String[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://schemas.microsoft.com/2003/10/Serialization/Arrays", "string"));
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[12] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("SearchZone");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "searchZoneClauses"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "ArrayOfSearchZoneClause"), com.groupnbt._2010._10._30.Dns.DnsService.SearchZoneClause[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "SearchZoneClause"));
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "zoneInfoLevel"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "ZoneInfoLevel"), com.groupnbt._2010._10._30.Dns.DnsService.ZoneInfoLevel.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "SearchZoneResult"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "Response"), com.groupnbt._2010._10._30.Dns.DnsService.Response.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "zones"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "ArrayOfZone"), com.groupnbt._2010._10._30.Dns.DnsService.Zone[].class, false, false);
        param.setItemQName(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "Zone"));
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[13] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("SetZoneOwner");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "zoneName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "owner"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "Response"));
        oper.setReturnClass(com.groupnbt._2010._10._30.Dns.DnsService.Response.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "SetZoneOwnerResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[14] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("CreateRecord");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "zoneName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "record"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "Record"), com.groupnbt._2010._10._30.Dns.DnsService.Record.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "CreateRecordResult"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "Response"), com.groupnbt._2010._10._30.Dns.DnsService.Response.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "recordId"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), java.lang.Integer.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[15] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("UpdateRecord");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "record"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "Record"), com.groupnbt._2010._10._30.Dns.DnsService.Record.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "Response"));
        oper.setReturnClass(com.groupnbt._2010._10._30.Dns.DnsService.Response.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "UpdateRecordResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[16] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("DeleteRecord");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "recordId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), java.lang.Integer.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "Response"));
        oper.setReturnClass(com.groupnbt._2010._10._30.Dns.DnsService.Response.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "DeleteRecordResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[17] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetRecord");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "recordId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), java.lang.Integer.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "GetRecordResult"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "Response"), com.groupnbt._2010._10._30.Dns.DnsService.Response.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "record"), org.apache.axis.description.ParameterDesc.OUT, new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "Record"), com.groupnbt._2010._10._30.Dns.DnsService.Record.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[18] = oper;

    }

    public BasicHttpBinding_IDnsServiceStub() throws org.apache.axis.AxisFault {
         this(null);
    }

    public BasicHttpBinding_IDnsServiceStub(java.net.URL endpointURL, javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
         this(service);
         super.cachedEndpoint = endpointURL;
    }

	public BasicHttpBinding_IDnsServiceStub(javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
        if (service == null) {
            super.service = new org.apache.axis.client.Service();
        } else {
            super.service = service;
        }
        ((org.apache.axis.client.Service)super.service).setTypeMappingVersion("1.2");
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
            qName = new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "A");
            cachedSerQNames.add(qName);
            cls = com.groupnbt._2010._10._30.Dns.DnsService.A.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "AAAA");
            cachedSerQNames.add(qName);
            cls = com.groupnbt._2010._10._30.Dns.DnsService.AAAA.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "ArrayOfRecord");
            cachedSerQNames.add(qName);
            cls = com.groupnbt._2010._10._30.Dns.DnsService.Record[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "Record");
            qName2 = new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "Record");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "ArrayOfRoleItem");
            cachedSerQNames.add(qName);
            cls = com.groupnbt._2010._10._30.Dns.DnsService.RoleItem[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "RoleItem");
            qName2 = new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "RoleItem");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "ArrayOfSearchUserClause");
            cachedSerQNames.add(qName);
            cls = com.groupnbt._2010._10._30.Dns.DnsService.SearchUserClause[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "SearchUserClause");
            qName2 = new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "SearchUserClause");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "ArrayOfSearchZoneClause");
            cachedSerQNames.add(qName);
            cls = com.groupnbt._2010._10._30.Dns.DnsService.SearchZoneClause[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "SearchZoneClause");
            qName2 = new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "SearchZoneClause");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "ArrayOfZone");
            cachedSerQNames.add(qName);
            cls = com.groupnbt._2010._10._30.Dns.DnsService.Zone[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "Zone");
            qName2 = new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "Zone");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "ArrayOfZoneLogEntry");
            cachedSerQNames.add(qName);
            cls = com.groupnbt._2010._10._30.Dns.DnsService.ZoneLogEntry[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "ZoneLogEntry");
            qName2 = new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "ZoneLogEntry");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "CNAME");
            cachedSerQNames.add(qName);
            cls = com.groupnbt._2010._10._30.Dns.DnsService.CNAME.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "MailForward");
            cachedSerQNames.add(qName);
            cls = com.groupnbt._2010._10._30.Dns.DnsService.MailForward.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "MX");
            cachedSerQNames.add(qName);
            cls = com.groupnbt._2010._10._30.Dns.DnsService.MX.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "NS");
            cachedSerQNames.add(qName);
            cls = com.groupnbt._2010._10._30.Dns.DnsService.NS.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "PTR");
            cachedSerQNames.add(qName);
            cls = com.groupnbt._2010._10._30.Dns.DnsService.PTR.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "Record");
            cachedSerQNames.add(qName);
            cls = com.groupnbt._2010._10._30.Dns.DnsService.Record.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "RedirectionType");
            cachedSerQNames.add(qName);
            cls = com.groupnbt._2010._10._30.Dns.DnsService.RedirectionType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "Response");
            cachedSerQNames.add(qName);
            cls = com.groupnbt._2010._10._30.Dns.DnsService.Response.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "RoleItem");
            cachedSerQNames.add(qName);
            cls = com.groupnbt._2010._10._30.Dns.DnsService.RoleItem.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "SearchOperatorType");
            cachedSerQNames.add(qName);
            cls = com.groupnbt._2010._10._30.Dns.DnsService.SearchOperatorType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "SearchUserClause");
            cachedSerQNames.add(qName);
            cls = com.groupnbt._2010._10._30.Dns.DnsService.SearchUserClause.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "SearchUserField");
            cachedSerQNames.add(qName);
            cls = com.groupnbt._2010._10._30.Dns.DnsService.SearchUserField.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "SearchZoneClause");
            cachedSerQNames.add(qName);
            cls = com.groupnbt._2010._10._30.Dns.DnsService.SearchZoneClause.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "SearchZoneField");
            cachedSerQNames.add(qName);
            cls = com.groupnbt._2010._10._30.Dns.DnsService.SearchZoneField.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "SOA");
            cachedSerQNames.add(qName);
            cls = com.groupnbt._2010._10._30.Dns.DnsService.SOA.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "SRV");
            cachedSerQNames.add(qName);
            cls = com.groupnbt._2010._10._30.Dns.DnsService.SRV.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "TXT");
            cachedSerQNames.add(qName);
            cls = com.groupnbt._2010._10._30.Dns.DnsService.TXT.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "User");
            cachedSerQNames.add(qName);
            cls = com.groupnbt._2010._10._30.Dns.DnsService.User.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "WebForward");
            cachedSerQNames.add(qName);
            cls = com.groupnbt._2010._10._30.Dns.DnsService.WebForward.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "Zone");
            cachedSerQNames.add(qName);
            cls = com.groupnbt._2010._10._30.Dns.DnsService.Zone.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "ZoneInfoLevel");
            cachedSerQNames.add(qName);
            cls = com.groupnbt._2010._10._30.Dns.DnsService.ZoneInfoLevel.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "ZoneLogEntry");
            cachedSerQNames.add(qName);
            cls = com.groupnbt._2010._10._30.Dns.DnsService.ZoneLogEntry.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://schemas.microsoft.com/2003/10/Serialization/Arrays", "ArrayOfstring");
            cachedSerQNames.add(qName);
            cls = java.lang.String[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string");
            qName2 = new javax.xml.namespace.QName("http://schemas.microsoft.com/2003/10/Serialization/Arrays", "string");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

    }

    protected org.apache.axis.client.Call createCall() throws java.rmi.RemoteException {
        try {
            org.apache.axis.client.Call _call = super._createCall();
            if (super.maintainSessionSet) {
                _call.setMaintainSession(super.maintainSession);
            }
            if (super.cachedUsername != null) {
                _call.setUsername(super.cachedUsername);
            }
            if (super.cachedPassword != null) {
                _call.setPassword(super.cachedPassword);
            }
            if (super.cachedEndpoint != null) {
                _call.setTargetEndpointAddress(super.cachedEndpoint);
            }
            if (super.cachedTimeout != null) {
                _call.setTimeout(super.cachedTimeout);
            }
            if (super.cachedPortName != null) {
                _call.setPortName(super.cachedPortName);
            }
            java.util.Enumeration keys = super.cachedProperties.keys();
            while (keys.hasMoreElements()) {
                java.lang.String key = (java.lang.String) keys.nextElement();
                _call.setProperty(key, super.cachedProperties.get(key));
            }
            // All the type mapping information is registered
            // when the first call is made.
            // The type mapping information is actually registered in
            // the TypeMappingRegistry of the service, which
            // is the reason why registration is only needed for the first call.
            synchronized (this) {
                if (firstCall()) {
                    // must set encoding style before registering serializers
                    _call.setEncodingStyle(null);
                    for (int i = 0; i < cachedSerFactories.size(); ++i) {
                        java.lang.Class cls = (java.lang.Class) cachedSerClasses.get(i);
                        javax.xml.namespace.QName qName =
                                (javax.xml.namespace.QName) cachedSerQNames.get(i);
                        java.lang.Object x = cachedSerFactories.get(i);
                        if (x instanceof Class) {
                            java.lang.Class sf = (java.lang.Class)
                                 cachedSerFactories.get(i);
                            java.lang.Class df = (java.lang.Class)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                        else if (x instanceof javax.xml.rpc.encoding.SerializerFactory) {
                            org.apache.axis.encoding.SerializerFactory sf = (org.apache.axis.encoding.SerializerFactory)
                                 cachedSerFactories.get(i);
                            org.apache.axis.encoding.DeserializerFactory df = (org.apache.axis.encoding.DeserializerFactory)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                    }
                }
            }
            return _call;
        }
        catch (java.lang.Throwable _t) {
            throw new org.apache.axis.AxisFault("Failure trying to get the Call object", _t);
        }
    }

    public void getRoles(com.groupnbt._2010._10._30.Dns.DnsService.holders.ResponseHolder getRolesResult, com.groupnbt._2010._10._30.Dns.DnsService.holders.ArrayOfRoleItemHolder roles) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[0]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://groupnbt.com/2010/10/30/Dns/DnsService/IDnsService/GetRoles");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "GetRoles"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                getRolesResult.value = (com.groupnbt._2010._10._30.Dns.DnsService.Response) _output.get(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "GetRolesResult"));
            } catch (java.lang.Exception _exception) {
                getRolesResult.value = (com.groupnbt._2010._10._30.Dns.DnsService.Response) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "GetRolesResult")), com.groupnbt._2010._10._30.Dns.DnsService.Response.class);
            }
            try {
                roles.value = (com.groupnbt._2010._10._30.Dns.DnsService.RoleItem[]) _output.get(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "roles"));
            } catch (java.lang.Exception _exception) {
                roles.value = (com.groupnbt._2010._10._30.Dns.DnsService.RoleItem[]) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "roles")), com.groupnbt._2010._10._30.Dns.DnsService.RoleItem[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.groupnbt._2010._10._30.Dns.DnsService.Response createUser(com.groupnbt._2010._10._30.Dns.DnsService.User user) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[1]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://groupnbt.com/2010/10/30/Dns/DnsService/IDnsService/CreateUser");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "CreateUser"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {user});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.groupnbt._2010._10._30.Dns.DnsService.Response) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.groupnbt._2010._10._30.Dns.DnsService.Response) org.apache.axis.utils.JavaUtils.convert(_resp, com.groupnbt._2010._10._30.Dns.DnsService.Response.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.groupnbt._2010._10._30.Dns.DnsService.Response updateUser(com.groupnbt._2010._10._30.Dns.DnsService.User user) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[2]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://groupnbt.com/2010/10/30/Dns/DnsService/IDnsService/UpdateUser");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "UpdateUser"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {user});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.groupnbt._2010._10._30.Dns.DnsService.Response) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.groupnbt._2010._10._30.Dns.DnsService.Response) org.apache.axis.utils.JavaUtils.convert(_resp, com.groupnbt._2010._10._30.Dns.DnsService.Response.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.groupnbt._2010._10._30.Dns.DnsService.Response deleteUser(java.lang.String userName) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[3]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://groupnbt.com/2010/10/30/Dns/DnsService/IDnsService/DeleteUser");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "DeleteUser"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {userName});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.groupnbt._2010._10._30.Dns.DnsService.Response) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.groupnbt._2010._10._30.Dns.DnsService.Response) org.apache.axis.utils.JavaUtils.convert(_resp, com.groupnbt._2010._10._30.Dns.DnsService.Response.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void getUser(java.lang.String userName, com.groupnbt._2010._10._30.Dns.DnsService.holders.ResponseHolder getUserResult, com.groupnbt._2010._10._30.Dns.DnsService.holders.UserHolder user) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[4]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://groupnbt.com/2010/10/30/Dns/DnsService/IDnsService/GetUser");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "GetUser"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {userName});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                getUserResult.value = (com.groupnbt._2010._10._30.Dns.DnsService.Response) _output.get(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "GetUserResult"));
            } catch (java.lang.Exception _exception) {
                getUserResult.value = (com.groupnbt._2010._10._30.Dns.DnsService.Response) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "GetUserResult")), com.groupnbt._2010._10._30.Dns.DnsService.Response.class);
            }
            try {
                user.value = (com.groupnbt._2010._10._30.Dns.DnsService.User) _output.get(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "user"));
            } catch (java.lang.Exception _exception) {
                user.value = (com.groupnbt._2010._10._30.Dns.DnsService.User) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "user")), com.groupnbt._2010._10._30.Dns.DnsService.User.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void searchUser(com.groupnbt._2010._10._30.Dns.DnsService.SearchUserClause[] searchUserClauses, com.groupnbt._2010._10._30.Dns.DnsService.holders.ResponseHolder searchUserResult, com.microsoft.schemas._2003._10.Serialization.Arrays.holders.ArrayOfstringHolder userNames) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[5]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://groupnbt.com/2010/10/30/Dns/DnsService/IDnsService/SearchUser");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "SearchUser"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {searchUserClauses});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                searchUserResult.value = (com.groupnbt._2010._10._30.Dns.DnsService.Response) _output.get(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "SearchUserResult"));
            } catch (java.lang.Exception _exception) {
                searchUserResult.value = (com.groupnbt._2010._10._30.Dns.DnsService.Response) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "SearchUserResult")), com.groupnbt._2010._10._30.Dns.DnsService.Response.class);
            }
            try {
                userNames.value = (java.lang.String[]) _output.get(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "userNames"));
            } catch (java.lang.Exception _exception) {
                userNames.value = (java.lang.String[]) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "userNames")), java.lang.String[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.groupnbt._2010._10._30.Dns.DnsService.Response changePassword(java.lang.String userName, java.lang.String newPassword) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[6]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://groupnbt.com/2010/10/30/Dns/DnsService/IDnsService/ChangePassword");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "ChangePassword"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {userName, newPassword});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.groupnbt._2010._10._30.Dns.DnsService.Response) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.groupnbt._2010._10._30.Dns.DnsService.Response) org.apache.axis.utils.JavaUtils.convert(_resp, com.groupnbt._2010._10._30.Dns.DnsService.Response.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.groupnbt._2010._10._30.Dns.DnsService.Response createZone(java.lang.String zoneName, java.lang.String owner, com.groupnbt._2010._10._30.Dns.DnsService.Record[] records) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[7]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://groupnbt.com/2010/10/30/Dns/DnsService/IDnsService/CreateZone");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "CreateZone"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {zoneName, owner, records});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.groupnbt._2010._10._30.Dns.DnsService.Response) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.groupnbt._2010._10._30.Dns.DnsService.Response) org.apache.axis.utils.JavaUtils.convert(_resp, com.groupnbt._2010._10._30.Dns.DnsService.Response.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.groupnbt._2010._10._30.Dns.DnsService.Response deleteZone(java.lang.String zoneName) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[8]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://groupnbt.com/2010/10/30/Dns/DnsService/IDnsService/DeleteZone");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "DeleteZone"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {zoneName});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.groupnbt._2010._10._30.Dns.DnsService.Response) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.groupnbt._2010._10._30.Dns.DnsService.Response) org.apache.axis.utils.JavaUtils.convert(_resp, com.groupnbt._2010._10._30.Dns.DnsService.Response.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void getZoneLog(java.lang.String zoneName, com.groupnbt._2010._10._30.Dns.DnsService.holders.ResponseHolder getZoneLogResult, com.groupnbt._2010._10._30.Dns.DnsService.holders.ArrayOfZoneLogEntryHolder zoneLogEntries) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[9]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://groupnbt.com/2010/10/30/Dns/DnsService/IDnsService/GetZoneLog");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "GetZoneLog"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {zoneName});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                getZoneLogResult.value = (com.groupnbt._2010._10._30.Dns.DnsService.Response) _output.get(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "GetZoneLogResult"));
            } catch (java.lang.Exception _exception) {
                getZoneLogResult.value = (com.groupnbt._2010._10._30.Dns.DnsService.Response) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "GetZoneLogResult")), com.groupnbt._2010._10._30.Dns.DnsService.Response.class);
            }
            try {
                zoneLogEntries.value = (com.groupnbt._2010._10._30.Dns.DnsService.ZoneLogEntry[]) _output.get(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "zoneLogEntries"));
            } catch (java.lang.Exception _exception) {
                zoneLogEntries.value = (com.groupnbt._2010._10._30.Dns.DnsService.ZoneLogEntry[]) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "zoneLogEntries")), com.groupnbt._2010._10._30.Dns.DnsService.ZoneLogEntry[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void getZone(java.lang.String zoneName, com.groupnbt._2010._10._30.Dns.DnsService.holders.ResponseHolder getZoneResult, com.groupnbt._2010._10._30.Dns.DnsService.holders.ZoneHolder zone) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[10]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://groupnbt.com/2010/10/30/Dns/DnsService/IDnsService/GetZone");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "GetZone"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {zoneName});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                getZoneResult.value = (com.groupnbt._2010._10._30.Dns.DnsService.Response) _output.get(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "GetZoneResult"));
            } catch (java.lang.Exception _exception) {
                getZoneResult.value = (com.groupnbt._2010._10._30.Dns.DnsService.Response) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "GetZoneResult")), com.groupnbt._2010._10._30.Dns.DnsService.Response.class);
            }
            try {
                zone.value = (com.groupnbt._2010._10._30.Dns.DnsService.Zone) _output.get(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "zone"));
            } catch (java.lang.Exception _exception) {
                zone.value = (com.groupnbt._2010._10._30.Dns.DnsService.Zone) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "zone")), com.groupnbt._2010._10._30.Dns.DnsService.Zone.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void restoreZone(java.lang.String zoneName, com.groupnbt._2010._10._30.Dns.DnsService.holders.ResponseHolder restoreZoneResult, com.groupnbt._2010._10._30.Dns.DnsService.holders.ZoneHolder zone) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[11]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://groupnbt.com/2010/10/30/Dns/DnsService/IDnsService/RestoreZone");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "RestoreZone"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {zoneName});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                restoreZoneResult.value = (com.groupnbt._2010._10._30.Dns.DnsService.Response) _output.get(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "RestoreZoneResult"));
            } catch (java.lang.Exception _exception) {
                restoreZoneResult.value = (com.groupnbt._2010._10._30.Dns.DnsService.Response) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "RestoreZoneResult")), com.groupnbt._2010._10._30.Dns.DnsService.Response.class);
            }
            try {
                zone.value = (com.groupnbt._2010._10._30.Dns.DnsService.Zone) _output.get(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "zone"));
            } catch (java.lang.Exception _exception) {
                zone.value = (com.groupnbt._2010._10._30.Dns.DnsService.Zone) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "zone")), com.groupnbt._2010._10._30.Dns.DnsService.Zone.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void searchZoneNames(com.groupnbt._2010._10._30.Dns.DnsService.SearchZoneClause[] searchZoneClauses, com.groupnbt._2010._10._30.Dns.DnsService.holders.ResponseHolder searchZoneNamesResult, com.microsoft.schemas._2003._10.Serialization.Arrays.holders.ArrayOfstringHolder zoneNames) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[12]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://groupnbt.com/2010/10/30/Dns/DnsService/IDnsService/SearchZoneNames");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "SearchZoneNames"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {searchZoneClauses});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                searchZoneNamesResult.value = (com.groupnbt._2010._10._30.Dns.DnsService.Response) _output.get(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "SearchZoneNamesResult"));
            } catch (java.lang.Exception _exception) {
                searchZoneNamesResult.value = (com.groupnbt._2010._10._30.Dns.DnsService.Response) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "SearchZoneNamesResult")), com.groupnbt._2010._10._30.Dns.DnsService.Response.class);
            }
            try {
                zoneNames.value = (java.lang.String[]) _output.get(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "zoneNames"));
            } catch (java.lang.Exception _exception) {
                zoneNames.value = (java.lang.String[]) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "zoneNames")), java.lang.String[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void searchZone(com.groupnbt._2010._10._30.Dns.DnsService.SearchZoneClause[] searchZoneClauses, com.groupnbt._2010._10._30.Dns.DnsService.ZoneInfoLevel zoneInfoLevel, com.groupnbt._2010._10._30.Dns.DnsService.holders.ResponseHolder searchZoneResult, com.groupnbt._2010._10._30.Dns.DnsService.holders.ArrayOfZoneHolder zones) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[13]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://groupnbt.com/2010/10/30/Dns/DnsService/IDnsService/SearchZone");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "SearchZone"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {searchZoneClauses, zoneInfoLevel});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                searchZoneResult.value = (com.groupnbt._2010._10._30.Dns.DnsService.Response) _output.get(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "SearchZoneResult"));
            } catch (java.lang.Exception _exception) {
                searchZoneResult.value = (com.groupnbt._2010._10._30.Dns.DnsService.Response) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "SearchZoneResult")), com.groupnbt._2010._10._30.Dns.DnsService.Response.class);
            }
            try {
                zones.value = (com.groupnbt._2010._10._30.Dns.DnsService.Zone[]) _output.get(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "zones"));
            } catch (java.lang.Exception _exception) {
                zones.value = (com.groupnbt._2010._10._30.Dns.DnsService.Zone[]) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "zones")), com.groupnbt._2010._10._30.Dns.DnsService.Zone[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.groupnbt._2010._10._30.Dns.DnsService.Response setZoneOwner(java.lang.String zoneName, java.lang.String owner) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[14]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://groupnbt.com/2010/10/30/Dns/DnsService/IDnsService/SetZoneOwner");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "SetZoneOwner"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {zoneName, owner});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.groupnbt._2010._10._30.Dns.DnsService.Response) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.groupnbt._2010._10._30.Dns.DnsService.Response) org.apache.axis.utils.JavaUtils.convert(_resp, com.groupnbt._2010._10._30.Dns.DnsService.Response.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void createRecord(java.lang.String zoneName, com.groupnbt._2010._10._30.Dns.DnsService.Record record, com.groupnbt._2010._10._30.Dns.DnsService.holders.ResponseHolder createRecordResult, javax.xml.rpc.holders.IntegerWrapperHolder recordId) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[15]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://groupnbt.com/2010/10/30/Dns/DnsService/IDnsService/CreateRecord");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "CreateRecord"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {zoneName, record});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                createRecordResult.value = (com.groupnbt._2010._10._30.Dns.DnsService.Response) _output.get(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "CreateRecordResult"));
            } catch (java.lang.Exception _exception) {
                createRecordResult.value = (com.groupnbt._2010._10._30.Dns.DnsService.Response) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "CreateRecordResult")), com.groupnbt._2010._10._30.Dns.DnsService.Response.class);
            }
            try {
                recordId.value = (java.lang.Integer) _output.get(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "recordId"));
            } catch (java.lang.Exception _exception) {
                recordId.value = (java.lang.Integer) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "recordId")), java.lang.Integer.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.groupnbt._2010._10._30.Dns.DnsService.Response updateRecord(com.groupnbt._2010._10._30.Dns.DnsService.Record record) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[16]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://groupnbt.com/2010/10/30/Dns/DnsService/IDnsService/UpdateRecord");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "UpdateRecord"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {record});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.groupnbt._2010._10._30.Dns.DnsService.Response) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.groupnbt._2010._10._30.Dns.DnsService.Response) org.apache.axis.utils.JavaUtils.convert(_resp, com.groupnbt._2010._10._30.Dns.DnsService.Response.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.groupnbt._2010._10._30.Dns.DnsService.Response deleteRecord(java.lang.Integer recordId) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[17]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://groupnbt.com/2010/10/30/Dns/DnsService/IDnsService/DeleteRecord");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "DeleteRecord"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {recordId});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.groupnbt._2010._10._30.Dns.DnsService.Response) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.groupnbt._2010._10._30.Dns.DnsService.Response) org.apache.axis.utils.JavaUtils.convert(_resp, com.groupnbt._2010._10._30.Dns.DnsService.Response.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void getRecord(java.lang.Integer recordId, com.groupnbt._2010._10._30.Dns.DnsService.holders.ResponseHolder getRecordResult, com.groupnbt._2010._10._30.Dns.DnsService.holders.RecordHolder record) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[18]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://groupnbt.com/2010/10/30/Dns/DnsService/IDnsService/GetRecord");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "GetRecord"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {recordId});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            java.util.Map _output;
            _output = _call.getOutputParams();
            try {
                getRecordResult.value = (com.groupnbt._2010._10._30.Dns.DnsService.Response) _output.get(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "GetRecordResult"));
            } catch (java.lang.Exception _exception) {
                getRecordResult.value = (com.groupnbt._2010._10._30.Dns.DnsService.Response) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "GetRecordResult")), com.groupnbt._2010._10._30.Dns.DnsService.Response.class);
            }
            try {
                record.value = (com.groupnbt._2010._10._30.Dns.DnsService.Record) _output.get(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "record"));
            } catch (java.lang.Exception _exception) {
                record.value = (com.groupnbt._2010._10._30.Dns.DnsService.Record) org.apache.axis.utils.JavaUtils.convert(_output.get(new javax.xml.namespace.QName("http://groupnbt.com/2010/10/30/Dns/DnsService", "record")), com.groupnbt._2010._10._30.Dns.DnsService.Record.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

}
