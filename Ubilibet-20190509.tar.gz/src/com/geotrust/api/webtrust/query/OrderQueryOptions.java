/**
 * OrderQueryOptions.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.query;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class OrderQueryOptions  implements java.io.Serializable {
    private java.lang.Boolean returnProductDetail;

    private java.lang.Boolean returnContacts;

    private java.lang.Boolean returnCertificateInfo;

    private java.lang.Boolean returnCertificateAlgorithmInfo;

    private java.lang.Boolean returnFulfillment;

    private java.lang.Boolean returnCACerts;

    private java.lang.Boolean returnPKCS7Cert;

    private java.lang.Boolean returnOrderAttributes;

    private java.lang.Boolean returnAuthenticationComments;

    private java.lang.Boolean returnAuthenticationStatuses;

    private java.lang.Boolean returnTrustServicesSummary;

    private java.lang.Boolean returnTrustServicesDetails;

    private java.lang.Boolean returnVulnerabilityScanSummary;

    private java.lang.Boolean returnVulnerabilityScanDetails;

    private java.lang.Boolean returnFileAuthDVSummary;

    private java.lang.Boolean returnDNSAuthDVSummary;

    private com.geotrust.api.webtrust.query.SearchCriteria certificateSearchCriteria;

    public OrderQueryOptions() {
    }

    public OrderQueryOptions(
           java.lang.Boolean returnProductDetail,
           java.lang.Boolean returnContacts,
           java.lang.Boolean returnCertificateInfo,
           java.lang.Boolean returnCertificateAlgorithmInfo,
           java.lang.Boolean returnFulfillment,
           java.lang.Boolean returnCACerts,
           java.lang.Boolean returnPKCS7Cert,
           java.lang.Boolean returnOrderAttributes,
           java.lang.Boolean returnAuthenticationComments,
           java.lang.Boolean returnAuthenticationStatuses,
           java.lang.Boolean returnTrustServicesSummary,
           java.lang.Boolean returnTrustServicesDetails,
           java.lang.Boolean returnVulnerabilityScanSummary,
           java.lang.Boolean returnVulnerabilityScanDetails,
           java.lang.Boolean returnFileAuthDVSummary,
           java.lang.Boolean returnDNSAuthDVSummary,
           com.geotrust.api.webtrust.query.SearchCriteria certificateSearchCriteria) {
           this.returnProductDetail = returnProductDetail;
           this.returnContacts = returnContacts;
           this.returnCertificateInfo = returnCertificateInfo;
           this.returnCertificateAlgorithmInfo = returnCertificateAlgorithmInfo;
           this.returnFulfillment = returnFulfillment;
           this.returnCACerts = returnCACerts;
           this.returnPKCS7Cert = returnPKCS7Cert;
           this.returnOrderAttributes = returnOrderAttributes;
           this.returnAuthenticationComments = returnAuthenticationComments;
           this.returnAuthenticationStatuses = returnAuthenticationStatuses;
           this.returnTrustServicesSummary = returnTrustServicesSummary;
           this.returnTrustServicesDetails = returnTrustServicesDetails;
           this.returnVulnerabilityScanSummary = returnVulnerabilityScanSummary;
           this.returnVulnerabilityScanDetails = returnVulnerabilityScanDetails;
           this.returnFileAuthDVSummary = returnFileAuthDVSummary;
           this.returnDNSAuthDVSummary = returnDNSAuthDVSummary;
           this.certificateSearchCriteria = certificateSearchCriteria;
    }


    /**
     * Gets the returnProductDetail value for this OrderQueryOptions.
     * 
     * @return returnProductDetail
     */
    public java.lang.Boolean getReturnProductDetail() {
        return returnProductDetail;
    }


    /**
     * Sets the returnProductDetail value for this OrderQueryOptions.
     * 
     * @param returnProductDetail
     */
    public void setReturnProductDetail(java.lang.Boolean returnProductDetail) {
        this.returnProductDetail = returnProductDetail;
    }


    /**
     * Gets the returnContacts value for this OrderQueryOptions.
     * 
     * @return returnContacts
     */
    public java.lang.Boolean getReturnContacts() {
        return returnContacts;
    }


    /**
     * Sets the returnContacts value for this OrderQueryOptions.
     * 
     * @param returnContacts
     */
    public void setReturnContacts(java.lang.Boolean returnContacts) {
        this.returnContacts = returnContacts;
    }


    /**
     * Gets the returnCertificateInfo value for this OrderQueryOptions.
     * 
     * @return returnCertificateInfo
     */
    public java.lang.Boolean getReturnCertificateInfo() {
        return returnCertificateInfo;
    }


    /**
     * Sets the returnCertificateInfo value for this OrderQueryOptions.
     * 
     * @param returnCertificateInfo
     */
    public void setReturnCertificateInfo(java.lang.Boolean returnCertificateInfo) {
        this.returnCertificateInfo = returnCertificateInfo;
    }


    /**
     * Gets the returnCertificateAlgorithmInfo value for this OrderQueryOptions.
     * 
     * @return returnCertificateAlgorithmInfo
     */
    public java.lang.Boolean getReturnCertificateAlgorithmInfo() {
        return returnCertificateAlgorithmInfo;
    }


    /**
     * Sets the returnCertificateAlgorithmInfo value for this OrderQueryOptions.
     * 
     * @param returnCertificateAlgorithmInfo
     */
    public void setReturnCertificateAlgorithmInfo(java.lang.Boolean returnCertificateAlgorithmInfo) {
        this.returnCertificateAlgorithmInfo = returnCertificateAlgorithmInfo;
    }


    /**
     * Gets the returnFulfillment value for this OrderQueryOptions.
     * 
     * @return returnFulfillment
     */
    public java.lang.Boolean getReturnFulfillment() {
        return returnFulfillment;
    }


    /**
     * Sets the returnFulfillment value for this OrderQueryOptions.
     * 
     * @param returnFulfillment
     */
    public void setReturnFulfillment(java.lang.Boolean returnFulfillment) {
        this.returnFulfillment = returnFulfillment;
    }


    /**
     * Gets the returnCACerts value for this OrderQueryOptions.
     * 
     * @return returnCACerts
     */
    public java.lang.Boolean getReturnCACerts() {
        return returnCACerts;
    }


    /**
     * Sets the returnCACerts value for this OrderQueryOptions.
     * 
     * @param returnCACerts
     */
    public void setReturnCACerts(java.lang.Boolean returnCACerts) {
        this.returnCACerts = returnCACerts;
    }


    /**
     * Gets the returnPKCS7Cert value for this OrderQueryOptions.
     * 
     * @return returnPKCS7Cert
     */
    public java.lang.Boolean getReturnPKCS7Cert() {
        return returnPKCS7Cert;
    }


    /**
     * Sets the returnPKCS7Cert value for this OrderQueryOptions.
     * 
     * @param returnPKCS7Cert
     */
    public void setReturnPKCS7Cert(java.lang.Boolean returnPKCS7Cert) {
        this.returnPKCS7Cert = returnPKCS7Cert;
    }


    /**
     * Gets the returnOrderAttributes value for this OrderQueryOptions.
     * 
     * @return returnOrderAttributes
     */
    public java.lang.Boolean getReturnOrderAttributes() {
        return returnOrderAttributes;
    }


    /**
     * Sets the returnOrderAttributes value for this OrderQueryOptions.
     * 
     * @param returnOrderAttributes
     */
    public void setReturnOrderAttributes(java.lang.Boolean returnOrderAttributes) {
        this.returnOrderAttributes = returnOrderAttributes;
    }


    /**
     * Gets the returnAuthenticationComments value for this OrderQueryOptions.
     * 
     * @return returnAuthenticationComments
     */
    public java.lang.Boolean getReturnAuthenticationComments() {
        return returnAuthenticationComments;
    }


    /**
     * Sets the returnAuthenticationComments value for this OrderQueryOptions.
     * 
     * @param returnAuthenticationComments
     */
    public void setReturnAuthenticationComments(java.lang.Boolean returnAuthenticationComments) {
        this.returnAuthenticationComments = returnAuthenticationComments;
    }


    /**
     * Gets the returnAuthenticationStatuses value for this OrderQueryOptions.
     * 
     * @return returnAuthenticationStatuses
     */
    public java.lang.Boolean getReturnAuthenticationStatuses() {
        return returnAuthenticationStatuses;
    }


    /**
     * Sets the returnAuthenticationStatuses value for this OrderQueryOptions.
     * 
     * @param returnAuthenticationStatuses
     */
    public void setReturnAuthenticationStatuses(java.lang.Boolean returnAuthenticationStatuses) {
        this.returnAuthenticationStatuses = returnAuthenticationStatuses;
    }


    /**
     * Gets the returnTrustServicesSummary value for this OrderQueryOptions.
     * 
     * @return returnTrustServicesSummary
     */
    public java.lang.Boolean getReturnTrustServicesSummary() {
        return returnTrustServicesSummary;
    }


    /**
     * Sets the returnTrustServicesSummary value for this OrderQueryOptions.
     * 
     * @param returnTrustServicesSummary
     */
    public void setReturnTrustServicesSummary(java.lang.Boolean returnTrustServicesSummary) {
        this.returnTrustServicesSummary = returnTrustServicesSummary;
    }


    /**
     * Gets the returnTrustServicesDetails value for this OrderQueryOptions.
     * 
     * @return returnTrustServicesDetails
     */
    public java.lang.Boolean getReturnTrustServicesDetails() {
        return returnTrustServicesDetails;
    }


    /**
     * Sets the returnTrustServicesDetails value for this OrderQueryOptions.
     * 
     * @param returnTrustServicesDetails
     */
    public void setReturnTrustServicesDetails(java.lang.Boolean returnTrustServicesDetails) {
        this.returnTrustServicesDetails = returnTrustServicesDetails;
    }


    /**
     * Gets the returnVulnerabilityScanSummary value for this OrderQueryOptions.
     * 
     * @return returnVulnerabilityScanSummary
     */
    public java.lang.Boolean getReturnVulnerabilityScanSummary() {
        return returnVulnerabilityScanSummary;
    }


    /**
     * Sets the returnVulnerabilityScanSummary value for this OrderQueryOptions.
     * 
     * @param returnVulnerabilityScanSummary
     */
    public void setReturnVulnerabilityScanSummary(java.lang.Boolean returnVulnerabilityScanSummary) {
        this.returnVulnerabilityScanSummary = returnVulnerabilityScanSummary;
    }


    /**
     * Gets the returnVulnerabilityScanDetails value for this OrderQueryOptions.
     * 
     * @return returnVulnerabilityScanDetails
     */
    public java.lang.Boolean getReturnVulnerabilityScanDetails() {
        return returnVulnerabilityScanDetails;
    }


    /**
     * Sets the returnVulnerabilityScanDetails value for this OrderQueryOptions.
     * 
     * @param returnVulnerabilityScanDetails
     */
    public void setReturnVulnerabilityScanDetails(java.lang.Boolean returnVulnerabilityScanDetails) {
        this.returnVulnerabilityScanDetails = returnVulnerabilityScanDetails;
    }


    /**
     * Gets the returnFileAuthDVSummary value for this OrderQueryOptions.
     * 
     * @return returnFileAuthDVSummary
     */
    public java.lang.Boolean getReturnFileAuthDVSummary() {
        return returnFileAuthDVSummary;
    }


    /**
     * Sets the returnFileAuthDVSummary value for this OrderQueryOptions.
     * 
     * @param returnFileAuthDVSummary
     */
    public void setReturnFileAuthDVSummary(java.lang.Boolean returnFileAuthDVSummary) {
        this.returnFileAuthDVSummary = returnFileAuthDVSummary;
    }


    /**
     * Gets the returnDNSAuthDVSummary value for this OrderQueryOptions.
     * 
     * @return returnDNSAuthDVSummary
     */
    public java.lang.Boolean getReturnDNSAuthDVSummary() {
        return returnDNSAuthDVSummary;
    }


    /**
     * Sets the returnDNSAuthDVSummary value for this OrderQueryOptions.
     * 
     * @param returnDNSAuthDVSummary
     */
    public void setReturnDNSAuthDVSummary(java.lang.Boolean returnDNSAuthDVSummary) {
        this.returnDNSAuthDVSummary = returnDNSAuthDVSummary;
    }


    /**
     * Gets the certificateSearchCriteria value for this OrderQueryOptions.
     * 
     * @return certificateSearchCriteria
     */
    public com.geotrust.api.webtrust.query.SearchCriteria getCertificateSearchCriteria() {
        return certificateSearchCriteria;
    }


    /**
     * Sets the certificateSearchCriteria value for this OrderQueryOptions.
     * 
     * @param certificateSearchCriteria
     */
    public void setCertificateSearchCriteria(com.geotrust.api.webtrust.query.SearchCriteria certificateSearchCriteria) {
        this.certificateSearchCriteria = certificateSearchCriteria;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof OrderQueryOptions)) return false;
        OrderQueryOptions other = (OrderQueryOptions) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.returnProductDetail==null && other.getReturnProductDetail()==null) || 
             (this.returnProductDetail!=null &&
              this.returnProductDetail.equals(other.getReturnProductDetail()))) &&
            ((this.returnContacts==null && other.getReturnContacts()==null) || 
             (this.returnContacts!=null &&
              this.returnContacts.equals(other.getReturnContacts()))) &&
            ((this.returnCertificateInfo==null && other.getReturnCertificateInfo()==null) || 
             (this.returnCertificateInfo!=null &&
              this.returnCertificateInfo.equals(other.getReturnCertificateInfo()))) &&
            ((this.returnCertificateAlgorithmInfo==null && other.getReturnCertificateAlgorithmInfo()==null) || 
             (this.returnCertificateAlgorithmInfo!=null &&
              this.returnCertificateAlgorithmInfo.equals(other.getReturnCertificateAlgorithmInfo()))) &&
            ((this.returnFulfillment==null && other.getReturnFulfillment()==null) || 
             (this.returnFulfillment!=null &&
              this.returnFulfillment.equals(other.getReturnFulfillment()))) &&
            ((this.returnCACerts==null && other.getReturnCACerts()==null) || 
             (this.returnCACerts!=null &&
              this.returnCACerts.equals(other.getReturnCACerts()))) &&
            ((this.returnPKCS7Cert==null && other.getReturnPKCS7Cert()==null) || 
             (this.returnPKCS7Cert!=null &&
              this.returnPKCS7Cert.equals(other.getReturnPKCS7Cert()))) &&
            ((this.returnOrderAttributes==null && other.getReturnOrderAttributes()==null) || 
             (this.returnOrderAttributes!=null &&
              this.returnOrderAttributes.equals(other.getReturnOrderAttributes()))) &&
            ((this.returnAuthenticationComments==null && other.getReturnAuthenticationComments()==null) || 
             (this.returnAuthenticationComments!=null &&
              this.returnAuthenticationComments.equals(other.getReturnAuthenticationComments()))) &&
            ((this.returnAuthenticationStatuses==null && other.getReturnAuthenticationStatuses()==null) || 
             (this.returnAuthenticationStatuses!=null &&
              this.returnAuthenticationStatuses.equals(other.getReturnAuthenticationStatuses()))) &&
            ((this.returnTrustServicesSummary==null && other.getReturnTrustServicesSummary()==null) || 
             (this.returnTrustServicesSummary!=null &&
              this.returnTrustServicesSummary.equals(other.getReturnTrustServicesSummary()))) &&
            ((this.returnTrustServicesDetails==null && other.getReturnTrustServicesDetails()==null) || 
             (this.returnTrustServicesDetails!=null &&
              this.returnTrustServicesDetails.equals(other.getReturnTrustServicesDetails()))) &&
            ((this.returnVulnerabilityScanSummary==null && other.getReturnVulnerabilityScanSummary()==null) || 
             (this.returnVulnerabilityScanSummary!=null &&
              this.returnVulnerabilityScanSummary.equals(other.getReturnVulnerabilityScanSummary()))) &&
            ((this.returnVulnerabilityScanDetails==null && other.getReturnVulnerabilityScanDetails()==null) || 
             (this.returnVulnerabilityScanDetails!=null &&
              this.returnVulnerabilityScanDetails.equals(other.getReturnVulnerabilityScanDetails()))) &&
            ((this.returnFileAuthDVSummary==null && other.getReturnFileAuthDVSummary()==null) || 
             (this.returnFileAuthDVSummary!=null &&
              this.returnFileAuthDVSummary.equals(other.getReturnFileAuthDVSummary()))) &&
            ((this.returnDNSAuthDVSummary==null && other.getReturnDNSAuthDVSummary()==null) || 
             (this.returnDNSAuthDVSummary!=null &&
              this.returnDNSAuthDVSummary.equals(other.getReturnDNSAuthDVSummary()))) &&
            ((this.certificateSearchCriteria==null && other.getCertificateSearchCriteria()==null) || 
             (this.certificateSearchCriteria!=null &&
              this.certificateSearchCriteria.equals(other.getCertificateSearchCriteria())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getReturnProductDetail() != null) {
            _hashCode += getReturnProductDetail().hashCode();
        }
        if (getReturnContacts() != null) {
            _hashCode += getReturnContacts().hashCode();
        }
        if (getReturnCertificateInfo() != null) {
            _hashCode += getReturnCertificateInfo().hashCode();
        }
        if (getReturnCertificateAlgorithmInfo() != null) {
            _hashCode += getReturnCertificateAlgorithmInfo().hashCode();
        }
        if (getReturnFulfillment() != null) {
            _hashCode += getReturnFulfillment().hashCode();
        }
        if (getReturnCACerts() != null) {
            _hashCode += getReturnCACerts().hashCode();
        }
        if (getReturnPKCS7Cert() != null) {
            _hashCode += getReturnPKCS7Cert().hashCode();
        }
        if (getReturnOrderAttributes() != null) {
            _hashCode += getReturnOrderAttributes().hashCode();
        }
        if (getReturnAuthenticationComments() != null) {
            _hashCode += getReturnAuthenticationComments().hashCode();
        }
        if (getReturnAuthenticationStatuses() != null) {
            _hashCode += getReturnAuthenticationStatuses().hashCode();
        }
        if (getReturnTrustServicesSummary() != null) {
            _hashCode += getReturnTrustServicesSummary().hashCode();
        }
        if (getReturnTrustServicesDetails() != null) {
            _hashCode += getReturnTrustServicesDetails().hashCode();
        }
        if (getReturnVulnerabilityScanSummary() != null) {
            _hashCode += getReturnVulnerabilityScanSummary().hashCode();
        }
        if (getReturnVulnerabilityScanDetails() != null) {
            _hashCode += getReturnVulnerabilityScanDetails().hashCode();
        }
        if (getReturnFileAuthDVSummary() != null) {
            _hashCode += getReturnFileAuthDVSummary().hashCode();
        }
        if (getReturnDNSAuthDVSummary() != null) {
            _hashCode += getReturnDNSAuthDVSummary().hashCode();
        }
        if (getCertificateSearchCriteria() != null) {
            _hashCode += getCertificateSearchCriteria().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(OrderQueryOptions.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "orderQueryOptions"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("returnProductDetail");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ReturnProductDetail"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("returnContacts");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ReturnContacts"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("returnCertificateInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ReturnCertificateInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("returnCertificateAlgorithmInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ReturnCertificateAlgorithmInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("returnFulfillment");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ReturnFulfillment"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("returnCACerts");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ReturnCACerts"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("returnPKCS7Cert");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ReturnPKCS7Cert"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("returnOrderAttributes");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ReturnOrderAttributes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("returnAuthenticationComments");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ReturnAuthenticationComments"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("returnAuthenticationStatuses");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ReturnAuthenticationStatuses"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("returnTrustServicesSummary");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ReturnTrustServicesSummary"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("returnTrustServicesDetails");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ReturnTrustServicesDetails"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("returnVulnerabilityScanSummary");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ReturnVulnerabilityScanSummary"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("returnVulnerabilityScanDetails");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ReturnVulnerabilityScanDetails"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("returnFileAuthDVSummary");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ReturnFileAuthDVSummary"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("returnDNSAuthDVSummary");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ReturnDNSAuthDVSummary"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("certificateSearchCriteria");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "CertificateSearchCriteria"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "SearchCriteria"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
