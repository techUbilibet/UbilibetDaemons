/**
 * Approver.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.query;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class Approver  implements java.io.Serializable {
    private java.lang.String approverType;

    private java.lang.String approverEmail;

    public Approver() {
    }

    public Approver(
           java.lang.String approverType,
           java.lang.String approverEmail) {
           this.approverType = approverType;
           this.approverEmail = approverEmail;
    }


    /**
     * Gets the approverType value for this Approver.
     * 
     * @return approverType
     */
    public java.lang.String getApproverType() {
        return approverType;
    }


    /**
     * Sets the approverType value for this Approver.
     * 
     * @param approverType
     */
    public void setApproverType(java.lang.String approverType) {
        this.approverType = approverType;
    }


    /**
     * Gets the approverEmail value for this Approver.
     * 
     * @return approverEmail
     */
    public java.lang.String getApproverEmail() {
        return approverEmail;
    }


    /**
     * Sets the approverEmail value for this Approver.
     * 
     * @param approverEmail
     */
    public void setApproverEmail(java.lang.String approverEmail) {
        this.approverEmail = approverEmail;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Approver)) return false;
        Approver other = (Approver) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.approverType==null && other.getApproverType()==null) || 
             (this.approverType!=null &&
              this.approverType.equals(other.getApproverType()))) &&
            ((this.approverEmail==null && other.getApproverEmail()==null) || 
             (this.approverEmail!=null &&
              this.approverEmail.equals(other.getApproverEmail())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getApproverType() != null) {
            _hashCode += getApproverType().hashCode();
        }
        if (getApproverEmail() != null) {
            _hashCode += getApproverEmail().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Approver.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "Approver"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("approverType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ApproverType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("approverEmail");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ApproverEmail"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
