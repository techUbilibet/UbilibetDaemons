/**
 * OrderStatusMinor.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.query;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class OrderStatusMinor  implements java.io.Serializable {
    private java.lang.String orderStatusMinorCode;

    private java.lang.String orderStatusMinorName;

    public OrderStatusMinor() {
    }

    public OrderStatusMinor(
           java.lang.String orderStatusMinorCode,
           java.lang.String orderStatusMinorName) {
           this.orderStatusMinorCode = orderStatusMinorCode;
           this.orderStatusMinorName = orderStatusMinorName;
    }


    /**
     * Gets the orderStatusMinorCode value for this OrderStatusMinor.
     * 
     * @return orderStatusMinorCode
     */
    public java.lang.String getOrderStatusMinorCode() {
        return orderStatusMinorCode;
    }


    /**
     * Sets the orderStatusMinorCode value for this OrderStatusMinor.
     * 
     * @param orderStatusMinorCode
     */
    public void setOrderStatusMinorCode(java.lang.String orderStatusMinorCode) {
        this.orderStatusMinorCode = orderStatusMinorCode;
    }


    /**
     * Gets the orderStatusMinorName value for this OrderStatusMinor.
     * 
     * @return orderStatusMinorName
     */
    public java.lang.String getOrderStatusMinorName() {
        return orderStatusMinorName;
    }


    /**
     * Sets the orderStatusMinorName value for this OrderStatusMinor.
     * 
     * @param orderStatusMinorName
     */
    public void setOrderStatusMinorName(java.lang.String orderStatusMinorName) {
        this.orderStatusMinorName = orderStatusMinorName;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof OrderStatusMinor)) return false;
        OrderStatusMinor other = (OrderStatusMinor) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.orderStatusMinorCode==null && other.getOrderStatusMinorCode()==null) || 
             (this.orderStatusMinorCode!=null &&
              this.orderStatusMinorCode.equals(other.getOrderStatusMinorCode()))) &&
            ((this.orderStatusMinorName==null && other.getOrderStatusMinorName()==null) || 
             (this.orderStatusMinorName!=null &&
              this.orderStatusMinorName.equals(other.getOrderStatusMinorName())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getOrderStatusMinorCode() != null) {
            _hashCode += getOrderStatusMinorCode().hashCode();
        }
        if (getOrderStatusMinorName() != null) {
            _hashCode += getOrderStatusMinorName().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(OrderStatusMinor.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "orderStatusMinor"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderStatusMinorCode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "OrderStatusMinorCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderStatusMinorName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "OrderStatusMinorName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
