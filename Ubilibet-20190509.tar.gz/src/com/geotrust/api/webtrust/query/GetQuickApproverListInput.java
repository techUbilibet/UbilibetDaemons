/**
 * GetQuickApproverListInput.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.query;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class GetQuickApproverListInput  implements java.io.Serializable {
    private com.geotrust.api.webtrust.query.QueryRequestHeader queryRequestHeader;

    private java.lang.String domain;

    private com.geotrust.api.webtrust.query.IncludeUserAgreement includeUserAgreement;

    public GetQuickApproverListInput() {
    }

    public GetQuickApproverListInput(
           com.geotrust.api.webtrust.query.QueryRequestHeader queryRequestHeader,
           java.lang.String domain,
           com.geotrust.api.webtrust.query.IncludeUserAgreement includeUserAgreement) {
           this.queryRequestHeader = queryRequestHeader;
           this.domain = domain;
           this.includeUserAgreement = includeUserAgreement;
    }


    /**
     * Gets the queryRequestHeader value for this GetQuickApproverListInput.
     * 
     * @return queryRequestHeader
     */
    public com.geotrust.api.webtrust.query.QueryRequestHeader getQueryRequestHeader() {
        return queryRequestHeader;
    }


    /**
     * Sets the queryRequestHeader value for this GetQuickApproverListInput.
     * 
     * @param queryRequestHeader
     */
    public void setQueryRequestHeader(com.geotrust.api.webtrust.query.QueryRequestHeader queryRequestHeader) {
        this.queryRequestHeader = queryRequestHeader;
    }


    /**
     * Gets the domain value for this GetQuickApproverListInput.
     * 
     * @return domain
     */
    public java.lang.String getDomain() {
        return domain;
    }


    /**
     * Sets the domain value for this GetQuickApproverListInput.
     * 
     * @param domain
     */
    public void setDomain(java.lang.String domain) {
        this.domain = domain;
    }


    /**
     * Gets the includeUserAgreement value for this GetQuickApproverListInput.
     * 
     * @return includeUserAgreement
     */
    public com.geotrust.api.webtrust.query.IncludeUserAgreement getIncludeUserAgreement() {
        return includeUserAgreement;
    }


    /**
     * Sets the includeUserAgreement value for this GetQuickApproverListInput.
     * 
     * @param includeUserAgreement
     */
    public void setIncludeUserAgreement(com.geotrust.api.webtrust.query.IncludeUserAgreement includeUserAgreement) {
        this.includeUserAgreement = includeUserAgreement;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof GetQuickApproverListInput)) return false;
        GetQuickApproverListInput other = (GetQuickApproverListInput) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.queryRequestHeader==null && other.getQueryRequestHeader()==null) || 
             (this.queryRequestHeader!=null &&
              this.queryRequestHeader.equals(other.getQueryRequestHeader()))) &&
            ((this.domain==null && other.getDomain()==null) || 
             (this.domain!=null &&
              this.domain.equals(other.getDomain()))) &&
            ((this.includeUserAgreement==null && other.getIncludeUserAgreement()==null) || 
             (this.includeUserAgreement!=null &&
              this.includeUserAgreement.equals(other.getIncludeUserAgreement())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getQueryRequestHeader() != null) {
            _hashCode += getQueryRequestHeader().hashCode();
        }
        if (getDomain() != null) {
            _hashCode += getDomain().hashCode();
        }
        if (getIncludeUserAgreement() != null) {
            _hashCode += getIncludeUserAgreement().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(GetQuickApproverListInput.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetQuickApproverListInput"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("queryRequestHeader");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "QueryRequestHeader"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "queryRequestHeader"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("domain");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "Domain"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("includeUserAgreement");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "IncludeUserAgreement"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "includeUserAgreement"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
