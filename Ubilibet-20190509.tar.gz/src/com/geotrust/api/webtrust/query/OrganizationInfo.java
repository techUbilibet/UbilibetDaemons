/**
 * OrganizationInfo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.query;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class OrganizationInfo  implements java.io.Serializable {
    private java.lang.String organizationName;

    private com.geotrust.api.webtrust.query.LocalTradingName[] localTradingNames;

    private java.lang.String DUNS;

    private java.lang.String division;

    private java.lang.String incorporatingAgency;

    private java.lang.String registrationNumber;

    private java.lang.String jurisdictionCity;

    private java.lang.String jurisdictionRegion;

    private java.lang.String jurisdictionCountry;

    private java.lang.String businessCategory;

    private java.util.Calendar licenseStartDate;

    private java.util.Calendar licenseEndDate;

    private java.util.Calendar registrationDate;

    private com.geotrust.api.webtrust.query.OrganizationAddress organizationAddress;

    private com.geotrust.api.webtrust.query.CustomField[] customFields;

    public OrganizationInfo() {
    }

    public OrganizationInfo(
           java.lang.String organizationName,
           com.geotrust.api.webtrust.query.LocalTradingName[] localTradingNames,
           java.lang.String DUNS,
           java.lang.String division,
           java.lang.String incorporatingAgency,
           java.lang.String registrationNumber,
           java.lang.String jurisdictionCity,
           java.lang.String jurisdictionRegion,
           java.lang.String jurisdictionCountry,
           java.lang.String businessCategory,
           java.util.Calendar licenseStartDate,
           java.util.Calendar licenseEndDate,
           java.util.Calendar registrationDate,
           com.geotrust.api.webtrust.query.OrganizationAddress organizationAddress,
           com.geotrust.api.webtrust.query.CustomField[] customFields) {
           this.organizationName = organizationName;
           this.localTradingNames = localTradingNames;
           this.DUNS = DUNS;
           this.division = division;
           this.incorporatingAgency = incorporatingAgency;
           this.registrationNumber = registrationNumber;
           this.jurisdictionCity = jurisdictionCity;
           this.jurisdictionRegion = jurisdictionRegion;
           this.jurisdictionCountry = jurisdictionCountry;
           this.businessCategory = businessCategory;
           this.licenseStartDate = licenseStartDate;
           this.licenseEndDate = licenseEndDate;
           this.registrationDate = registrationDate;
           this.organizationAddress = organizationAddress;
           this.customFields = customFields;
    }


    /**
     * Gets the organizationName value for this OrganizationInfo.
     * 
     * @return organizationName
     */
    public java.lang.String getOrganizationName() {
        return organizationName;
    }


    /**
     * Sets the organizationName value for this OrganizationInfo.
     * 
     * @param organizationName
     */
    public void setOrganizationName(java.lang.String organizationName) {
        this.organizationName = organizationName;
    }


    /**
     * Gets the localTradingNames value for this OrganizationInfo.
     * 
     * @return localTradingNames
     */
    public com.geotrust.api.webtrust.query.LocalTradingName[] getLocalTradingNames() {
        return localTradingNames;
    }


    /**
     * Sets the localTradingNames value for this OrganizationInfo.
     * 
     * @param localTradingNames
     */
    public void setLocalTradingNames(com.geotrust.api.webtrust.query.LocalTradingName[] localTradingNames) {
        this.localTradingNames = localTradingNames;
    }


    /**
     * Gets the DUNS value for this OrganizationInfo.
     * 
     * @return DUNS
     */
    public java.lang.String getDUNS() {
        return DUNS;
    }


    /**
     * Sets the DUNS value for this OrganizationInfo.
     * 
     * @param DUNS
     */
    public void setDUNS(java.lang.String DUNS) {
        this.DUNS = DUNS;
    }


    /**
     * Gets the division value for this OrganizationInfo.
     * 
     * @return division
     */
    public java.lang.String getDivision() {
        return division;
    }


    /**
     * Sets the division value for this OrganizationInfo.
     * 
     * @param division
     */
    public void setDivision(java.lang.String division) {
        this.division = division;
    }


    /**
     * Gets the incorporatingAgency value for this OrganizationInfo.
     * 
     * @return incorporatingAgency
     */
    public java.lang.String getIncorporatingAgency() {
        return incorporatingAgency;
    }


    /**
     * Sets the incorporatingAgency value for this OrganizationInfo.
     * 
     * @param incorporatingAgency
     */
    public void setIncorporatingAgency(java.lang.String incorporatingAgency) {
        this.incorporatingAgency = incorporatingAgency;
    }


    /**
     * Gets the registrationNumber value for this OrganizationInfo.
     * 
     * @return registrationNumber
     */
    public java.lang.String getRegistrationNumber() {
        return registrationNumber;
    }


    /**
     * Sets the registrationNumber value for this OrganizationInfo.
     * 
     * @param registrationNumber
     */
    public void setRegistrationNumber(java.lang.String registrationNumber) {
        this.registrationNumber = registrationNumber;
    }


    /**
     * Gets the jurisdictionCity value for this OrganizationInfo.
     * 
     * @return jurisdictionCity
     */
    public java.lang.String getJurisdictionCity() {
        return jurisdictionCity;
    }


    /**
     * Sets the jurisdictionCity value for this OrganizationInfo.
     * 
     * @param jurisdictionCity
     */
    public void setJurisdictionCity(java.lang.String jurisdictionCity) {
        this.jurisdictionCity = jurisdictionCity;
    }


    /**
     * Gets the jurisdictionRegion value for this OrganizationInfo.
     * 
     * @return jurisdictionRegion
     */
    public java.lang.String getJurisdictionRegion() {
        return jurisdictionRegion;
    }


    /**
     * Sets the jurisdictionRegion value for this OrganizationInfo.
     * 
     * @param jurisdictionRegion
     */
    public void setJurisdictionRegion(java.lang.String jurisdictionRegion) {
        this.jurisdictionRegion = jurisdictionRegion;
    }


    /**
     * Gets the jurisdictionCountry value for this OrganizationInfo.
     * 
     * @return jurisdictionCountry
     */
    public java.lang.String getJurisdictionCountry() {
        return jurisdictionCountry;
    }


    /**
     * Sets the jurisdictionCountry value for this OrganizationInfo.
     * 
     * @param jurisdictionCountry
     */
    public void setJurisdictionCountry(java.lang.String jurisdictionCountry) {
        this.jurisdictionCountry = jurisdictionCountry;
    }


    /**
     * Gets the businessCategory value for this OrganizationInfo.
     * 
     * @return businessCategory
     */
    public java.lang.String getBusinessCategory() {
        return businessCategory;
    }


    /**
     * Sets the businessCategory value for this OrganizationInfo.
     * 
     * @param businessCategory
     */
    public void setBusinessCategory(java.lang.String businessCategory) {
        this.businessCategory = businessCategory;
    }


    /**
     * Gets the licenseStartDate value for this OrganizationInfo.
     * 
     * @return licenseStartDate
     */
    public java.util.Calendar getLicenseStartDate() {
        return licenseStartDate;
    }


    /**
     * Sets the licenseStartDate value for this OrganizationInfo.
     * 
     * @param licenseStartDate
     */
    public void setLicenseStartDate(java.util.Calendar licenseStartDate) {
        this.licenseStartDate = licenseStartDate;
    }


    /**
     * Gets the licenseEndDate value for this OrganizationInfo.
     * 
     * @return licenseEndDate
     */
    public java.util.Calendar getLicenseEndDate() {
        return licenseEndDate;
    }


    /**
     * Sets the licenseEndDate value for this OrganizationInfo.
     * 
     * @param licenseEndDate
     */
    public void setLicenseEndDate(java.util.Calendar licenseEndDate) {
        this.licenseEndDate = licenseEndDate;
    }


    /**
     * Gets the registrationDate value for this OrganizationInfo.
     * 
     * @return registrationDate
     */
    public java.util.Calendar getRegistrationDate() {
        return registrationDate;
    }


    /**
     * Sets the registrationDate value for this OrganizationInfo.
     * 
     * @param registrationDate
     */
    public void setRegistrationDate(java.util.Calendar registrationDate) {
        this.registrationDate = registrationDate;
    }


    /**
     * Gets the organizationAddress value for this OrganizationInfo.
     * 
     * @return organizationAddress
     */
    public com.geotrust.api.webtrust.query.OrganizationAddress getOrganizationAddress() {
        return organizationAddress;
    }


    /**
     * Sets the organizationAddress value for this OrganizationInfo.
     * 
     * @param organizationAddress
     */
    public void setOrganizationAddress(com.geotrust.api.webtrust.query.OrganizationAddress organizationAddress) {
        this.organizationAddress = organizationAddress;
    }


    /**
     * Gets the customFields value for this OrganizationInfo.
     * 
     * @return customFields
     */
    public com.geotrust.api.webtrust.query.CustomField[] getCustomFields() {
        return customFields;
    }


    /**
     * Sets the customFields value for this OrganizationInfo.
     * 
     * @param customFields
     */
    public void setCustomFields(com.geotrust.api.webtrust.query.CustomField[] customFields) {
        this.customFields = customFields;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof OrganizationInfo)) return false;
        OrganizationInfo other = (OrganizationInfo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.organizationName==null && other.getOrganizationName()==null) || 
             (this.organizationName!=null &&
              this.organizationName.equals(other.getOrganizationName()))) &&
            ((this.localTradingNames==null && other.getLocalTradingNames()==null) || 
             (this.localTradingNames!=null &&
              java.util.Arrays.equals(this.localTradingNames, other.getLocalTradingNames()))) &&
            ((this.DUNS==null && other.getDUNS()==null) || 
             (this.DUNS!=null &&
              this.DUNS.equals(other.getDUNS()))) &&
            ((this.division==null && other.getDivision()==null) || 
             (this.division!=null &&
              this.division.equals(other.getDivision()))) &&
            ((this.incorporatingAgency==null && other.getIncorporatingAgency()==null) || 
             (this.incorporatingAgency!=null &&
              this.incorporatingAgency.equals(other.getIncorporatingAgency()))) &&
            ((this.registrationNumber==null && other.getRegistrationNumber()==null) || 
             (this.registrationNumber!=null &&
              this.registrationNumber.equals(other.getRegistrationNumber()))) &&
            ((this.jurisdictionCity==null && other.getJurisdictionCity()==null) || 
             (this.jurisdictionCity!=null &&
              this.jurisdictionCity.equals(other.getJurisdictionCity()))) &&
            ((this.jurisdictionRegion==null && other.getJurisdictionRegion()==null) || 
             (this.jurisdictionRegion!=null &&
              this.jurisdictionRegion.equals(other.getJurisdictionRegion()))) &&
            ((this.jurisdictionCountry==null && other.getJurisdictionCountry()==null) || 
             (this.jurisdictionCountry!=null &&
              this.jurisdictionCountry.equals(other.getJurisdictionCountry()))) &&
            ((this.businessCategory==null && other.getBusinessCategory()==null) || 
             (this.businessCategory!=null &&
              this.businessCategory.equals(other.getBusinessCategory()))) &&
            ((this.licenseStartDate==null && other.getLicenseStartDate()==null) || 
             (this.licenseStartDate!=null &&
              this.licenseStartDate.equals(other.getLicenseStartDate()))) &&
            ((this.licenseEndDate==null && other.getLicenseEndDate()==null) || 
             (this.licenseEndDate!=null &&
              this.licenseEndDate.equals(other.getLicenseEndDate()))) &&
            ((this.registrationDate==null && other.getRegistrationDate()==null) || 
             (this.registrationDate!=null &&
              this.registrationDate.equals(other.getRegistrationDate()))) &&
            ((this.organizationAddress==null && other.getOrganizationAddress()==null) || 
             (this.organizationAddress!=null &&
              this.organizationAddress.equals(other.getOrganizationAddress()))) &&
            ((this.customFields==null && other.getCustomFields()==null) || 
             (this.customFields!=null &&
              java.util.Arrays.equals(this.customFields, other.getCustomFields())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getOrganizationName() != null) {
            _hashCode += getOrganizationName().hashCode();
        }
        if (getLocalTradingNames() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getLocalTradingNames());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getLocalTradingNames(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getDUNS() != null) {
            _hashCode += getDUNS().hashCode();
        }
        if (getDivision() != null) {
            _hashCode += getDivision().hashCode();
        }
        if (getIncorporatingAgency() != null) {
            _hashCode += getIncorporatingAgency().hashCode();
        }
        if (getRegistrationNumber() != null) {
            _hashCode += getRegistrationNumber().hashCode();
        }
        if (getJurisdictionCity() != null) {
            _hashCode += getJurisdictionCity().hashCode();
        }
        if (getJurisdictionRegion() != null) {
            _hashCode += getJurisdictionRegion().hashCode();
        }
        if (getJurisdictionCountry() != null) {
            _hashCode += getJurisdictionCountry().hashCode();
        }
        if (getBusinessCategory() != null) {
            _hashCode += getBusinessCategory().hashCode();
        }
        if (getLicenseStartDate() != null) {
            _hashCode += getLicenseStartDate().hashCode();
        }
        if (getLicenseEndDate() != null) {
            _hashCode += getLicenseEndDate().hashCode();
        }
        if (getRegistrationDate() != null) {
            _hashCode += getRegistrationDate().hashCode();
        }
        if (getOrganizationAddress() != null) {
            _hashCode += getOrganizationAddress().hashCode();
        }
        if (getCustomFields() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCustomFields());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCustomFields(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(OrganizationInfo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "organizationInfo"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("organizationName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "OrganizationName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("localTradingNames");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "LocalTradingNames"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "LocalTradingName"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "LocalTradingName"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DUNS");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "DUNS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("division");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "Division"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("incorporatingAgency");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "IncorporatingAgency"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("registrationNumber");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "RegistrationNumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("jurisdictionCity");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "JurisdictionCity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("jurisdictionRegion");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "JurisdictionRegion"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("jurisdictionCountry");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "JurisdictionCountry"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("businessCategory");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "BusinessCategory"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("licenseStartDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "LicenseStartDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("licenseEndDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "LicenseEndDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("registrationDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "RegistrationDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("organizationAddress");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "OrganizationAddress"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "organizationAddress"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("customFields");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "CustomFields"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "CustomField"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "CustomField"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
