/**
 * InfectedPage.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.query;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class InfectedPage  implements java.io.Serializable {
    private java.util.Calendar foundDate;

    private java.lang.String pageURL;

    private java.lang.String[] infectionIssues;

    public InfectedPage() {
    }

    public InfectedPage(
           java.util.Calendar foundDate,
           java.lang.String pageURL,
           java.lang.String[] infectionIssues) {
           this.foundDate = foundDate;
           this.pageURL = pageURL;
           this.infectionIssues = infectionIssues;
    }


    /**
     * Gets the foundDate value for this InfectedPage.
     * 
     * @return foundDate
     */
    public java.util.Calendar getFoundDate() {
        return foundDate;
    }


    /**
     * Sets the foundDate value for this InfectedPage.
     * 
     * @param foundDate
     */
    public void setFoundDate(java.util.Calendar foundDate) {
        this.foundDate = foundDate;
    }


    /**
     * Gets the pageURL value for this InfectedPage.
     * 
     * @return pageURL
     */
    public java.lang.String getPageURL() {
        return pageURL;
    }


    /**
     * Sets the pageURL value for this InfectedPage.
     * 
     * @param pageURL
     */
    public void setPageURL(java.lang.String pageURL) {
        this.pageURL = pageURL;
    }


    /**
     * Gets the infectionIssues value for this InfectedPage.
     * 
     * @return infectionIssues
     */
    public java.lang.String[] getInfectionIssues() {
        return infectionIssues;
    }


    /**
     * Sets the infectionIssues value for this InfectedPage.
     * 
     * @param infectionIssues
     */
    public void setInfectionIssues(java.lang.String[] infectionIssues) {
        this.infectionIssues = infectionIssues;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof InfectedPage)) return false;
        InfectedPage other = (InfectedPage) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.foundDate==null && other.getFoundDate()==null) || 
             (this.foundDate!=null &&
              this.foundDate.equals(other.getFoundDate()))) &&
            ((this.pageURL==null && other.getPageURL()==null) || 
             (this.pageURL!=null &&
              this.pageURL.equals(other.getPageURL()))) &&
            ((this.infectionIssues==null && other.getInfectionIssues()==null) || 
             (this.infectionIssues!=null &&
              java.util.Arrays.equals(this.infectionIssues, other.getInfectionIssues())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getFoundDate() != null) {
            _hashCode += getFoundDate().hashCode();
        }
        if (getPageURL() != null) {
            _hashCode += getPageURL().hashCode();
        }
        if (getInfectionIssues() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getInfectionIssues());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getInfectionIssues(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(InfectedPage.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "InfectedPage"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("foundDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "FoundDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("pageURL");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "PageURL"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("infectionIssues");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "InfectionIssues"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "String"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
