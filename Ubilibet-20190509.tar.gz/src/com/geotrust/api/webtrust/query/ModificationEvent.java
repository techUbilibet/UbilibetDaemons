/**
 * ModificationEvent.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.query;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class ModificationEvent  implements java.io.Serializable {
    private int modificationEventID;

    private java.lang.String modificationEventName;

    private java.util.Calendar modificationTimestamp;

    public ModificationEvent() {
    }

    public ModificationEvent(
           int modificationEventID,
           java.lang.String modificationEventName,
           java.util.Calendar modificationTimestamp) {
           this.modificationEventID = modificationEventID;
           this.modificationEventName = modificationEventName;
           this.modificationTimestamp = modificationTimestamp;
    }


    /**
     * Gets the modificationEventID value for this ModificationEvent.
     * 
     * @return modificationEventID
     */
    public int getModificationEventID() {
        return modificationEventID;
    }


    /**
     * Sets the modificationEventID value for this ModificationEvent.
     * 
     * @param modificationEventID
     */
    public void setModificationEventID(int modificationEventID) {
        this.modificationEventID = modificationEventID;
    }


    /**
     * Gets the modificationEventName value for this ModificationEvent.
     * 
     * @return modificationEventName
     */
    public java.lang.String getModificationEventName() {
        return modificationEventName;
    }


    /**
     * Sets the modificationEventName value for this ModificationEvent.
     * 
     * @param modificationEventName
     */
    public void setModificationEventName(java.lang.String modificationEventName) {
        this.modificationEventName = modificationEventName;
    }


    /**
     * Gets the modificationTimestamp value for this ModificationEvent.
     * 
     * @return modificationTimestamp
     */
    public java.util.Calendar getModificationTimestamp() {
        return modificationTimestamp;
    }


    /**
     * Sets the modificationTimestamp value for this ModificationEvent.
     * 
     * @param modificationTimestamp
     */
    public void setModificationTimestamp(java.util.Calendar modificationTimestamp) {
        this.modificationTimestamp = modificationTimestamp;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ModificationEvent)) return false;
        ModificationEvent other = (ModificationEvent) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.modificationEventID == other.getModificationEventID() &&
            ((this.modificationEventName==null && other.getModificationEventName()==null) || 
             (this.modificationEventName!=null &&
              this.modificationEventName.equals(other.getModificationEventName()))) &&
            ((this.modificationTimestamp==null && other.getModificationTimestamp()==null) || 
             (this.modificationTimestamp!=null &&
              this.modificationTimestamp.equals(other.getModificationTimestamp())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getModificationEventID();
        if (getModificationEventName() != null) {
            _hashCode += getModificationEventName().hashCode();
        }
        if (getModificationTimestamp() != null) {
            _hashCode += getModificationTimestamp().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ModificationEvent.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ModificationEvent"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("modificationEventID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ModificationEventID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("modificationEventName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ModificationEventName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("modificationTimestamp");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ModificationTimestamp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
