/**
 * TrialDetails.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.query;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class TrialDetails  implements java.io.Serializable {
    private boolean orderPlacedAsTrial;

    private java.util.Calendar trialExpirationDate;

    private java.lang.String trialState;

    public TrialDetails() {
    }

    public TrialDetails(
           boolean orderPlacedAsTrial,
           java.util.Calendar trialExpirationDate,
           java.lang.String trialState) {
           this.orderPlacedAsTrial = orderPlacedAsTrial;
           this.trialExpirationDate = trialExpirationDate;
           this.trialState = trialState;
    }


    /**
     * Gets the orderPlacedAsTrial value for this TrialDetails.
     * 
     * @return orderPlacedAsTrial
     */
    public boolean isOrderPlacedAsTrial() {
        return orderPlacedAsTrial;
    }


    /**
     * Sets the orderPlacedAsTrial value for this TrialDetails.
     * 
     * @param orderPlacedAsTrial
     */
    public void setOrderPlacedAsTrial(boolean orderPlacedAsTrial) {
        this.orderPlacedAsTrial = orderPlacedAsTrial;
    }


    /**
     * Gets the trialExpirationDate value for this TrialDetails.
     * 
     * @return trialExpirationDate
     */
    public java.util.Calendar getTrialExpirationDate() {
        return trialExpirationDate;
    }


    /**
     * Sets the trialExpirationDate value for this TrialDetails.
     * 
     * @param trialExpirationDate
     */
    public void setTrialExpirationDate(java.util.Calendar trialExpirationDate) {
        this.trialExpirationDate = trialExpirationDate;
    }


    /**
     * Gets the trialState value for this TrialDetails.
     * 
     * @return trialState
     */
    public java.lang.String getTrialState() {
        return trialState;
    }


    /**
     * Sets the trialState value for this TrialDetails.
     * 
     * @param trialState
     */
    public void setTrialState(java.lang.String trialState) {
        this.trialState = trialState;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof TrialDetails)) return false;
        TrialDetails other = (TrialDetails) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.orderPlacedAsTrial == other.isOrderPlacedAsTrial() &&
            ((this.trialExpirationDate==null && other.getTrialExpirationDate()==null) || 
             (this.trialExpirationDate!=null &&
              this.trialExpirationDate.equals(other.getTrialExpirationDate()))) &&
            ((this.trialState==null && other.getTrialState()==null) || 
             (this.trialState!=null &&
              this.trialState.equals(other.getTrialState())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += (isOrderPlacedAsTrial() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getTrialExpirationDate() != null) {
            _hashCode += getTrialExpirationDate().hashCode();
        }
        if (getTrialState() != null) {
            _hashCode += getTrialState().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(TrialDetails.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "TrialDetails"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderPlacedAsTrial");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "OrderPlacedAsTrial"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("trialExpirationDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "TrialExpirationDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("trialState");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "TrialState"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
