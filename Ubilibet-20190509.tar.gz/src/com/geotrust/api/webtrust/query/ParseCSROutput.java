/**
 * ParseCSROutput.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.query;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class ParseCSROutput  implements java.io.Serializable {
    private com.geotrust.api.webtrust.query.QueryResponseHeader queryResponseHeader;

    private java.lang.String domainName;

    private java.lang.String country;

    private java.lang.String email;

    private java.lang.String locality;

    private java.lang.String organization;

    private java.lang.String organizationUnit;

    private java.lang.String state;

    private boolean isValidTrueDomainName;

    private boolean isValidQuickDomainName;

    private boolean hasBadExtensions;

    public ParseCSROutput() {
    }

    public ParseCSROutput(
           com.geotrust.api.webtrust.query.QueryResponseHeader queryResponseHeader,
           java.lang.String domainName,
           java.lang.String country,
           java.lang.String email,
           java.lang.String locality,
           java.lang.String organization,
           java.lang.String organizationUnit,
           java.lang.String state,
           boolean isValidTrueDomainName,
           boolean isValidQuickDomainName,
           boolean hasBadExtensions) {
           this.queryResponseHeader = queryResponseHeader;
           this.domainName = domainName;
           this.country = country;
           this.email = email;
           this.locality = locality;
           this.organization = organization;
           this.organizationUnit = organizationUnit;
           this.state = state;
           this.isValidTrueDomainName = isValidTrueDomainName;
           this.isValidQuickDomainName = isValidQuickDomainName;
           this.hasBadExtensions = hasBadExtensions;
    }


    /**
     * Gets the queryResponseHeader value for this ParseCSROutput.
     * 
     * @return queryResponseHeader
     */
    public com.geotrust.api.webtrust.query.QueryResponseHeader getQueryResponseHeader() {
        return queryResponseHeader;
    }


    /**
     * Sets the queryResponseHeader value for this ParseCSROutput.
     * 
     * @param queryResponseHeader
     */
    public void setQueryResponseHeader(com.geotrust.api.webtrust.query.QueryResponseHeader queryResponseHeader) {
        this.queryResponseHeader = queryResponseHeader;
    }


    /**
     * Gets the domainName value for this ParseCSROutput.
     * 
     * @return domainName
     */
    public java.lang.String getDomainName() {
        return domainName;
    }


    /**
     * Sets the domainName value for this ParseCSROutput.
     * 
     * @param domainName
     */
    public void setDomainName(java.lang.String domainName) {
        this.domainName = domainName;
    }


    /**
     * Gets the country value for this ParseCSROutput.
     * 
     * @return country
     */
    public java.lang.String getCountry() {
        return country;
    }


    /**
     * Sets the country value for this ParseCSROutput.
     * 
     * @param country
     */
    public void setCountry(java.lang.String country) {
        this.country = country;
    }


    /**
     * Gets the email value for this ParseCSROutput.
     * 
     * @return email
     */
    public java.lang.String getEmail() {
        return email;
    }


    /**
     * Sets the email value for this ParseCSROutput.
     * 
     * @param email
     */
    public void setEmail(java.lang.String email) {
        this.email = email;
    }


    /**
     * Gets the locality value for this ParseCSROutput.
     * 
     * @return locality
     */
    public java.lang.String getLocality() {
        return locality;
    }


    /**
     * Sets the locality value for this ParseCSROutput.
     * 
     * @param locality
     */
    public void setLocality(java.lang.String locality) {
        this.locality = locality;
    }


    /**
     * Gets the organization value for this ParseCSROutput.
     * 
     * @return organization
     */
    public java.lang.String getOrganization() {
        return organization;
    }


    /**
     * Sets the organization value for this ParseCSROutput.
     * 
     * @param organization
     */
    public void setOrganization(java.lang.String organization) {
        this.organization = organization;
    }


    /**
     * Gets the organizationUnit value for this ParseCSROutput.
     * 
     * @return organizationUnit
     */
    public java.lang.String getOrganizationUnit() {
        return organizationUnit;
    }


    /**
     * Sets the organizationUnit value for this ParseCSROutput.
     * 
     * @param organizationUnit
     */
    public void setOrganizationUnit(java.lang.String organizationUnit) {
        this.organizationUnit = organizationUnit;
    }


    /**
     * Gets the state value for this ParseCSROutput.
     * 
     * @return state
     */
    public java.lang.String getState() {
        return state;
    }


    /**
     * Sets the state value for this ParseCSROutput.
     * 
     * @param state
     */
    public void setState(java.lang.String state) {
        this.state = state;
    }


    /**
     * Gets the isValidTrueDomainName value for this ParseCSROutput.
     * 
     * @return isValidTrueDomainName
     */
    public boolean isIsValidTrueDomainName() {
        return isValidTrueDomainName;
    }


    /**
     * Sets the isValidTrueDomainName value for this ParseCSROutput.
     * 
     * @param isValidTrueDomainName
     */
    public void setIsValidTrueDomainName(boolean isValidTrueDomainName) {
        this.isValidTrueDomainName = isValidTrueDomainName;
    }


    /**
     * Gets the isValidQuickDomainName value for this ParseCSROutput.
     * 
     * @return isValidQuickDomainName
     */
    public boolean isIsValidQuickDomainName() {
        return isValidQuickDomainName;
    }


    /**
     * Sets the isValidQuickDomainName value for this ParseCSROutput.
     * 
     * @param isValidQuickDomainName
     */
    public void setIsValidQuickDomainName(boolean isValidQuickDomainName) {
        this.isValidQuickDomainName = isValidQuickDomainName;
    }


    /**
     * Gets the hasBadExtensions value for this ParseCSROutput.
     * 
     * @return hasBadExtensions
     */
    public boolean isHasBadExtensions() {
        return hasBadExtensions;
    }


    /**
     * Sets the hasBadExtensions value for this ParseCSROutput.
     * 
     * @param hasBadExtensions
     */
    public void setHasBadExtensions(boolean hasBadExtensions) {
        this.hasBadExtensions = hasBadExtensions;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ParseCSROutput)) return false;
        ParseCSROutput other = (ParseCSROutput) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.queryResponseHeader==null && other.getQueryResponseHeader()==null) || 
             (this.queryResponseHeader!=null &&
              this.queryResponseHeader.equals(other.getQueryResponseHeader()))) &&
            ((this.domainName==null && other.getDomainName()==null) || 
             (this.domainName!=null &&
              this.domainName.equals(other.getDomainName()))) &&
            ((this.country==null && other.getCountry()==null) || 
             (this.country!=null &&
              this.country.equals(other.getCountry()))) &&
            ((this.email==null && other.getEmail()==null) || 
             (this.email!=null &&
              this.email.equals(other.getEmail()))) &&
            ((this.locality==null && other.getLocality()==null) || 
             (this.locality!=null &&
              this.locality.equals(other.getLocality()))) &&
            ((this.organization==null && other.getOrganization()==null) || 
             (this.organization!=null &&
              this.organization.equals(other.getOrganization()))) &&
            ((this.organizationUnit==null && other.getOrganizationUnit()==null) || 
             (this.organizationUnit!=null &&
              this.organizationUnit.equals(other.getOrganizationUnit()))) &&
            ((this.state==null && other.getState()==null) || 
             (this.state!=null &&
              this.state.equals(other.getState()))) &&
            this.isValidTrueDomainName == other.isIsValidTrueDomainName() &&
            this.isValidQuickDomainName == other.isIsValidQuickDomainName() &&
            this.hasBadExtensions == other.isHasBadExtensions();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getQueryResponseHeader() != null) {
            _hashCode += getQueryResponseHeader().hashCode();
        }
        if (getDomainName() != null) {
            _hashCode += getDomainName().hashCode();
        }
        if (getCountry() != null) {
            _hashCode += getCountry().hashCode();
        }
        if (getEmail() != null) {
            _hashCode += getEmail().hashCode();
        }
        if (getLocality() != null) {
            _hashCode += getLocality().hashCode();
        }
        if (getOrganization() != null) {
            _hashCode += getOrganization().hashCode();
        }
        if (getOrganizationUnit() != null) {
            _hashCode += getOrganizationUnit().hashCode();
        }
        if (getState() != null) {
            _hashCode += getState().hashCode();
        }
        _hashCode += (isIsValidTrueDomainName() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isIsValidQuickDomainName() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isHasBadExtensions() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ParseCSROutput.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ParseCSROutput"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("queryResponseHeader");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "QueryResponseHeader"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "queryResponseHeader"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("domainName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "DomainName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("country");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "Country"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("email");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "Email"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("locality");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "Locality"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("organization");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "Organization"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("organizationUnit");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "OrganizationUnit"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("state");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "State"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isValidTrueDomainName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "IsValidTrueDomainName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isValidQuickDomainName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "IsValidQuickDomainName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hasBadExtensions");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "HasBadExtensions"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
