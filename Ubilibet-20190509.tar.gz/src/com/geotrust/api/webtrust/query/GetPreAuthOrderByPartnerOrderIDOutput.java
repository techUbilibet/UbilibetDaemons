/**
 * GetPreAuthOrderByPartnerOrderIDOutput.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.query;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class GetPreAuthOrderByPartnerOrderIDOutput  implements java.io.Serializable {
    private com.geotrust.api.webtrust.query.QueryResponseHeader authQueryResponseHeader;

    private com.geotrust.api.webtrust.query.AuthOrderDataStatus authOrderDataStatus;

    public GetPreAuthOrderByPartnerOrderIDOutput() {
    }

    public GetPreAuthOrderByPartnerOrderIDOutput(
           com.geotrust.api.webtrust.query.QueryResponseHeader authQueryResponseHeader,
           com.geotrust.api.webtrust.query.AuthOrderDataStatus authOrderDataStatus) {
           this.authQueryResponseHeader = authQueryResponseHeader;
           this.authOrderDataStatus = authOrderDataStatus;
    }


    /**
     * Gets the authQueryResponseHeader value for this GetPreAuthOrderByPartnerOrderIDOutput.
     * 
     * @return authQueryResponseHeader
     */
    public com.geotrust.api.webtrust.query.QueryResponseHeader getAuthQueryResponseHeader() {
        return authQueryResponseHeader;
    }


    /**
     * Sets the authQueryResponseHeader value for this GetPreAuthOrderByPartnerOrderIDOutput.
     * 
     * @param authQueryResponseHeader
     */
    public void setAuthQueryResponseHeader(com.geotrust.api.webtrust.query.QueryResponseHeader authQueryResponseHeader) {
        this.authQueryResponseHeader = authQueryResponseHeader;
    }


    /**
     * Gets the authOrderDataStatus value for this GetPreAuthOrderByPartnerOrderIDOutput.
     * 
     * @return authOrderDataStatus
     */
    public com.geotrust.api.webtrust.query.AuthOrderDataStatus getAuthOrderDataStatus() {
        return authOrderDataStatus;
    }


    /**
     * Sets the authOrderDataStatus value for this GetPreAuthOrderByPartnerOrderIDOutput.
     * 
     * @param authOrderDataStatus
     */
    public void setAuthOrderDataStatus(com.geotrust.api.webtrust.query.AuthOrderDataStatus authOrderDataStatus) {
        this.authOrderDataStatus = authOrderDataStatus;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof GetPreAuthOrderByPartnerOrderIDOutput)) return false;
        GetPreAuthOrderByPartnerOrderIDOutput other = (GetPreAuthOrderByPartnerOrderIDOutput) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.authQueryResponseHeader==null && other.getAuthQueryResponseHeader()==null) || 
             (this.authQueryResponseHeader!=null &&
              this.authQueryResponseHeader.equals(other.getAuthQueryResponseHeader()))) &&
            ((this.authOrderDataStatus==null && other.getAuthOrderDataStatus()==null) || 
             (this.authOrderDataStatus!=null &&
              this.authOrderDataStatus.equals(other.getAuthOrderDataStatus())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getAuthQueryResponseHeader() != null) {
            _hashCode += getAuthQueryResponseHeader().hashCode();
        }
        if (getAuthOrderDataStatus() != null) {
            _hashCode += getAuthOrderDataStatus().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(GetPreAuthOrderByPartnerOrderIDOutput.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetPreAuthOrderByPartnerOrderIDOutput"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("authQueryResponseHeader");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "AuthQueryResponseHeader"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "queryResponseHeader"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("authOrderDataStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "AuthOrderDataStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "AuthOrderDataStatus"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
