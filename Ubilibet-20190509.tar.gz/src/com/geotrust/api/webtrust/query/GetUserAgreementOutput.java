/**
 * GetUserAgreementOutput.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.query;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class GetUserAgreementOutput  implements java.io.Serializable {
    private com.geotrust.api.webtrust.query.QueryResponseHeader queryResponseHeader;

    private java.lang.String userAgreement;

    public GetUserAgreementOutput() {
    }

    public GetUserAgreementOutput(
           com.geotrust.api.webtrust.query.QueryResponseHeader queryResponseHeader,
           java.lang.String userAgreement) {
           this.queryResponseHeader = queryResponseHeader;
           this.userAgreement = userAgreement;
    }


    /**
     * Gets the queryResponseHeader value for this GetUserAgreementOutput.
     * 
     * @return queryResponseHeader
     */
    public com.geotrust.api.webtrust.query.QueryResponseHeader getQueryResponseHeader() {
        return queryResponseHeader;
    }


    /**
     * Sets the queryResponseHeader value for this GetUserAgreementOutput.
     * 
     * @param queryResponseHeader
     */
    public void setQueryResponseHeader(com.geotrust.api.webtrust.query.QueryResponseHeader queryResponseHeader) {
        this.queryResponseHeader = queryResponseHeader;
    }


    /**
     * Gets the userAgreement value for this GetUserAgreementOutput.
     * 
     * @return userAgreement
     */
    public java.lang.String getUserAgreement() {
        return userAgreement;
    }


    /**
     * Sets the userAgreement value for this GetUserAgreementOutput.
     * 
     * @param userAgreement
     */
    public void setUserAgreement(java.lang.String userAgreement) {
        this.userAgreement = userAgreement;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof GetUserAgreementOutput)) return false;
        GetUserAgreementOutput other = (GetUserAgreementOutput) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.queryResponseHeader==null && other.getQueryResponseHeader()==null) || 
             (this.queryResponseHeader!=null &&
              this.queryResponseHeader.equals(other.getQueryResponseHeader()))) &&
            ((this.userAgreement==null && other.getUserAgreement()==null) || 
             (this.userAgreement!=null &&
              this.userAgreement.equals(other.getUserAgreement())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getQueryResponseHeader() != null) {
            _hashCode += getQueryResponseHeader().hashCode();
        }
        if (getUserAgreement() != null) {
            _hashCode += getUserAgreement().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(GetUserAgreementOutput.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetUserAgreementOutput"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("queryResponseHeader");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "QueryResponseHeader"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "queryResponseHeader"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("userAgreement");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "UserAgreement"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
