/**
 * CertTransparency.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.query;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class CertTransparency  implements java.io.Serializable {
    private java.lang.Boolean CTLogging;

    private java.lang.String CTMethod;

    private java.lang.String CTPrivacy;

    public CertTransparency() {
    }

    public CertTransparency(
           java.lang.Boolean CTLogging,
           java.lang.String CTMethod,
           java.lang.String CTPrivacy) {
           this.CTLogging = CTLogging;
           this.CTMethod = CTMethod;
           this.CTPrivacy = CTPrivacy;
    }


    /**
     * Gets the CTLogging value for this CertTransparency.
     * 
     * @return CTLogging
     */
    public java.lang.Boolean getCTLogging() {
        return CTLogging;
    }


    /**
     * Sets the CTLogging value for this CertTransparency.
     * 
     * @param CTLogging
     */
    public void setCTLogging(java.lang.Boolean CTLogging) {
        this.CTLogging = CTLogging;
    }


    /**
     * Gets the CTMethod value for this CertTransparency.
     * 
     * @return CTMethod
     */
    public java.lang.String getCTMethod() {
        return CTMethod;
    }


    /**
     * Sets the CTMethod value for this CertTransparency.
     * 
     * @param CTMethod
     */
    public void setCTMethod(java.lang.String CTMethod) {
        this.CTMethod = CTMethod;
    }


    /**
     * Gets the CTPrivacy value for this CertTransparency.
     * 
     * @return CTPrivacy
     */
    public java.lang.String getCTPrivacy() {
        return CTPrivacy;
    }


    /**
     * Sets the CTPrivacy value for this CertTransparency.
     * 
     * @param CTPrivacy
     */
    public void setCTPrivacy(java.lang.String CTPrivacy) {
        this.CTPrivacy = CTPrivacy;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CertTransparency)) return false;
        CertTransparency other = (CertTransparency) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.CTLogging==null && other.getCTLogging()==null) || 
             (this.CTLogging!=null &&
              this.CTLogging.equals(other.getCTLogging()))) &&
            ((this.CTMethod==null && other.getCTMethod()==null) || 
             (this.CTMethod!=null &&
              this.CTMethod.equals(other.getCTMethod()))) &&
            ((this.CTPrivacy==null && other.getCTPrivacy()==null) || 
             (this.CTPrivacy!=null &&
              this.CTPrivacy.equals(other.getCTPrivacy())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCTLogging() != null) {
            _hashCode += getCTLogging().hashCode();
        }
        if (getCTMethod() != null) {
            _hashCode += getCTMethod().hashCode();
        }
        if (getCTPrivacy() != null) {
            _hashCode += getCTPrivacy().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CertTransparency.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "CertTransparency"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CTLogging");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "CTLogging"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CTMethod");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "CTMethod"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CTPrivacy");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "CTPrivacy"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
