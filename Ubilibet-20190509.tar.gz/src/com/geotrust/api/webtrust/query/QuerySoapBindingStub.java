/**
 * QuerySoapBindingStub.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.query;

@SuppressWarnings({ "unchecked", "unused", "rawtypes" })
public class QuerySoapBindingStub extends org.apache.axis.client.Stub implements com.geotrust.api.webtrust.query.QuerySoap {
    private java.util.Vector cachedSerClasses = new java.util.Vector();
    private java.util.Vector cachedSerQNames = new java.util.Vector();
    private java.util.Vector cachedSerFactories = new java.util.Vector();
    private java.util.Vector cachedDeserFactories = new java.util.Vector();

    static org.apache.axis.description.OperationDesc [] _operations;

    static {
        _operations = new org.apache.axis.description.OperationDesc[14];
        _initOperationDesc1();
        _initOperationDesc2();
    }

    private static void _initOperationDesc1(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetFulfillment");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "Request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetFulfillmentInput"), com.geotrust.api.webtrust.query.GetFulfillmentInput.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetFulfillmentOutput"));
        oper.setReturnClass(com.geotrust.api.webtrust.query.GetFulfillmentOutput.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetFulfillmentResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[0] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetModifiedPreAuthOrderSummary");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "Request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetModifiedPreAuthOrderSummaryInput"), com.geotrust.api.webtrust.query.GetModifiedPreAuthOrderSummaryInput.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetModifiedPreAuthOrderSummaryOutput"));
        oper.setReturnClass(com.geotrust.api.webtrust.query.GetModifiedPreAuthOrderSummaryOutput.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetModifiedPreAuthOrderSummaryResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[1] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("CheckStatus");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "Request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "CheckStatusInput"), com.geotrust.api.webtrust.query.CheckStatusInput.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "CheckStatusOutput"));
        oper.setReturnClass(com.geotrust.api.webtrust.query.CheckStatusOutput.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "CheckStatusResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[2] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetModifiedOrderSummary");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "Request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetModifiedOrderSummaryInput"), com.geotrust.api.webtrust.query.GetModifiedOrderSummaryInput.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetModifiedOrderSummaryOutput"));
        oper.setReturnClass(com.geotrust.api.webtrust.query.GetModifiedOrderSummaryOutput.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetModifiedOrderSummaryResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[3] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetPreAuthOrderByPartnerOrderID");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "AuthQueryRequest"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetPreAuthOrderByPartnerOrderIDInput"), com.geotrust.api.webtrust.query.GetPreAuthOrderByPartnerOrderIDInput.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetPreAuthOrderByPartnerOrderIDOutput"));
        oper.setReturnClass(com.geotrust.api.webtrust.query.GetPreAuthOrderByPartnerOrderIDOutput.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetPreAuthOrderByPartnerOrderIDResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[4] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetModifiedOrders");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "Request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetModifiedOrdersInput"), com.geotrust.api.webtrust.query.GetModifiedOrdersInput.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetModifiedOrdersOutput"));
        oper.setReturnClass(com.geotrust.api.webtrust.query.GetModifiedOrdersOutput.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetModifiedOrdersResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[5] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetUserAgreement");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "Request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetUserAgreementInput"), com.geotrust.api.webtrust.query.GetUserAgreementInput.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetUserAgreementOutput"));
        oper.setReturnClass(com.geotrust.api.webtrust.query.GetUserAgreementOutput.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetUserAgreementResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[6] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetOrderByGTOrderID");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "Request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetOrderByGTOrderIDInput"), com.geotrust.api.webtrust.query.GetOrderByGTOrderIDInput.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetOrderByPartnerOrderIDOutput"));
        oper.setReturnClass(com.geotrust.api.webtrust.query.GetOrderByPartnerOrderIDOutput.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetOrderByPartnerOrderIDResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[7] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetOrdersByDateRange");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "Request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetOrdersByDateRangeInput"), com.geotrust.api.webtrust.query.GetOrdersByDateRangeInput.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetOrdersByDateRangeOutput"));
        oper.setReturnClass(com.geotrust.api.webtrust.query.GetOrdersByDateRangeOutput.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetOrdersByDateRangeResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[8] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetOrderByPartnerOrderID");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "Request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetOrderByPartnerOrderIDInput"), com.geotrust.api.webtrust.query.GetOrderByPartnerOrderIDInput.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetOrderByPartnerOrderIDOutput"));
        oper.setReturnClass(com.geotrust.api.webtrust.query.GetOrderByPartnerOrderIDOutput.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetOrderByPartnerOrderIDResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[9] = oper;

    }

    private static void _initOperationDesc2(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("hello");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "Input"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        oper.setReturnClass(java.lang.String.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "helloResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[10] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetPreAuthOrdersByDateRange");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "AuthQueryRequest"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetPreAuthOrdersByDataRangeInput"), com.geotrust.api.webtrust.query.GetPreAuthOrdersByDataRangeInput.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetPreAuthOrdersByDateRangeOutput"));
        oper.setReturnClass(com.geotrust.api.webtrust.query.GetPreAuthOrdersByDateRangeOutput.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetPreAuthDataByOrganizationResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[11] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("ParseCSR");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "Request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ParseCSRInput"), com.geotrust.api.webtrust.query.ParseCSRInput.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ParseCSROutput"));
        oper.setReturnClass(com.geotrust.api.webtrust.query.ParseCSROutput.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ParseCSRResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[12] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetQuickApproverList");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "Request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetQuickApproverListInput"), com.geotrust.api.webtrust.query.GetQuickApproverListInput.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetQuickApproverListOutput"));
        oper.setReturnClass(com.geotrust.api.webtrust.query.GetQuickApproverListOutput.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetQuickApproverListResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[13] = oper;

    }

    public QuerySoapBindingStub() throws org.apache.axis.AxisFault {
         this(null);
    }

    public QuerySoapBindingStub(java.net.URL endpointURL, javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
         this(service);
         super.cachedEndpoint = endpointURL;
    }

    public QuerySoapBindingStub(javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
        if (service == null) {
            super.service = new org.apache.axis.client.Service();
        } else {
            super.service = service;
        }
        ((org.apache.axis.client.Service)super.service).setTypeMappingVersion("1.2");
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
        addBindings0();
        addBindings1();
    }

    private void addBindings0() {
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "algorithmInfo");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.AlgorithmInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "Approver");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.Approver.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ArrayOfApprover");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.Approver[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "Approver");
            qName2 = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "Approver");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ArrayOfAuthenticationComment");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.AuthenticationComment[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "AuthenticationComment");
            qName2 = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "AuthenticationComment");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ArrayOfAuthenticationStatus");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.AuthenticationStatus[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "AuthenticationStatus");
            qName2 = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "AuthenticationStatus");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ArrayOfAuthOrderDataStatus");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.AuthOrderDataStatus[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "AuthOrderDataStatus");
            qName2 = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "AuthOrderDataStatus");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ArrayOfCAAEntry");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.CAAEntry[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "CAAEntry");
            qName2 = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "CAAEntry");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ArrayOfCACertificate");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.CACertificate[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "CACertificate");
            qName2 = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "CACertificate");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ArrayOfCertificateDetail");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.CertificateDetail[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "CertificateDetail");
            qName2 = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "CertificateDetail");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ArrayOfContactPairAuthStatus");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.ContactPairAuthStatus[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ContactPairAuthStatus");
            qName2 = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ContactPairAuthStatus");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ArrayOfCriterion");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.Criterion[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "Criterion");
            qName2 = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "Criterion");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ArrayOfCustomField");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.CustomField[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "CustomField");
            qName2 = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "CustomField");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ArrayOfDomainAuthStatus");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.DomainAuthStatus[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "DomainAuthStatus");
            qName2 = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "DomainAuthStatus");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ArrayOfError");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.Error[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "Error");
            qName2 = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "Error");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ArrayOfInfectedPage");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.InfectedPage[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "InfectedPage");
            qName2 = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "InfectedPage");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ArrayOfLocalTradingName");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.LocalTradingName[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "LocalTradingName");
            qName2 = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "LocalTradingName");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ArrayOfModificationEvent");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.ModificationEvent[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ModificationEvent");
            qName2 = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ModificationEvent");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ArrayOfModifiedPartnerOrder");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.ModifiedPartnerOrder[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ModifiedPartnerOrder");
            qName2 = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ModifiedPartnerOrder");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ArrayOfOrderAttribute");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.OrderAttribute[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "OrderAttribute");
            qName2 = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "OrderAttribute");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ArrayOfOrderDetail");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.OrderDetail[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "OrderDetail");
            qName2 = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "OrderDetail");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ArrayOfOrderSummary");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.OrderSummary[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "OrderSummary");
            qName2 = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "OrderSummary");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ArrayOfSANVettingStatus");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.SANVettingStatus[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "SANVettingStatus");
            qName2 = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "SANVettingStatus");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ArrayOfString");
            cachedSerQNames.add(qName);
            cls = java.lang.String[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string");
            qName2 = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "String");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ArrayOfVulnerability");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.Vulnerability[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "Vulnerability");
            qName2 = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "Vulnerability");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "AuthDataStatus");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.AuthDataStatus.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "AuthenticationComment");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.AuthenticationComment.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "AuthenticationStatus");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.AuthenticationStatus.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "AuthOrderDataStatus");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.AuthOrderDataStatus.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "AuthOrderParameters");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.AuthOrderParameters.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "AuthQueryOrganizationInfo");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.AuthQueryOrganizationInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "AuthQueryParameters");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.AuthQueryParameters.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "AuthStatus");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.AuthStatus.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "authToken");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.AuthToken.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "CAAEntry");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.CAAEntry.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "CACertificate");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.CACertificate.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "CertificateDetail");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.CertificateDetail.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "certificateInfo");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.CertificateInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "CertTransparency");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.CertTransparency.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "CheckStatusInput");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.CheckStatusInput.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "CheckStatusOutput");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.CheckStatusOutput.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "Contact");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.Contact.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ContactPair");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.ContactPair.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ContactPairAuthStatus");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.ContactPairAuthStatus.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "Criterion");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.Criterion.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "CustomField");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.CustomField.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "DNSAuthDVInfo");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.DNSAuthDVInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "DNSRecord");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.DNSRecord.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "Domain");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.Domain.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "DomainAuthStatus");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.DomainAuthStatus.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "Error");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.Error.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "fileAuthDVInfo");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.FileAuthDVInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "fulfillment");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.Fulfillment.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetFulfillmentInput");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.GetFulfillmentInput.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetFulfillmentOutput");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.GetFulfillmentOutput.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetModifiedOrdersInput");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.GetModifiedOrdersInput.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetModifiedOrdersOutput");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.GetModifiedOrdersOutput.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetModifiedOrderSummaryInput");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.GetModifiedOrderSummaryInput.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetModifiedOrderSummaryOutput");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.GetModifiedOrderSummaryOutput.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetModifiedPreAuthOrderSummaryInput");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.GetModifiedPreAuthOrderSummaryInput.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetModifiedPreAuthOrderSummaryOutput");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.GetModifiedPreAuthOrderSummaryOutput.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetOrderByGTOrderIDInput");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.GetOrderByGTOrderIDInput.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetOrderByPartnerOrderIDInput");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.GetOrderByPartnerOrderIDInput.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetOrderByPartnerOrderIDOutput");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.GetOrderByPartnerOrderIDOutput.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetOrdersByDateRangeInput");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.GetOrdersByDateRangeInput.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetOrdersByDateRangeOutput");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.GetOrdersByDateRangeOutput.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetPreAuthOrderByPartnerOrderIDInput");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.GetPreAuthOrderByPartnerOrderIDInput.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetPreAuthOrderByPartnerOrderIDOutput");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.GetPreAuthOrderByPartnerOrderIDOutput.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetPreAuthOrdersByDataRangeInput");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.GetPreAuthOrdersByDataRangeInput.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetPreAuthOrdersByDateRangeOutput");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.GetPreAuthOrdersByDateRangeOutput.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetQuickApproverListInput");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.GetQuickApproverListInput.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetQuickApproverListOutput");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.GetQuickApproverListOutput.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetUserAgreementInput");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.GetUserAgreementInput.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetUserAgreementOutput");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.GetUserAgreementOutput.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "includeUserAgreement");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.IncludeUserAgreement.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "InfectedPage");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.InfectedPage.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "LocalTradingName");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.LocalTradingName.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "malwareScanReport");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.MalwareScanReport.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ModificationEvent");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.ModificationEvent.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ModifiedPartnerOrder");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.ModifiedPartnerOrder.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "OrderAttribute");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.OrderAttribute.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "orderContacts");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.OrderContacts.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "OrderDetail");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.OrderDetail.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "orderInfo");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.OrderInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "orderQueryOptions");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.OrderQueryOptions.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "OrderStateReason");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.OrderStateReason.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "orderStatus");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.OrderStatus.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "orderStatusMinor");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.OrderStatusMinor.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "OrderSummary");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.OrderSummary.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "organizationAddress");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.OrganizationAddress.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "OrganizationAuthStatus");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.OrganizationAuthStatus.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "organizationInfo");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.OrganizationInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ParseCSRInput");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.ParseCSRInput.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ParseCSROutput");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.ParseCSROutput.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "queryRequestHeader");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.QueryRequestHeader.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "queryResponseHeader");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.QueryResponseHeader.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "quickOrderDetail");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.QuickOrderDetail.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "SANVettingStatus");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.SANVettingStatus.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "SearchCriteria");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.SearchCriteria.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "TCOrderDetail");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.TCOrderDetail.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "TrialDetails");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.TrialDetails.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

    }
    private void addBindings1() {
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "trueOrderDetail");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.TrueOrderDetail.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "trustServicesDetails");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.TrustServicesDetails.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "Vulnerability");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.Vulnerability.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "vulnerabilityScanDetails");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.VulnerabilityScanDetails.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "vulnerabilityScanInfo");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.query.VulnerabilityScanInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

    }

    protected org.apache.axis.client.Call createCall() throws java.rmi.RemoteException {
        try {
            org.apache.axis.client.Call _call = super._createCall();
            if (super.maintainSessionSet) {
                _call.setMaintainSession(super.maintainSession);
            }
            if (super.cachedUsername != null) {
                _call.setUsername(super.cachedUsername);
            }
            if (super.cachedPassword != null) {
                _call.setPassword(super.cachedPassword);
            }
            if (super.cachedEndpoint != null) {
                _call.setTargetEndpointAddress(super.cachedEndpoint);
            }
            if (super.cachedTimeout != null) {
                _call.setTimeout(super.cachedTimeout);
            }
            if (super.cachedPortName != null) {
                _call.setPortName(super.cachedPortName);
            }
            java.util.Enumeration keys = super.cachedProperties.keys();
            while (keys.hasMoreElements()) {
                java.lang.String key = (java.lang.String) keys.nextElement();
                _call.setProperty(key, super.cachedProperties.get(key));
            }
            // All the type mapping information is registered
            // when the first call is made.
            // The type mapping information is actually registered in
            // the TypeMappingRegistry of the service, which
            // is the reason why registration is only needed for the first call.
            synchronized (this) {
                if (firstCall()) {
                    // must set encoding style before registering serializers
                    _call.setEncodingStyle(null);
                    for (int i = 0; i < cachedSerFactories.size(); ++i) {
                        java.lang.Class cls = (java.lang.Class) cachedSerClasses.get(i);
                        javax.xml.namespace.QName qName =
                                (javax.xml.namespace.QName) cachedSerQNames.get(i);
                        java.lang.Object x = cachedSerFactories.get(i);
                        if (x instanceof Class) {
                            java.lang.Class sf = (java.lang.Class)
                                 cachedSerFactories.get(i);
                            java.lang.Class df = (java.lang.Class)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                        else if (x instanceof javax.xml.rpc.encoding.SerializerFactory) {
                            org.apache.axis.encoding.SerializerFactory sf = (org.apache.axis.encoding.SerializerFactory)
                                 cachedSerFactories.get(i);
                            org.apache.axis.encoding.DeserializerFactory df = (org.apache.axis.encoding.DeserializerFactory)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                    }
                }
            }
            return _call;
        }
        catch (java.lang.Throwable _t) {
            throw new org.apache.axis.AxisFault("Failure trying to get the Call object", _t);
        }
    }

    public com.geotrust.api.webtrust.query.GetFulfillmentOutput getFulfillment(com.geotrust.api.webtrust.query.GetFulfillmentInput request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[0]);
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetFulfillment"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.geotrust.api.webtrust.query.GetFulfillmentOutput) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.geotrust.api.webtrust.query.GetFulfillmentOutput) org.apache.axis.utils.JavaUtils.convert(_resp, com.geotrust.api.webtrust.query.GetFulfillmentOutput.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.geotrust.api.webtrust.query.GetModifiedPreAuthOrderSummaryOutput getModifiedPreAuthOrderSummary(com.geotrust.api.webtrust.query.GetModifiedPreAuthOrderSummaryInput request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[1]);
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetModifiedPreAuthOrderSummary"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.geotrust.api.webtrust.query.GetModifiedPreAuthOrderSummaryOutput) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.geotrust.api.webtrust.query.GetModifiedPreAuthOrderSummaryOutput) org.apache.axis.utils.JavaUtils.convert(_resp, com.geotrust.api.webtrust.query.GetModifiedPreAuthOrderSummaryOutput.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.geotrust.api.webtrust.query.CheckStatusOutput checkStatus(com.geotrust.api.webtrust.query.CheckStatusInput request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[2]);
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "CheckStatus"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.geotrust.api.webtrust.query.CheckStatusOutput) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.geotrust.api.webtrust.query.CheckStatusOutput) org.apache.axis.utils.JavaUtils.convert(_resp, com.geotrust.api.webtrust.query.CheckStatusOutput.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.geotrust.api.webtrust.query.GetModifiedOrderSummaryOutput getModifiedOrderSummary(com.geotrust.api.webtrust.query.GetModifiedOrderSummaryInput request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[3]);
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetModifiedOrderSummary"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.geotrust.api.webtrust.query.GetModifiedOrderSummaryOutput) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.geotrust.api.webtrust.query.GetModifiedOrderSummaryOutput) org.apache.axis.utils.JavaUtils.convert(_resp, com.geotrust.api.webtrust.query.GetModifiedOrderSummaryOutput.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.geotrust.api.webtrust.query.GetPreAuthOrderByPartnerOrderIDOutput getPreAuthOrderByPartnerOrderID(com.geotrust.api.webtrust.query.GetPreAuthOrderByPartnerOrderIDInput authQueryRequest) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[4]);
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetPreAuthOrderByPartnerOrderID"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {authQueryRequest});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.geotrust.api.webtrust.query.GetPreAuthOrderByPartnerOrderIDOutput) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.geotrust.api.webtrust.query.GetPreAuthOrderByPartnerOrderIDOutput) org.apache.axis.utils.JavaUtils.convert(_resp, com.geotrust.api.webtrust.query.GetPreAuthOrderByPartnerOrderIDOutput.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.geotrust.api.webtrust.query.GetModifiedOrdersOutput getModifiedOrders(com.geotrust.api.webtrust.query.GetModifiedOrdersInput request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[5]);
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetModifiedOrders"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.geotrust.api.webtrust.query.GetModifiedOrdersOutput) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.geotrust.api.webtrust.query.GetModifiedOrdersOutput) org.apache.axis.utils.JavaUtils.convert(_resp, com.geotrust.api.webtrust.query.GetModifiedOrdersOutput.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.geotrust.api.webtrust.query.GetUserAgreementOutput getUserAgreement(com.geotrust.api.webtrust.query.GetUserAgreementInput request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[6]);
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetUserAgreement"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.geotrust.api.webtrust.query.GetUserAgreementOutput) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.geotrust.api.webtrust.query.GetUserAgreementOutput) org.apache.axis.utils.JavaUtils.convert(_resp, com.geotrust.api.webtrust.query.GetUserAgreementOutput.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.geotrust.api.webtrust.query.GetOrderByPartnerOrderIDOutput getOrderByGTOrderID(com.geotrust.api.webtrust.query.GetOrderByGTOrderIDInput request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[7]);
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetOrderByGTOrderID"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.geotrust.api.webtrust.query.GetOrderByPartnerOrderIDOutput) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.geotrust.api.webtrust.query.GetOrderByPartnerOrderIDOutput) org.apache.axis.utils.JavaUtils.convert(_resp, com.geotrust.api.webtrust.query.GetOrderByPartnerOrderIDOutput.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.geotrust.api.webtrust.query.GetOrdersByDateRangeOutput getOrdersByDateRange(com.geotrust.api.webtrust.query.GetOrdersByDateRangeInput request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[8]);
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetOrdersByDateRange"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.geotrust.api.webtrust.query.GetOrdersByDateRangeOutput) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.geotrust.api.webtrust.query.GetOrdersByDateRangeOutput) org.apache.axis.utils.JavaUtils.convert(_resp, com.geotrust.api.webtrust.query.GetOrdersByDateRangeOutput.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.geotrust.api.webtrust.query.GetOrderByPartnerOrderIDOutput getOrderByPartnerOrderID(com.geotrust.api.webtrust.query.GetOrderByPartnerOrderIDInput request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[9]);
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetOrderByPartnerOrderID"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.geotrust.api.webtrust.query.GetOrderByPartnerOrderIDOutput) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.geotrust.api.webtrust.query.GetOrderByPartnerOrderIDOutput) org.apache.axis.utils.JavaUtils.convert(_resp, com.geotrust.api.webtrust.query.GetOrderByPartnerOrderIDOutput.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public java.lang.String hello(java.lang.String input) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[10]);
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "hello"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {input});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (java.lang.String) _resp;
            } catch (java.lang.Exception _exception) {
                return (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_resp, java.lang.String.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.geotrust.api.webtrust.query.GetPreAuthOrdersByDateRangeOutput getPreAuthOrdersByDateRange(com.geotrust.api.webtrust.query.GetPreAuthOrdersByDataRangeInput authQueryRequest) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[11]);
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetPreAuthOrdersByDateRange"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {authQueryRequest});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.geotrust.api.webtrust.query.GetPreAuthOrdersByDateRangeOutput) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.geotrust.api.webtrust.query.GetPreAuthOrdersByDateRangeOutput) org.apache.axis.utils.JavaUtils.convert(_resp, com.geotrust.api.webtrust.query.GetPreAuthOrdersByDateRangeOutput.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.geotrust.api.webtrust.query.ParseCSROutput parseCSR(com.geotrust.api.webtrust.query.ParseCSRInput request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[12]);
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ParseCSR"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.geotrust.api.webtrust.query.ParseCSROutput) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.geotrust.api.webtrust.query.ParseCSROutput) org.apache.axis.utils.JavaUtils.convert(_resp, com.geotrust.api.webtrust.query.ParseCSROutput.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.geotrust.api.webtrust.query.GetQuickApproverListOutput getQuickApproverList(com.geotrust.api.webtrust.query.GetQuickApproverListInput request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[13]);
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetQuickApproverList"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.geotrust.api.webtrust.query.GetQuickApproverListOutput) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.geotrust.api.webtrust.query.GetQuickApproverListOutput) org.apache.axis.utils.JavaUtils.convert(_resp, com.geotrust.api.webtrust.query.GetQuickApproverListOutput.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

}
