/**
 * ModifiedPartnerOrder.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.query;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class ModifiedPartnerOrder  implements java.io.Serializable {
    private java.lang.String partnerCode;

    private int modifiedOrderCount;

    private com.geotrust.api.webtrust.query.OrderSummary[] orderSummaries;

    public ModifiedPartnerOrder() {
    }

    public ModifiedPartnerOrder(
           java.lang.String partnerCode,
           int modifiedOrderCount,
           com.geotrust.api.webtrust.query.OrderSummary[] orderSummaries) {
           this.partnerCode = partnerCode;
           this.modifiedOrderCount = modifiedOrderCount;
           this.orderSummaries = orderSummaries;
    }


    /**
     * Gets the partnerCode value for this ModifiedPartnerOrder.
     * 
     * @return partnerCode
     */
    public java.lang.String getPartnerCode() {
        return partnerCode;
    }


    /**
     * Sets the partnerCode value for this ModifiedPartnerOrder.
     * 
     * @param partnerCode
     */
    public void setPartnerCode(java.lang.String partnerCode) {
        this.partnerCode = partnerCode;
    }


    /**
     * Gets the modifiedOrderCount value for this ModifiedPartnerOrder.
     * 
     * @return modifiedOrderCount
     */
    public int getModifiedOrderCount() {
        return modifiedOrderCount;
    }


    /**
     * Sets the modifiedOrderCount value for this ModifiedPartnerOrder.
     * 
     * @param modifiedOrderCount
     */
    public void setModifiedOrderCount(int modifiedOrderCount) {
        this.modifiedOrderCount = modifiedOrderCount;
    }


    /**
     * Gets the orderSummaries value for this ModifiedPartnerOrder.
     * 
     * @return orderSummaries
     */
    public com.geotrust.api.webtrust.query.OrderSummary[] getOrderSummaries() {
        return orderSummaries;
    }


    /**
     * Sets the orderSummaries value for this ModifiedPartnerOrder.
     * 
     * @param orderSummaries
     */
    public void setOrderSummaries(com.geotrust.api.webtrust.query.OrderSummary[] orderSummaries) {
        this.orderSummaries = orderSummaries;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ModifiedPartnerOrder)) return false;
        ModifiedPartnerOrder other = (ModifiedPartnerOrder) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.partnerCode==null && other.getPartnerCode()==null) || 
             (this.partnerCode!=null &&
              this.partnerCode.equals(other.getPartnerCode()))) &&
            this.modifiedOrderCount == other.getModifiedOrderCount() &&
            ((this.orderSummaries==null && other.getOrderSummaries()==null) || 
             (this.orderSummaries!=null &&
              java.util.Arrays.equals(this.orderSummaries, other.getOrderSummaries())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getPartnerCode() != null) {
            _hashCode += getPartnerCode().hashCode();
        }
        _hashCode += getModifiedOrderCount();
        if (getOrderSummaries() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getOrderSummaries());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getOrderSummaries(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ModifiedPartnerOrder.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ModifiedPartnerOrder"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("partnerCode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "PartnerCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("modifiedOrderCount");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ModifiedOrderCount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderSummaries");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "OrderSummaries"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "OrderSummary"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "OrderSummary"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
