/**
 * Fulfillment.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.query;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class Fulfillment  implements java.io.Serializable {
    private com.geotrust.api.webtrust.query.CACertificate[] CACertificates;

    private java.lang.String serverCertificate;

    private java.lang.String iconScript;

    private java.lang.String certificate;

    private java.lang.String PKCS7;

    private java.lang.String PKCS12;

    private java.lang.String PKCS12EncryptedPassword;

    private java.lang.String sealUrl;

    public Fulfillment() {
    }

    public Fulfillment(
           com.geotrust.api.webtrust.query.CACertificate[] CACertificates,
           java.lang.String serverCertificate,
           java.lang.String iconScript,
           java.lang.String certificate,
           java.lang.String PKCS7,
           java.lang.String PKCS12,
           java.lang.String PKCS12EncryptedPassword,
           java.lang.String sealUrl) {
           this.CACertificates = CACertificates;
           this.serverCertificate = serverCertificate;
           this.iconScript = iconScript;
           this.certificate = certificate;
           this.PKCS7 = PKCS7;
           this.PKCS12 = PKCS12;
           this.PKCS12EncryptedPassword = PKCS12EncryptedPassword;
           this.sealUrl = sealUrl;
    }


    /**
     * Gets the CACertificates value for this Fulfillment.
     * 
     * @return CACertificates
     */
    public com.geotrust.api.webtrust.query.CACertificate[] getCACertificates() {
        return CACertificates;
    }


    /**
     * Sets the CACertificates value for this Fulfillment.
     * 
     * @param CACertificates
     */
    public void setCACertificates(com.geotrust.api.webtrust.query.CACertificate[] CACertificates) {
        this.CACertificates = CACertificates;
    }


    /**
     * Gets the serverCertificate value for this Fulfillment.
     * 
     * @return serverCertificate
     */
    public java.lang.String getServerCertificate() {
        return serverCertificate;
    }


    /**
     * Sets the serverCertificate value for this Fulfillment.
     * 
     * @param serverCertificate
     */
    public void setServerCertificate(java.lang.String serverCertificate) {
        this.serverCertificate = serverCertificate;
    }


    /**
     * Gets the iconScript value for this Fulfillment.
     * 
     * @return iconScript
     */
    public java.lang.String getIconScript() {
        return iconScript;
    }


    /**
     * Sets the iconScript value for this Fulfillment.
     * 
     * @param iconScript
     */
    public void setIconScript(java.lang.String iconScript) {
        this.iconScript = iconScript;
    }


    /**
     * Gets the certificate value for this Fulfillment.
     * 
     * @return certificate
     */
    public java.lang.String getCertificate() {
        return certificate;
    }


    /**
     * Sets the certificate value for this Fulfillment.
     * 
     * @param certificate
     */
    public void setCertificate(java.lang.String certificate) {
        this.certificate = certificate;
    }


    /**
     * Gets the PKCS7 value for this Fulfillment.
     * 
     * @return PKCS7
     */
    public java.lang.String getPKCS7() {
        return PKCS7;
    }


    /**
     * Sets the PKCS7 value for this Fulfillment.
     * 
     * @param PKCS7
     */
    public void setPKCS7(java.lang.String PKCS7) {
        this.PKCS7 = PKCS7;
    }


    /**
     * Gets the PKCS12 value for this Fulfillment.
     * 
     * @return PKCS12
     */
    public java.lang.String getPKCS12() {
        return PKCS12;
    }


    /**
     * Sets the PKCS12 value for this Fulfillment.
     * 
     * @param PKCS12
     */
    public void setPKCS12(java.lang.String PKCS12) {
        this.PKCS12 = PKCS12;
    }


    /**
     * Gets the PKCS12EncryptedPassword value for this Fulfillment.
     * 
     * @return PKCS12EncryptedPassword
     */
    public java.lang.String getPKCS12EncryptedPassword() {
        return PKCS12EncryptedPassword;
    }


    /**
     * Sets the PKCS12EncryptedPassword value for this Fulfillment.
     * 
     * @param PKCS12EncryptedPassword
     */
    public void setPKCS12EncryptedPassword(java.lang.String PKCS12EncryptedPassword) {
        this.PKCS12EncryptedPassword = PKCS12EncryptedPassword;
    }


    /**
     * Gets the sealUrl value for this Fulfillment.
     * 
     * @return sealUrl
     */
    public java.lang.String getSealUrl() {
        return sealUrl;
    }


    /**
     * Sets the sealUrl value for this Fulfillment.
     * 
     * @param sealUrl
     */
    public void setSealUrl(java.lang.String sealUrl) {
        this.sealUrl = sealUrl;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Fulfillment)) return false;
        Fulfillment other = (Fulfillment) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.CACertificates==null && other.getCACertificates()==null) || 
             (this.CACertificates!=null &&
              java.util.Arrays.equals(this.CACertificates, other.getCACertificates()))) &&
            ((this.serverCertificate==null && other.getServerCertificate()==null) || 
             (this.serverCertificate!=null &&
              this.serverCertificate.equals(other.getServerCertificate()))) &&
            ((this.iconScript==null && other.getIconScript()==null) || 
             (this.iconScript!=null &&
              this.iconScript.equals(other.getIconScript()))) &&
            ((this.certificate==null && other.getCertificate()==null) || 
             (this.certificate!=null &&
              this.certificate.equals(other.getCertificate()))) &&
            ((this.PKCS7==null && other.getPKCS7()==null) || 
             (this.PKCS7!=null &&
              this.PKCS7.equals(other.getPKCS7()))) &&
            ((this.PKCS12==null && other.getPKCS12()==null) || 
             (this.PKCS12!=null &&
              this.PKCS12.equals(other.getPKCS12()))) &&
            ((this.PKCS12EncryptedPassword==null && other.getPKCS12EncryptedPassword()==null) || 
             (this.PKCS12EncryptedPassword!=null &&
              this.PKCS12EncryptedPassword.equals(other.getPKCS12EncryptedPassword()))) &&
            ((this.sealUrl==null && other.getSealUrl()==null) || 
             (this.sealUrl!=null &&
              this.sealUrl.equals(other.getSealUrl())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCACertificates() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCACertificates());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCACertificates(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getServerCertificate() != null) {
            _hashCode += getServerCertificate().hashCode();
        }
        if (getIconScript() != null) {
            _hashCode += getIconScript().hashCode();
        }
        if (getCertificate() != null) {
            _hashCode += getCertificate().hashCode();
        }
        if (getPKCS7() != null) {
            _hashCode += getPKCS7().hashCode();
        }
        if (getPKCS12() != null) {
            _hashCode += getPKCS12().hashCode();
        }
        if (getPKCS12EncryptedPassword() != null) {
            _hashCode += getPKCS12EncryptedPassword().hashCode();
        }
        if (getSealUrl() != null) {
            _hashCode += getSealUrl().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Fulfillment.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "fulfillment"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CACertificates");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "CACertificates"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "CACertificate"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "CACertificate"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("serverCertificate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ServerCertificate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("iconScript");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "IconScript"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("certificate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "Certificate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("PKCS7");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "PKCS7"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("PKCS12");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "PKCS12"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("PKCS12EncryptedPassword");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "PKCS12EncryptedPassword"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sealUrl");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "SealUrl"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
