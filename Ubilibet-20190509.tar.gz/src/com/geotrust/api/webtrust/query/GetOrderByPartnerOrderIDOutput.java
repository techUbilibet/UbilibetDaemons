/**
 * GetOrderByPartnerOrderIDOutput.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.query;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class GetOrderByPartnerOrderIDOutput  implements java.io.Serializable {
    private com.geotrust.api.webtrust.query.QueryResponseHeader queryResponseHeader;

    private com.geotrust.api.webtrust.query.OrderDetail orderDetail;

    public GetOrderByPartnerOrderIDOutput() {
    }

    public GetOrderByPartnerOrderIDOutput(
           com.geotrust.api.webtrust.query.QueryResponseHeader queryResponseHeader,
           com.geotrust.api.webtrust.query.OrderDetail orderDetail) {
           this.queryResponseHeader = queryResponseHeader;
           this.orderDetail = orderDetail;
    }


    /**
     * Gets the queryResponseHeader value for this GetOrderByPartnerOrderIDOutput.
     * 
     * @return queryResponseHeader
     */
    public com.geotrust.api.webtrust.query.QueryResponseHeader getQueryResponseHeader() {
        return queryResponseHeader;
    }


    /**
     * Sets the queryResponseHeader value for this GetOrderByPartnerOrderIDOutput.
     * 
     * @param queryResponseHeader
     */
    public void setQueryResponseHeader(com.geotrust.api.webtrust.query.QueryResponseHeader queryResponseHeader) {
        this.queryResponseHeader = queryResponseHeader;
    }


    /**
     * Gets the orderDetail value for this GetOrderByPartnerOrderIDOutput.
     * 
     * @return orderDetail
     */
    public com.geotrust.api.webtrust.query.OrderDetail getOrderDetail() {
        return orderDetail;
    }


    /**
     * Sets the orderDetail value for this GetOrderByPartnerOrderIDOutput.
     * 
     * @param orderDetail
     */
    public void setOrderDetail(com.geotrust.api.webtrust.query.OrderDetail orderDetail) {
        this.orderDetail = orderDetail;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof GetOrderByPartnerOrderIDOutput)) return false;
        GetOrderByPartnerOrderIDOutput other = (GetOrderByPartnerOrderIDOutput) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.queryResponseHeader==null && other.getQueryResponseHeader()==null) || 
             (this.queryResponseHeader!=null &&
              this.queryResponseHeader.equals(other.getQueryResponseHeader()))) &&
            ((this.orderDetail==null && other.getOrderDetail()==null) || 
             (this.orderDetail!=null &&
              this.orderDetail.equals(other.getOrderDetail())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getQueryResponseHeader() != null) {
            _hashCode += getQueryResponseHeader().hashCode();
        }
        if (getOrderDetail() != null) {
            _hashCode += getOrderDetail().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(GetOrderByPartnerOrderIDOutput.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetOrderByPartnerOrderIDOutput"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("queryResponseHeader");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "QueryResponseHeader"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "queryResponseHeader"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderDetail");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "OrderDetail"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "OrderDetail"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
