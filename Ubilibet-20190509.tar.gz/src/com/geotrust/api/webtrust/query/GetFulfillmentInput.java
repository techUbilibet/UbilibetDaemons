/**
 * GetFulfillmentInput.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.query;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class GetFulfillmentInput  implements java.io.Serializable {
    private com.geotrust.api.webtrust.query.QueryRequestHeader queryRequestHeader;

    private java.lang.String partnerOrderID;

    private java.lang.Boolean returnCACerts;

    private java.lang.Boolean returnPKCS7Cert;

    private java.lang.Boolean returnIconScript;

    public GetFulfillmentInput() {
    }

    public GetFulfillmentInput(
           com.geotrust.api.webtrust.query.QueryRequestHeader queryRequestHeader,
           java.lang.String partnerOrderID,
           java.lang.Boolean returnCACerts,
           java.lang.Boolean returnPKCS7Cert,
           java.lang.Boolean returnIconScript) {
           this.queryRequestHeader = queryRequestHeader;
           this.partnerOrderID = partnerOrderID;
           this.returnCACerts = returnCACerts;
           this.returnPKCS7Cert = returnPKCS7Cert;
           this.returnIconScript = returnIconScript;
    }


    /**
     * Gets the queryRequestHeader value for this GetFulfillmentInput.
     * 
     * @return queryRequestHeader
     */
    public com.geotrust.api.webtrust.query.QueryRequestHeader getQueryRequestHeader() {
        return queryRequestHeader;
    }


    /**
     * Sets the queryRequestHeader value for this GetFulfillmentInput.
     * 
     * @param queryRequestHeader
     */
    public void setQueryRequestHeader(com.geotrust.api.webtrust.query.QueryRequestHeader queryRequestHeader) {
        this.queryRequestHeader = queryRequestHeader;
    }


    /**
     * Gets the partnerOrderID value for this GetFulfillmentInput.
     * 
     * @return partnerOrderID
     */
    public java.lang.String getPartnerOrderID() {
        return partnerOrderID;
    }


    /**
     * Sets the partnerOrderID value for this GetFulfillmentInput.
     * 
     * @param partnerOrderID
     */
    public void setPartnerOrderID(java.lang.String partnerOrderID) {
        this.partnerOrderID = partnerOrderID;
    }


    /**
     * Gets the returnCACerts value for this GetFulfillmentInput.
     * 
     * @return returnCACerts
     */
    public java.lang.Boolean getReturnCACerts() {
        return returnCACerts;
    }


    /**
     * Sets the returnCACerts value for this GetFulfillmentInput.
     * 
     * @param returnCACerts
     */
    public void setReturnCACerts(java.lang.Boolean returnCACerts) {
        this.returnCACerts = returnCACerts;
    }


    /**
     * Gets the returnPKCS7Cert value for this GetFulfillmentInput.
     * 
     * @return returnPKCS7Cert
     */
    public java.lang.Boolean getReturnPKCS7Cert() {
        return returnPKCS7Cert;
    }


    /**
     * Sets the returnPKCS7Cert value for this GetFulfillmentInput.
     * 
     * @param returnPKCS7Cert
     */
    public void setReturnPKCS7Cert(java.lang.Boolean returnPKCS7Cert) {
        this.returnPKCS7Cert = returnPKCS7Cert;
    }


    /**
     * Gets the returnIconScript value for this GetFulfillmentInput.
     * 
     * @return returnIconScript
     */
    public java.lang.Boolean getReturnIconScript() {
        return returnIconScript;
    }


    /**
     * Sets the returnIconScript value for this GetFulfillmentInput.
     * 
     * @param returnIconScript
     */
    public void setReturnIconScript(java.lang.Boolean returnIconScript) {
        this.returnIconScript = returnIconScript;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof GetFulfillmentInput)) return false;
        GetFulfillmentInput other = (GetFulfillmentInput) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.queryRequestHeader==null && other.getQueryRequestHeader()==null) || 
             (this.queryRequestHeader!=null &&
              this.queryRequestHeader.equals(other.getQueryRequestHeader()))) &&
            ((this.partnerOrderID==null && other.getPartnerOrderID()==null) || 
             (this.partnerOrderID!=null &&
              this.partnerOrderID.equals(other.getPartnerOrderID()))) &&
            ((this.returnCACerts==null && other.getReturnCACerts()==null) || 
             (this.returnCACerts!=null &&
              this.returnCACerts.equals(other.getReturnCACerts()))) &&
            ((this.returnPKCS7Cert==null && other.getReturnPKCS7Cert()==null) || 
             (this.returnPKCS7Cert!=null &&
              this.returnPKCS7Cert.equals(other.getReturnPKCS7Cert()))) &&
            ((this.returnIconScript==null && other.getReturnIconScript()==null) || 
             (this.returnIconScript!=null &&
              this.returnIconScript.equals(other.getReturnIconScript())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getQueryRequestHeader() != null) {
            _hashCode += getQueryRequestHeader().hashCode();
        }
        if (getPartnerOrderID() != null) {
            _hashCode += getPartnerOrderID().hashCode();
        }
        if (getReturnCACerts() != null) {
            _hashCode += getReturnCACerts().hashCode();
        }
        if (getReturnPKCS7Cert() != null) {
            _hashCode += getReturnPKCS7Cert().hashCode();
        }
        if (getReturnIconScript() != null) {
            _hashCode += getReturnIconScript().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(GetFulfillmentInput.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetFulfillmentInput"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("queryRequestHeader");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "QueryRequestHeader"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "queryRequestHeader"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("partnerOrderID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "PartnerOrderID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("returnCACerts");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ReturnCACerts"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("returnPKCS7Cert");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ReturnPKCS7Cert"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("returnIconScript");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ReturnIconScript"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
