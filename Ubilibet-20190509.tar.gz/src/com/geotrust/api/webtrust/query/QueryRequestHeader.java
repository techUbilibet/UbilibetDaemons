/**
 * QueryRequestHeader.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.query;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class QueryRequestHeader  implements java.io.Serializable {
    private java.lang.String apiVersion;

    private java.lang.String partnerCode;

    private com.geotrust.api.webtrust.query.AuthToken authToken;

    private java.lang.String replayToken;

    private java.lang.Boolean useReplayToken;

    public QueryRequestHeader() {
    }

    public QueryRequestHeader(
           java.lang.String apiVersion,
           java.lang.String partnerCode,
           com.geotrust.api.webtrust.query.AuthToken authToken,
           java.lang.String replayToken,
           java.lang.Boolean useReplayToken) {
           this.apiVersion = apiVersion;
           this.partnerCode = partnerCode;
           this.authToken = authToken;
           this.replayToken = replayToken;
           this.useReplayToken = useReplayToken;
    }


    /**
     * Gets the apiVersion value for this QueryRequestHeader.
     * 
     * @return apiVersion
     */
    public java.lang.String getApiVersion() {
        return apiVersion;
    }


    /**
     * Sets the apiVersion value for this QueryRequestHeader.
     * 
     * @param apiVersion
     */
    public void setApiVersion(java.lang.String apiVersion) {
        this.apiVersion = apiVersion;
    }


    /**
     * Gets the partnerCode value for this QueryRequestHeader.
     * 
     * @return partnerCode
     */
    public java.lang.String getPartnerCode() {
        return partnerCode;
    }


    /**
     * Sets the partnerCode value for this QueryRequestHeader.
     * 
     * @param partnerCode
     */
    public void setPartnerCode(java.lang.String partnerCode) {
        this.partnerCode = partnerCode;
    }


    /**
     * Gets the authToken value for this QueryRequestHeader.
     * 
     * @return authToken
     */
    public com.geotrust.api.webtrust.query.AuthToken getAuthToken() {
        return authToken;
    }


    /**
     * Sets the authToken value for this QueryRequestHeader.
     * 
     * @param authToken
     */
    public void setAuthToken(com.geotrust.api.webtrust.query.AuthToken authToken) {
        this.authToken = authToken;
    }


    /**
     * Gets the replayToken value for this QueryRequestHeader.
     * 
     * @return replayToken
     */
    public java.lang.String getReplayToken() {
        return replayToken;
    }


    /**
     * Sets the replayToken value for this QueryRequestHeader.
     * 
     * @param replayToken
     */
    public void setReplayToken(java.lang.String replayToken) {
        this.replayToken = replayToken;
    }


    /**
     * Gets the useReplayToken value for this QueryRequestHeader.
     * 
     * @return useReplayToken
     */
    public java.lang.Boolean getUseReplayToken() {
        return useReplayToken;
    }


    /**
     * Sets the useReplayToken value for this QueryRequestHeader.
     * 
     * @param useReplayToken
     */
    public void setUseReplayToken(java.lang.Boolean useReplayToken) {
        this.useReplayToken = useReplayToken;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof QueryRequestHeader)) return false;
        QueryRequestHeader other = (QueryRequestHeader) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.apiVersion==null && other.getApiVersion()==null) || 
             (this.apiVersion!=null &&
              this.apiVersion.equals(other.getApiVersion()))) &&
            ((this.partnerCode==null && other.getPartnerCode()==null) || 
             (this.partnerCode!=null &&
              this.partnerCode.equals(other.getPartnerCode()))) &&
            ((this.authToken==null && other.getAuthToken()==null) || 
             (this.authToken!=null &&
              this.authToken.equals(other.getAuthToken()))) &&
            ((this.replayToken==null && other.getReplayToken()==null) || 
             (this.replayToken!=null &&
              this.replayToken.equals(other.getReplayToken()))) &&
            ((this.useReplayToken==null && other.getUseReplayToken()==null) || 
             (this.useReplayToken!=null &&
              this.useReplayToken.equals(other.getUseReplayToken())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getApiVersion() != null) {
            _hashCode += getApiVersion().hashCode();
        }
        if (getPartnerCode() != null) {
            _hashCode += getPartnerCode().hashCode();
        }
        if (getAuthToken() != null) {
            _hashCode += getAuthToken().hashCode();
        }
        if (getReplayToken() != null) {
            _hashCode += getReplayToken().hashCode();
        }
        if (getUseReplayToken() != null) {
            _hashCode += getUseReplayToken().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(QueryRequestHeader.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "queryRequestHeader"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("apiVersion");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ApiVersion"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("partnerCode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "PartnerCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("authToken");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "AuthToken"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "authToken"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("replayToken");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ReplayToken"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("useReplayToken");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "UseReplayToken"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
