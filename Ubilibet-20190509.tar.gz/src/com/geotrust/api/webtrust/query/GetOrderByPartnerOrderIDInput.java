/**
 * GetOrderByPartnerOrderIDInput.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.query;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class GetOrderByPartnerOrderIDInput  implements java.io.Serializable {
    private com.geotrust.api.webtrust.query.QueryRequestHeader queryRequestHeader;

    private java.lang.String partnerOrderID;

    private com.geotrust.api.webtrust.query.OrderQueryOptions orderQueryOptions;

    public GetOrderByPartnerOrderIDInput() {
    }

    public GetOrderByPartnerOrderIDInput(
           com.geotrust.api.webtrust.query.QueryRequestHeader queryRequestHeader,
           java.lang.String partnerOrderID,
           com.geotrust.api.webtrust.query.OrderQueryOptions orderQueryOptions) {
           this.queryRequestHeader = queryRequestHeader;
           this.partnerOrderID = partnerOrderID;
           this.orderQueryOptions = orderQueryOptions;
    }


    /**
     * Gets the queryRequestHeader value for this GetOrderByPartnerOrderIDInput.
     * 
     * @return queryRequestHeader
     */
    public com.geotrust.api.webtrust.query.QueryRequestHeader getQueryRequestHeader() {
        return queryRequestHeader;
    }


    /**
     * Sets the queryRequestHeader value for this GetOrderByPartnerOrderIDInput.
     * 
     * @param queryRequestHeader
     */
    public void setQueryRequestHeader(com.geotrust.api.webtrust.query.QueryRequestHeader queryRequestHeader) {
        this.queryRequestHeader = queryRequestHeader;
    }


    /**
     * Gets the partnerOrderID value for this GetOrderByPartnerOrderIDInput.
     * 
     * @return partnerOrderID
     */
    public java.lang.String getPartnerOrderID() {
        return partnerOrderID;
    }


    /**
     * Sets the partnerOrderID value for this GetOrderByPartnerOrderIDInput.
     * 
     * @param partnerOrderID
     */
    public void setPartnerOrderID(java.lang.String partnerOrderID) {
        this.partnerOrderID = partnerOrderID;
    }


    /**
     * Gets the orderQueryOptions value for this GetOrderByPartnerOrderIDInput.
     * 
     * @return orderQueryOptions
     */
    public com.geotrust.api.webtrust.query.OrderQueryOptions getOrderQueryOptions() {
        return orderQueryOptions;
    }


    /**
     * Sets the orderQueryOptions value for this GetOrderByPartnerOrderIDInput.
     * 
     * @param orderQueryOptions
     */
    public void setOrderQueryOptions(com.geotrust.api.webtrust.query.OrderQueryOptions orderQueryOptions) {
        this.orderQueryOptions = orderQueryOptions;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof GetOrderByPartnerOrderIDInput)) return false;
        GetOrderByPartnerOrderIDInput other = (GetOrderByPartnerOrderIDInput) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.queryRequestHeader==null && other.getQueryRequestHeader()==null) || 
             (this.queryRequestHeader!=null &&
              this.queryRequestHeader.equals(other.getQueryRequestHeader()))) &&
            ((this.partnerOrderID==null && other.getPartnerOrderID()==null) || 
             (this.partnerOrderID!=null &&
              this.partnerOrderID.equals(other.getPartnerOrderID()))) &&
            ((this.orderQueryOptions==null && other.getOrderQueryOptions()==null) || 
             (this.orderQueryOptions!=null &&
              this.orderQueryOptions.equals(other.getOrderQueryOptions())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getQueryRequestHeader() != null) {
            _hashCode += getQueryRequestHeader().hashCode();
        }
        if (getPartnerOrderID() != null) {
            _hashCode += getPartnerOrderID().hashCode();
        }
        if (getOrderQueryOptions() != null) {
            _hashCode += getOrderQueryOptions().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(GetOrderByPartnerOrderIDInput.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetOrderByPartnerOrderIDInput"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("queryRequestHeader");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "QueryRequestHeader"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "queryRequestHeader"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("partnerOrderID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "PartnerOrderID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderQueryOptions");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "OrderQueryOptions"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "orderQueryOptions"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
