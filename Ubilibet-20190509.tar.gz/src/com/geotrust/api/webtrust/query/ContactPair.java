/**
 * ContactPair.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.query;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class ContactPair  implements java.io.Serializable {
    private com.geotrust.api.webtrust.query.Contact adminContact;

    private com.geotrust.api.webtrust.query.Contact techContact;

    private java.lang.String contactType;

    public ContactPair() {
    }

    public ContactPair(
           com.geotrust.api.webtrust.query.Contact adminContact,
           com.geotrust.api.webtrust.query.Contact techContact,
           java.lang.String contactType) {
           this.adminContact = adminContact;
           this.techContact = techContact;
           this.contactType = contactType;
    }


    /**
     * Gets the adminContact value for this ContactPair.
     * 
     * @return adminContact
     */
    public com.geotrust.api.webtrust.query.Contact getAdminContact() {
        return adminContact;
    }


    /**
     * Sets the adminContact value for this ContactPair.
     * 
     * @param adminContact
     */
    public void setAdminContact(com.geotrust.api.webtrust.query.Contact adminContact) {
        this.adminContact = adminContact;
    }


    /**
     * Gets the techContact value for this ContactPair.
     * 
     * @return techContact
     */
    public com.geotrust.api.webtrust.query.Contact getTechContact() {
        return techContact;
    }


    /**
     * Sets the techContact value for this ContactPair.
     * 
     * @param techContact
     */
    public void setTechContact(com.geotrust.api.webtrust.query.Contact techContact) {
        this.techContact = techContact;
    }


    /**
     * Gets the contactType value for this ContactPair.
     * 
     * @return contactType
     */
    public java.lang.String getContactType() {
        return contactType;
    }


    /**
     * Sets the contactType value for this ContactPair.
     * 
     * @param contactType
     */
    public void setContactType(java.lang.String contactType) {
        this.contactType = contactType;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ContactPair)) return false;
        ContactPair other = (ContactPair) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.adminContact==null && other.getAdminContact()==null) || 
             (this.adminContact!=null &&
              this.adminContact.equals(other.getAdminContact()))) &&
            ((this.techContact==null && other.getTechContact()==null) || 
             (this.techContact!=null &&
              this.techContact.equals(other.getTechContact()))) &&
            ((this.contactType==null && other.getContactType()==null) || 
             (this.contactType!=null &&
              this.contactType.equals(other.getContactType())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getAdminContact() != null) {
            _hashCode += getAdminContact().hashCode();
        }
        if (getTechContact() != null) {
            _hashCode += getTechContact().hashCode();
        }
        if (getContactType() != null) {
            _hashCode += getContactType().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ContactPair.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ContactPair"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("adminContact");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "AdminContact"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "Contact"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("techContact");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "TechContact"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "Contact"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contactType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ContactType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
