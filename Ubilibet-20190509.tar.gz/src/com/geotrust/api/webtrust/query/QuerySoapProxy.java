package com.geotrust.api.webtrust.query;


public class QuerySoapProxy implements com.geotrust.api.webtrust.query.QuerySoap {
  private String _endpoint = null;
  private com.geotrust.api.webtrust.query.QuerySoap querySoap = null;
  
  public QuerySoapProxy() {
    _initQuerySoapProxy();
  }
  
  public QuerySoapProxy(String endpoint) {
    _endpoint = endpoint;
    _initQuerySoapProxy();
  }
  
  private void _initQuerySoapProxy() {
    try {
      querySoap = (new com.geotrust.api.webtrust.query.QueryLocator()).getquerySoap();
      if (querySoap != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)querySoap)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)querySoap)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (querySoap != null)
      ((javax.xml.rpc.Stub)querySoap)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.geotrust.api.webtrust.query.QuerySoap getQuerySoap() {
    if (querySoap == null)
      _initQuerySoapProxy();
    return querySoap;
  }
  
  public com.geotrust.api.webtrust.query.GetFulfillmentOutput getFulfillment(com.geotrust.api.webtrust.query.GetFulfillmentInput request) throws java.rmi.RemoteException{
    if (querySoap == null)
      _initQuerySoapProxy();
    return querySoap.getFulfillment(request);
  }
  
  public com.geotrust.api.webtrust.query.GetModifiedPreAuthOrderSummaryOutput getModifiedPreAuthOrderSummary(com.geotrust.api.webtrust.query.GetModifiedPreAuthOrderSummaryInput request) throws java.rmi.RemoteException{
    if (querySoap == null)
      _initQuerySoapProxy();
    return querySoap.getModifiedPreAuthOrderSummary(request);
  }
  
  public com.geotrust.api.webtrust.query.CheckStatusOutput checkStatus(com.geotrust.api.webtrust.query.CheckStatusInput request) throws java.rmi.RemoteException{
    if (querySoap == null)
      _initQuerySoapProxy();
    return querySoap.checkStatus(request);
  }
  
  public com.geotrust.api.webtrust.query.GetModifiedOrderSummaryOutput getModifiedOrderSummary(com.geotrust.api.webtrust.query.GetModifiedOrderSummaryInput request) throws java.rmi.RemoteException{
    if (querySoap == null)
      _initQuerySoapProxy();
    return querySoap.getModifiedOrderSummary(request);
  }
  
  public com.geotrust.api.webtrust.query.GetPreAuthOrderByPartnerOrderIDOutput getPreAuthOrderByPartnerOrderID(com.geotrust.api.webtrust.query.GetPreAuthOrderByPartnerOrderIDInput authQueryRequest) throws java.rmi.RemoteException{
    if (querySoap == null)
      _initQuerySoapProxy();
    return querySoap.getPreAuthOrderByPartnerOrderID(authQueryRequest);
  }
  
  public com.geotrust.api.webtrust.query.GetModifiedOrdersOutput getModifiedOrders(com.geotrust.api.webtrust.query.GetModifiedOrdersInput request) throws java.rmi.RemoteException{
    if (querySoap == null)
      _initQuerySoapProxy();
    return querySoap.getModifiedOrders(request);
  }
  
  public com.geotrust.api.webtrust.query.GetUserAgreementOutput getUserAgreement(com.geotrust.api.webtrust.query.GetUserAgreementInput request) throws java.rmi.RemoteException{
    if (querySoap == null)
      _initQuerySoapProxy();
    return querySoap.getUserAgreement(request);
  }
  
  public com.geotrust.api.webtrust.query.GetOrderByPartnerOrderIDOutput getOrderByGTOrderID(com.geotrust.api.webtrust.query.GetOrderByGTOrderIDInput request) throws java.rmi.RemoteException{
    if (querySoap == null)
      _initQuerySoapProxy();
    return querySoap.getOrderByGTOrderID(request);
  }
  
  public com.geotrust.api.webtrust.query.GetOrdersByDateRangeOutput getOrdersByDateRange(com.geotrust.api.webtrust.query.GetOrdersByDateRangeInput request) throws java.rmi.RemoteException{
    if (querySoap == null)
      _initQuerySoapProxy();
    return querySoap.getOrdersByDateRange(request);
  }
  
  public com.geotrust.api.webtrust.query.GetOrderByPartnerOrderIDOutput getOrderByPartnerOrderID(com.geotrust.api.webtrust.query.GetOrderByPartnerOrderIDInput request) throws java.rmi.RemoteException{
    if (querySoap == null)
      _initQuerySoapProxy();
    return querySoap.getOrderByPartnerOrderID(request);
  }
  
  public java.lang.String hello(java.lang.String input) throws java.rmi.RemoteException{
    if (querySoap == null)
      _initQuerySoapProxy();
    return querySoap.hello(input);
  }
  
  public com.geotrust.api.webtrust.query.GetPreAuthOrdersByDateRangeOutput getPreAuthOrdersByDateRange(com.geotrust.api.webtrust.query.GetPreAuthOrdersByDataRangeInput authQueryRequest) throws java.rmi.RemoteException{
    if (querySoap == null)
      _initQuerySoapProxy();
    return querySoap.getPreAuthOrdersByDateRange(authQueryRequest);
  }
  
  public com.geotrust.api.webtrust.query.ParseCSROutput parseCSR(com.geotrust.api.webtrust.query.ParseCSRInput request) throws java.rmi.RemoteException{
    if (querySoap == null)
      _initQuerySoapProxy();
    return querySoap.parseCSR(request);
  }
  
  public com.geotrust.api.webtrust.query.GetQuickApproverListOutput getQuickApproverList(com.geotrust.api.webtrust.query.GetQuickApproverListInput request) throws java.rmi.RemoteException{
    if (querySoap == null)
      _initQuerySoapProxy();
    return querySoap.getQuickApproverList(request);
  }
  
  
}