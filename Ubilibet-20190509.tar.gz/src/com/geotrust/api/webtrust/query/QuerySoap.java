/**
 * QuerySoap.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.query;


public interface QuerySoap extends java.rmi.Remote {
    public com.geotrust.api.webtrust.query.GetFulfillmentOutput getFulfillment(com.geotrust.api.webtrust.query.GetFulfillmentInput request) throws java.rmi.RemoteException;
    public com.geotrust.api.webtrust.query.GetModifiedPreAuthOrderSummaryOutput getModifiedPreAuthOrderSummary(com.geotrust.api.webtrust.query.GetModifiedPreAuthOrderSummaryInput request) throws java.rmi.RemoteException;
    public com.geotrust.api.webtrust.query.CheckStatusOutput checkStatus(com.geotrust.api.webtrust.query.CheckStatusInput request) throws java.rmi.RemoteException;
    public com.geotrust.api.webtrust.query.GetModifiedOrderSummaryOutput getModifiedOrderSummary(com.geotrust.api.webtrust.query.GetModifiedOrderSummaryInput request) throws java.rmi.RemoteException;
    public com.geotrust.api.webtrust.query.GetPreAuthOrderByPartnerOrderIDOutput getPreAuthOrderByPartnerOrderID(com.geotrust.api.webtrust.query.GetPreAuthOrderByPartnerOrderIDInput authQueryRequest) throws java.rmi.RemoteException;
    public com.geotrust.api.webtrust.query.GetModifiedOrdersOutput getModifiedOrders(com.geotrust.api.webtrust.query.GetModifiedOrdersInput request) throws java.rmi.RemoteException;
    public com.geotrust.api.webtrust.query.GetUserAgreementOutput getUserAgreement(com.geotrust.api.webtrust.query.GetUserAgreementInput request) throws java.rmi.RemoteException;
    public com.geotrust.api.webtrust.query.GetOrderByPartnerOrderIDOutput getOrderByGTOrderID(com.geotrust.api.webtrust.query.GetOrderByGTOrderIDInput request) throws java.rmi.RemoteException;
    public com.geotrust.api.webtrust.query.GetOrdersByDateRangeOutput getOrdersByDateRange(com.geotrust.api.webtrust.query.GetOrdersByDateRangeInput request) throws java.rmi.RemoteException;
    public com.geotrust.api.webtrust.query.GetOrderByPartnerOrderIDOutput getOrderByPartnerOrderID(com.geotrust.api.webtrust.query.GetOrderByPartnerOrderIDInput request) throws java.rmi.RemoteException;
    public java.lang.String hello(java.lang.String input) throws java.rmi.RemoteException;
    public com.geotrust.api.webtrust.query.GetPreAuthOrdersByDateRangeOutput getPreAuthOrdersByDateRange(com.geotrust.api.webtrust.query.GetPreAuthOrdersByDataRangeInput authQueryRequest) throws java.rmi.RemoteException;
    public com.geotrust.api.webtrust.query.ParseCSROutput parseCSR(com.geotrust.api.webtrust.query.ParseCSRInput request) throws java.rmi.RemoteException;
    public com.geotrust.api.webtrust.query.GetQuickApproverListOutput getQuickApproverList(com.geotrust.api.webtrust.query.GetQuickApproverListInput request) throws java.rmi.RemoteException;
}
