/**
 * GetPreAuthOrdersByDateRangeOutput.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.query;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class GetPreAuthOrdersByDateRangeOutput  implements java.io.Serializable {
    private com.geotrust.api.webtrust.query.QueryResponseHeader authQueryResponseHeader;

    private java.util.Calendar fromDate;

    private java.util.Calendar toDate;

    private com.geotrust.api.webtrust.query.OrganizationAuthStatus organizationAuthStatus;

    private com.geotrust.api.webtrust.query.AuthOrderDataStatus[] authOrderDataStatuses;

    public GetPreAuthOrdersByDateRangeOutput() {
    }

    public GetPreAuthOrdersByDateRangeOutput(
           com.geotrust.api.webtrust.query.QueryResponseHeader authQueryResponseHeader,
           java.util.Calendar fromDate,
           java.util.Calendar toDate,
           com.geotrust.api.webtrust.query.OrganizationAuthStatus organizationAuthStatus,
           com.geotrust.api.webtrust.query.AuthOrderDataStatus[] authOrderDataStatuses) {
           this.authQueryResponseHeader = authQueryResponseHeader;
           this.fromDate = fromDate;
           this.toDate = toDate;
           this.organizationAuthStatus = organizationAuthStatus;
           this.authOrderDataStatuses = authOrderDataStatuses;
    }


    /**
     * Gets the authQueryResponseHeader value for this GetPreAuthOrdersByDateRangeOutput.
     * 
     * @return authQueryResponseHeader
     */
    public com.geotrust.api.webtrust.query.QueryResponseHeader getAuthQueryResponseHeader() {
        return authQueryResponseHeader;
    }


    /**
     * Sets the authQueryResponseHeader value for this GetPreAuthOrdersByDateRangeOutput.
     * 
     * @param authQueryResponseHeader
     */
    public void setAuthQueryResponseHeader(com.geotrust.api.webtrust.query.QueryResponseHeader authQueryResponseHeader) {
        this.authQueryResponseHeader = authQueryResponseHeader;
    }


    /**
     * Gets the fromDate value for this GetPreAuthOrdersByDateRangeOutput.
     * 
     * @return fromDate
     */
    public java.util.Calendar getFromDate() {
        return fromDate;
    }


    /**
     * Sets the fromDate value for this GetPreAuthOrdersByDateRangeOutput.
     * 
     * @param fromDate
     */
    public void setFromDate(java.util.Calendar fromDate) {
        this.fromDate = fromDate;
    }


    /**
     * Gets the toDate value for this GetPreAuthOrdersByDateRangeOutput.
     * 
     * @return toDate
     */
    public java.util.Calendar getToDate() {
        return toDate;
    }


    /**
     * Sets the toDate value for this GetPreAuthOrdersByDateRangeOutput.
     * 
     * @param toDate
     */
    public void setToDate(java.util.Calendar toDate) {
        this.toDate = toDate;
    }


    /**
     * Gets the organizationAuthStatus value for this GetPreAuthOrdersByDateRangeOutput.
     * 
     * @return organizationAuthStatus
     */
    public com.geotrust.api.webtrust.query.OrganizationAuthStatus getOrganizationAuthStatus() {
        return organizationAuthStatus;
    }


    /**
     * Sets the organizationAuthStatus value for this GetPreAuthOrdersByDateRangeOutput.
     * 
     * @param organizationAuthStatus
     */
    public void setOrganizationAuthStatus(com.geotrust.api.webtrust.query.OrganizationAuthStatus organizationAuthStatus) {
        this.organizationAuthStatus = organizationAuthStatus;
    }


    /**
     * Gets the authOrderDataStatuses value for this GetPreAuthOrdersByDateRangeOutput.
     * 
     * @return authOrderDataStatuses
     */
    public com.geotrust.api.webtrust.query.AuthOrderDataStatus[] getAuthOrderDataStatuses() {
        return authOrderDataStatuses;
    }


    /**
     * Sets the authOrderDataStatuses value for this GetPreAuthOrdersByDateRangeOutput.
     * 
     * @param authOrderDataStatuses
     */
    public void setAuthOrderDataStatuses(com.geotrust.api.webtrust.query.AuthOrderDataStatus[] authOrderDataStatuses) {
        this.authOrderDataStatuses = authOrderDataStatuses;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof GetPreAuthOrdersByDateRangeOutput)) return false;
        GetPreAuthOrdersByDateRangeOutput other = (GetPreAuthOrdersByDateRangeOutput) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.authQueryResponseHeader==null && other.getAuthQueryResponseHeader()==null) || 
             (this.authQueryResponseHeader!=null &&
              this.authQueryResponseHeader.equals(other.getAuthQueryResponseHeader()))) &&
            ((this.fromDate==null && other.getFromDate()==null) || 
             (this.fromDate!=null &&
              this.fromDate.equals(other.getFromDate()))) &&
            ((this.toDate==null && other.getToDate()==null) || 
             (this.toDate!=null &&
              this.toDate.equals(other.getToDate()))) &&
            ((this.organizationAuthStatus==null && other.getOrganizationAuthStatus()==null) || 
             (this.organizationAuthStatus!=null &&
              this.organizationAuthStatus.equals(other.getOrganizationAuthStatus()))) &&
            ((this.authOrderDataStatuses==null && other.getAuthOrderDataStatuses()==null) || 
             (this.authOrderDataStatuses!=null &&
              java.util.Arrays.equals(this.authOrderDataStatuses, other.getAuthOrderDataStatuses())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getAuthQueryResponseHeader() != null) {
            _hashCode += getAuthQueryResponseHeader().hashCode();
        }
        if (getFromDate() != null) {
            _hashCode += getFromDate().hashCode();
        }
        if (getToDate() != null) {
            _hashCode += getToDate().hashCode();
        }
        if (getOrganizationAuthStatus() != null) {
            _hashCode += getOrganizationAuthStatus().hashCode();
        }
        if (getAuthOrderDataStatuses() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getAuthOrderDataStatuses());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getAuthOrderDataStatuses(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(GetPreAuthOrdersByDateRangeOutput.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetPreAuthOrdersByDateRangeOutput"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("authQueryResponseHeader");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "AuthQueryResponseHeader"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "queryResponseHeader"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fromDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "FromDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("toDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "ToDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("organizationAuthStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "OrganizationAuthStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "OrganizationAuthStatus"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("authOrderDataStatuses");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "AuthOrderDataStatuses"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "AuthOrderDataStatus"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "AuthOrderDataStatus"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
