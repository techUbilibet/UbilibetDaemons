/**
 * GetPreAuthOrdersByDataRangeInput.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.query;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class GetPreAuthOrdersByDataRangeInput  implements java.io.Serializable {
    private com.geotrust.api.webtrust.query.QueryRequestHeader queryRequestHeader;

    private com.geotrust.api.webtrust.query.AuthQueryParameters queryParameters;

    public GetPreAuthOrdersByDataRangeInput() {
    }

    public GetPreAuthOrdersByDataRangeInput(
           com.geotrust.api.webtrust.query.QueryRequestHeader queryRequestHeader,
           com.geotrust.api.webtrust.query.AuthQueryParameters queryParameters) {
           this.queryRequestHeader = queryRequestHeader;
           this.queryParameters = queryParameters;
    }


    /**
     * Gets the queryRequestHeader value for this GetPreAuthOrdersByDataRangeInput.
     * 
     * @return queryRequestHeader
     */
    public com.geotrust.api.webtrust.query.QueryRequestHeader getQueryRequestHeader() {
        return queryRequestHeader;
    }


    /**
     * Sets the queryRequestHeader value for this GetPreAuthOrdersByDataRangeInput.
     * 
     * @param queryRequestHeader
     */
    public void setQueryRequestHeader(com.geotrust.api.webtrust.query.QueryRequestHeader queryRequestHeader) {
        this.queryRequestHeader = queryRequestHeader;
    }


    /**
     * Gets the queryParameters value for this GetPreAuthOrdersByDataRangeInput.
     * 
     * @return queryParameters
     */
    public com.geotrust.api.webtrust.query.AuthQueryParameters getQueryParameters() {
        return queryParameters;
    }


    /**
     * Sets the queryParameters value for this GetPreAuthOrdersByDataRangeInput.
     * 
     * @param queryParameters
     */
    public void setQueryParameters(com.geotrust.api.webtrust.query.AuthQueryParameters queryParameters) {
        this.queryParameters = queryParameters;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof GetPreAuthOrdersByDataRangeInput)) return false;
        GetPreAuthOrdersByDataRangeInput other = (GetPreAuthOrdersByDataRangeInput) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.queryRequestHeader==null && other.getQueryRequestHeader()==null) || 
             (this.queryRequestHeader!=null &&
              this.queryRequestHeader.equals(other.getQueryRequestHeader()))) &&
            ((this.queryParameters==null && other.getQueryParameters()==null) || 
             (this.queryParameters!=null &&
              this.queryParameters.equals(other.getQueryParameters())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getQueryRequestHeader() != null) {
            _hashCode += getQueryRequestHeader().hashCode();
        }
        if (getQueryParameters() != null) {
            _hashCode += getQueryParameters().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(GetPreAuthOrdersByDataRangeInput.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetPreAuthOrdersByDataRangeInput"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("queryRequestHeader");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "QueryRequestHeader"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "queryRequestHeader"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("queryParameters");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "QueryParameters"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "AuthQueryParameters"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
