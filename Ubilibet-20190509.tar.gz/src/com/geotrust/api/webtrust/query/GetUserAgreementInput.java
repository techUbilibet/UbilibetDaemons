/**
 * GetUserAgreementInput.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.query;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class GetUserAgreementInput  implements java.io.Serializable {
    private com.geotrust.api.webtrust.query.QueryRequestHeader queryRequestHeader;

    private java.lang.String userAgreementProductCode;

    private java.lang.String agreementType;

    public GetUserAgreementInput() {
    }

    public GetUserAgreementInput(
           com.geotrust.api.webtrust.query.QueryRequestHeader queryRequestHeader,
           java.lang.String userAgreementProductCode,
           java.lang.String agreementType) {
           this.queryRequestHeader = queryRequestHeader;
           this.userAgreementProductCode = userAgreementProductCode;
           this.agreementType = agreementType;
    }


    /**
     * Gets the queryRequestHeader value for this GetUserAgreementInput.
     * 
     * @return queryRequestHeader
     */
    public com.geotrust.api.webtrust.query.QueryRequestHeader getQueryRequestHeader() {
        return queryRequestHeader;
    }


    /**
     * Sets the queryRequestHeader value for this GetUserAgreementInput.
     * 
     * @param queryRequestHeader
     */
    public void setQueryRequestHeader(com.geotrust.api.webtrust.query.QueryRequestHeader queryRequestHeader) {
        this.queryRequestHeader = queryRequestHeader;
    }


    /**
     * Gets the userAgreementProductCode value for this GetUserAgreementInput.
     * 
     * @return userAgreementProductCode
     */
    public java.lang.String getUserAgreementProductCode() {
        return userAgreementProductCode;
    }


    /**
     * Sets the userAgreementProductCode value for this GetUserAgreementInput.
     * 
     * @param userAgreementProductCode
     */
    public void setUserAgreementProductCode(java.lang.String userAgreementProductCode) {
        this.userAgreementProductCode = userAgreementProductCode;
    }


    /**
     * Gets the agreementType value for this GetUserAgreementInput.
     * 
     * @return agreementType
     */
    public java.lang.String getAgreementType() {
        return agreementType;
    }


    /**
     * Sets the agreementType value for this GetUserAgreementInput.
     * 
     * @param agreementType
     */
    public void setAgreementType(java.lang.String agreementType) {
        this.agreementType = agreementType;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof GetUserAgreementInput)) return false;
        GetUserAgreementInput other = (GetUserAgreementInput) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.queryRequestHeader==null && other.getQueryRequestHeader()==null) || 
             (this.queryRequestHeader!=null &&
              this.queryRequestHeader.equals(other.getQueryRequestHeader()))) &&
            ((this.userAgreementProductCode==null && other.getUserAgreementProductCode()==null) || 
             (this.userAgreementProductCode!=null &&
              this.userAgreementProductCode.equals(other.getUserAgreementProductCode()))) &&
            ((this.agreementType==null && other.getAgreementType()==null) || 
             (this.agreementType!=null &&
              this.agreementType.equals(other.getAgreementType())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getQueryRequestHeader() != null) {
            _hashCode += getQueryRequestHeader().hashCode();
        }
        if (getUserAgreementProductCode() != null) {
            _hashCode += getUserAgreementProductCode().hashCode();
        }
        if (getAgreementType() != null) {
            _hashCode += getAgreementType().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(GetUserAgreementInput.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "GetUserAgreementInput"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("queryRequestHeader");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "QueryRequestHeader"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "queryRequestHeader"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("userAgreementProductCode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "UserAgreementProductCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("agreementType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/query", "AgreementType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
