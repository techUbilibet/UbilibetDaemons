/**
 * QuickPaymentsOrderInfo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.order;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class QuickPaymentsOrderInfo  implements java.io.Serializable {
    private java.lang.String processor;

    private boolean merchantAccount;

    private java.lang.String supportOption;

    public QuickPaymentsOrderInfo() {
    }

    public QuickPaymentsOrderInfo(
           java.lang.String processor,
           boolean merchantAccount,
           java.lang.String supportOption) {
           this.processor = processor;
           this.merchantAccount = merchantAccount;
           this.supportOption = supportOption;
    }


    /**
     * Gets the processor value for this QuickPaymentsOrderInfo.
     * 
     * @return processor
     */
    public java.lang.String getProcessor() {
        return processor;
    }


    /**
     * Sets the processor value for this QuickPaymentsOrderInfo.
     * 
     * @param processor
     */
    public void setProcessor(java.lang.String processor) {
        this.processor = processor;
    }


    /**
     * Gets the merchantAccount value for this QuickPaymentsOrderInfo.
     * 
     * @return merchantAccount
     */
    public boolean isMerchantAccount() {
        return merchantAccount;
    }


    /**
     * Sets the merchantAccount value for this QuickPaymentsOrderInfo.
     * 
     * @param merchantAccount
     */
    public void setMerchantAccount(boolean merchantAccount) {
        this.merchantAccount = merchantAccount;
    }


    /**
     * Gets the supportOption value for this QuickPaymentsOrderInfo.
     * 
     * @return supportOption
     */
    public java.lang.String getSupportOption() {
        return supportOption;
    }


    /**
     * Sets the supportOption value for this QuickPaymentsOrderInfo.
     * 
     * @param supportOption
     */
    public void setSupportOption(java.lang.String supportOption) {
        this.supportOption = supportOption;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof QuickPaymentsOrderInfo)) return false;
        QuickPaymentsOrderInfo other = (QuickPaymentsOrderInfo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.processor==null && other.getProcessor()==null) || 
             (this.processor!=null &&
              this.processor.equals(other.getProcessor()))) &&
            this.merchantAccount == other.isMerchantAccount() &&
            ((this.supportOption==null && other.getSupportOption()==null) || 
             (this.supportOption!=null &&
              this.supportOption.equals(other.getSupportOption())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getProcessor() != null) {
            _hashCode += getProcessor().hashCode();
        }
        _hashCode += (isMerchantAccount() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getSupportOption() != null) {
            _hashCode += getSupportOption().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(QuickPaymentsOrderInfo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "quickPaymentsOrderInfo"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processor");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Processor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("merchantAccount");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "MerchantAccount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("supportOption");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "SupportOption"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
