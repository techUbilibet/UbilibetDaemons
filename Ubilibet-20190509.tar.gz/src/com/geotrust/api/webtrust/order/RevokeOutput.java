/**
 * RevokeOutput.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.order;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class RevokeOutput  implements java.io.Serializable {
    private com.geotrust.api.webtrust.order.OrderResponseHeader orderResponseHeader;

    private java.lang.Integer geoTrustOrderID;

    private java.lang.String serialNumber;

    private java.lang.String revokeStatus;

    private java.lang.String DNSEntry;

    public RevokeOutput() {
    }

    public RevokeOutput(
           com.geotrust.api.webtrust.order.OrderResponseHeader orderResponseHeader,
           java.lang.Integer geoTrustOrderID,
           java.lang.String serialNumber,
           java.lang.String revokeStatus,
           java.lang.String DNSEntry) {
           this.orderResponseHeader = orderResponseHeader;
           this.geoTrustOrderID = geoTrustOrderID;
           this.serialNumber = serialNumber;
           this.revokeStatus = revokeStatus;
           this.DNSEntry = DNSEntry;
    }


    /**
     * Gets the orderResponseHeader value for this RevokeOutput.
     * 
     * @return orderResponseHeader
     */
    public com.geotrust.api.webtrust.order.OrderResponseHeader getOrderResponseHeader() {
        return orderResponseHeader;
    }


    /**
     * Sets the orderResponseHeader value for this RevokeOutput.
     * 
     * @param orderResponseHeader
     */
    public void setOrderResponseHeader(com.geotrust.api.webtrust.order.OrderResponseHeader orderResponseHeader) {
        this.orderResponseHeader = orderResponseHeader;
    }


    /**
     * Gets the geoTrustOrderID value for this RevokeOutput.
     * 
     * @return geoTrustOrderID
     */
    public java.lang.Integer getGeoTrustOrderID() {
        return geoTrustOrderID;
    }


    /**
     * Sets the geoTrustOrderID value for this RevokeOutput.
     * 
     * @param geoTrustOrderID
     */
    public void setGeoTrustOrderID(java.lang.Integer geoTrustOrderID) {
        this.geoTrustOrderID = geoTrustOrderID;
    }


    /**
     * Gets the serialNumber value for this RevokeOutput.
     * 
     * @return serialNumber
     */
    public java.lang.String getSerialNumber() {
        return serialNumber;
    }


    /**
     * Sets the serialNumber value for this RevokeOutput.
     * 
     * @param serialNumber
     */
    public void setSerialNumber(java.lang.String serialNumber) {
        this.serialNumber = serialNumber;
    }


    /**
     * Gets the revokeStatus value for this RevokeOutput.
     * 
     * @return revokeStatus
     */
    public java.lang.String getRevokeStatus() {
        return revokeStatus;
    }


    /**
     * Sets the revokeStatus value for this RevokeOutput.
     * 
     * @param revokeStatus
     */
    public void setRevokeStatus(java.lang.String revokeStatus) {
        this.revokeStatus = revokeStatus;
    }


    /**
     * Gets the DNSEntry value for this RevokeOutput.
     * 
     * @return DNSEntry
     */
    public java.lang.String getDNSEntry() {
        return DNSEntry;
    }


    /**
     * Sets the DNSEntry value for this RevokeOutput.
     * 
     * @param DNSEntry
     */
    public void setDNSEntry(java.lang.String DNSEntry) {
        this.DNSEntry = DNSEntry;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof RevokeOutput)) return false;
        RevokeOutput other = (RevokeOutput) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.orderResponseHeader==null && other.getOrderResponseHeader()==null) || 
             (this.orderResponseHeader!=null &&
              this.orderResponseHeader.equals(other.getOrderResponseHeader()))) &&
            ((this.geoTrustOrderID==null && other.getGeoTrustOrderID()==null) || 
             (this.geoTrustOrderID!=null &&
              this.geoTrustOrderID.equals(other.getGeoTrustOrderID()))) &&
            ((this.serialNumber==null && other.getSerialNumber()==null) || 
             (this.serialNumber!=null &&
              this.serialNumber.equals(other.getSerialNumber()))) &&
            ((this.revokeStatus==null && other.getRevokeStatus()==null) || 
             (this.revokeStatus!=null &&
              this.revokeStatus.equals(other.getRevokeStatus()))) &&
            ((this.DNSEntry==null && other.getDNSEntry()==null) || 
             (this.DNSEntry!=null &&
              this.DNSEntry.equals(other.getDNSEntry())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getOrderResponseHeader() != null) {
            _hashCode += getOrderResponseHeader().hashCode();
        }
        if (getGeoTrustOrderID() != null) {
            _hashCode += getGeoTrustOrderID().hashCode();
        }
        if (getSerialNumber() != null) {
            _hashCode += getSerialNumber().hashCode();
        }
        if (getRevokeStatus() != null) {
            _hashCode += getRevokeStatus().hashCode();
        }
        if (getDNSEntry() != null) {
            _hashCode += getDNSEntry().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(RevokeOutput.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "RevokeOutput"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderResponseHeader");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "OrderResponseHeader"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "orderResponseHeader"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("geoTrustOrderID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "GeoTrustOrderID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("serialNumber");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "SerialNumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("revokeStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "RevokeStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DNSEntry");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "DNSEntry"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
