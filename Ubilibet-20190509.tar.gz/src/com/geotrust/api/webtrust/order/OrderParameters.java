/**
 * OrderParameters.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.order;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class OrderParameters  implements java.io.Serializable {
    private java.lang.String method;

    private java.lang.String contractID;

    private java.lang.Integer validityPeriod;

    private java.lang.Integer serverCount;

    private java.lang.String CSR;

    private java.lang.String signatureHashAlgorithm;

    private java.lang.String webServerType;

    private java.lang.Boolean wildCard;

    private java.lang.Boolean CUIndicator;

    private java.lang.String CUCertificate;

    private java.lang.String DNSNames;

    private java.lang.Boolean renewalIndicator;

    private java.lang.String renewalBehavior;

    private java.lang.String specialInstructions;

    private java.lang.String emailLanguageCode;

    private java.lang.Boolean reissuanceInsuranceIndicator;

    private java.lang.Boolean installationSupportIndicator;

    private java.lang.String domainName;

    private java.lang.Integer chainKeySize;

    private java.lang.String certificateType;

    private java.lang.String CSCertType;

    private java.lang.String originalPartnerOrderID;

    private java.lang.Boolean approvalIndicator;

    private java.lang.String discountType;

    private java.lang.Boolean wstepIndicator;

    private java.lang.String wstepUsername;

    private java.lang.String wstepPassword;

    private java.lang.Integer usageHours;

    private java.util.Calendar usageFromDate;

    private java.util.Calendar usageToDate;

    private java.lang.Boolean usageBillingIndicator;

    private java.lang.String sealPreference;

    private java.lang.Boolean trialIndicator;

    private java.lang.Boolean fileAuthDVIndicator;

    private java.lang.String DVAuthMethod;

    private com.geotrust.api.webtrust.order.VulnerabilityScanPreferences vulnerabilityScanPreferences;

    private com.geotrust.api.webtrust.order.CertTransparency certTransparency;

    private com.geotrust.api.webtrust.order.CPUpgradeParameters CPUpgradeParameters;

    public OrderParameters() {
    }

    public OrderParameters(
           java.lang.String method,
           java.lang.String contractID,
           java.lang.Integer validityPeriod,
           java.lang.Integer serverCount,
           java.lang.String CSR,
           java.lang.String signatureHashAlgorithm,
           java.lang.String webServerType,
           java.lang.Boolean wildCard,
           java.lang.Boolean CUIndicator,
           java.lang.String CUCertificate,
           java.lang.String DNSNames,
           java.lang.Boolean renewalIndicator,
           java.lang.String renewalBehavior,
           java.lang.String specialInstructions,
           java.lang.String emailLanguageCode,
           java.lang.Boolean reissuanceInsuranceIndicator,
           java.lang.Boolean installationSupportIndicator,
           java.lang.String domainName,
           java.lang.Integer chainKeySize,
           java.lang.String certificateType,
           java.lang.String CSCertType,
           java.lang.String originalPartnerOrderID,
           java.lang.Boolean approvalIndicator,
           java.lang.String discountType,
           java.lang.Boolean wstepIndicator,
           java.lang.String wstepUsername,
           java.lang.String wstepPassword,
           java.lang.Integer usageHours,
           java.util.Calendar usageFromDate,
           java.util.Calendar usageToDate,
           java.lang.Boolean usageBillingIndicator,
           java.lang.String sealPreference,
           java.lang.Boolean trialIndicator,
           java.lang.Boolean fileAuthDVIndicator,
           java.lang.String DVAuthMethod,
           com.geotrust.api.webtrust.order.VulnerabilityScanPreferences vulnerabilityScanPreferences,
           com.geotrust.api.webtrust.order.CertTransparency certTransparency,
           com.geotrust.api.webtrust.order.CPUpgradeParameters CPUpgradeParameters) {
           this.method = method;
           this.contractID = contractID;
           this.validityPeriod = validityPeriod;
           this.serverCount = serverCount;
           this.CSR = CSR;
           this.signatureHashAlgorithm = signatureHashAlgorithm;
           this.webServerType = webServerType;
           this.wildCard = wildCard;
           this.CUIndicator = CUIndicator;
           this.CUCertificate = CUCertificate;
           this.DNSNames = DNSNames;
           this.renewalIndicator = renewalIndicator;
           this.renewalBehavior = renewalBehavior;
           this.specialInstructions = specialInstructions;
           this.emailLanguageCode = emailLanguageCode;
           this.reissuanceInsuranceIndicator = reissuanceInsuranceIndicator;
           this.installationSupportIndicator = installationSupportIndicator;
           this.domainName = domainName;
           this.chainKeySize = chainKeySize;
           this.certificateType = certificateType;
           this.CSCertType = CSCertType;
           this.originalPartnerOrderID = originalPartnerOrderID;
           this.approvalIndicator = approvalIndicator;
           this.discountType = discountType;
           this.wstepIndicator = wstepIndicator;
           this.wstepUsername = wstepUsername;
           this.wstepPassword = wstepPassword;
           this.usageHours = usageHours;
           this.usageFromDate = usageFromDate;
           this.usageToDate = usageToDate;
           this.usageBillingIndicator = usageBillingIndicator;
           this.sealPreference = sealPreference;
           this.trialIndicator = trialIndicator;
           this.fileAuthDVIndicator = fileAuthDVIndicator;
           this.DVAuthMethod = DVAuthMethod;
           this.vulnerabilityScanPreferences = vulnerabilityScanPreferences;
           this.certTransparency = certTransparency;
           this.CPUpgradeParameters = CPUpgradeParameters;
    }


    /**
     * Gets the method value for this OrderParameters.
     * 
     * @return method
     */
    public java.lang.String getMethod() {
        return method;
    }


    /**
     * Sets the method value for this OrderParameters.
     * 
     * @param method
     */
    public void setMethod(java.lang.String method) {
        this.method = method;
    }


    /**
     * Gets the contractID value for this OrderParameters.
     * 
     * @return contractID
     */
    public java.lang.String getContractID() {
        return contractID;
    }


    /**
     * Sets the contractID value for this OrderParameters.
     * 
     * @param contractID
     */
    public void setContractID(java.lang.String contractID) {
        this.contractID = contractID;
    }


    /**
     * Gets the validityPeriod value for this OrderParameters.
     * 
     * @return validityPeriod
     */
    public java.lang.Integer getValidityPeriod() {
        return validityPeriod;
    }


    /**
     * Sets the validityPeriod value for this OrderParameters.
     * 
     * @param validityPeriod
     */
    public void setValidityPeriod(java.lang.Integer validityPeriod) {
        this.validityPeriod = validityPeriod;
    }


    /**
     * Gets the serverCount value for this OrderParameters.
     * 
     * @return serverCount
     */
    public java.lang.Integer getServerCount() {
        return serverCount;
    }


    /**
     * Sets the serverCount value for this OrderParameters.
     * 
     * @param serverCount
     */
    public void setServerCount(java.lang.Integer serverCount) {
        this.serverCount = serverCount;
    }


    /**
     * Gets the CSR value for this OrderParameters.
     * 
     * @return CSR
     */
    public java.lang.String getCSR() {
        return CSR;
    }


    /**
     * Sets the CSR value for this OrderParameters.
     * 
     * @param CSR
     */
    public void setCSR(java.lang.String CSR) {
        this.CSR = CSR;
    }


    /**
     * Gets the signatureHashAlgorithm value for this OrderParameters.
     * 
     * @return signatureHashAlgorithm
     */
    public java.lang.String getSignatureHashAlgorithm() {
        return signatureHashAlgorithm;
    }


    /**
     * Sets the signatureHashAlgorithm value for this OrderParameters.
     * 
     * @param signatureHashAlgorithm
     */
    public void setSignatureHashAlgorithm(java.lang.String signatureHashAlgorithm) {
        this.signatureHashAlgorithm = signatureHashAlgorithm;
    }


    /**
     * Gets the webServerType value for this OrderParameters.
     * 
     * @return webServerType
     */
    public java.lang.String getWebServerType() {
        return webServerType;
    }


    /**
     * Sets the webServerType value for this OrderParameters.
     * 
     * @param webServerType
     */
    public void setWebServerType(java.lang.String webServerType) {
        this.webServerType = webServerType;
    }


    /**
     * Gets the wildCard value for this OrderParameters.
     * 
     * @return wildCard
     */
    public java.lang.Boolean getWildCard() {
        return wildCard;
    }


    /**
     * Sets the wildCard value for this OrderParameters.
     * 
     * @param wildCard
     */
    public void setWildCard(java.lang.Boolean wildCard) {
        this.wildCard = wildCard;
    }


    /**
     * Gets the CUIndicator value for this OrderParameters.
     * 
     * @return CUIndicator
     */
    public java.lang.Boolean getCUIndicator() {
        return CUIndicator;
    }


    /**
     * Sets the CUIndicator value for this OrderParameters.
     * 
     * @param CUIndicator
     */
    public void setCUIndicator(java.lang.Boolean CUIndicator) {
        this.CUIndicator = CUIndicator;
    }


    /**
     * Gets the CUCertificate value for this OrderParameters.
     * 
     * @return CUCertificate
     */
    public java.lang.String getCUCertificate() {
        return CUCertificate;
    }


    /**
     * Sets the CUCertificate value for this OrderParameters.
     * 
     * @param CUCertificate
     */
    public void setCUCertificate(java.lang.String CUCertificate) {
        this.CUCertificate = CUCertificate;
    }


    /**
     * Gets the DNSNames value for this OrderParameters.
     * 
     * @return DNSNames
     */
    public java.lang.String getDNSNames() {
        return DNSNames;
    }


    /**
     * Sets the DNSNames value for this OrderParameters.
     * 
     * @param DNSNames
     */
    public void setDNSNames(java.lang.String DNSNames) {
        this.DNSNames = DNSNames;
    }


    /**
     * Gets the renewalIndicator value for this OrderParameters.
     * 
     * @return renewalIndicator
     */
    public java.lang.Boolean getRenewalIndicator() {
        return renewalIndicator;
    }


    /**
     * Sets the renewalIndicator value for this OrderParameters.
     * 
     * @param renewalIndicator
     */
    public void setRenewalIndicator(java.lang.Boolean renewalIndicator) {
        this.renewalIndicator = renewalIndicator;
    }


    /**
     * Gets the renewalBehavior value for this OrderParameters.
     * 
     * @return renewalBehavior
     */
    public java.lang.String getRenewalBehavior() {
        return renewalBehavior;
    }


    /**
     * Sets the renewalBehavior value for this OrderParameters.
     * 
     * @param renewalBehavior
     */
    public void setRenewalBehavior(java.lang.String renewalBehavior) {
        this.renewalBehavior = renewalBehavior;
    }


    /**
     * Gets the specialInstructions value for this OrderParameters.
     * 
     * @return specialInstructions
     */
    public java.lang.String getSpecialInstructions() {
        return specialInstructions;
    }


    /**
     * Sets the specialInstructions value for this OrderParameters.
     * 
     * @param specialInstructions
     */
    public void setSpecialInstructions(java.lang.String specialInstructions) {
        this.specialInstructions = specialInstructions;
    }


    /**
     * Gets the emailLanguageCode value for this OrderParameters.
     * 
     * @return emailLanguageCode
     */
    public java.lang.String getEmailLanguageCode() {
        return emailLanguageCode;
    }


    /**
     * Sets the emailLanguageCode value for this OrderParameters.
     * 
     * @param emailLanguageCode
     */
    public void setEmailLanguageCode(java.lang.String emailLanguageCode) {
        this.emailLanguageCode = emailLanguageCode;
    }


    /**
     * Gets the reissuanceInsuranceIndicator value for this OrderParameters.
     * 
     * @return reissuanceInsuranceIndicator
     */
    public java.lang.Boolean getReissuanceInsuranceIndicator() {
        return reissuanceInsuranceIndicator;
    }


    /**
     * Sets the reissuanceInsuranceIndicator value for this OrderParameters.
     * 
     * @param reissuanceInsuranceIndicator
     */
    public void setReissuanceInsuranceIndicator(java.lang.Boolean reissuanceInsuranceIndicator) {
        this.reissuanceInsuranceIndicator = reissuanceInsuranceIndicator;
    }


    /**
     * Gets the installationSupportIndicator value for this OrderParameters.
     * 
     * @return installationSupportIndicator
     */
    public java.lang.Boolean getInstallationSupportIndicator() {
        return installationSupportIndicator;
    }


    /**
     * Sets the installationSupportIndicator value for this OrderParameters.
     * 
     * @param installationSupportIndicator
     */
    public void setInstallationSupportIndicator(java.lang.Boolean installationSupportIndicator) {
        this.installationSupportIndicator = installationSupportIndicator;
    }


    /**
     * Gets the domainName value for this OrderParameters.
     * 
     * @return domainName
     */
    public java.lang.String getDomainName() {
        return domainName;
    }


    /**
     * Sets the domainName value for this OrderParameters.
     * 
     * @param domainName
     */
    public void setDomainName(java.lang.String domainName) {
        this.domainName = domainName;
    }


    /**
     * Gets the chainKeySize value for this OrderParameters.
     * 
     * @return chainKeySize
     */
    public java.lang.Integer getChainKeySize() {
        return chainKeySize;
    }


    /**
     * Sets the chainKeySize value for this OrderParameters.
     * 
     * @param chainKeySize
     */
    public void setChainKeySize(java.lang.Integer chainKeySize) {
        this.chainKeySize = chainKeySize;
    }


    /**
     * Gets the certificateType value for this OrderParameters.
     * 
     * @return certificateType
     */
    public java.lang.String getCertificateType() {
        return certificateType;
    }


    /**
     * Sets the certificateType value for this OrderParameters.
     * 
     * @param certificateType
     */
    public void setCertificateType(java.lang.String certificateType) {
        this.certificateType = certificateType;
    }


    /**
     * Gets the CSCertType value for this OrderParameters.
     * 
     * @return CSCertType
     */
    public java.lang.String getCSCertType() {
        return CSCertType;
    }


    /**
     * Sets the CSCertType value for this OrderParameters.
     * 
     * @param CSCertType
     */
    public void setCSCertType(java.lang.String CSCertType) {
        this.CSCertType = CSCertType;
    }


    /**
     * Gets the originalPartnerOrderID value for this OrderParameters.
     * 
     * @return originalPartnerOrderID
     */
    public java.lang.String getOriginalPartnerOrderID() {
        return originalPartnerOrderID;
    }


    /**
     * Sets the originalPartnerOrderID value for this OrderParameters.
     * 
     * @param originalPartnerOrderID
     */
    public void setOriginalPartnerOrderID(java.lang.String originalPartnerOrderID) {
        this.originalPartnerOrderID = originalPartnerOrderID;
    }


    /**
     * Gets the approvalIndicator value for this OrderParameters.
     * 
     * @return approvalIndicator
     */
    public java.lang.Boolean getApprovalIndicator() {
        return approvalIndicator;
    }


    /**
     * Sets the approvalIndicator value for this OrderParameters.
     * 
     * @param approvalIndicator
     */
    public void setApprovalIndicator(java.lang.Boolean approvalIndicator) {
        this.approvalIndicator = approvalIndicator;
    }


    /**
     * Gets the discountType value for this OrderParameters.
     * 
     * @return discountType
     */
    public java.lang.String getDiscountType() {
        return discountType;
    }


    /**
     * Sets the discountType value for this OrderParameters.
     * 
     * @param discountType
     */
    public void setDiscountType(java.lang.String discountType) {
        this.discountType = discountType;
    }


    /**
     * Gets the wstepIndicator value for this OrderParameters.
     * 
     * @return wstepIndicator
     */
    public java.lang.Boolean getWstepIndicator() {
        return wstepIndicator;
    }


    /**
     * Sets the wstepIndicator value for this OrderParameters.
     * 
     * @param wstepIndicator
     */
    public void setWstepIndicator(java.lang.Boolean wstepIndicator) {
        this.wstepIndicator = wstepIndicator;
    }


    /**
     * Gets the wstepUsername value for this OrderParameters.
     * 
     * @return wstepUsername
     */
    public java.lang.String getWstepUsername() {
        return wstepUsername;
    }


    /**
     * Sets the wstepUsername value for this OrderParameters.
     * 
     * @param wstepUsername
     */
    public void setWstepUsername(java.lang.String wstepUsername) {
        this.wstepUsername = wstepUsername;
    }


    /**
     * Gets the wstepPassword value for this OrderParameters.
     * 
     * @return wstepPassword
     */
    public java.lang.String getWstepPassword() {
        return wstepPassword;
    }


    /**
     * Sets the wstepPassword value for this OrderParameters.
     * 
     * @param wstepPassword
     */
    public void setWstepPassword(java.lang.String wstepPassword) {
        this.wstepPassword = wstepPassword;
    }


    /**
     * Gets the usageHours value for this OrderParameters.
     * 
     * @return usageHours
     */
    public java.lang.Integer getUsageHours() {
        return usageHours;
    }


    /**
     * Sets the usageHours value for this OrderParameters.
     * 
     * @param usageHours
     */
    public void setUsageHours(java.lang.Integer usageHours) {
        this.usageHours = usageHours;
    }


    /**
     * Gets the usageFromDate value for this OrderParameters.
     * 
     * @return usageFromDate
     */
    public java.util.Calendar getUsageFromDate() {
        return usageFromDate;
    }


    /**
     * Sets the usageFromDate value for this OrderParameters.
     * 
     * @param usageFromDate
     */
    public void setUsageFromDate(java.util.Calendar usageFromDate) {
        this.usageFromDate = usageFromDate;
    }


    /**
     * Gets the usageToDate value for this OrderParameters.
     * 
     * @return usageToDate
     */
    public java.util.Calendar getUsageToDate() {
        return usageToDate;
    }


    /**
     * Sets the usageToDate value for this OrderParameters.
     * 
     * @param usageToDate
     */
    public void setUsageToDate(java.util.Calendar usageToDate) {
        this.usageToDate = usageToDate;
    }


    /**
     * Gets the usageBillingIndicator value for this OrderParameters.
     * 
     * @return usageBillingIndicator
     */
    public java.lang.Boolean getUsageBillingIndicator() {
        return usageBillingIndicator;
    }


    /**
     * Sets the usageBillingIndicator value for this OrderParameters.
     * 
     * @param usageBillingIndicator
     */
    public void setUsageBillingIndicator(java.lang.Boolean usageBillingIndicator) {
        this.usageBillingIndicator = usageBillingIndicator;
    }


    /**
     * Gets the sealPreference value for this OrderParameters.
     * 
     * @return sealPreference
     */
    public java.lang.String getSealPreference() {
        return sealPreference;
    }


    /**
     * Sets the sealPreference value for this OrderParameters.
     * 
     * @param sealPreference
     */
    public void setSealPreference(java.lang.String sealPreference) {
        this.sealPreference = sealPreference;
    }


    /**
     * Gets the trialIndicator value for this OrderParameters.
     * 
     * @return trialIndicator
     */
    public java.lang.Boolean getTrialIndicator() {
        return trialIndicator;
    }


    /**
     * Sets the trialIndicator value for this OrderParameters.
     * 
     * @param trialIndicator
     */
    public void setTrialIndicator(java.lang.Boolean trialIndicator) {
        this.trialIndicator = trialIndicator;
    }


    /**
     * Gets the fileAuthDVIndicator value for this OrderParameters.
     * 
     * @return fileAuthDVIndicator
     */
    public java.lang.Boolean getFileAuthDVIndicator() {
        return fileAuthDVIndicator;
    }


    /**
     * Sets the fileAuthDVIndicator value for this OrderParameters.
     * 
     * @param fileAuthDVIndicator
     */
    public void setFileAuthDVIndicator(java.lang.Boolean fileAuthDVIndicator) {
        this.fileAuthDVIndicator = fileAuthDVIndicator;
    }


    /**
     * Gets the DVAuthMethod value for this OrderParameters.
     * 
     * @return DVAuthMethod
     */
    public java.lang.String getDVAuthMethod() {
        return DVAuthMethod;
    }


    /**
     * Sets the DVAuthMethod value for this OrderParameters.
     * 
     * @param DVAuthMethod
     */
    public void setDVAuthMethod(java.lang.String DVAuthMethod) {
        this.DVAuthMethod = DVAuthMethod;
    }


    /**
     * Gets the vulnerabilityScanPreferences value for this OrderParameters.
     * 
     * @return vulnerabilityScanPreferences
     */
    public com.geotrust.api.webtrust.order.VulnerabilityScanPreferences getVulnerabilityScanPreferences() {
        return vulnerabilityScanPreferences;
    }


    /**
     * Sets the vulnerabilityScanPreferences value for this OrderParameters.
     * 
     * @param vulnerabilityScanPreferences
     */
    public void setVulnerabilityScanPreferences(com.geotrust.api.webtrust.order.VulnerabilityScanPreferences vulnerabilityScanPreferences) {
        this.vulnerabilityScanPreferences = vulnerabilityScanPreferences;
    }


    /**
     * Gets the certTransparency value for this OrderParameters.
     * 
     * @return certTransparency
     */
    public com.geotrust.api.webtrust.order.CertTransparency getCertTransparency() {
        return certTransparency;
    }


    /**
     * Sets the certTransparency value for this OrderParameters.
     * 
     * @param certTransparency
     */
    public void setCertTransparency(com.geotrust.api.webtrust.order.CertTransparency certTransparency) {
        this.certTransparency = certTransparency;
    }


    /**
     * Gets the CPUpgradeParameters value for this OrderParameters.
     * 
     * @return CPUpgradeParameters
     */
    public com.geotrust.api.webtrust.order.CPUpgradeParameters getCPUpgradeParameters() {
        return CPUpgradeParameters;
    }


    /**
     * Sets the CPUpgradeParameters value for this OrderParameters.
     * 
     * @param CPUpgradeParameters
     */
    public void setCPUpgradeParameters(com.geotrust.api.webtrust.order.CPUpgradeParameters CPUpgradeParameters) {
        this.CPUpgradeParameters = CPUpgradeParameters;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof OrderParameters)) return false;
        OrderParameters other = (OrderParameters) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.method==null && other.getMethod()==null) || 
             (this.method!=null &&
              this.method.equals(other.getMethod()))) &&
            ((this.contractID==null && other.getContractID()==null) || 
             (this.contractID!=null &&
              this.contractID.equals(other.getContractID()))) &&
            ((this.validityPeriod==null && other.getValidityPeriod()==null) || 
             (this.validityPeriod!=null &&
              this.validityPeriod.equals(other.getValidityPeriod()))) &&
            ((this.serverCount==null && other.getServerCount()==null) || 
             (this.serverCount!=null &&
              this.serverCount.equals(other.getServerCount()))) &&
            ((this.CSR==null && other.getCSR()==null) || 
             (this.CSR!=null &&
              this.CSR.equals(other.getCSR()))) &&
            ((this.signatureHashAlgorithm==null && other.getSignatureHashAlgorithm()==null) || 
             (this.signatureHashAlgorithm!=null &&
              this.signatureHashAlgorithm.equals(other.getSignatureHashAlgorithm()))) &&
            ((this.webServerType==null && other.getWebServerType()==null) || 
             (this.webServerType!=null &&
              this.webServerType.equals(other.getWebServerType()))) &&
            ((this.wildCard==null && other.getWildCard()==null) || 
             (this.wildCard!=null &&
              this.wildCard.equals(other.getWildCard()))) &&
            ((this.CUIndicator==null && other.getCUIndicator()==null) || 
             (this.CUIndicator!=null &&
              this.CUIndicator.equals(other.getCUIndicator()))) &&
            ((this.CUCertificate==null && other.getCUCertificate()==null) || 
             (this.CUCertificate!=null &&
              this.CUCertificate.equals(other.getCUCertificate()))) &&
            ((this.DNSNames==null && other.getDNSNames()==null) || 
             (this.DNSNames!=null &&
              this.DNSNames.equals(other.getDNSNames()))) &&
            ((this.renewalIndicator==null && other.getRenewalIndicator()==null) || 
             (this.renewalIndicator!=null &&
              this.renewalIndicator.equals(other.getRenewalIndicator()))) &&
            ((this.renewalBehavior==null && other.getRenewalBehavior()==null) || 
             (this.renewalBehavior!=null &&
              this.renewalBehavior.equals(other.getRenewalBehavior()))) &&
            ((this.specialInstructions==null && other.getSpecialInstructions()==null) || 
             (this.specialInstructions!=null &&
              this.specialInstructions.equals(other.getSpecialInstructions()))) &&
            ((this.emailLanguageCode==null && other.getEmailLanguageCode()==null) || 
             (this.emailLanguageCode!=null &&
              this.emailLanguageCode.equals(other.getEmailLanguageCode()))) &&
            ((this.reissuanceInsuranceIndicator==null && other.getReissuanceInsuranceIndicator()==null) || 
             (this.reissuanceInsuranceIndicator!=null &&
              this.reissuanceInsuranceIndicator.equals(other.getReissuanceInsuranceIndicator()))) &&
            ((this.installationSupportIndicator==null && other.getInstallationSupportIndicator()==null) || 
             (this.installationSupportIndicator!=null &&
              this.installationSupportIndicator.equals(other.getInstallationSupportIndicator()))) &&
            ((this.domainName==null && other.getDomainName()==null) || 
             (this.domainName!=null &&
              this.domainName.equals(other.getDomainName()))) &&
            ((this.chainKeySize==null && other.getChainKeySize()==null) || 
             (this.chainKeySize!=null &&
              this.chainKeySize.equals(other.getChainKeySize()))) &&
            ((this.certificateType==null && other.getCertificateType()==null) || 
             (this.certificateType!=null &&
              this.certificateType.equals(other.getCertificateType()))) &&
            ((this.CSCertType==null && other.getCSCertType()==null) || 
             (this.CSCertType!=null &&
              this.CSCertType.equals(other.getCSCertType()))) &&
            ((this.originalPartnerOrderID==null && other.getOriginalPartnerOrderID()==null) || 
             (this.originalPartnerOrderID!=null &&
              this.originalPartnerOrderID.equals(other.getOriginalPartnerOrderID()))) &&
            ((this.approvalIndicator==null && other.getApprovalIndicator()==null) || 
             (this.approvalIndicator!=null &&
              this.approvalIndicator.equals(other.getApprovalIndicator()))) &&
            ((this.discountType==null && other.getDiscountType()==null) || 
             (this.discountType!=null &&
              this.discountType.equals(other.getDiscountType()))) &&
            ((this.wstepIndicator==null && other.getWstepIndicator()==null) || 
             (this.wstepIndicator!=null &&
              this.wstepIndicator.equals(other.getWstepIndicator()))) &&
            ((this.wstepUsername==null && other.getWstepUsername()==null) || 
             (this.wstepUsername!=null &&
              this.wstepUsername.equals(other.getWstepUsername()))) &&
            ((this.wstepPassword==null && other.getWstepPassword()==null) || 
             (this.wstepPassword!=null &&
              this.wstepPassword.equals(other.getWstepPassword()))) &&
            ((this.usageHours==null && other.getUsageHours()==null) || 
             (this.usageHours!=null &&
              this.usageHours.equals(other.getUsageHours()))) &&
            ((this.usageFromDate==null && other.getUsageFromDate()==null) || 
             (this.usageFromDate!=null &&
              this.usageFromDate.equals(other.getUsageFromDate()))) &&
            ((this.usageToDate==null && other.getUsageToDate()==null) || 
             (this.usageToDate!=null &&
              this.usageToDate.equals(other.getUsageToDate()))) &&
            ((this.usageBillingIndicator==null && other.getUsageBillingIndicator()==null) || 
             (this.usageBillingIndicator!=null &&
              this.usageBillingIndicator.equals(other.getUsageBillingIndicator()))) &&
            ((this.sealPreference==null && other.getSealPreference()==null) || 
             (this.sealPreference!=null &&
              this.sealPreference.equals(other.getSealPreference()))) &&
            ((this.trialIndicator==null && other.getTrialIndicator()==null) || 
             (this.trialIndicator!=null &&
              this.trialIndicator.equals(other.getTrialIndicator()))) &&
            ((this.fileAuthDVIndicator==null && other.getFileAuthDVIndicator()==null) || 
             (this.fileAuthDVIndicator!=null &&
              this.fileAuthDVIndicator.equals(other.getFileAuthDVIndicator()))) &&
            ((this.DVAuthMethod==null && other.getDVAuthMethod()==null) || 
             (this.DVAuthMethod!=null &&
              this.DVAuthMethod.equals(other.getDVAuthMethod()))) &&
            ((this.vulnerabilityScanPreferences==null && other.getVulnerabilityScanPreferences()==null) || 
             (this.vulnerabilityScanPreferences!=null &&
              this.vulnerabilityScanPreferences.equals(other.getVulnerabilityScanPreferences()))) &&
            ((this.certTransparency==null && other.getCertTransparency()==null) || 
             (this.certTransparency!=null &&
              this.certTransparency.equals(other.getCertTransparency()))) &&
            ((this.CPUpgradeParameters==null && other.getCPUpgradeParameters()==null) || 
             (this.CPUpgradeParameters!=null &&
              this.CPUpgradeParameters.equals(other.getCPUpgradeParameters())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getMethod() != null) {
            _hashCode += getMethod().hashCode();
        }
        if (getContractID() != null) {
            _hashCode += getContractID().hashCode();
        }
        if (getValidityPeriod() != null) {
            _hashCode += getValidityPeriod().hashCode();
        }
        if (getServerCount() != null) {
            _hashCode += getServerCount().hashCode();
        }
        if (getCSR() != null) {
            _hashCode += getCSR().hashCode();
        }
        if (getSignatureHashAlgorithm() != null) {
            _hashCode += getSignatureHashAlgorithm().hashCode();
        }
        if (getWebServerType() != null) {
            _hashCode += getWebServerType().hashCode();
        }
        if (getWildCard() != null) {
            _hashCode += getWildCard().hashCode();
        }
        if (getCUIndicator() != null) {
            _hashCode += getCUIndicator().hashCode();
        }
        if (getCUCertificate() != null) {
            _hashCode += getCUCertificate().hashCode();
        }
        if (getDNSNames() != null) {
            _hashCode += getDNSNames().hashCode();
        }
        if (getRenewalIndicator() != null) {
            _hashCode += getRenewalIndicator().hashCode();
        }
        if (getRenewalBehavior() != null) {
            _hashCode += getRenewalBehavior().hashCode();
        }
        if (getSpecialInstructions() != null) {
            _hashCode += getSpecialInstructions().hashCode();
        }
        if (getEmailLanguageCode() != null) {
            _hashCode += getEmailLanguageCode().hashCode();
        }
        if (getReissuanceInsuranceIndicator() != null) {
            _hashCode += getReissuanceInsuranceIndicator().hashCode();
        }
        if (getInstallationSupportIndicator() != null) {
            _hashCode += getInstallationSupportIndicator().hashCode();
        }
        if (getDomainName() != null) {
            _hashCode += getDomainName().hashCode();
        }
        if (getChainKeySize() != null) {
            _hashCode += getChainKeySize().hashCode();
        }
        if (getCertificateType() != null) {
            _hashCode += getCertificateType().hashCode();
        }
        if (getCSCertType() != null) {
            _hashCode += getCSCertType().hashCode();
        }
        if (getOriginalPartnerOrderID() != null) {
            _hashCode += getOriginalPartnerOrderID().hashCode();
        }
        if (getApprovalIndicator() != null) {
            _hashCode += getApprovalIndicator().hashCode();
        }
        if (getDiscountType() != null) {
            _hashCode += getDiscountType().hashCode();
        }
        if (getWstepIndicator() != null) {
            _hashCode += getWstepIndicator().hashCode();
        }
        if (getWstepUsername() != null) {
            _hashCode += getWstepUsername().hashCode();
        }
        if (getWstepPassword() != null) {
            _hashCode += getWstepPassword().hashCode();
        }
        if (getUsageHours() != null) {
            _hashCode += getUsageHours().hashCode();
        }
        if (getUsageFromDate() != null) {
            _hashCode += getUsageFromDate().hashCode();
        }
        if (getUsageToDate() != null) {
            _hashCode += getUsageToDate().hashCode();
        }
        if (getUsageBillingIndicator() != null) {
            _hashCode += getUsageBillingIndicator().hashCode();
        }
        if (getSealPreference() != null) {
            _hashCode += getSealPreference().hashCode();
        }
        if (getTrialIndicator() != null) {
            _hashCode += getTrialIndicator().hashCode();
        }
        if (getFileAuthDVIndicator() != null) {
            _hashCode += getFileAuthDVIndicator().hashCode();
        }
        if (getDVAuthMethod() != null) {
            _hashCode += getDVAuthMethod().hashCode();
        }
        if (getVulnerabilityScanPreferences() != null) {
            _hashCode += getVulnerabilityScanPreferences().hashCode();
        }
        if (getCertTransparency() != null) {
            _hashCode += getCertTransparency().hashCode();
        }
        if (getCPUpgradeParameters() != null) {
            _hashCode += getCPUpgradeParameters().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(OrderParameters.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "orderParameters"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("method");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Method"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contractID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ContractID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("validityPeriod");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ValidityPeriod"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("serverCount");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ServerCount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CSR");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "CSR"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("signatureHashAlgorithm");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "SignatureHashAlgorithm"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("webServerType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "WebServerType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wildCard");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "WildCard"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CUIndicator");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "CUIndicator"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CUCertificate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "CUCertificate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DNSNames");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "DNSNames"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("renewalIndicator");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "RenewalIndicator"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("renewalBehavior");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "RenewalBehavior"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("specialInstructions");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "SpecialInstructions"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("emailLanguageCode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "EmailLanguageCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("reissuanceInsuranceIndicator");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ReissuanceInsuranceIndicator"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("installationSupportIndicator");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "InstallationSupportIndicator"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("domainName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "DomainName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("chainKeySize");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ChainKeySize"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("certificateType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "CertificateType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CSCertType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "CSCertType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("originalPartnerOrderID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "OriginalPartnerOrderID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("approvalIndicator");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ApprovalIndicator"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("discountType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "DiscountType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wstepIndicator");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "WstepIndicator"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wstepUsername");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "WstepUsername"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wstepPassword");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "WstepPassword"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("usageHours");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "UsageHours"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("usageFromDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "UsageFromDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("usageToDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "UsageToDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("usageBillingIndicator");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "UsageBillingIndicator"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sealPreference");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "SealPreference"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("trialIndicator");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "TrialIndicator"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fileAuthDVIndicator");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "FileAuthDVIndicator"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DVAuthMethod");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "DVAuthMethod"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("vulnerabilityScanPreferences");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "VulnerabilityScanPreferences"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "vulnerabilityScanPreferences"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("certTransparency");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "CertTransparency"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "CertTransparency"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CPUpgradeParameters");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "CPUpgradeParameters"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "CPUpgradeParameters"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
