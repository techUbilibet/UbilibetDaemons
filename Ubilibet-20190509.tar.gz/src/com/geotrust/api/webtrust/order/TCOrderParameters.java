/**
 * TCOrderParameters.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.order;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class TCOrderParameters  implements java.io.Serializable {
    private java.lang.String contractID;

    private java.lang.Integer validityPeriod;

    private java.lang.String CSR;

    private java.lang.String p12Password;

    private java.lang.String emailLanguageCode;

    public TCOrderParameters() {
    }

    public TCOrderParameters(
           java.lang.String contractID,
           java.lang.Integer validityPeriod,
           java.lang.String CSR,
           java.lang.String p12Password,
           java.lang.String emailLanguageCode) {
           this.contractID = contractID;
           this.validityPeriod = validityPeriod;
           this.CSR = CSR;
           this.p12Password = p12Password;
           this.emailLanguageCode = emailLanguageCode;
    }


    /**
     * Gets the contractID value for this TCOrderParameters.
     * 
     * @return contractID
     */
    public java.lang.String getContractID() {
        return contractID;
    }


    /**
     * Sets the contractID value for this TCOrderParameters.
     * 
     * @param contractID
     */
    public void setContractID(java.lang.String contractID) {
        this.contractID = contractID;
    }


    /**
     * Gets the validityPeriod value for this TCOrderParameters.
     * 
     * @return validityPeriod
     */
    public java.lang.Integer getValidityPeriod() {
        return validityPeriod;
    }


    /**
     * Sets the validityPeriod value for this TCOrderParameters.
     * 
     * @param validityPeriod
     */
    public void setValidityPeriod(java.lang.Integer validityPeriod) {
        this.validityPeriod = validityPeriod;
    }


    /**
     * Gets the CSR value for this TCOrderParameters.
     * 
     * @return CSR
     */
    public java.lang.String getCSR() {
        return CSR;
    }


    /**
     * Sets the CSR value for this TCOrderParameters.
     * 
     * @param CSR
     */
    public void setCSR(java.lang.String CSR) {
        this.CSR = CSR;
    }


    /**
     * Gets the p12Password value for this TCOrderParameters.
     * 
     * @return p12Password
     */
    public java.lang.String getP12Password() {
        return p12Password;
    }


    /**
     * Sets the p12Password value for this TCOrderParameters.
     * 
     * @param p12Password
     */
    public void setP12Password(java.lang.String p12Password) {
        this.p12Password = p12Password;
    }


    /**
     * Gets the emailLanguageCode value for this TCOrderParameters.
     * 
     * @return emailLanguageCode
     */
    public java.lang.String getEmailLanguageCode() {
        return emailLanguageCode;
    }


    /**
     * Sets the emailLanguageCode value for this TCOrderParameters.
     * 
     * @param emailLanguageCode
     */
    public void setEmailLanguageCode(java.lang.String emailLanguageCode) {
        this.emailLanguageCode = emailLanguageCode;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof TCOrderParameters)) return false;
        TCOrderParameters other = (TCOrderParameters) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.contractID==null && other.getContractID()==null) || 
             (this.contractID!=null &&
              this.contractID.equals(other.getContractID()))) &&
            ((this.validityPeriod==null && other.getValidityPeriod()==null) || 
             (this.validityPeriod!=null &&
              this.validityPeriod.equals(other.getValidityPeriod()))) &&
            ((this.CSR==null && other.getCSR()==null) || 
             (this.CSR!=null &&
              this.CSR.equals(other.getCSR()))) &&
            ((this.p12Password==null && other.getP12Password()==null) || 
             (this.p12Password!=null &&
              this.p12Password.equals(other.getP12Password()))) &&
            ((this.emailLanguageCode==null && other.getEmailLanguageCode()==null) || 
             (this.emailLanguageCode!=null &&
              this.emailLanguageCode.equals(other.getEmailLanguageCode())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getContractID() != null) {
            _hashCode += getContractID().hashCode();
        }
        if (getValidityPeriod() != null) {
            _hashCode += getValidityPeriod().hashCode();
        }
        if (getCSR() != null) {
            _hashCode += getCSR().hashCode();
        }
        if (getP12Password() != null) {
            _hashCode += getP12Password().hashCode();
        }
        if (getEmailLanguageCode() != null) {
            _hashCode += getEmailLanguageCode().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(TCOrderParameters.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "TCOrderParameters"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contractID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ContractID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("validityPeriod");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ValidityPeriod"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CSR");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "CSR"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("p12Password");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "P12Password"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("emailLanguageCode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "EmailLanguageCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
