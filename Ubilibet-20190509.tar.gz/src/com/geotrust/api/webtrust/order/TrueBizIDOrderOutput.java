/**
 * TrueBizIDOrderOutput.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.order;

@SuppressWarnings({ "rawtypes", "serial", "unused" }) 
public class TrueBizIDOrderOutput  implements java.io.Serializable {
    private com.geotrust.api.webtrust.order.OrderResponseHeader orderResponseHeader;

    private int geoTrustOrderID;

    public TrueBizIDOrderOutput() {
    }

    public TrueBizIDOrderOutput(
           com.geotrust.api.webtrust.order.OrderResponseHeader orderResponseHeader,
           int geoTrustOrderID) {
           this.orderResponseHeader = orderResponseHeader;
           this.geoTrustOrderID = geoTrustOrderID;
    }


    /**
     * Gets the orderResponseHeader value for this TrueBizIDOrderOutput.
     * 
     * @return orderResponseHeader
     */
    public com.geotrust.api.webtrust.order.OrderResponseHeader getOrderResponseHeader() {
        return orderResponseHeader;
    }


    /**
     * Sets the orderResponseHeader value for this TrueBizIDOrderOutput.
     * 
     * @param orderResponseHeader
     */
    public void setOrderResponseHeader(com.geotrust.api.webtrust.order.OrderResponseHeader orderResponseHeader) {
        this.orderResponseHeader = orderResponseHeader;
    }


    /**
     * Gets the geoTrustOrderID value for this TrueBizIDOrderOutput.
     * 
     * @return geoTrustOrderID
     */
    public int getGeoTrustOrderID() {
        return geoTrustOrderID;
    }


    /**
     * Sets the geoTrustOrderID value for this TrueBizIDOrderOutput.
     * 
     * @param geoTrustOrderID
     */
    public void setGeoTrustOrderID(int geoTrustOrderID) {
        this.geoTrustOrderID = geoTrustOrderID;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof TrueBizIDOrderOutput)) return false;
        TrueBizIDOrderOutput other = (TrueBizIDOrderOutput) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.orderResponseHeader==null && other.getOrderResponseHeader()==null) || 
             (this.orderResponseHeader!=null &&
              this.orderResponseHeader.equals(other.getOrderResponseHeader()))) &&
            this.geoTrustOrderID == other.getGeoTrustOrderID();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getOrderResponseHeader() != null) {
            _hashCode += getOrderResponseHeader().hashCode();
        }
        _hashCode += getGeoTrustOrderID();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(TrueBizIDOrderOutput.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "TrueBizIDOrderOutput"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderResponseHeader");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "OrderResponseHeader"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "orderResponseHeader"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("geoTrustOrderID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "GeoTrustOrderID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
