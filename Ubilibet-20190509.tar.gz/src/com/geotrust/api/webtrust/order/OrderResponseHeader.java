/**
 * OrderResponseHeader.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.order;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class OrderResponseHeader  implements java.io.Serializable {
    private java.lang.String partnerOrderID;

    private int successCode;

    private java.lang.String consumerAuthURL;

    private com.geotrust.api.webtrust.order.Error[] errors;

    private java.util.Calendar timestamp;

    public OrderResponseHeader() {
    }

    public OrderResponseHeader(
           java.lang.String partnerOrderID,
           int successCode,
           java.lang.String consumerAuthURL,
           com.geotrust.api.webtrust.order.Error[] errors,
           java.util.Calendar timestamp) {
           this.partnerOrderID = partnerOrderID;
           this.successCode = successCode;
           this.consumerAuthURL = consumerAuthURL;
           this.errors = errors;
           this.timestamp = timestamp;
    }


    /**
     * Gets the partnerOrderID value for this OrderResponseHeader.
     * 
     * @return partnerOrderID
     */
    public java.lang.String getPartnerOrderID() {
        return partnerOrderID;
    }


    /**
     * Sets the partnerOrderID value for this OrderResponseHeader.
     * 
     * @param partnerOrderID
     */
    public void setPartnerOrderID(java.lang.String partnerOrderID) {
        this.partnerOrderID = partnerOrderID;
    }


    /**
     * Gets the successCode value for this OrderResponseHeader.
     * 
     * @return successCode
     */
    public int getSuccessCode() {
        return successCode;
    }


    /**
     * Sets the successCode value for this OrderResponseHeader.
     * 
     * @param successCode
     */
    public void setSuccessCode(int successCode) {
        this.successCode = successCode;
    }


    /**
     * Gets the consumerAuthURL value for this OrderResponseHeader.
     * 
     * @return consumerAuthURL
     */
    public java.lang.String getConsumerAuthURL() {
        return consumerAuthURL;
    }


    /**
     * Sets the consumerAuthURL value for this OrderResponseHeader.
     * 
     * @param consumerAuthURL
     */
    public void setConsumerAuthURL(java.lang.String consumerAuthURL) {
        this.consumerAuthURL = consumerAuthURL;
    }


    /**
     * Gets the errors value for this OrderResponseHeader.
     * 
     * @return errors
     */
    public com.geotrust.api.webtrust.order.Error[] getErrors() {
        return errors;
    }


    /**
     * Sets the errors value for this OrderResponseHeader.
     * 
     * @param errors
     */
    public void setErrors(com.geotrust.api.webtrust.order.Error[] errors) {
        this.errors = errors;
    }


    /**
     * Gets the timestamp value for this OrderResponseHeader.
     * 
     * @return timestamp
     */
    public java.util.Calendar getTimestamp() {
        return timestamp;
    }


    /**
     * Sets the timestamp value for this OrderResponseHeader.
     * 
     * @param timestamp
     */
    public void setTimestamp(java.util.Calendar timestamp) {
        this.timestamp = timestamp;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof OrderResponseHeader)) return false;
        OrderResponseHeader other = (OrderResponseHeader) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.partnerOrderID==null && other.getPartnerOrderID()==null) || 
             (this.partnerOrderID!=null &&
              this.partnerOrderID.equals(other.getPartnerOrderID()))) &&
            this.successCode == other.getSuccessCode() &&
            ((this.consumerAuthURL==null && other.getConsumerAuthURL()==null) || 
             (this.consumerAuthURL!=null &&
              this.consumerAuthURL.equals(other.getConsumerAuthURL()))) &&
            ((this.errors==null && other.getErrors()==null) || 
             (this.errors!=null &&
              java.util.Arrays.equals(this.errors, other.getErrors()))) &&
            ((this.timestamp==null && other.getTimestamp()==null) || 
             (this.timestamp!=null &&
              this.timestamp.equals(other.getTimestamp())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getPartnerOrderID() != null) {
            _hashCode += getPartnerOrderID().hashCode();
        }
        _hashCode += getSuccessCode();
        if (getConsumerAuthURL() != null) {
            _hashCode += getConsumerAuthURL().hashCode();
        }
        if (getErrors() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getErrors());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getErrors(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getTimestamp() != null) {
            _hashCode += getTimestamp().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(OrderResponseHeader.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "orderResponseHeader"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("partnerOrderID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "PartnerOrderID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("successCode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "SuccessCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("consumerAuthURL");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "consumerAuthURL"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("errors");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Errors"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Error"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Error"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("timestamp");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Timestamp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
