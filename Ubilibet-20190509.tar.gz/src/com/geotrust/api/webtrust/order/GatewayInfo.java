/**
 * GatewayInfo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.order;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class GatewayInfo  implements java.io.Serializable {
    private java.lang.String originatingemail;

    private java.lang.String bankid;

    private java.lang.String agentnumberaccount;

    private com.geotrust.api.webtrust.order.CreditCardsAllowed creditCardsAllowed;

    private java.lang.String chainnumber;

    private java.lang.String sic;

    private java.lang.String locationnumber;

    private java.lang.String mid;

    private java.lang.String storenumber;

    private java.lang.String tid;

    private java.lang.String terminalnumber;

    public GatewayInfo() {
    }

    public GatewayInfo(
           java.lang.String originatingemail,
           java.lang.String bankid,
           java.lang.String agentnumberaccount,
           com.geotrust.api.webtrust.order.CreditCardsAllowed creditCardsAllowed,
           java.lang.String chainnumber,
           java.lang.String sic,
           java.lang.String locationnumber,
           java.lang.String mid,
           java.lang.String storenumber,
           java.lang.String tid,
           java.lang.String terminalnumber) {
           this.originatingemail = originatingemail;
           this.bankid = bankid;
           this.agentnumberaccount = agentnumberaccount;
           this.creditCardsAllowed = creditCardsAllowed;
           this.chainnumber = chainnumber;
           this.sic = sic;
           this.locationnumber = locationnumber;
           this.mid = mid;
           this.storenumber = storenumber;
           this.tid = tid;
           this.terminalnumber = terminalnumber;
    }


    /**
     * Gets the originatingemail value for this GatewayInfo.
     * 
     * @return originatingemail
     */
    public java.lang.String getOriginatingemail() {
        return originatingemail;
    }


    /**
     * Sets the originatingemail value for this GatewayInfo.
     * 
     * @param originatingemail
     */
    public void setOriginatingemail(java.lang.String originatingemail) {
        this.originatingemail = originatingemail;
    }


    /**
     * Gets the bankid value for this GatewayInfo.
     * 
     * @return bankid
     */
    public java.lang.String getBankid() {
        return bankid;
    }


    /**
     * Sets the bankid value for this GatewayInfo.
     * 
     * @param bankid
     */
    public void setBankid(java.lang.String bankid) {
        this.bankid = bankid;
    }


    /**
     * Gets the agentnumberaccount value for this GatewayInfo.
     * 
     * @return agentnumberaccount
     */
    public java.lang.String getAgentnumberaccount() {
        return agentnumberaccount;
    }


    /**
     * Sets the agentnumberaccount value for this GatewayInfo.
     * 
     * @param agentnumberaccount
     */
    public void setAgentnumberaccount(java.lang.String agentnumberaccount) {
        this.agentnumberaccount = agentnumberaccount;
    }


    /**
     * Gets the creditCardsAllowed value for this GatewayInfo.
     * 
     * @return creditCardsAllowed
     */
    public com.geotrust.api.webtrust.order.CreditCardsAllowed getCreditCardsAllowed() {
        return creditCardsAllowed;
    }


    /**
     * Sets the creditCardsAllowed value for this GatewayInfo.
     * 
     * @param creditCardsAllowed
     */
    public void setCreditCardsAllowed(com.geotrust.api.webtrust.order.CreditCardsAllowed creditCardsAllowed) {
        this.creditCardsAllowed = creditCardsAllowed;
    }


    /**
     * Gets the chainnumber value for this GatewayInfo.
     * 
     * @return chainnumber
     */
    public java.lang.String getChainnumber() {
        return chainnumber;
    }


    /**
     * Sets the chainnumber value for this GatewayInfo.
     * 
     * @param chainnumber
     */
    public void setChainnumber(java.lang.String chainnumber) {
        this.chainnumber = chainnumber;
    }


    /**
     * Gets the sic value for this GatewayInfo.
     * 
     * @return sic
     */
    public java.lang.String getSic() {
        return sic;
    }


    /**
     * Sets the sic value for this GatewayInfo.
     * 
     * @param sic
     */
    public void setSic(java.lang.String sic) {
        this.sic = sic;
    }


    /**
     * Gets the locationnumber value for this GatewayInfo.
     * 
     * @return locationnumber
     */
    public java.lang.String getLocationnumber() {
        return locationnumber;
    }


    /**
     * Sets the locationnumber value for this GatewayInfo.
     * 
     * @param locationnumber
     */
    public void setLocationnumber(java.lang.String locationnumber) {
        this.locationnumber = locationnumber;
    }


    /**
     * Gets the mid value for this GatewayInfo.
     * 
     * @return mid
     */
    public java.lang.String getMid() {
        return mid;
    }


    /**
     * Sets the mid value for this GatewayInfo.
     * 
     * @param mid
     */
    public void setMid(java.lang.String mid) {
        this.mid = mid;
    }


    /**
     * Gets the storenumber value for this GatewayInfo.
     * 
     * @return storenumber
     */
    public java.lang.String getStorenumber() {
        return storenumber;
    }


    /**
     * Sets the storenumber value for this GatewayInfo.
     * 
     * @param storenumber
     */
    public void setStorenumber(java.lang.String storenumber) {
        this.storenumber = storenumber;
    }


    /**
     * Gets the tid value for this GatewayInfo.
     * 
     * @return tid
     */
    public java.lang.String getTid() {
        return tid;
    }


    /**
     * Sets the tid value for this GatewayInfo.
     * 
     * @param tid
     */
    public void setTid(java.lang.String tid) {
        this.tid = tid;
    }


    /**
     * Gets the terminalnumber value for this GatewayInfo.
     * 
     * @return terminalnumber
     */
    public java.lang.String getTerminalnumber() {
        return terminalnumber;
    }


    /**
     * Sets the terminalnumber value for this GatewayInfo.
     * 
     * @param terminalnumber
     */
    public void setTerminalnumber(java.lang.String terminalnumber) {
        this.terminalnumber = terminalnumber;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof GatewayInfo)) return false;
        GatewayInfo other = (GatewayInfo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.originatingemail==null && other.getOriginatingemail()==null) || 
             (this.originatingemail!=null &&
              this.originatingemail.equals(other.getOriginatingemail()))) &&
            ((this.bankid==null && other.getBankid()==null) || 
             (this.bankid!=null &&
              this.bankid.equals(other.getBankid()))) &&
            ((this.agentnumberaccount==null && other.getAgentnumberaccount()==null) || 
             (this.agentnumberaccount!=null &&
              this.agentnumberaccount.equals(other.getAgentnumberaccount()))) &&
            ((this.creditCardsAllowed==null && other.getCreditCardsAllowed()==null) || 
             (this.creditCardsAllowed!=null &&
              this.creditCardsAllowed.equals(other.getCreditCardsAllowed()))) &&
            ((this.chainnumber==null && other.getChainnumber()==null) || 
             (this.chainnumber!=null &&
              this.chainnumber.equals(other.getChainnumber()))) &&
            ((this.sic==null && other.getSic()==null) || 
             (this.sic!=null &&
              this.sic.equals(other.getSic()))) &&
            ((this.locationnumber==null && other.getLocationnumber()==null) || 
             (this.locationnumber!=null &&
              this.locationnumber.equals(other.getLocationnumber()))) &&
            ((this.mid==null && other.getMid()==null) || 
             (this.mid!=null &&
              this.mid.equals(other.getMid()))) &&
            ((this.storenumber==null && other.getStorenumber()==null) || 
             (this.storenumber!=null &&
              this.storenumber.equals(other.getStorenumber()))) &&
            ((this.tid==null && other.getTid()==null) || 
             (this.tid!=null &&
              this.tid.equals(other.getTid()))) &&
            ((this.terminalnumber==null && other.getTerminalnumber()==null) || 
             (this.terminalnumber!=null &&
              this.terminalnumber.equals(other.getTerminalnumber())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getOriginatingemail() != null) {
            _hashCode += getOriginatingemail().hashCode();
        }
        if (getBankid() != null) {
            _hashCode += getBankid().hashCode();
        }
        if (getAgentnumberaccount() != null) {
            _hashCode += getAgentnumberaccount().hashCode();
        }
        if (getCreditCardsAllowed() != null) {
            _hashCode += getCreditCardsAllowed().hashCode();
        }
        if (getChainnumber() != null) {
            _hashCode += getChainnumber().hashCode();
        }
        if (getSic() != null) {
            _hashCode += getSic().hashCode();
        }
        if (getLocationnumber() != null) {
            _hashCode += getLocationnumber().hashCode();
        }
        if (getMid() != null) {
            _hashCode += getMid().hashCode();
        }
        if (getStorenumber() != null) {
            _hashCode += getStorenumber().hashCode();
        }
        if (getTid() != null) {
            _hashCode += getTid().hashCode();
        }
        if (getTerminalnumber() != null) {
            _hashCode += getTerminalnumber().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(GatewayInfo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "gatewayInfo"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("originatingemail");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "originatingemail"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bankid");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "bankid"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("agentnumberaccount");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "agentnumberaccount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("creditCardsAllowed");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "CreditCardsAllowed"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "creditCardsAllowed"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("chainnumber");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "chainnumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sic");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "sic"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("locationnumber");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "locationnumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("mid");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "mid"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("storenumber");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "storenumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tid");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "tid"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("terminalnumber");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "terminalnumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
