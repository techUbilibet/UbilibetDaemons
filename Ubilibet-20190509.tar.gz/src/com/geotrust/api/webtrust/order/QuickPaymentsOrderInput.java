/**
 * QuickPaymentsOrderInput.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.order;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class QuickPaymentsOrderInput  implements java.io.Serializable {
    private com.geotrust.api.webtrust.order.OrderRequestHeader orderRequestHeader;

    private com.geotrust.api.webtrust.order.QuickPaymentsOrderInfo quickPaymentsOrderInfo;

    private com.geotrust.api.webtrust.order.MerchantData merchantData;

    private com.geotrust.api.webtrust.order.MerchantAdminContact merchantAdminContact;

    private com.geotrust.api.webtrust.order.MerchantTechContact merchantTechContact;

    private com.geotrust.api.webtrust.order.MerchantBillingContact merchantBillingContact;

    private com.geotrust.api.webtrust.order.PaymentInfo paymentInfo;

    private com.geotrust.api.webtrust.order.GatewayInfo gatewayInfo;

    private com.geotrust.api.webtrust.order.MerchantAccountInfo merchantAccountInfo;

    public QuickPaymentsOrderInput() {
    }

    public QuickPaymentsOrderInput(
           com.geotrust.api.webtrust.order.OrderRequestHeader orderRequestHeader,
           com.geotrust.api.webtrust.order.QuickPaymentsOrderInfo quickPaymentsOrderInfo,
           com.geotrust.api.webtrust.order.MerchantData merchantData,
           com.geotrust.api.webtrust.order.MerchantAdminContact merchantAdminContact,
           com.geotrust.api.webtrust.order.MerchantTechContact merchantTechContact,
           com.geotrust.api.webtrust.order.MerchantBillingContact merchantBillingContact,
           com.geotrust.api.webtrust.order.PaymentInfo paymentInfo,
           com.geotrust.api.webtrust.order.GatewayInfo gatewayInfo,
           com.geotrust.api.webtrust.order.MerchantAccountInfo merchantAccountInfo) {
           this.orderRequestHeader = orderRequestHeader;
           this.quickPaymentsOrderInfo = quickPaymentsOrderInfo;
           this.merchantData = merchantData;
           this.merchantAdminContact = merchantAdminContact;
           this.merchantTechContact = merchantTechContact;
           this.merchantBillingContact = merchantBillingContact;
           this.paymentInfo = paymentInfo;
           this.gatewayInfo = gatewayInfo;
           this.merchantAccountInfo = merchantAccountInfo;
    }


    /**
     * Gets the orderRequestHeader value for this QuickPaymentsOrderInput.
     * 
     * @return orderRequestHeader
     */
    public com.geotrust.api.webtrust.order.OrderRequestHeader getOrderRequestHeader() {
        return orderRequestHeader;
    }


    /**
     * Sets the orderRequestHeader value for this QuickPaymentsOrderInput.
     * 
     * @param orderRequestHeader
     */
    public void setOrderRequestHeader(com.geotrust.api.webtrust.order.OrderRequestHeader orderRequestHeader) {
        this.orderRequestHeader = orderRequestHeader;
    }


    /**
     * Gets the quickPaymentsOrderInfo value for this QuickPaymentsOrderInput.
     * 
     * @return quickPaymentsOrderInfo
     */
    public com.geotrust.api.webtrust.order.QuickPaymentsOrderInfo getQuickPaymentsOrderInfo() {
        return quickPaymentsOrderInfo;
    }


    /**
     * Sets the quickPaymentsOrderInfo value for this QuickPaymentsOrderInput.
     * 
     * @param quickPaymentsOrderInfo
     */
    public void setQuickPaymentsOrderInfo(com.geotrust.api.webtrust.order.QuickPaymentsOrderInfo quickPaymentsOrderInfo) {
        this.quickPaymentsOrderInfo = quickPaymentsOrderInfo;
    }


    /**
     * Gets the merchantData value for this QuickPaymentsOrderInput.
     * 
     * @return merchantData
     */
    public com.geotrust.api.webtrust.order.MerchantData getMerchantData() {
        return merchantData;
    }


    /**
     * Sets the merchantData value for this QuickPaymentsOrderInput.
     * 
     * @param merchantData
     */
    public void setMerchantData(com.geotrust.api.webtrust.order.MerchantData merchantData) {
        this.merchantData = merchantData;
    }


    /**
     * Gets the merchantAdminContact value for this QuickPaymentsOrderInput.
     * 
     * @return merchantAdminContact
     */
    public com.geotrust.api.webtrust.order.MerchantAdminContact getMerchantAdminContact() {
        return merchantAdminContact;
    }


    /**
     * Sets the merchantAdminContact value for this QuickPaymentsOrderInput.
     * 
     * @param merchantAdminContact
     */
    public void setMerchantAdminContact(com.geotrust.api.webtrust.order.MerchantAdminContact merchantAdminContact) {
        this.merchantAdminContact = merchantAdminContact;
    }


    /**
     * Gets the merchantTechContact value for this QuickPaymentsOrderInput.
     * 
     * @return merchantTechContact
     */
    public com.geotrust.api.webtrust.order.MerchantTechContact getMerchantTechContact() {
        return merchantTechContact;
    }


    /**
     * Sets the merchantTechContact value for this QuickPaymentsOrderInput.
     * 
     * @param merchantTechContact
     */
    public void setMerchantTechContact(com.geotrust.api.webtrust.order.MerchantTechContact merchantTechContact) {
        this.merchantTechContact = merchantTechContact;
    }


    /**
     * Gets the merchantBillingContact value for this QuickPaymentsOrderInput.
     * 
     * @return merchantBillingContact
     */
    public com.geotrust.api.webtrust.order.MerchantBillingContact getMerchantBillingContact() {
        return merchantBillingContact;
    }


    /**
     * Sets the merchantBillingContact value for this QuickPaymentsOrderInput.
     * 
     * @param merchantBillingContact
     */
    public void setMerchantBillingContact(com.geotrust.api.webtrust.order.MerchantBillingContact merchantBillingContact) {
        this.merchantBillingContact = merchantBillingContact;
    }


    /**
     * Gets the paymentInfo value for this QuickPaymentsOrderInput.
     * 
     * @return paymentInfo
     */
    public com.geotrust.api.webtrust.order.PaymentInfo getPaymentInfo() {
        return paymentInfo;
    }


    /**
     * Sets the paymentInfo value for this QuickPaymentsOrderInput.
     * 
     * @param paymentInfo
     */
    public void setPaymentInfo(com.geotrust.api.webtrust.order.PaymentInfo paymentInfo) {
        this.paymentInfo = paymentInfo;
    }


    /**
     * Gets the gatewayInfo value for this QuickPaymentsOrderInput.
     * 
     * @return gatewayInfo
     */
    public com.geotrust.api.webtrust.order.GatewayInfo getGatewayInfo() {
        return gatewayInfo;
    }


    /**
     * Sets the gatewayInfo value for this QuickPaymentsOrderInput.
     * 
     * @param gatewayInfo
     */
    public void setGatewayInfo(com.geotrust.api.webtrust.order.GatewayInfo gatewayInfo) {
        this.gatewayInfo = gatewayInfo;
    }


    /**
     * Gets the merchantAccountInfo value for this QuickPaymentsOrderInput.
     * 
     * @return merchantAccountInfo
     */
    public com.geotrust.api.webtrust.order.MerchantAccountInfo getMerchantAccountInfo() {
        return merchantAccountInfo;
    }


    /**
     * Sets the merchantAccountInfo value for this QuickPaymentsOrderInput.
     * 
     * @param merchantAccountInfo
     */
    public void setMerchantAccountInfo(com.geotrust.api.webtrust.order.MerchantAccountInfo merchantAccountInfo) {
        this.merchantAccountInfo = merchantAccountInfo;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof QuickPaymentsOrderInput)) return false;
        QuickPaymentsOrderInput other = (QuickPaymentsOrderInput) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.orderRequestHeader==null && other.getOrderRequestHeader()==null) || 
             (this.orderRequestHeader!=null &&
              this.orderRequestHeader.equals(other.getOrderRequestHeader()))) &&
            ((this.quickPaymentsOrderInfo==null && other.getQuickPaymentsOrderInfo()==null) || 
             (this.quickPaymentsOrderInfo!=null &&
              this.quickPaymentsOrderInfo.equals(other.getQuickPaymentsOrderInfo()))) &&
            ((this.merchantData==null && other.getMerchantData()==null) || 
             (this.merchantData!=null &&
              this.merchantData.equals(other.getMerchantData()))) &&
            ((this.merchantAdminContact==null && other.getMerchantAdminContact()==null) || 
             (this.merchantAdminContact!=null &&
              this.merchantAdminContact.equals(other.getMerchantAdminContact()))) &&
            ((this.merchantTechContact==null && other.getMerchantTechContact()==null) || 
             (this.merchantTechContact!=null &&
              this.merchantTechContact.equals(other.getMerchantTechContact()))) &&
            ((this.merchantBillingContact==null && other.getMerchantBillingContact()==null) || 
             (this.merchantBillingContact!=null &&
              this.merchantBillingContact.equals(other.getMerchantBillingContact()))) &&
            ((this.paymentInfo==null && other.getPaymentInfo()==null) || 
             (this.paymentInfo!=null &&
              this.paymentInfo.equals(other.getPaymentInfo()))) &&
            ((this.gatewayInfo==null && other.getGatewayInfo()==null) || 
             (this.gatewayInfo!=null &&
              this.gatewayInfo.equals(other.getGatewayInfo()))) &&
            ((this.merchantAccountInfo==null && other.getMerchantAccountInfo()==null) || 
             (this.merchantAccountInfo!=null &&
              this.merchantAccountInfo.equals(other.getMerchantAccountInfo())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getOrderRequestHeader() != null) {
            _hashCode += getOrderRequestHeader().hashCode();
        }
        if (getQuickPaymentsOrderInfo() != null) {
            _hashCode += getQuickPaymentsOrderInfo().hashCode();
        }
        if (getMerchantData() != null) {
            _hashCode += getMerchantData().hashCode();
        }
        if (getMerchantAdminContact() != null) {
            _hashCode += getMerchantAdminContact().hashCode();
        }
        if (getMerchantTechContact() != null) {
            _hashCode += getMerchantTechContact().hashCode();
        }
        if (getMerchantBillingContact() != null) {
            _hashCode += getMerchantBillingContact().hashCode();
        }
        if (getPaymentInfo() != null) {
            _hashCode += getPaymentInfo().hashCode();
        }
        if (getGatewayInfo() != null) {
            _hashCode += getGatewayInfo().hashCode();
        }
        if (getMerchantAccountInfo() != null) {
            _hashCode += getMerchantAccountInfo().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(QuickPaymentsOrderInput.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "QuickPaymentsOrderInput"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderRequestHeader");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "OrderRequestHeader"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "orderRequestHeader"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("quickPaymentsOrderInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "QuickPaymentsOrderInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "quickPaymentsOrderInfo"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("merchantData");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "MerchantData"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "merchantData"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("merchantAdminContact");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "MerchantAdminContact"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "merchantAdminContact"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("merchantTechContact");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "MerchantTechContact"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "merchantTechContact"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("merchantBillingContact");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "MerchantBillingContact"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "merchantBillingContact"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("paymentInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "PaymentInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "paymentInfo"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("gatewayInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "GatewayInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "gatewayInfo"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("merchantAccountInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "MerchantAccountInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "merchantAccountInfo"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
