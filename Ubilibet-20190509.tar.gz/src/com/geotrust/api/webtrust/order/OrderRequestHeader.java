/**
 * OrderRequestHeader.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.order;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class OrderRequestHeader  implements java.io.Serializable {
    private java.lang.String apiVersion;

    private java.lang.String partnerCode;

    private java.lang.String productCode;

    private java.lang.String partnerOrderID;

    private com.geotrust.api.webtrust.order.AuthToken authToken;

    private java.lang.String replayToken;

    private java.lang.Boolean useReplayToken;

    private java.lang.String profileName;

    public OrderRequestHeader() {
    }

    public OrderRequestHeader(
           java.lang.String apiVersion,
           java.lang.String partnerCode,
           java.lang.String productCode,
           java.lang.String partnerOrderID,
           com.geotrust.api.webtrust.order.AuthToken authToken,
           java.lang.String replayToken,
           java.lang.Boolean useReplayToken,
           java.lang.String profileName) {
           this.apiVersion = apiVersion;
           this.partnerCode = partnerCode;
           this.productCode = productCode;
           this.partnerOrderID = partnerOrderID;
           this.authToken = authToken;
           this.replayToken = replayToken;
           this.useReplayToken = useReplayToken;
           this.profileName = profileName;
    }


    /**
     * Gets the apiVersion value for this OrderRequestHeader.
     * 
     * @return apiVersion
     */
    public java.lang.String getApiVersion() {
        return apiVersion;
    }


    /**
     * Sets the apiVersion value for this OrderRequestHeader.
     * 
     * @param apiVersion
     */
    public void setApiVersion(java.lang.String apiVersion) {
        this.apiVersion = apiVersion;
    }


    /**
     * Gets the partnerCode value for this OrderRequestHeader.
     * 
     * @return partnerCode
     */
    public java.lang.String getPartnerCode() {
        return partnerCode;
    }


    /**
     * Sets the partnerCode value for this OrderRequestHeader.
     * 
     * @param partnerCode
     */
    public void setPartnerCode(java.lang.String partnerCode) {
        this.partnerCode = partnerCode;
    }


    /**
     * Gets the productCode value for this OrderRequestHeader.
     * 
     * @return productCode
     */
    public java.lang.String getProductCode() {
        return productCode;
    }


    /**
     * Sets the productCode value for this OrderRequestHeader.
     * 
     * @param productCode
     */
    public void setProductCode(java.lang.String productCode) {
        this.productCode = productCode;
    }


    /**
     * Gets the partnerOrderID value for this OrderRequestHeader.
     * 
     * @return partnerOrderID
     */
    public java.lang.String getPartnerOrderID() {
        return partnerOrderID;
    }


    /**
     * Sets the partnerOrderID value for this OrderRequestHeader.
     * 
     * @param partnerOrderID
     */
    public void setPartnerOrderID(java.lang.String partnerOrderID) {
        this.partnerOrderID = partnerOrderID;
    }


    /**
     * Gets the authToken value for this OrderRequestHeader.
     * 
     * @return authToken
     */
    public com.geotrust.api.webtrust.order.AuthToken getAuthToken() {
        return authToken;
    }


    /**
     * Sets the authToken value for this OrderRequestHeader.
     * 
     * @param authToken
     */
    public void setAuthToken(com.geotrust.api.webtrust.order.AuthToken authToken) {
        this.authToken = authToken;
    }


    /**
     * Gets the replayToken value for this OrderRequestHeader.
     * 
     * @return replayToken
     */
    public java.lang.String getReplayToken() {
        return replayToken;
    }


    /**
     * Sets the replayToken value for this OrderRequestHeader.
     * 
     * @param replayToken
     */
    public void setReplayToken(java.lang.String replayToken) {
        this.replayToken = replayToken;
    }


    /**
     * Gets the useReplayToken value for this OrderRequestHeader.
     * 
     * @return useReplayToken
     */
    public java.lang.Boolean getUseReplayToken() {
        return useReplayToken;
    }


    /**
     * Sets the useReplayToken value for this OrderRequestHeader.
     * 
     * @param useReplayToken
     */
    public void setUseReplayToken(java.lang.Boolean useReplayToken) {
        this.useReplayToken = useReplayToken;
    }


    /**
     * Gets the profileName value for this OrderRequestHeader.
     * 
     * @return profileName
     */
    public java.lang.String getProfileName() {
        return profileName;
    }


    /**
     * Sets the profileName value for this OrderRequestHeader.
     * 
     * @param profileName
     */
    public void setProfileName(java.lang.String profileName) {
        this.profileName = profileName;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof OrderRequestHeader)) return false;
        OrderRequestHeader other = (OrderRequestHeader) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.apiVersion==null && other.getApiVersion()==null) || 
             (this.apiVersion!=null &&
              this.apiVersion.equals(other.getApiVersion()))) &&
            ((this.partnerCode==null && other.getPartnerCode()==null) || 
             (this.partnerCode!=null &&
              this.partnerCode.equals(other.getPartnerCode()))) &&
            ((this.productCode==null && other.getProductCode()==null) || 
             (this.productCode!=null &&
              this.productCode.equals(other.getProductCode()))) &&
            ((this.partnerOrderID==null && other.getPartnerOrderID()==null) || 
             (this.partnerOrderID!=null &&
              this.partnerOrderID.equals(other.getPartnerOrderID()))) &&
            ((this.authToken==null && other.getAuthToken()==null) || 
             (this.authToken!=null &&
              this.authToken.equals(other.getAuthToken()))) &&
            ((this.replayToken==null && other.getReplayToken()==null) || 
             (this.replayToken!=null &&
              this.replayToken.equals(other.getReplayToken()))) &&
            ((this.useReplayToken==null && other.getUseReplayToken()==null) || 
             (this.useReplayToken!=null &&
              this.useReplayToken.equals(other.getUseReplayToken()))) &&
            ((this.profileName==null && other.getProfileName()==null) || 
             (this.profileName!=null &&
              this.profileName.equals(other.getProfileName())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getApiVersion() != null) {
            _hashCode += getApiVersion().hashCode();
        }
        if (getPartnerCode() != null) {
            _hashCode += getPartnerCode().hashCode();
        }
        if (getProductCode() != null) {
            _hashCode += getProductCode().hashCode();
        }
        if (getPartnerOrderID() != null) {
            _hashCode += getPartnerOrderID().hashCode();
        }
        if (getAuthToken() != null) {
            _hashCode += getAuthToken().hashCode();
        }
        if (getReplayToken() != null) {
            _hashCode += getReplayToken().hashCode();
        }
        if (getUseReplayToken() != null) {
            _hashCode += getUseReplayToken().hashCode();
        }
        if (getProfileName() != null) {
            _hashCode += getProfileName().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(OrderRequestHeader.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "orderRequestHeader"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("apiVersion");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ApiVersion"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("partnerCode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "PartnerCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("productCode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ProductCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("partnerOrderID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "PartnerOrderID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("authToken");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "AuthToken"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "authToken"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("replayToken");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ReplayToken"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("useReplayToken");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "UseReplayToken"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("profileName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ProfileName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
