/**
 * ParsedCSR.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.order;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class ParsedCSR  implements java.io.Serializable {
    private java.lang.String domainName;

    private java.lang.String country;

    private java.lang.String email;

    private java.lang.String locality;

    private java.lang.String organization;

    private java.lang.String organizationUnit;

    private java.lang.String state;

    private java.lang.String DNSNames;

    private boolean isValidTrueDomainName;

    private boolean isValidQuickDomainName;

    private boolean hasBadExtensions;

    private java.lang.String encryptionAlgorithm;

    private java.lang.String hashAlgorithm;

    public ParsedCSR() {
    }

    public ParsedCSR(
           java.lang.String domainName,
           java.lang.String country,
           java.lang.String email,
           java.lang.String locality,
           java.lang.String organization,
           java.lang.String organizationUnit,
           java.lang.String state,
           java.lang.String DNSNames,
           boolean isValidTrueDomainName,
           boolean isValidQuickDomainName,
           boolean hasBadExtensions,
           java.lang.String encryptionAlgorithm,
           java.lang.String hashAlgorithm) {
           this.domainName = domainName;
           this.country = country;
           this.email = email;
           this.locality = locality;
           this.organization = organization;
           this.organizationUnit = organizationUnit;
           this.state = state;
           this.DNSNames = DNSNames;
           this.isValidTrueDomainName = isValidTrueDomainName;
           this.isValidQuickDomainName = isValidQuickDomainName;
           this.hasBadExtensions = hasBadExtensions;
           this.encryptionAlgorithm = encryptionAlgorithm;
           this.hashAlgorithm = hashAlgorithm;
    }


    /**
     * Gets the domainName value for this ParsedCSR.
     * 
     * @return domainName
     */
    public java.lang.String getDomainName() {
        return domainName;
    }


    /**
     * Sets the domainName value for this ParsedCSR.
     * 
     * @param domainName
     */
    public void setDomainName(java.lang.String domainName) {
        this.domainName = domainName;
    }


    /**
     * Gets the country value for this ParsedCSR.
     * 
     * @return country
     */
    public java.lang.String getCountry() {
        return country;
    }


    /**
     * Sets the country value for this ParsedCSR.
     * 
     * @param country
     */
    public void setCountry(java.lang.String country) {
        this.country = country;
    }


    /**
     * Gets the email value for this ParsedCSR.
     * 
     * @return email
     */
    public java.lang.String getEmail() {
        return email;
    }


    /**
     * Sets the email value for this ParsedCSR.
     * 
     * @param email
     */
    public void setEmail(java.lang.String email) {
        this.email = email;
    }


    /**
     * Gets the locality value for this ParsedCSR.
     * 
     * @return locality
     */
    public java.lang.String getLocality() {
        return locality;
    }


    /**
     * Sets the locality value for this ParsedCSR.
     * 
     * @param locality
     */
    public void setLocality(java.lang.String locality) {
        this.locality = locality;
    }


    /**
     * Gets the organization value for this ParsedCSR.
     * 
     * @return organization
     */
    public java.lang.String getOrganization() {
        return organization;
    }


    /**
     * Sets the organization value for this ParsedCSR.
     * 
     * @param organization
     */
    public void setOrganization(java.lang.String organization) {
        this.organization = organization;
    }


    /**
     * Gets the organizationUnit value for this ParsedCSR.
     * 
     * @return organizationUnit
     */
    public java.lang.String getOrganizationUnit() {
        return organizationUnit;
    }


    /**
     * Sets the organizationUnit value for this ParsedCSR.
     * 
     * @param organizationUnit
     */
    public void setOrganizationUnit(java.lang.String organizationUnit) {
        this.organizationUnit = organizationUnit;
    }


    /**
     * Gets the state value for this ParsedCSR.
     * 
     * @return state
     */
    public java.lang.String getState() {
        return state;
    }


    /**
     * Sets the state value for this ParsedCSR.
     * 
     * @param state
     */
    public void setState(java.lang.String state) {
        this.state = state;
    }


    /**
     * Gets the DNSNames value for this ParsedCSR.
     * 
     * @return DNSNames
     */
    public java.lang.String getDNSNames() {
        return DNSNames;
    }


    /**
     * Sets the DNSNames value for this ParsedCSR.
     * 
     * @param DNSNames
     */
    public void setDNSNames(java.lang.String DNSNames) {
        this.DNSNames = DNSNames;
    }


    /**
     * Gets the isValidTrueDomainName value for this ParsedCSR.
     * 
     * @return isValidTrueDomainName
     */
    public boolean isIsValidTrueDomainName() {
        return isValidTrueDomainName;
    }


    /**
     * Sets the isValidTrueDomainName value for this ParsedCSR.
     * 
     * @param isValidTrueDomainName
     */
    public void setIsValidTrueDomainName(boolean isValidTrueDomainName) {
        this.isValidTrueDomainName = isValidTrueDomainName;
    }


    /**
     * Gets the isValidQuickDomainName value for this ParsedCSR.
     * 
     * @return isValidQuickDomainName
     */
    public boolean isIsValidQuickDomainName() {
        return isValidQuickDomainName;
    }


    /**
     * Sets the isValidQuickDomainName value for this ParsedCSR.
     * 
     * @param isValidQuickDomainName
     */
    public void setIsValidQuickDomainName(boolean isValidQuickDomainName) {
        this.isValidQuickDomainName = isValidQuickDomainName;
    }


    /**
     * Gets the hasBadExtensions value for this ParsedCSR.
     * 
     * @return hasBadExtensions
     */
    public boolean isHasBadExtensions() {
        return hasBadExtensions;
    }


    /**
     * Sets the hasBadExtensions value for this ParsedCSR.
     * 
     * @param hasBadExtensions
     */
    public void setHasBadExtensions(boolean hasBadExtensions) {
        this.hasBadExtensions = hasBadExtensions;
    }


    /**
     * Gets the encryptionAlgorithm value for this ParsedCSR.
     * 
     * @return encryptionAlgorithm
     */
    public java.lang.String getEncryptionAlgorithm() {
        return encryptionAlgorithm;
    }


    /**
     * Sets the encryptionAlgorithm value for this ParsedCSR.
     * 
     * @param encryptionAlgorithm
     */
    public void setEncryptionAlgorithm(java.lang.String encryptionAlgorithm) {
        this.encryptionAlgorithm = encryptionAlgorithm;
    }


    /**
     * Gets the hashAlgorithm value for this ParsedCSR.
     * 
     * @return hashAlgorithm
     */
    public java.lang.String getHashAlgorithm() {
        return hashAlgorithm;
    }


    /**
     * Sets the hashAlgorithm value for this ParsedCSR.
     * 
     * @param hashAlgorithm
     */
    public void setHashAlgorithm(java.lang.String hashAlgorithm) {
        this.hashAlgorithm = hashAlgorithm;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ParsedCSR)) return false;
        ParsedCSR other = (ParsedCSR) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.domainName==null && other.getDomainName()==null) || 
             (this.domainName!=null &&
              this.domainName.equals(other.getDomainName()))) &&
            ((this.country==null && other.getCountry()==null) || 
             (this.country!=null &&
              this.country.equals(other.getCountry()))) &&
            ((this.email==null && other.getEmail()==null) || 
             (this.email!=null &&
              this.email.equals(other.getEmail()))) &&
            ((this.locality==null && other.getLocality()==null) || 
             (this.locality!=null &&
              this.locality.equals(other.getLocality()))) &&
            ((this.organization==null && other.getOrganization()==null) || 
             (this.organization!=null &&
              this.organization.equals(other.getOrganization()))) &&
            ((this.organizationUnit==null && other.getOrganizationUnit()==null) || 
             (this.organizationUnit!=null &&
              this.organizationUnit.equals(other.getOrganizationUnit()))) &&
            ((this.state==null && other.getState()==null) || 
             (this.state!=null &&
              this.state.equals(other.getState()))) &&
            ((this.DNSNames==null && other.getDNSNames()==null) || 
             (this.DNSNames!=null &&
              this.DNSNames.equals(other.getDNSNames()))) &&
            this.isValidTrueDomainName == other.isIsValidTrueDomainName() &&
            this.isValidQuickDomainName == other.isIsValidQuickDomainName() &&
            this.hasBadExtensions == other.isHasBadExtensions() &&
            ((this.encryptionAlgorithm==null && other.getEncryptionAlgorithm()==null) || 
             (this.encryptionAlgorithm!=null &&
              this.encryptionAlgorithm.equals(other.getEncryptionAlgorithm()))) &&
            ((this.hashAlgorithm==null && other.getHashAlgorithm()==null) || 
             (this.hashAlgorithm!=null &&
              this.hashAlgorithm.equals(other.getHashAlgorithm())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getDomainName() != null) {
            _hashCode += getDomainName().hashCode();
        }
        if (getCountry() != null) {
            _hashCode += getCountry().hashCode();
        }
        if (getEmail() != null) {
            _hashCode += getEmail().hashCode();
        }
        if (getLocality() != null) {
            _hashCode += getLocality().hashCode();
        }
        if (getOrganization() != null) {
            _hashCode += getOrganization().hashCode();
        }
        if (getOrganizationUnit() != null) {
            _hashCode += getOrganizationUnit().hashCode();
        }
        if (getState() != null) {
            _hashCode += getState().hashCode();
        }
        if (getDNSNames() != null) {
            _hashCode += getDNSNames().hashCode();
        }
        _hashCode += (isIsValidTrueDomainName() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isIsValidQuickDomainName() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isHasBadExtensions() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getEncryptionAlgorithm() != null) {
            _hashCode += getEncryptionAlgorithm().hashCode();
        }
        if (getHashAlgorithm() != null) {
            _hashCode += getHashAlgorithm().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ParsedCSR.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "parsedCSR"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("domainName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "DomainName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("country");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Country"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("email");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Email"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("locality");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Locality"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("organization");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Organization"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("organizationUnit");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "OrganizationUnit"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("state");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "State"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DNSNames");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "DNSNames"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isValidTrueDomainName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "IsValidTrueDomainName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isValidQuickDomainName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "IsValidQuickDomainName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hasBadExtensions");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "HasBadExtensions"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("encryptionAlgorithm");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "EncryptionAlgorithm"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hashAlgorithm");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "HashAlgorithm"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
