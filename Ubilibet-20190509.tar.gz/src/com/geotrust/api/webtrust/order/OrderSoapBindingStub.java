/**
 * OrderSoapBindingStub.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.order;

@SuppressWarnings({ "unchecked", "unused", "rawtypes" })
public class OrderSoapBindingStub extends org.apache.axis.client.Stub implements com.geotrust.api.webtrust.order.OrderSoap {
    private java.util.Vector cachedSerClasses = new java.util.Vector();
    private java.util.Vector cachedSerQNames = new java.util.Vector();
    private java.util.Vector cachedSerFactories = new java.util.Vector();
    private java.util.Vector cachedDeserFactories = new java.util.Vector();

    static org.apache.axis.description.OperationDesc [] _operations;

    static {
        _operations = new org.apache.axis.description.OperationDesc[15];
        _initOperationDesc1();
        _initOperationDesc2();
    }

    private static void _initOperationDesc1(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("ModifyOrder");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ModifyOrderInput"), com.geotrust.api.webtrust.order.ModifyOrderInput.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ModifyOrderOutput"));
        oper.setReturnClass(com.geotrust.api.webtrust.order.ModifyOrderOutput.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ModifyOrderResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[0] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("ShowReplayTokens");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "PartnerCode"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ArrayOfString"));
        oper.setReturnClass(java.lang.String[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ShowReplayTokensResult"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "String"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[1] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("QuickOrder");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "QuickOrderInput"), com.geotrust.api.webtrust.order.QuickOrderInput.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "QuickOrderOutput"));
        oper.setReturnClass(com.geotrust.api.webtrust.order.QuickOrderOutput.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "QuickOrderResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[2] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("TCOrder");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "TCOrderInput"), com.geotrust.api.webtrust.order.TCOrderInput.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "TCOrderOutput"));
        oper.setReturnClass(com.geotrust.api.webtrust.order.TCOrderOutput.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "TCOrderResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[3] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("Revoke");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "RevokeInput"), com.geotrust.api.webtrust.order.RevokeInput.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "RevokeOutput"));
        oper.setReturnClass(com.geotrust.api.webtrust.order.RevokeOutput.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "RevokeResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[4] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("QuickInvite");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "QuickInviteInput"), com.geotrust.api.webtrust.order.QuickInviteInput.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "QuickInviteOutput"));
        oper.setReturnClass(com.geotrust.api.webtrust.order.QuickInviteOutput.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "QuickInviteResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[5] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("ValidatePreAuthenticationData");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ValidateAuthDataRequest"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ValidateAuthDataInput"), com.geotrust.api.webtrust.order.ValidateAuthDataInput.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ValidateAuthDataOutput"));
        oper.setReturnClass(com.geotrust.api.webtrust.order.ValidateAuthDataOutput.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ValidateAuthDataResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[6] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("QuickPaymentsOrder");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "QuickPaymentsOrderInput"), com.geotrust.api.webtrust.order.QuickPaymentsOrderInput.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "QuickPaymentsOrderOutput"));
        oper.setReturnClass(com.geotrust.api.webtrust.order.QuickPaymentsOrderOutput.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "QuickPaymentsOrderResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[7] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("ValidateOrderParameters");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ValidateOrderParametersInput"), com.geotrust.api.webtrust.order.ValidateOrderParametersInput.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ValidateOrderParametersOutput"));
        oper.setReturnClass(com.geotrust.api.webtrust.order.ValidateOrderParametersOutput.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ValidateOrderParametersResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[8] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("TrueSiteOrder");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "TrueSiteOrderInput"), com.geotrust.api.webtrust.order.TrueSiteOrderInput.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "TrueSiteOrderOutput"));
        oper.setReturnClass(com.geotrust.api.webtrust.order.TrueSiteOrderOutput.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "TrueSiteOrderResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[9] = oper;

    }

    private static void _initOperationDesc2(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("TCInvite");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "TCInviteInput"), com.geotrust.api.webtrust.order.TCInviteInput.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "TCInviteOutput"));
        oper.setReturnClass(com.geotrust.api.webtrust.order.TCInviteOutput.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "TCInviteResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[10] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("ChangeApproverEmail");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ChangeApproverEmailInput"), com.geotrust.api.webtrust.order.ChangeApproverEmailInput.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ChangeApproverEmailOutput"));
        oper.setReturnClass(com.geotrust.api.webtrust.order.ChangeApproverEmailOutput.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ChangeApproverEmailResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[11] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("ResendEmail");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ResendEmailInput"), com.geotrust.api.webtrust.order.ResendEmailInput.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ResendEmailOutput"));
        oper.setReturnClass(com.geotrust.api.webtrust.order.ResendEmailOutput.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ResendEmailResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[12] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("Reissue");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Request"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ReissueInput"), com.geotrust.api.webtrust.order.ReissueInput.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ReissueOutput"));
        oper.setReturnClass(com.geotrust.api.webtrust.order.ReissueOutput.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ReissueResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[13] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("OrderPreAuthentication");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "AuthOrderRequest"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "AuthOrderInput"), com.geotrust.api.webtrust.order.AuthOrderInput.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "AuthOrderOutput"));
        oper.setReturnClass(com.geotrust.api.webtrust.order.AuthOrderOutput.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "AuthOrderResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[14] = oper;

    }

    public OrderSoapBindingStub() throws org.apache.axis.AxisFault {
         this(null);
    }

    public OrderSoapBindingStub(java.net.URL endpointURL, javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
         this(service);
         super.cachedEndpoint = endpointURL;
    }

    public OrderSoapBindingStub(javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
        if (service == null) {
            super.service = new org.apache.axis.client.Service();
        } else {
            super.service = service;
        }
        ((org.apache.axis.client.Service)super.service).setTypeMappingVersion("1.2");
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
        addBindings0();
        addBindings1();
    }

    private void addBindings0() {
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "algorithmInfo");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.AlgorithmInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ArrayOfAuthenticationComment");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.AuthenticationComment[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "AuthenticationComment");
            qName2 = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "AuthenticationComment");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ArrayOfAuthenticationStatus");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.AuthenticationStatus[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "AuthenticationStatus");
            qName2 = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "AuthenticationStatus");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ArrayOfCAAEntry");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.CAAEntry[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "CAAEntry");
            qName2 = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "CAAEntry");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ArrayOfCACertificate");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.CACertificate[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "CACertificate");
            qName2 = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "CACertificate");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ArrayOfCertificateDetail");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.CertificateDetail[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "CertificateDetail");
            qName2 = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "CertificateDetail");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ArrayOfContactPair");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.ContactPair[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ContactPair");
            qName2 = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ContactPair");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ArrayOfContactPairAuthStatus");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.ContactPairAuthStatus[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ContactPairAuthStatus");
            qName2 = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ContactPairAuthStatus");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ArrayOfCustomField");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.CustomField[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "CustomField");
            qName2 = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "CustomField");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ArrayOfDomain");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.Domain[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Domain");
            qName2 = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Domain");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ArrayOfDomainAuthStatus");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.DomainAuthStatus[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "DomainAuthStatus");
            qName2 = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "DomainAuthStatus");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ArrayOfError");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.Error[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Error");
            qName2 = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Error");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ArrayOfInfectedPage");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.InfectedPage[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "InfectedPage");
            qName2 = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "InfectedPage");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ArrayOfInviteDetail");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.InviteDetail[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "InviteDetail");
            qName2 = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "InviteDetail");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ArrayOfLocalTradingName");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.LocalTradingName[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "LocalTradingName");
            qName2 = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "LocalTradingName");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ArrayOfModificationEvent");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.ModificationEvent[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ModificationEvent");
            qName2 = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ModificationEvent");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ArrayOfOrderAttribute");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.OrderAttribute[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "OrderAttribute");
            qName2 = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "OrderAttribute");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ArrayOfOrderChange");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.OrderChange[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "OrderChange");
            qName2 = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "OrderChange");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ArrayOfPartnerTag");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.PartnerTag[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "PartnerTag");
            qName2 = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "PartnerTag");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ArrayOfSANVettingStatus");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.SANVettingStatus[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "SANVettingStatus");
            qName2 = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "SANVettingStatus");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ArrayOfString");
            cachedSerQNames.add(qName);
            cls = java.lang.String[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string");
            qName2 = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "String");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ArrayOfVulnerability");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.Vulnerability[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Vulnerability");
            qName2 = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Vulnerability");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "AuthData");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.AuthData.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "AuthDataStatus");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.AuthDataStatus.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "AuthenticationComment");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.AuthenticationComment.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "AuthenticationStatus");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.AuthenticationStatus.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "AuthOrderDataStatus");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.AuthOrderDataStatus.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "AuthOrderInput");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.AuthOrderInput.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "AuthOrderOutput");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.AuthOrderOutput.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "AuthOrderParameters");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.AuthOrderParameters.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "AuthStatus");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.AuthStatus.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "authToken");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.AuthToken.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "CAAEntry");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.CAAEntry.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "CACertificate");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.CACertificate.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "CertificateDetail");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.CertificateDetail.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "certificateInfo");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.CertificateInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "CertTransparency");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.CertTransparency.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ChangeApproverEmailInput");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.ChangeApproverEmailInput.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ChangeApproverEmailOutput");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.ChangeApproverEmailOutput.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Contact");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.Contact.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ContactPair");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.ContactPair.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ContactPairAuthStatus");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.ContactPairAuthStatus.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "CPUpgradeParameters");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.CPUpgradeParameters.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "creditCardInfo");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.CreditCardInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "creditCardsAllowed");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.CreditCardsAllowed.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "cuInfo");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.CuInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "CustomField");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.CustomField.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "DNSAuthDVDetails");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.DNSAuthDVDetails.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "DNSAuthDVInfo");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.DNSAuthDVInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "DNSRecord");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.DNSRecord.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Domain");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.Domain.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "DomainAuthStatus");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.DomainAuthStatus.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Error");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.Error.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "fileAuthDVDetails");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.FileAuthDVDetails.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "fileAuthDVInfo");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.FileAuthDVInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "fulfillment");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.Fulfillment.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "gatewayInfo");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.GatewayInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "InfectedPage");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.InfectedPage.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "InviteDetail");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.InviteDetail.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "LocalTradingName");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.LocalTradingName.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "malwareScanReport");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.MalwareScanReport.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "merchantAccountInfo");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.MerchantAccountInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "merchantAdminContact");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.MerchantAdminContact.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "merchantBillingContact");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.MerchantBillingContact.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "merchantData");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.MerchantData.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "merchantTechContact");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.MerchantTechContact.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ModificationEvent");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.ModificationEvent.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ModifyOrderInput");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.ModifyOrderInput.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ModifyOrderOutput");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.ModifyOrderOutput.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "operationData");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.OperationData.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "OrderAttribute");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.OrderAttribute.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "OrderChange");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.OrderChange.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "orderContacts");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.OrderContacts.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "OrderDetail");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.OrderDetail.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "orderInfo");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.OrderInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "orderParameters");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.OrderParameters.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "orderRequestHeader");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.OrderRequestHeader.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "orderResponseHeader");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.OrderResponseHeader.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "OrderStateReason");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.OrderStateReason.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "orderStatusMinor");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.OrderStatusMinor.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "organizationAddress");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.OrganizationAddress.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "OrganizationAuthStatus");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.OrganizationAuthStatus.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "organizationInfo");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.OrganizationInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "parsedCSR");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.ParsedCSR.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "PartnerTag");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.PartnerTag.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "paymentInfo");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.PaymentInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Pin1Request");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.Pin1Request.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "QuickInviteInput");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.QuickInviteInput.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "QuickInviteOutput");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.QuickInviteOutput.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "quickOrderDetail");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.QuickOrderDetail.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "QuickOrderInput");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.QuickOrderInput.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "QuickOrderOutput");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.QuickOrderOutput.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "quickPaymentsOrderInfo");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.QuickPaymentsOrderInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "QuickPaymentsOrderInput");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.QuickPaymentsOrderInput.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "QuickPaymentsOrderOutput");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.QuickPaymentsOrderOutput.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "quickPaymentsResponse");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.QuickPaymentsResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ReissueInput");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.ReissueInput.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ReissueOutput");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.ReissueOutput.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "renewalInfo");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.RenewalInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ResendEmailInput");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.ResendEmailInput.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

    }
    private void addBindings1() {
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ResendEmailOutput");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.ResendEmailOutput.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "RevokeInput");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.RevokeInput.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "RevokeOutput");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.RevokeOutput.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "SANVettingStatus");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.SANVettingStatus.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "TCInviteInput");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.TCInviteInput.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "TCInviteOutput");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.TCInviteOutput.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "TCOrderDetail");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.TCOrderDetail.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "TCOrderInput");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.TCOrderInput.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "TCOrderOutput");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.TCOrderOutput.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "TCOrderParameters");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.TCOrderParameters.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "TrialDetails");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.TrialDetails.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "trueOrderDetail");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.TrueOrderDetail.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "TrueOrderInput");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.TrueOrderInput.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "TrueSiteOrderInput");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.TrueSiteOrderInput.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "TrueSiteOrderOutput");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.TrueSiteOrderOutput.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "trueSiteOrderParameters");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.TrueSiteOrderParameters.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "trustServicesDetails");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.TrustServicesDetails.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ValidateAuthDataInput");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.ValidateAuthDataInput.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ValidateAuthDataOutput");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.ValidateAuthDataOutput.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ValidateOrderParametersInput");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.ValidateOrderParametersInput.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ValidateOrderParametersOutput");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.ValidateOrderParametersOutput.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "validationParameters");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.ValidationParameters.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Vulnerability");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.Vulnerability.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "vulnerabilityScanDetails");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.VulnerabilityScanDetails.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "vulnerabilityScanInfo");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.VulnerabilityScanInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "vulnerabilityScanPreferences");
            cachedSerQNames.add(qName);
            cls = com.geotrust.api.webtrust.order.VulnerabilityScanPreferences.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

    }

    protected org.apache.axis.client.Call createCall() throws java.rmi.RemoteException {
        try {
            org.apache.axis.client.Call _call = super._createCall();
            if (super.maintainSessionSet) {
                _call.setMaintainSession(super.maintainSession);
            }
            if (super.cachedUsername != null) {
                _call.setUsername(super.cachedUsername);
            }
            if (super.cachedPassword != null) {
                _call.setPassword(super.cachedPassword);
            }
            if (super.cachedEndpoint != null) {
                _call.setTargetEndpointAddress(super.cachedEndpoint);
            }
            if (super.cachedTimeout != null) {
                _call.setTimeout(super.cachedTimeout);
            }
            if (super.cachedPortName != null) {
                _call.setPortName(super.cachedPortName);
            }
            java.util.Enumeration keys = super.cachedProperties.keys();
            while (keys.hasMoreElements()) {
                java.lang.String key = (java.lang.String) keys.nextElement();
                _call.setProperty(key, super.cachedProperties.get(key));
            }
            // All the type mapping information is registered
            // when the first call is made.
            // The type mapping information is actually registered in
            // the TypeMappingRegistry of the service, which
            // is the reason why registration is only needed for the first call.
            synchronized (this) {
                if (firstCall()) {
                    // must set encoding style before registering serializers
                    _call.setEncodingStyle(null);
                    for (int i = 0; i < cachedSerFactories.size(); ++i) {
                        java.lang.Class cls = (java.lang.Class) cachedSerClasses.get(i);
                        javax.xml.namespace.QName qName =
                                (javax.xml.namespace.QName) cachedSerQNames.get(i);
                        java.lang.Object x = cachedSerFactories.get(i);
                        if (x instanceof Class) {
                            java.lang.Class sf = (java.lang.Class)
                                 cachedSerFactories.get(i);
                            java.lang.Class df = (java.lang.Class)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                        else if (x instanceof javax.xml.rpc.encoding.SerializerFactory) {
                            org.apache.axis.encoding.SerializerFactory sf = (org.apache.axis.encoding.SerializerFactory)
                                 cachedSerFactories.get(i);
                            org.apache.axis.encoding.DeserializerFactory df = (org.apache.axis.encoding.DeserializerFactory)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                    }
                }
            }
            return _call;
        }
        catch (java.lang.Throwable _t) {
            throw new org.apache.axis.AxisFault("Failure trying to get the Call object", _t);
        }
    }

    public com.geotrust.api.webtrust.order.ModifyOrderOutput modifyOrder(com.geotrust.api.webtrust.order.ModifyOrderInput request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[0]);
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ModifyOrder"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.geotrust.api.webtrust.order.ModifyOrderOutput) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.geotrust.api.webtrust.order.ModifyOrderOutput) org.apache.axis.utils.JavaUtils.convert(_resp, com.geotrust.api.webtrust.order.ModifyOrderOutput.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public java.lang.String[] showReplayTokens(java.lang.String partnerCode) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[1]);
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ShowReplayTokens"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {partnerCode});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (java.lang.String[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (java.lang.String[]) org.apache.axis.utils.JavaUtils.convert(_resp, java.lang.String[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.geotrust.api.webtrust.order.QuickOrderOutput quickOrder(com.geotrust.api.webtrust.order.QuickOrderInput request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[2]);
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "QuickOrder"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.geotrust.api.webtrust.order.QuickOrderOutput) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.geotrust.api.webtrust.order.QuickOrderOutput) org.apache.axis.utils.JavaUtils.convert(_resp, com.geotrust.api.webtrust.order.QuickOrderOutput.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.geotrust.api.webtrust.order.TCOrderOutput TCOrder(com.geotrust.api.webtrust.order.TCOrderInput request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[3]);
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "TCOrder"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.geotrust.api.webtrust.order.TCOrderOutput) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.geotrust.api.webtrust.order.TCOrderOutput) org.apache.axis.utils.JavaUtils.convert(_resp, com.geotrust.api.webtrust.order.TCOrderOutput.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.geotrust.api.webtrust.order.RevokeOutput revoke(com.geotrust.api.webtrust.order.RevokeInput request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[4]);
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Revoke"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.geotrust.api.webtrust.order.RevokeOutput) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.geotrust.api.webtrust.order.RevokeOutput) org.apache.axis.utils.JavaUtils.convert(_resp, com.geotrust.api.webtrust.order.RevokeOutput.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.geotrust.api.webtrust.order.QuickInviteOutput quickInvite(com.geotrust.api.webtrust.order.QuickInviteInput request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[5]);
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "QuickInvite"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.geotrust.api.webtrust.order.QuickInviteOutput) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.geotrust.api.webtrust.order.QuickInviteOutput) org.apache.axis.utils.JavaUtils.convert(_resp, com.geotrust.api.webtrust.order.QuickInviteOutput.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.geotrust.api.webtrust.order.ValidateAuthDataOutput validatePreAuthenticationData(com.geotrust.api.webtrust.order.ValidateAuthDataInput validateAuthDataRequest) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[6]);
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ValidatePreAuthenticationData"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {validateAuthDataRequest});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.geotrust.api.webtrust.order.ValidateAuthDataOutput) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.geotrust.api.webtrust.order.ValidateAuthDataOutput) org.apache.axis.utils.JavaUtils.convert(_resp, com.geotrust.api.webtrust.order.ValidateAuthDataOutput.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.geotrust.api.webtrust.order.QuickPaymentsOrderOutput quickPaymentsOrder(com.geotrust.api.webtrust.order.QuickPaymentsOrderInput request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[7]);
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "QuickPaymentsOrder"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.geotrust.api.webtrust.order.QuickPaymentsOrderOutput) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.geotrust.api.webtrust.order.QuickPaymentsOrderOutput) org.apache.axis.utils.JavaUtils.convert(_resp, com.geotrust.api.webtrust.order.QuickPaymentsOrderOutput.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.geotrust.api.webtrust.order.ValidateOrderParametersOutput validateOrderParameters(com.geotrust.api.webtrust.order.ValidateOrderParametersInput request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[8]);
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ValidateOrderParameters"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.geotrust.api.webtrust.order.ValidateOrderParametersOutput) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.geotrust.api.webtrust.order.ValidateOrderParametersOutput) org.apache.axis.utils.JavaUtils.convert(_resp, com.geotrust.api.webtrust.order.ValidateOrderParametersOutput.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.geotrust.api.webtrust.order.TrueSiteOrderOutput trueSiteOrder(com.geotrust.api.webtrust.order.TrueSiteOrderInput request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[9]);
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "TrueSiteOrder"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.geotrust.api.webtrust.order.TrueSiteOrderOutput) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.geotrust.api.webtrust.order.TrueSiteOrderOutput) org.apache.axis.utils.JavaUtils.convert(_resp, com.geotrust.api.webtrust.order.TrueSiteOrderOutput.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.geotrust.api.webtrust.order.TCInviteOutput TCInvite(com.geotrust.api.webtrust.order.TCInviteInput request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[10]);
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "TCInvite"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.geotrust.api.webtrust.order.TCInviteOutput) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.geotrust.api.webtrust.order.TCInviteOutput) org.apache.axis.utils.JavaUtils.convert(_resp, com.geotrust.api.webtrust.order.TCInviteOutput.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.geotrust.api.webtrust.order.ChangeApproverEmailOutput changeApproverEmail(com.geotrust.api.webtrust.order.ChangeApproverEmailInput request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[11]);
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ChangeApproverEmail"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.geotrust.api.webtrust.order.ChangeApproverEmailOutput) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.geotrust.api.webtrust.order.ChangeApproverEmailOutput) org.apache.axis.utils.JavaUtils.convert(_resp, com.geotrust.api.webtrust.order.ChangeApproverEmailOutput.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.geotrust.api.webtrust.order.ResendEmailOutput resendEmail(com.geotrust.api.webtrust.order.ResendEmailInput request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[12]);
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ResendEmail"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.geotrust.api.webtrust.order.ResendEmailOutput) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.geotrust.api.webtrust.order.ResendEmailOutput) org.apache.axis.utils.JavaUtils.convert(_resp, com.geotrust.api.webtrust.order.ResendEmailOutput.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.geotrust.api.webtrust.order.ReissueOutput reissue(com.geotrust.api.webtrust.order.ReissueInput request) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[13]);
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Reissue"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {request});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.geotrust.api.webtrust.order.ReissueOutput) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.geotrust.api.webtrust.order.ReissueOutput) org.apache.axis.utils.JavaUtils.convert(_resp, com.geotrust.api.webtrust.order.ReissueOutput.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.geotrust.api.webtrust.order.AuthOrderOutput orderPreAuthentication(com.geotrust.api.webtrust.order.AuthOrderInput authOrderRequest) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[14]);
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "OrderPreAuthentication"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {authOrderRequest});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.geotrust.api.webtrust.order.AuthOrderOutput) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.geotrust.api.webtrust.order.AuthOrderOutput) org.apache.axis.utils.JavaUtils.convert(_resp, com.geotrust.api.webtrust.order.AuthOrderOutput.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

}
