package com.geotrust.api.webtrust.order;


public class OrderSoapProxy implements com.geotrust.api.webtrust.order.OrderSoap {
  private String _endpoint = null;
  private com.geotrust.api.webtrust.order.OrderSoap orderSoap = null;
  
  public OrderSoapProxy() {
    _initOrderSoapProxy();
  }
  
  public OrderSoapProxy(String endpoint) {
    _endpoint = endpoint;
    _initOrderSoapProxy();
  }
  
  private void _initOrderSoapProxy() {
    try {
      orderSoap = (new com.geotrust.api.webtrust.order.OrderLocator()).getorderSoap();
      if (orderSoap != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)orderSoap)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)orderSoap)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (orderSoap != null)
      ((javax.xml.rpc.Stub)orderSoap)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.geotrust.api.webtrust.order.OrderSoap getOrderSoap() {
    if (orderSoap == null)
      _initOrderSoapProxy();
    return orderSoap;
  }
  
  public com.geotrust.api.webtrust.order.ModifyOrderOutput modifyOrder(com.geotrust.api.webtrust.order.ModifyOrderInput request) throws java.rmi.RemoteException{
    if (orderSoap == null)
      _initOrderSoapProxy();
    return orderSoap.modifyOrder(request);
  }
  
  public java.lang.String[] showReplayTokens(java.lang.String partnerCode) throws java.rmi.RemoteException{
    if (orderSoap == null)
      _initOrderSoapProxy();
    return orderSoap.showReplayTokens(partnerCode);
  }
  
  public com.geotrust.api.webtrust.order.QuickOrderOutput quickOrder(com.geotrust.api.webtrust.order.QuickOrderInput request) throws java.rmi.RemoteException{
    if (orderSoap == null)
      _initOrderSoapProxy();
    return orderSoap.quickOrder(request);
  }
  
  public com.geotrust.api.webtrust.order.TCOrderOutput TCOrder(com.geotrust.api.webtrust.order.TCOrderInput request) throws java.rmi.RemoteException{
    if (orderSoap == null)
      _initOrderSoapProxy();
    return orderSoap.TCOrder(request);
  }
  
  public com.geotrust.api.webtrust.order.RevokeOutput revoke(com.geotrust.api.webtrust.order.RevokeInput request) throws java.rmi.RemoteException{
    if (orderSoap == null)
      _initOrderSoapProxy();
    return orderSoap.revoke(request);
  }
  
  public com.geotrust.api.webtrust.order.QuickInviteOutput quickInvite(com.geotrust.api.webtrust.order.QuickInviteInput request) throws java.rmi.RemoteException{
    if (orderSoap == null)
      _initOrderSoapProxy();
    return orderSoap.quickInvite(request);
  }
  
  public com.geotrust.api.webtrust.order.ValidateAuthDataOutput validatePreAuthenticationData(com.geotrust.api.webtrust.order.ValidateAuthDataInput validateAuthDataRequest) throws java.rmi.RemoteException{
    if (orderSoap == null)
      _initOrderSoapProxy();
    return orderSoap.validatePreAuthenticationData(validateAuthDataRequest);
  }
  
  public com.geotrust.api.webtrust.order.QuickPaymentsOrderOutput quickPaymentsOrder(com.geotrust.api.webtrust.order.QuickPaymentsOrderInput request) throws java.rmi.RemoteException{
    if (orderSoap == null)
      _initOrderSoapProxy();
    return orderSoap.quickPaymentsOrder(request);
  }
  
  public com.geotrust.api.webtrust.order.ValidateOrderParametersOutput validateOrderParameters(com.geotrust.api.webtrust.order.ValidateOrderParametersInput request) throws java.rmi.RemoteException{
    if (orderSoap == null)
      _initOrderSoapProxy();
    return orderSoap.validateOrderParameters(request);
  }
  
  public com.geotrust.api.webtrust.order.TrueSiteOrderOutput trueSiteOrder(com.geotrust.api.webtrust.order.TrueSiteOrderInput request) throws java.rmi.RemoteException{
    if (orderSoap == null)
      _initOrderSoapProxy();
    return orderSoap.trueSiteOrder(request);
  }
  
  public com.geotrust.api.webtrust.order.TCInviteOutput TCInvite(com.geotrust.api.webtrust.order.TCInviteInput request) throws java.rmi.RemoteException{
    if (orderSoap == null)
      _initOrderSoapProxy();
    return orderSoap.TCInvite(request);
  }
  
  public com.geotrust.api.webtrust.order.ChangeApproverEmailOutput changeApproverEmail(com.geotrust.api.webtrust.order.ChangeApproverEmailInput request) throws java.rmi.RemoteException{
    if (orderSoap == null)
      _initOrderSoapProxy();
    return orderSoap.changeApproverEmail(request);
  }
  
  public com.geotrust.api.webtrust.order.ResendEmailOutput resendEmail(com.geotrust.api.webtrust.order.ResendEmailInput request) throws java.rmi.RemoteException{
    if (orderSoap == null)
      _initOrderSoapProxy();
    return orderSoap.resendEmail(request);
  }
  
  public com.geotrust.api.webtrust.order.ReissueOutput reissue(com.geotrust.api.webtrust.order.ReissueInput request) throws java.rmi.RemoteException{
    if (orderSoap == null)
      _initOrderSoapProxy();
    return orderSoap.reissue(request);
  }
  
  public com.geotrust.api.webtrust.order.AuthOrderOutput orderPreAuthentication(com.geotrust.api.webtrust.order.AuthOrderInput authOrderRequest) throws java.rmi.RemoteException{
    if (orderSoap == null)
      _initOrderSoapProxy();
    return orderSoap.orderPreAuthentication(authOrderRequest);
  }
  
  
}