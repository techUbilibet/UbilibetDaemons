/**
 * MerchantData.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.order;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class MerchantData  implements java.io.Serializable {
    private java.lang.String business_name;

    private java.lang.String business_legalname;

    private java.lang.String business_address;

    private java.lang.String business_city;

    private java.lang.String business_state;

    private java.lang.String business_zip;

    private java.lang.String business_country;

    private java.lang.String business_phone;

    private java.lang.String business_fax;

    private java.lang.String website_url;

    private java.lang.String DUNS;

    public MerchantData() {
    }

    public MerchantData(
           java.lang.String business_name,
           java.lang.String business_legalname,
           java.lang.String business_address,
           java.lang.String business_city,
           java.lang.String business_state,
           java.lang.String business_zip,
           java.lang.String business_country,
           java.lang.String business_phone,
           java.lang.String business_fax,
           java.lang.String website_url,
           java.lang.String DUNS) {
           this.business_name = business_name;
           this.business_legalname = business_legalname;
           this.business_address = business_address;
           this.business_city = business_city;
           this.business_state = business_state;
           this.business_zip = business_zip;
           this.business_country = business_country;
           this.business_phone = business_phone;
           this.business_fax = business_fax;
           this.website_url = website_url;
           this.DUNS = DUNS;
    }


    /**
     * Gets the business_name value for this MerchantData.
     * 
     * @return business_name
     */
    public java.lang.String getBusiness_name() {
        return business_name;
    }


    /**
     * Sets the business_name value for this MerchantData.
     * 
     * @param business_name
     */
    public void setBusiness_name(java.lang.String business_name) {
        this.business_name = business_name;
    }


    /**
     * Gets the business_legalname value for this MerchantData.
     * 
     * @return business_legalname
     */
    public java.lang.String getBusiness_legalname() {
        return business_legalname;
    }


    /**
     * Sets the business_legalname value for this MerchantData.
     * 
     * @param business_legalname
     */
    public void setBusiness_legalname(java.lang.String business_legalname) {
        this.business_legalname = business_legalname;
    }


    /**
     * Gets the business_address value for this MerchantData.
     * 
     * @return business_address
     */
    public java.lang.String getBusiness_address() {
        return business_address;
    }


    /**
     * Sets the business_address value for this MerchantData.
     * 
     * @param business_address
     */
    public void setBusiness_address(java.lang.String business_address) {
        this.business_address = business_address;
    }


    /**
     * Gets the business_city value for this MerchantData.
     * 
     * @return business_city
     */
    public java.lang.String getBusiness_city() {
        return business_city;
    }


    /**
     * Sets the business_city value for this MerchantData.
     * 
     * @param business_city
     */
    public void setBusiness_city(java.lang.String business_city) {
        this.business_city = business_city;
    }


    /**
     * Gets the business_state value for this MerchantData.
     * 
     * @return business_state
     */
    public java.lang.String getBusiness_state() {
        return business_state;
    }


    /**
     * Sets the business_state value for this MerchantData.
     * 
     * @param business_state
     */
    public void setBusiness_state(java.lang.String business_state) {
        this.business_state = business_state;
    }


    /**
     * Gets the business_zip value for this MerchantData.
     * 
     * @return business_zip
     */
    public java.lang.String getBusiness_zip() {
        return business_zip;
    }


    /**
     * Sets the business_zip value for this MerchantData.
     * 
     * @param business_zip
     */
    public void setBusiness_zip(java.lang.String business_zip) {
        this.business_zip = business_zip;
    }


    /**
     * Gets the business_country value for this MerchantData.
     * 
     * @return business_country
     */
    public java.lang.String getBusiness_country() {
        return business_country;
    }


    /**
     * Sets the business_country value for this MerchantData.
     * 
     * @param business_country
     */
    public void setBusiness_country(java.lang.String business_country) {
        this.business_country = business_country;
    }


    /**
     * Gets the business_phone value for this MerchantData.
     * 
     * @return business_phone
     */
    public java.lang.String getBusiness_phone() {
        return business_phone;
    }


    /**
     * Sets the business_phone value for this MerchantData.
     * 
     * @param business_phone
     */
    public void setBusiness_phone(java.lang.String business_phone) {
        this.business_phone = business_phone;
    }


    /**
     * Gets the business_fax value for this MerchantData.
     * 
     * @return business_fax
     */
    public java.lang.String getBusiness_fax() {
        return business_fax;
    }


    /**
     * Sets the business_fax value for this MerchantData.
     * 
     * @param business_fax
     */
    public void setBusiness_fax(java.lang.String business_fax) {
        this.business_fax = business_fax;
    }


    /**
     * Gets the website_url value for this MerchantData.
     * 
     * @return website_url
     */
    public java.lang.String getWebsite_url() {
        return website_url;
    }


    /**
     * Sets the website_url value for this MerchantData.
     * 
     * @param website_url
     */
    public void setWebsite_url(java.lang.String website_url) {
        this.website_url = website_url;
    }


    /**
     * Gets the DUNS value for this MerchantData.
     * 
     * @return DUNS
     */
    public java.lang.String getDUNS() {
        return DUNS;
    }


    /**
     * Sets the DUNS value for this MerchantData.
     * 
     * @param DUNS
     */
    public void setDUNS(java.lang.String DUNS) {
        this.DUNS = DUNS;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof MerchantData)) return false;
        MerchantData other = (MerchantData) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.business_name==null && other.getBusiness_name()==null) || 
             (this.business_name!=null &&
              this.business_name.equals(other.getBusiness_name()))) &&
            ((this.business_legalname==null && other.getBusiness_legalname()==null) || 
             (this.business_legalname!=null &&
              this.business_legalname.equals(other.getBusiness_legalname()))) &&
            ((this.business_address==null && other.getBusiness_address()==null) || 
             (this.business_address!=null &&
              this.business_address.equals(other.getBusiness_address()))) &&
            ((this.business_city==null && other.getBusiness_city()==null) || 
             (this.business_city!=null &&
              this.business_city.equals(other.getBusiness_city()))) &&
            ((this.business_state==null && other.getBusiness_state()==null) || 
             (this.business_state!=null &&
              this.business_state.equals(other.getBusiness_state()))) &&
            ((this.business_zip==null && other.getBusiness_zip()==null) || 
             (this.business_zip!=null &&
              this.business_zip.equals(other.getBusiness_zip()))) &&
            ((this.business_country==null && other.getBusiness_country()==null) || 
             (this.business_country!=null &&
              this.business_country.equals(other.getBusiness_country()))) &&
            ((this.business_phone==null && other.getBusiness_phone()==null) || 
             (this.business_phone!=null &&
              this.business_phone.equals(other.getBusiness_phone()))) &&
            ((this.business_fax==null && other.getBusiness_fax()==null) || 
             (this.business_fax!=null &&
              this.business_fax.equals(other.getBusiness_fax()))) &&
            ((this.website_url==null && other.getWebsite_url()==null) || 
             (this.website_url!=null &&
              this.website_url.equals(other.getWebsite_url()))) &&
            ((this.DUNS==null && other.getDUNS()==null) || 
             (this.DUNS!=null &&
              this.DUNS.equals(other.getDUNS())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getBusiness_name() != null) {
            _hashCode += getBusiness_name().hashCode();
        }
        if (getBusiness_legalname() != null) {
            _hashCode += getBusiness_legalname().hashCode();
        }
        if (getBusiness_address() != null) {
            _hashCode += getBusiness_address().hashCode();
        }
        if (getBusiness_city() != null) {
            _hashCode += getBusiness_city().hashCode();
        }
        if (getBusiness_state() != null) {
            _hashCode += getBusiness_state().hashCode();
        }
        if (getBusiness_zip() != null) {
            _hashCode += getBusiness_zip().hashCode();
        }
        if (getBusiness_country() != null) {
            _hashCode += getBusiness_country().hashCode();
        }
        if (getBusiness_phone() != null) {
            _hashCode += getBusiness_phone().hashCode();
        }
        if (getBusiness_fax() != null) {
            _hashCode += getBusiness_fax().hashCode();
        }
        if (getWebsite_url() != null) {
            _hashCode += getWebsite_url().hashCode();
        }
        if (getDUNS() != null) {
            _hashCode += getDUNS().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(MerchantData.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "merchantData"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("business_name");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "business_name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("business_legalname");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "business_legalname"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("business_address");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "business_address"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("business_city");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "business_city"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("business_state");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "business_state"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("business_zip");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "business_zip"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("business_country");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "business_country"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("business_phone");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "business_phone"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("business_fax");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "business_fax"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("website_url");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "website_url"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DUNS");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "DUNS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
