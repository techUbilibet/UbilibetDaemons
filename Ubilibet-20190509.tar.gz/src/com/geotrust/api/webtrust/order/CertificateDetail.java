/**
 * CertificateDetail.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.order;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class CertificateDetail  implements java.io.Serializable {
    private com.geotrust.api.webtrust.order.CertificateInfo certificateInfo;

    private com.geotrust.api.webtrust.order.Fulfillment fulfillment;

    public CertificateDetail() {
    }

    public CertificateDetail(
           com.geotrust.api.webtrust.order.CertificateInfo certificateInfo,
           com.geotrust.api.webtrust.order.Fulfillment fulfillment) {
           this.certificateInfo = certificateInfo;
           this.fulfillment = fulfillment;
    }


    /**
     * Gets the certificateInfo value for this CertificateDetail.
     * 
     * @return certificateInfo
     */
    public com.geotrust.api.webtrust.order.CertificateInfo getCertificateInfo() {
        return certificateInfo;
    }


    /**
     * Sets the certificateInfo value for this CertificateDetail.
     * 
     * @param certificateInfo
     */
    public void setCertificateInfo(com.geotrust.api.webtrust.order.CertificateInfo certificateInfo) {
        this.certificateInfo = certificateInfo;
    }


    /**
     * Gets the fulfillment value for this CertificateDetail.
     * 
     * @return fulfillment
     */
    public com.geotrust.api.webtrust.order.Fulfillment getFulfillment() {
        return fulfillment;
    }


    /**
     * Sets the fulfillment value for this CertificateDetail.
     * 
     * @param fulfillment
     */
    public void setFulfillment(com.geotrust.api.webtrust.order.Fulfillment fulfillment) {
        this.fulfillment = fulfillment;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CertificateDetail)) return false;
        CertificateDetail other = (CertificateDetail) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.certificateInfo==null && other.getCertificateInfo()==null) || 
             (this.certificateInfo!=null &&
              this.certificateInfo.equals(other.getCertificateInfo()))) &&
            ((this.fulfillment==null && other.getFulfillment()==null) || 
             (this.fulfillment!=null &&
              this.fulfillment.equals(other.getFulfillment())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCertificateInfo() != null) {
            _hashCode += getCertificateInfo().hashCode();
        }
        if (getFulfillment() != null) {
            _hashCode += getFulfillment().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CertificateDetail.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "CertificateDetail"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("certificateInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "CertificateInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "certificateInfo"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fulfillment");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Fulfillment"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "fulfillment"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
