/**
 * QuickOrderDetail.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.order;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class QuickOrderDetail  implements java.io.Serializable {
    private com.geotrust.api.webtrust.order.OrderStatusMinor orderStatusMinor;

    private com.geotrust.api.webtrust.order.OrganizationInfo organizationInfo;

    private java.util.Calendar approverNotifiedDate;

    private java.util.Calendar approverConfirmDate;

    private java.lang.String approverEmailAddress;

    public QuickOrderDetail() {
    }

    public QuickOrderDetail(
           com.geotrust.api.webtrust.order.OrderStatusMinor orderStatusMinor,
           com.geotrust.api.webtrust.order.OrganizationInfo organizationInfo,
           java.util.Calendar approverNotifiedDate,
           java.util.Calendar approverConfirmDate,
           java.lang.String approverEmailAddress) {
           this.orderStatusMinor = orderStatusMinor;
           this.organizationInfo = organizationInfo;
           this.approverNotifiedDate = approverNotifiedDate;
           this.approverConfirmDate = approverConfirmDate;
           this.approverEmailAddress = approverEmailAddress;
    }


    /**
     * Gets the orderStatusMinor value for this QuickOrderDetail.
     * 
     * @return orderStatusMinor
     */
    public com.geotrust.api.webtrust.order.OrderStatusMinor getOrderStatusMinor() {
        return orderStatusMinor;
    }


    /**
     * Sets the orderStatusMinor value for this QuickOrderDetail.
     * 
     * @param orderStatusMinor
     */
    public void setOrderStatusMinor(com.geotrust.api.webtrust.order.OrderStatusMinor orderStatusMinor) {
        this.orderStatusMinor = orderStatusMinor;
    }


    /**
     * Gets the organizationInfo value for this QuickOrderDetail.
     * 
     * @return organizationInfo
     */
    public com.geotrust.api.webtrust.order.OrganizationInfo getOrganizationInfo() {
        return organizationInfo;
    }


    /**
     * Sets the organizationInfo value for this QuickOrderDetail.
     * 
     * @param organizationInfo
     */
    public void setOrganizationInfo(com.geotrust.api.webtrust.order.OrganizationInfo organizationInfo) {
        this.organizationInfo = organizationInfo;
    }


    /**
     * Gets the approverNotifiedDate value for this QuickOrderDetail.
     * 
     * @return approverNotifiedDate
     */
    public java.util.Calendar getApproverNotifiedDate() {
        return approverNotifiedDate;
    }


    /**
     * Sets the approverNotifiedDate value for this QuickOrderDetail.
     * 
     * @param approverNotifiedDate
     */
    public void setApproverNotifiedDate(java.util.Calendar approverNotifiedDate) {
        this.approverNotifiedDate = approverNotifiedDate;
    }


    /**
     * Gets the approverConfirmDate value for this QuickOrderDetail.
     * 
     * @return approverConfirmDate
     */
    public java.util.Calendar getApproverConfirmDate() {
        return approverConfirmDate;
    }


    /**
     * Sets the approverConfirmDate value for this QuickOrderDetail.
     * 
     * @param approverConfirmDate
     */
    public void setApproverConfirmDate(java.util.Calendar approverConfirmDate) {
        this.approverConfirmDate = approverConfirmDate;
    }


    /**
     * Gets the approverEmailAddress value for this QuickOrderDetail.
     * 
     * @return approverEmailAddress
     */
    public java.lang.String getApproverEmailAddress() {
        return approverEmailAddress;
    }


    /**
     * Sets the approverEmailAddress value for this QuickOrderDetail.
     * 
     * @param approverEmailAddress
     */
    public void setApproverEmailAddress(java.lang.String approverEmailAddress) {
        this.approverEmailAddress = approverEmailAddress;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof QuickOrderDetail)) return false;
        QuickOrderDetail other = (QuickOrderDetail) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.orderStatusMinor==null && other.getOrderStatusMinor()==null) || 
             (this.orderStatusMinor!=null &&
              this.orderStatusMinor.equals(other.getOrderStatusMinor()))) &&
            ((this.organizationInfo==null && other.getOrganizationInfo()==null) || 
             (this.organizationInfo!=null &&
              this.organizationInfo.equals(other.getOrganizationInfo()))) &&
            ((this.approverNotifiedDate==null && other.getApproverNotifiedDate()==null) || 
             (this.approverNotifiedDate!=null &&
              this.approverNotifiedDate.equals(other.getApproverNotifiedDate()))) &&
            ((this.approverConfirmDate==null && other.getApproverConfirmDate()==null) || 
             (this.approverConfirmDate!=null &&
              this.approverConfirmDate.equals(other.getApproverConfirmDate()))) &&
            ((this.approverEmailAddress==null && other.getApproverEmailAddress()==null) || 
             (this.approverEmailAddress!=null &&
              this.approverEmailAddress.equals(other.getApproverEmailAddress())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getOrderStatusMinor() != null) {
            _hashCode += getOrderStatusMinor().hashCode();
        }
        if (getOrganizationInfo() != null) {
            _hashCode += getOrganizationInfo().hashCode();
        }
        if (getApproverNotifiedDate() != null) {
            _hashCode += getApproverNotifiedDate().hashCode();
        }
        if (getApproverConfirmDate() != null) {
            _hashCode += getApproverConfirmDate().hashCode();
        }
        if (getApproverEmailAddress() != null) {
            _hashCode += getApproverEmailAddress().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(QuickOrderDetail.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "quickOrderDetail"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderStatusMinor");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "OrderStatusMinor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "orderStatusMinor"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("organizationInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "OrganizationInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "organizationInfo"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("approverNotifiedDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ApproverNotifiedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("approverConfirmDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ApproverConfirmDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("approverEmailAddress");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ApproverEmailAddress"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
