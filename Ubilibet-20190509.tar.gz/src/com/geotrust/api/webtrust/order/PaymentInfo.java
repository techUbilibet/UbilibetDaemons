/**
 * PaymentInfo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.order;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class PaymentInfo  implements java.io.Serializable {
    private com.geotrust.api.webtrust.order.CreditCardInfo creditCardInfo;

    private java.lang.String coupon;

    private java.lang.String purchaseOrder;

    public PaymentInfo() {
    }

    public PaymentInfo(
           com.geotrust.api.webtrust.order.CreditCardInfo creditCardInfo,
           java.lang.String coupon,
           java.lang.String purchaseOrder) {
           this.creditCardInfo = creditCardInfo;
           this.coupon = coupon;
           this.purchaseOrder = purchaseOrder;
    }


    /**
     * Gets the creditCardInfo value for this PaymentInfo.
     * 
     * @return creditCardInfo
     */
    public com.geotrust.api.webtrust.order.CreditCardInfo getCreditCardInfo() {
        return creditCardInfo;
    }


    /**
     * Sets the creditCardInfo value for this PaymentInfo.
     * 
     * @param creditCardInfo
     */
    public void setCreditCardInfo(com.geotrust.api.webtrust.order.CreditCardInfo creditCardInfo) {
        this.creditCardInfo = creditCardInfo;
    }


    /**
     * Gets the coupon value for this PaymentInfo.
     * 
     * @return coupon
     */
    public java.lang.String getCoupon() {
        return coupon;
    }


    /**
     * Sets the coupon value for this PaymentInfo.
     * 
     * @param coupon
     */
    public void setCoupon(java.lang.String coupon) {
        this.coupon = coupon;
    }


    /**
     * Gets the purchaseOrder value for this PaymentInfo.
     * 
     * @return purchaseOrder
     */
    public java.lang.String getPurchaseOrder() {
        return purchaseOrder;
    }


    /**
     * Sets the purchaseOrder value for this PaymentInfo.
     * 
     * @param purchaseOrder
     */
    public void setPurchaseOrder(java.lang.String purchaseOrder) {
        this.purchaseOrder = purchaseOrder;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof PaymentInfo)) return false;
        PaymentInfo other = (PaymentInfo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.creditCardInfo==null && other.getCreditCardInfo()==null) || 
             (this.creditCardInfo!=null &&
              this.creditCardInfo.equals(other.getCreditCardInfo()))) &&
            ((this.coupon==null && other.getCoupon()==null) || 
             (this.coupon!=null &&
              this.coupon.equals(other.getCoupon()))) &&
            ((this.purchaseOrder==null && other.getPurchaseOrder()==null) || 
             (this.purchaseOrder!=null &&
              this.purchaseOrder.equals(other.getPurchaseOrder())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCreditCardInfo() != null) {
            _hashCode += getCreditCardInfo().hashCode();
        }
        if (getCoupon() != null) {
            _hashCode += getCoupon().hashCode();
        }
        if (getPurchaseOrder() != null) {
            _hashCode += getPurchaseOrder().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(PaymentInfo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "paymentInfo"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("creditCardInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "CreditCardInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "creditCardInfo"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("coupon");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Coupon"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("purchaseOrder");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "PurchaseOrder"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
