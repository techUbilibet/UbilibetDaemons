/**
 * AuthData.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.order;

@SuppressWarnings({ "serial", "unused", "rawtypes"})
public class AuthData  implements java.io.Serializable {
    private com.geotrust.api.webtrust.order.OrganizationInfo organizationInfo;

    private com.geotrust.api.webtrust.order.Domain[] domainInfo;

    private com.geotrust.api.webtrust.order.ContactPair[] contactInfo;

    public AuthData() {
    }

    public AuthData(
           com.geotrust.api.webtrust.order.OrganizationInfo organizationInfo,
           com.geotrust.api.webtrust.order.Domain[] domainInfo,
           com.geotrust.api.webtrust.order.ContactPair[] contactInfo) {
           this.organizationInfo = organizationInfo;
           this.domainInfo = domainInfo;
           this.contactInfo = contactInfo;
    }


    /**
     * Gets the organizationInfo value for this AuthData.
     * 
     * @return organizationInfo
     */
    public com.geotrust.api.webtrust.order.OrganizationInfo getOrganizationInfo() {
        return organizationInfo;
    }


    /**
     * Sets the organizationInfo value for this AuthData.
     * 
     * @param organizationInfo
     */
    public void setOrganizationInfo(com.geotrust.api.webtrust.order.OrganizationInfo organizationInfo) {
        this.organizationInfo = organizationInfo;
    }


    /**
     * Gets the domainInfo value for this AuthData.
     * 
     * @return domainInfo
     */
    public com.geotrust.api.webtrust.order.Domain[] getDomainInfo() {
        return domainInfo;
    }


    /**
     * Sets the domainInfo value for this AuthData.
     * 
     * @param domainInfo
     */
    public void setDomainInfo(com.geotrust.api.webtrust.order.Domain[] domainInfo) {
        this.domainInfo = domainInfo;
    }


    /**
     * Gets the contactInfo value for this AuthData.
     * 
     * @return contactInfo
     */
    public com.geotrust.api.webtrust.order.ContactPair[] getContactInfo() {
        return contactInfo;
    }


    /**
     * Sets the contactInfo value for this AuthData.
     * 
     * @param contactInfo
     */
    public void setContactInfo(com.geotrust.api.webtrust.order.ContactPair[] contactInfo) {
        this.contactInfo = contactInfo;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof AuthData)) return false;
        AuthData other = (AuthData) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.organizationInfo==null && other.getOrganizationInfo()==null) || 
             (this.organizationInfo!=null &&
              this.organizationInfo.equals(other.getOrganizationInfo()))) &&
            ((this.domainInfo==null && other.getDomainInfo()==null) || 
             (this.domainInfo!=null &&
              java.util.Arrays.equals(this.domainInfo, other.getDomainInfo()))) &&
            ((this.contactInfo==null && other.getContactInfo()==null) || 
             (this.contactInfo!=null &&
              java.util.Arrays.equals(this.contactInfo, other.getContactInfo())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getOrganizationInfo() != null) {
            _hashCode += getOrganizationInfo().hashCode();
        }
        if (getDomainInfo() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDomainInfo());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDomainInfo(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getContactInfo() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getContactInfo());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getContactInfo(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(AuthData.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "AuthData"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("organizationInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "OrganizationInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "organizationInfo"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("domainInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "DomainInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Domain"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Domain"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contactInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ContactInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ContactPair"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ContactPair"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
