/**
 * QuickOrderInput.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.order;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class QuickOrderInput  extends com.geotrust.api.webtrust.order.Pin1Request  implements java.io.Serializable {
    private java.lang.String approverEmail;

    public QuickOrderInput() {
    }

    public QuickOrderInput(
           com.geotrust.api.webtrust.order.OrderRequestHeader orderRequestHeader,
           com.geotrust.api.webtrust.order.OrganizationInfo organizationInfo,
           com.geotrust.api.webtrust.order.OrderParameters orderParameters,
           com.geotrust.api.webtrust.order.Contact adminContact,
           com.geotrust.api.webtrust.order.Contact techContact,
           com.geotrust.api.webtrust.order.Contact billingContact,
           com.geotrust.api.webtrust.order.PaymentInfo paymentInfo,
           com.geotrust.api.webtrust.order.PartnerTag[] partnerTags,
           java.lang.Integer inviteDuration,
           java.lang.Integer chainKeySize,
           java.lang.Integer reservedSanCount,
           java.lang.String approverEmail) {
        super(
            orderRequestHeader,
            organizationInfo,
            orderParameters,
            adminContact,
            techContact,
            billingContact,
            paymentInfo,
            partnerTags,
            inviteDuration,
            chainKeySize,
            reservedSanCount);
        this.approverEmail = approverEmail;
    }


    /**
     * Gets the approverEmail value for this QuickOrderInput.
     * 
     * @return approverEmail
     */
    public java.lang.String getApproverEmail() {
        return approverEmail;
    }


    /**
     * Sets the approverEmail value for this QuickOrderInput.
     * 
     * @param approverEmail
     */
    public void setApproverEmail(java.lang.String approverEmail) {
        this.approverEmail = approverEmail;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof QuickOrderInput)) return false;
        QuickOrderInput other = (QuickOrderInput) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.approverEmail==null && other.getApproverEmail()==null) || 
             (this.approverEmail!=null &&
              this.approverEmail.equals(other.getApproverEmail())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getApproverEmail() != null) {
            _hashCode += getApproverEmail().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(QuickOrderInput.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "QuickOrderInput"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("approverEmail");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ApproverEmail"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
