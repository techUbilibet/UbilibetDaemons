/**
 * ValidateOrderParametersOutput.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.order;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class ValidateOrderParametersOutput  implements java.io.Serializable {
    private com.geotrust.api.webtrust.order.OrderResponseHeader orderResponseHeader;

    private java.lang.String price;

    private int validityPeriod;

    private com.geotrust.api.webtrust.order.ParsedCSR parsedCSR;

    private com.geotrust.api.webtrust.order.CuInfo CUInfo;

    private com.geotrust.api.webtrust.order.RenewalInfo renewalInfo;

    private java.lang.String certificateSignatureHashAlgorithm;

    private java.lang.String japaneseOrderIndicator;

    private com.geotrust.api.webtrust.order.SANVettingStatus[] SANVettingStatuses;

    public ValidateOrderParametersOutput() {
    }

    public ValidateOrderParametersOutput(
           com.geotrust.api.webtrust.order.OrderResponseHeader orderResponseHeader,
           java.lang.String price,
           int validityPeriod,
           com.geotrust.api.webtrust.order.ParsedCSR parsedCSR,
           com.geotrust.api.webtrust.order.CuInfo CUInfo,
           com.geotrust.api.webtrust.order.RenewalInfo renewalInfo,
           java.lang.String certificateSignatureHashAlgorithm,
           java.lang.String japaneseOrderIndicator,
           com.geotrust.api.webtrust.order.SANVettingStatus[] SANVettingStatuses) {
           this.orderResponseHeader = orderResponseHeader;
           this.price = price;
           this.validityPeriod = validityPeriod;
           this.parsedCSR = parsedCSR;
           this.CUInfo = CUInfo;
           this.renewalInfo = renewalInfo;
           this.certificateSignatureHashAlgorithm = certificateSignatureHashAlgorithm;
           this.japaneseOrderIndicator = japaneseOrderIndicator;
           this.SANVettingStatuses = SANVettingStatuses;
    }


    /**
     * Gets the orderResponseHeader value for this ValidateOrderParametersOutput.
     * 
     * @return orderResponseHeader
     */
    public com.geotrust.api.webtrust.order.OrderResponseHeader getOrderResponseHeader() {
        return orderResponseHeader;
    }


    /**
     * Sets the orderResponseHeader value for this ValidateOrderParametersOutput.
     * 
     * @param orderResponseHeader
     */
    public void setOrderResponseHeader(com.geotrust.api.webtrust.order.OrderResponseHeader orderResponseHeader) {
        this.orderResponseHeader = orderResponseHeader;
    }


    /**
     * Gets the price value for this ValidateOrderParametersOutput.
     * 
     * @return price
     */
    public java.lang.String getPrice() {
        return price;
    }


    /**
     * Sets the price value for this ValidateOrderParametersOutput.
     * 
     * @param price
     */
    public void setPrice(java.lang.String price) {
        this.price = price;
    }


    /**
     * Gets the validityPeriod value for this ValidateOrderParametersOutput.
     * 
     * @return validityPeriod
     */
    public int getValidityPeriod() {
        return validityPeriod;
    }


    /**
     * Sets the validityPeriod value for this ValidateOrderParametersOutput.
     * 
     * @param validityPeriod
     */
    public void setValidityPeriod(int validityPeriod) {
        this.validityPeriod = validityPeriod;
    }


    /**
     * Gets the parsedCSR value for this ValidateOrderParametersOutput.
     * 
     * @return parsedCSR
     */
    public com.geotrust.api.webtrust.order.ParsedCSR getParsedCSR() {
        return parsedCSR;
    }


    /**
     * Sets the parsedCSR value for this ValidateOrderParametersOutput.
     * 
     * @param parsedCSR
     */
    public void setParsedCSR(com.geotrust.api.webtrust.order.ParsedCSR parsedCSR) {
        this.parsedCSR = parsedCSR;
    }


    /**
     * Gets the CUInfo value for this ValidateOrderParametersOutput.
     * 
     * @return CUInfo
     */
    public com.geotrust.api.webtrust.order.CuInfo getCUInfo() {
        return CUInfo;
    }


    /**
     * Sets the CUInfo value for this ValidateOrderParametersOutput.
     * 
     * @param CUInfo
     */
    public void setCUInfo(com.geotrust.api.webtrust.order.CuInfo CUInfo) {
        this.CUInfo = CUInfo;
    }


    /**
     * Gets the renewalInfo value for this ValidateOrderParametersOutput.
     * 
     * @return renewalInfo
     */
    public com.geotrust.api.webtrust.order.RenewalInfo getRenewalInfo() {
        return renewalInfo;
    }


    /**
     * Sets the renewalInfo value for this ValidateOrderParametersOutput.
     * 
     * @param renewalInfo
     */
    public void setRenewalInfo(com.geotrust.api.webtrust.order.RenewalInfo renewalInfo) {
        this.renewalInfo = renewalInfo;
    }


    /**
     * Gets the certificateSignatureHashAlgorithm value for this ValidateOrderParametersOutput.
     * 
     * @return certificateSignatureHashAlgorithm
     */
    public java.lang.String getCertificateSignatureHashAlgorithm() {
        return certificateSignatureHashAlgorithm;
    }


    /**
     * Sets the certificateSignatureHashAlgorithm value for this ValidateOrderParametersOutput.
     * 
     * @param certificateSignatureHashAlgorithm
     */
    public void setCertificateSignatureHashAlgorithm(java.lang.String certificateSignatureHashAlgorithm) {
        this.certificateSignatureHashAlgorithm = certificateSignatureHashAlgorithm;
    }


    /**
     * Gets the japaneseOrderIndicator value for this ValidateOrderParametersOutput.
     * 
     * @return japaneseOrderIndicator
     */
    public java.lang.String getJapaneseOrderIndicator() {
        return japaneseOrderIndicator;
    }


    /**
     * Sets the japaneseOrderIndicator value for this ValidateOrderParametersOutput.
     * 
     * @param japaneseOrderIndicator
     */
    public void setJapaneseOrderIndicator(java.lang.String japaneseOrderIndicator) {
        this.japaneseOrderIndicator = japaneseOrderIndicator;
    }


    /**
     * Gets the SANVettingStatuses value for this ValidateOrderParametersOutput.
     * 
     * @return SANVettingStatuses
     */
    public com.geotrust.api.webtrust.order.SANVettingStatus[] getSANVettingStatuses() {
        return SANVettingStatuses;
    }


    /**
     * Sets the SANVettingStatuses value for this ValidateOrderParametersOutput.
     * 
     * @param SANVettingStatuses
     */
    public void setSANVettingStatuses(com.geotrust.api.webtrust.order.SANVettingStatus[] SANVettingStatuses) {
        this.SANVettingStatuses = SANVettingStatuses;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ValidateOrderParametersOutput)) return false;
        ValidateOrderParametersOutput other = (ValidateOrderParametersOutput) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.orderResponseHeader==null && other.getOrderResponseHeader()==null) || 
             (this.orderResponseHeader!=null &&
              this.orderResponseHeader.equals(other.getOrderResponseHeader()))) &&
            ((this.price==null && other.getPrice()==null) || 
             (this.price!=null &&
              this.price.equals(other.getPrice()))) &&
            this.validityPeriod == other.getValidityPeriod() &&
            ((this.parsedCSR==null && other.getParsedCSR()==null) || 
             (this.parsedCSR!=null &&
              this.parsedCSR.equals(other.getParsedCSR()))) &&
            ((this.CUInfo==null && other.getCUInfo()==null) || 
             (this.CUInfo!=null &&
              this.CUInfo.equals(other.getCUInfo()))) &&
            ((this.renewalInfo==null && other.getRenewalInfo()==null) || 
             (this.renewalInfo!=null &&
              this.renewalInfo.equals(other.getRenewalInfo()))) &&
            ((this.certificateSignatureHashAlgorithm==null && other.getCertificateSignatureHashAlgorithm()==null) || 
             (this.certificateSignatureHashAlgorithm!=null &&
              this.certificateSignatureHashAlgorithm.equals(other.getCertificateSignatureHashAlgorithm()))) &&
            ((this.japaneseOrderIndicator==null && other.getJapaneseOrderIndicator()==null) || 
             (this.japaneseOrderIndicator!=null &&
              this.japaneseOrderIndicator.equals(other.getJapaneseOrderIndicator()))) &&
            ((this.SANVettingStatuses==null && other.getSANVettingStatuses()==null) || 
             (this.SANVettingStatuses!=null &&
              java.util.Arrays.equals(this.SANVettingStatuses, other.getSANVettingStatuses())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getOrderResponseHeader() != null) {
            _hashCode += getOrderResponseHeader().hashCode();
        }
        if (getPrice() != null) {
            _hashCode += getPrice().hashCode();
        }
        _hashCode += getValidityPeriod();
        if (getParsedCSR() != null) {
            _hashCode += getParsedCSR().hashCode();
        }
        if (getCUInfo() != null) {
            _hashCode += getCUInfo().hashCode();
        }
        if (getRenewalInfo() != null) {
            _hashCode += getRenewalInfo().hashCode();
        }
        if (getCertificateSignatureHashAlgorithm() != null) {
            _hashCode += getCertificateSignatureHashAlgorithm().hashCode();
        }
        if (getJapaneseOrderIndicator() != null) {
            _hashCode += getJapaneseOrderIndicator().hashCode();
        }
        if (getSANVettingStatuses() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getSANVettingStatuses());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getSANVettingStatuses(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ValidateOrderParametersOutput.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ValidateOrderParametersOutput"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderResponseHeader");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "OrderResponseHeader"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "orderResponseHeader"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("price");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Price"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("validityPeriod");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ValidityPeriod"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("parsedCSR");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ParsedCSR"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "parsedCSR"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CUInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "CUInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "cuInfo"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("renewalInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "RenewalInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "renewalInfo"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("certificateSignatureHashAlgorithm");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "CertificateSignatureHashAlgorithm"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("japaneseOrderIndicator");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "JapaneseOrderIndicator"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SANVettingStatuses");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "SANVettingStatuses"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "SANVettingStatus"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "SANVettingStatus"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
