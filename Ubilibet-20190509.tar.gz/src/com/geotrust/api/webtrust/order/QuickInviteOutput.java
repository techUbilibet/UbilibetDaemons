/**
 * QuickInviteOutput.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.order;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class QuickInviteOutput  implements java.io.Serializable {
    private com.geotrust.api.webtrust.order.OrderResponseHeader orderResponseHeader;

    private java.lang.String inviteURL;

    private com.geotrust.api.webtrust.order.InviteDetail[] inviteDetails;

    public QuickInviteOutput() {
    }

    public QuickInviteOutput(
           com.geotrust.api.webtrust.order.OrderResponseHeader orderResponseHeader,
           java.lang.String inviteURL,
           com.geotrust.api.webtrust.order.InviteDetail[] inviteDetails) {
           this.orderResponseHeader = orderResponseHeader;
           this.inviteURL = inviteURL;
           this.inviteDetails = inviteDetails;
    }


    /**
     * Gets the orderResponseHeader value for this QuickInviteOutput.
     * 
     * @return orderResponseHeader
     */
    public com.geotrust.api.webtrust.order.OrderResponseHeader getOrderResponseHeader() {
        return orderResponseHeader;
    }


    /**
     * Sets the orderResponseHeader value for this QuickInviteOutput.
     * 
     * @param orderResponseHeader
     */
    public void setOrderResponseHeader(com.geotrust.api.webtrust.order.OrderResponseHeader orderResponseHeader) {
        this.orderResponseHeader = orderResponseHeader;
    }


    /**
     * Gets the inviteURL value for this QuickInviteOutput.
     * 
     * @return inviteURL
     */
    public java.lang.String getInviteURL() {
        return inviteURL;
    }


    /**
     * Sets the inviteURL value for this QuickInviteOutput.
     * 
     * @param inviteURL
     */
    public void setInviteURL(java.lang.String inviteURL) {
        this.inviteURL = inviteURL;
    }


    /**
     * Gets the inviteDetails value for this QuickInviteOutput.
     * 
     * @return inviteDetails
     */
    public com.geotrust.api.webtrust.order.InviteDetail[] getInviteDetails() {
        return inviteDetails;
    }


    /**
     * Sets the inviteDetails value for this QuickInviteOutput.
     * 
     * @param inviteDetails
     */
    public void setInviteDetails(com.geotrust.api.webtrust.order.InviteDetail[] inviteDetails) {
        this.inviteDetails = inviteDetails;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof QuickInviteOutput)) return false;
        QuickInviteOutput other = (QuickInviteOutput) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.orderResponseHeader==null && other.getOrderResponseHeader()==null) || 
             (this.orderResponseHeader!=null &&
              this.orderResponseHeader.equals(other.getOrderResponseHeader()))) &&
            ((this.inviteURL==null && other.getInviteURL()==null) || 
             (this.inviteURL!=null &&
              this.inviteURL.equals(other.getInviteURL()))) &&
            ((this.inviteDetails==null && other.getInviteDetails()==null) || 
             (this.inviteDetails!=null &&
              java.util.Arrays.equals(this.inviteDetails, other.getInviteDetails())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getOrderResponseHeader() != null) {
            _hashCode += getOrderResponseHeader().hashCode();
        }
        if (getInviteURL() != null) {
            _hashCode += getInviteURL().hashCode();
        }
        if (getInviteDetails() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getInviteDetails());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getInviteDetails(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(QuickInviteOutput.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "QuickInviteOutput"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderResponseHeader");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "OrderResponseHeader"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "orderResponseHeader"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("inviteURL");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "InviteURL"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("inviteDetails");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "InviteDetails"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "InviteDetail"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "InviteDetail"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
