/**
 * OrderContacts.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.order;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class OrderContacts  implements java.io.Serializable {
    private com.geotrust.api.webtrust.order.Contact adminContact;

    private com.geotrust.api.webtrust.order.Contact techContact;

    private com.geotrust.api.webtrust.order.Contact billingContact;

    public OrderContacts() {
    }

    public OrderContacts(
           com.geotrust.api.webtrust.order.Contact adminContact,
           com.geotrust.api.webtrust.order.Contact techContact,
           com.geotrust.api.webtrust.order.Contact billingContact) {
           this.adminContact = adminContact;
           this.techContact = techContact;
           this.billingContact = billingContact;
    }


    /**
     * Gets the adminContact value for this OrderContacts.
     * 
     * @return adminContact
     */
    public com.geotrust.api.webtrust.order.Contact getAdminContact() {
        return adminContact;
    }


    /**
     * Sets the adminContact value for this OrderContacts.
     * 
     * @param adminContact
     */
    public void setAdminContact(com.geotrust.api.webtrust.order.Contact adminContact) {
        this.adminContact = adminContact;
    }


    /**
     * Gets the techContact value for this OrderContacts.
     * 
     * @return techContact
     */
    public com.geotrust.api.webtrust.order.Contact getTechContact() {
        return techContact;
    }


    /**
     * Sets the techContact value for this OrderContacts.
     * 
     * @param techContact
     */
    public void setTechContact(com.geotrust.api.webtrust.order.Contact techContact) {
        this.techContact = techContact;
    }


    /**
     * Gets the billingContact value for this OrderContacts.
     * 
     * @return billingContact
     */
    public com.geotrust.api.webtrust.order.Contact getBillingContact() {
        return billingContact;
    }


    /**
     * Sets the billingContact value for this OrderContacts.
     * 
     * @param billingContact
     */
    public void setBillingContact(com.geotrust.api.webtrust.order.Contact billingContact) {
        this.billingContact = billingContact;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof OrderContacts)) return false;
        OrderContacts other = (OrderContacts) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.adminContact==null && other.getAdminContact()==null) || 
             (this.adminContact!=null &&
              this.adminContact.equals(other.getAdminContact()))) &&
            ((this.techContact==null && other.getTechContact()==null) || 
             (this.techContact!=null &&
              this.techContact.equals(other.getTechContact()))) &&
            ((this.billingContact==null && other.getBillingContact()==null) || 
             (this.billingContact!=null &&
              this.billingContact.equals(other.getBillingContact())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getAdminContact() != null) {
            _hashCode += getAdminContact().hashCode();
        }
        if (getTechContact() != null) {
            _hashCode += getTechContact().hashCode();
        }
        if (getBillingContact() != null) {
            _hashCode += getBillingContact().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(OrderContacts.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "orderContacts"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("adminContact");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "AdminContact"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Contact"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("techContact");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "TechContact"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Contact"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("billingContact");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "BillingContact"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Contact"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
