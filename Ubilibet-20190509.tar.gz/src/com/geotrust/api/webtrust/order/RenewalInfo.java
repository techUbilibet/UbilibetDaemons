/**
 * RenewalInfo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.order;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class RenewalInfo  implements java.io.Serializable {
    private boolean renewIndicator;

    private int renewalMonths;

    private java.lang.String renewalSerialNumber;

    private java.lang.String renewalExpirationDate;

    private java.lang.String renewalOrderID;

    private java.lang.String renewalProductCode;

    public RenewalInfo() {
    }

    public RenewalInfo(
           boolean renewIndicator,
           int renewalMonths,
           java.lang.String renewalSerialNumber,
           java.lang.String renewalExpirationDate,
           java.lang.String renewalOrderID,
           java.lang.String renewalProductCode) {
           this.renewIndicator = renewIndicator;
           this.renewalMonths = renewalMonths;
           this.renewalSerialNumber = renewalSerialNumber;
           this.renewalExpirationDate = renewalExpirationDate;
           this.renewalOrderID = renewalOrderID;
           this.renewalProductCode = renewalProductCode;
    }


    /**
     * Gets the renewIndicator value for this RenewalInfo.
     * 
     * @return renewIndicator
     */
    public boolean isRenewIndicator() {
        return renewIndicator;
    }


    /**
     * Sets the renewIndicator value for this RenewalInfo.
     * 
     * @param renewIndicator
     */
    public void setRenewIndicator(boolean renewIndicator) {
        this.renewIndicator = renewIndicator;
    }


    /**
     * Gets the renewalMonths value for this RenewalInfo.
     * 
     * @return renewalMonths
     */
    public int getRenewalMonths() {
        return renewalMonths;
    }


    /**
     * Sets the renewalMonths value for this RenewalInfo.
     * 
     * @param renewalMonths
     */
    public void setRenewalMonths(int renewalMonths) {
        this.renewalMonths = renewalMonths;
    }


    /**
     * Gets the renewalSerialNumber value for this RenewalInfo.
     * 
     * @return renewalSerialNumber
     */
    public java.lang.String getRenewalSerialNumber() {
        return renewalSerialNumber;
    }


    /**
     * Sets the renewalSerialNumber value for this RenewalInfo.
     * 
     * @param renewalSerialNumber
     */
    public void setRenewalSerialNumber(java.lang.String renewalSerialNumber) {
        this.renewalSerialNumber = renewalSerialNumber;
    }


    /**
     * Gets the renewalExpirationDate value for this RenewalInfo.
     * 
     * @return renewalExpirationDate
     */
    public java.lang.String getRenewalExpirationDate() {
        return renewalExpirationDate;
    }


    /**
     * Sets the renewalExpirationDate value for this RenewalInfo.
     * 
     * @param renewalExpirationDate
     */
    public void setRenewalExpirationDate(java.lang.String renewalExpirationDate) {
        this.renewalExpirationDate = renewalExpirationDate;
    }


    /**
     * Gets the renewalOrderID value for this RenewalInfo.
     * 
     * @return renewalOrderID
     */
    public java.lang.String getRenewalOrderID() {
        return renewalOrderID;
    }


    /**
     * Sets the renewalOrderID value for this RenewalInfo.
     * 
     * @param renewalOrderID
     */
    public void setRenewalOrderID(java.lang.String renewalOrderID) {
        this.renewalOrderID = renewalOrderID;
    }


    /**
     * Gets the renewalProductCode value for this RenewalInfo.
     * 
     * @return renewalProductCode
     */
    public java.lang.String getRenewalProductCode() {
        return renewalProductCode;
    }


    /**
     * Sets the renewalProductCode value for this RenewalInfo.
     * 
     * @param renewalProductCode
     */
    public void setRenewalProductCode(java.lang.String renewalProductCode) {
        this.renewalProductCode = renewalProductCode;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof RenewalInfo)) return false;
        RenewalInfo other = (RenewalInfo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.renewIndicator == other.isRenewIndicator() &&
            this.renewalMonths == other.getRenewalMonths() &&
            ((this.renewalSerialNumber==null && other.getRenewalSerialNumber()==null) || 
             (this.renewalSerialNumber!=null &&
              this.renewalSerialNumber.equals(other.getRenewalSerialNumber()))) &&
            ((this.renewalExpirationDate==null && other.getRenewalExpirationDate()==null) || 
             (this.renewalExpirationDate!=null &&
              this.renewalExpirationDate.equals(other.getRenewalExpirationDate()))) &&
            ((this.renewalOrderID==null && other.getRenewalOrderID()==null) || 
             (this.renewalOrderID!=null &&
              this.renewalOrderID.equals(other.getRenewalOrderID()))) &&
            ((this.renewalProductCode==null && other.getRenewalProductCode()==null) || 
             (this.renewalProductCode!=null &&
              this.renewalProductCode.equals(other.getRenewalProductCode())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += (isRenewIndicator() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += getRenewalMonths();
        if (getRenewalSerialNumber() != null) {
            _hashCode += getRenewalSerialNumber().hashCode();
        }
        if (getRenewalExpirationDate() != null) {
            _hashCode += getRenewalExpirationDate().hashCode();
        }
        if (getRenewalOrderID() != null) {
            _hashCode += getRenewalOrderID().hashCode();
        }
        if (getRenewalProductCode() != null) {
            _hashCode += getRenewalProductCode().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(RenewalInfo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "renewalInfo"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("renewIndicator");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "RenewIndicator"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("renewalMonths");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "RenewalMonths"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("renewalSerialNumber");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "RenewalSerialNumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("renewalExpirationDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "RenewalExpirationDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("renewalOrderID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "RenewalOrderID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("renewalProductCode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "RenewalProductCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
