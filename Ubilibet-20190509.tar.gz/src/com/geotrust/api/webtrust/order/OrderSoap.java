/**
 * OrderSoap.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.order;


public interface OrderSoap extends java.rmi.Remote {
    public com.geotrust.api.webtrust.order.ModifyOrderOutput modifyOrder(com.geotrust.api.webtrust.order.ModifyOrderInput request) throws java.rmi.RemoteException;
    public java.lang.String[] showReplayTokens(java.lang.String partnerCode) throws java.rmi.RemoteException;
    public com.geotrust.api.webtrust.order.QuickOrderOutput quickOrder(com.geotrust.api.webtrust.order.QuickOrderInput request) throws java.rmi.RemoteException;
    public com.geotrust.api.webtrust.order.TCOrderOutput TCOrder(com.geotrust.api.webtrust.order.TCOrderInput request) throws java.rmi.RemoteException;
    public com.geotrust.api.webtrust.order.RevokeOutput revoke(com.geotrust.api.webtrust.order.RevokeInput request) throws java.rmi.RemoteException;
    public com.geotrust.api.webtrust.order.QuickInviteOutput quickInvite(com.geotrust.api.webtrust.order.QuickInviteInput request) throws java.rmi.RemoteException;
    public com.geotrust.api.webtrust.order.ValidateAuthDataOutput validatePreAuthenticationData(com.geotrust.api.webtrust.order.ValidateAuthDataInput validateAuthDataRequest) throws java.rmi.RemoteException;
    public com.geotrust.api.webtrust.order.QuickPaymentsOrderOutput quickPaymentsOrder(com.geotrust.api.webtrust.order.QuickPaymentsOrderInput request) throws java.rmi.RemoteException;
    public com.geotrust.api.webtrust.order.ValidateOrderParametersOutput validateOrderParameters(com.geotrust.api.webtrust.order.ValidateOrderParametersInput request) throws java.rmi.RemoteException;
    public com.geotrust.api.webtrust.order.TrueSiteOrderOutput trueSiteOrder(com.geotrust.api.webtrust.order.TrueSiteOrderInput request) throws java.rmi.RemoteException;
    public com.geotrust.api.webtrust.order.TCInviteOutput TCInvite(com.geotrust.api.webtrust.order.TCInviteInput request) throws java.rmi.RemoteException;
    public com.geotrust.api.webtrust.order.ChangeApproverEmailOutput changeApproverEmail(com.geotrust.api.webtrust.order.ChangeApproverEmailInput request) throws java.rmi.RemoteException;
    public com.geotrust.api.webtrust.order.ResendEmailOutput resendEmail(com.geotrust.api.webtrust.order.ResendEmailInput request) throws java.rmi.RemoteException;
    public com.geotrust.api.webtrust.order.ReissueOutput reissue(com.geotrust.api.webtrust.order.ReissueInput request) throws java.rmi.RemoteException;
    public com.geotrust.api.webtrust.order.AuthOrderOutput orderPreAuthentication(com.geotrust.api.webtrust.order.AuthOrderInput authOrderRequest) throws java.rmi.RemoteException;
}
