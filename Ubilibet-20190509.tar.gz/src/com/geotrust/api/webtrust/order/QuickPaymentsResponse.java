/**
 * QuickPaymentsResponse.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.order;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class QuickPaymentsResponse  implements java.io.Serializable {
    private java.lang.String userpass;

    private java.lang.String szReturnCode;

    private java.lang.String szReturnMessage;

    private java.lang.String szhtmlserialnumber;

    private java.lang.String szloginserialnumber;

    private java.lang.String TID;

    private java.lang.String MID;

    private int orderID;

    public QuickPaymentsResponse() {
    }

    public QuickPaymentsResponse(
           java.lang.String userpass,
           java.lang.String szReturnCode,
           java.lang.String szReturnMessage,
           java.lang.String szhtmlserialnumber,
           java.lang.String szloginserialnumber,
           java.lang.String TID,
           java.lang.String MID,
           int orderID) {
           this.userpass = userpass;
           this.szReturnCode = szReturnCode;
           this.szReturnMessage = szReturnMessage;
           this.szhtmlserialnumber = szhtmlserialnumber;
           this.szloginserialnumber = szloginserialnumber;
           this.TID = TID;
           this.MID = MID;
           this.orderID = orderID;
    }


    /**
     * Gets the userpass value for this QuickPaymentsResponse.
     * 
     * @return userpass
     */
    public java.lang.String getUserpass() {
        return userpass;
    }


    /**
     * Sets the userpass value for this QuickPaymentsResponse.
     * 
     * @param userpass
     */
    public void setUserpass(java.lang.String userpass) {
        this.userpass = userpass;
    }


    /**
     * Gets the szReturnCode value for this QuickPaymentsResponse.
     * 
     * @return szReturnCode
     */
    public java.lang.String getSzReturnCode() {
        return szReturnCode;
    }


    /**
     * Sets the szReturnCode value for this QuickPaymentsResponse.
     * 
     * @param szReturnCode
     */
    public void setSzReturnCode(java.lang.String szReturnCode) {
        this.szReturnCode = szReturnCode;
    }


    /**
     * Gets the szReturnMessage value for this QuickPaymentsResponse.
     * 
     * @return szReturnMessage
     */
    public java.lang.String getSzReturnMessage() {
        return szReturnMessage;
    }


    /**
     * Sets the szReturnMessage value for this QuickPaymentsResponse.
     * 
     * @param szReturnMessage
     */
    public void setSzReturnMessage(java.lang.String szReturnMessage) {
        this.szReturnMessage = szReturnMessage;
    }


    /**
     * Gets the szhtmlserialnumber value for this QuickPaymentsResponse.
     * 
     * @return szhtmlserialnumber
     */
    public java.lang.String getSzhtmlserialnumber() {
        return szhtmlserialnumber;
    }


    /**
     * Sets the szhtmlserialnumber value for this QuickPaymentsResponse.
     * 
     * @param szhtmlserialnumber
     */
    public void setSzhtmlserialnumber(java.lang.String szhtmlserialnumber) {
        this.szhtmlserialnumber = szhtmlserialnumber;
    }


    /**
     * Gets the szloginserialnumber value for this QuickPaymentsResponse.
     * 
     * @return szloginserialnumber
     */
    public java.lang.String getSzloginserialnumber() {
        return szloginserialnumber;
    }


    /**
     * Sets the szloginserialnumber value for this QuickPaymentsResponse.
     * 
     * @param szloginserialnumber
     */
    public void setSzloginserialnumber(java.lang.String szloginserialnumber) {
        this.szloginserialnumber = szloginserialnumber;
    }


    /**
     * Gets the TID value for this QuickPaymentsResponse.
     * 
     * @return TID
     */
    public java.lang.String getTID() {
        return TID;
    }


    /**
     * Sets the TID value for this QuickPaymentsResponse.
     * 
     * @param TID
     */
    public void setTID(java.lang.String TID) {
        this.TID = TID;
    }


    /**
     * Gets the MID value for this QuickPaymentsResponse.
     * 
     * @return MID
     */
    public java.lang.String getMID() {
        return MID;
    }


    /**
     * Sets the MID value for this QuickPaymentsResponse.
     * 
     * @param MID
     */
    public void setMID(java.lang.String MID) {
        this.MID = MID;
    }


    /**
     * Gets the orderID value for this QuickPaymentsResponse.
     * 
     * @return orderID
     */
    public int getOrderID() {
        return orderID;
    }


    /**
     * Sets the orderID value for this QuickPaymentsResponse.
     * 
     * @param orderID
     */
    public void setOrderID(int orderID) {
        this.orderID = orderID;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof QuickPaymentsResponse)) return false;
        QuickPaymentsResponse other = (QuickPaymentsResponse) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.userpass==null && other.getUserpass()==null) || 
             (this.userpass!=null &&
              this.userpass.equals(other.getUserpass()))) &&
            ((this.szReturnCode==null && other.getSzReturnCode()==null) || 
             (this.szReturnCode!=null &&
              this.szReturnCode.equals(other.getSzReturnCode()))) &&
            ((this.szReturnMessage==null && other.getSzReturnMessage()==null) || 
             (this.szReturnMessage!=null &&
              this.szReturnMessage.equals(other.getSzReturnMessage()))) &&
            ((this.szhtmlserialnumber==null && other.getSzhtmlserialnumber()==null) || 
             (this.szhtmlserialnumber!=null &&
              this.szhtmlserialnumber.equals(other.getSzhtmlserialnumber()))) &&
            ((this.szloginserialnumber==null && other.getSzloginserialnumber()==null) || 
             (this.szloginserialnumber!=null &&
              this.szloginserialnumber.equals(other.getSzloginserialnumber()))) &&
            ((this.TID==null && other.getTID()==null) || 
             (this.TID!=null &&
              this.TID.equals(other.getTID()))) &&
            ((this.MID==null && other.getMID()==null) || 
             (this.MID!=null &&
              this.MID.equals(other.getMID()))) &&
            this.orderID == other.getOrderID();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getUserpass() != null) {
            _hashCode += getUserpass().hashCode();
        }
        if (getSzReturnCode() != null) {
            _hashCode += getSzReturnCode().hashCode();
        }
        if (getSzReturnMessage() != null) {
            _hashCode += getSzReturnMessage().hashCode();
        }
        if (getSzhtmlserialnumber() != null) {
            _hashCode += getSzhtmlserialnumber().hashCode();
        }
        if (getSzloginserialnumber() != null) {
            _hashCode += getSzloginserialnumber().hashCode();
        }
        if (getTID() != null) {
            _hashCode += getTID().hashCode();
        }
        if (getMID() != null) {
            _hashCode += getMID().hashCode();
        }
        _hashCode += getOrderID();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(QuickPaymentsResponse.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "quickPaymentsResponse"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("userpass");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Userpass"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("szReturnCode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "SzReturnCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("szReturnMessage");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "SzReturnMessage"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("szhtmlserialnumber");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Szhtmlserialnumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("szloginserialnumber");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Szloginserialnumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "TID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "MID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "OrderID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
