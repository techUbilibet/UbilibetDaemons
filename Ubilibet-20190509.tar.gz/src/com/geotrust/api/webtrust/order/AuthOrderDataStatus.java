/**
 * AuthOrderDataStatus.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.order;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class AuthOrderDataStatus  implements java.io.Serializable {
    private java.lang.String geoTrustOrderID;

    private java.lang.String partnerOrderID;

    private java.lang.String orderStatus;

    private com.geotrust.api.webtrust.order.AuthOrderParameters authOrderParameters;

    private com.geotrust.api.webtrust.order.AuthDataStatus authDataStatus;

    private com.geotrust.api.webtrust.order.AuthenticationComment[] authVettingComments;

    private com.geotrust.api.webtrust.order.Contact billingContact;

    public AuthOrderDataStatus() {
    }

    public AuthOrderDataStatus(
           java.lang.String geoTrustOrderID,
           java.lang.String partnerOrderID,
           java.lang.String orderStatus,
           com.geotrust.api.webtrust.order.AuthOrderParameters authOrderParameters,
           com.geotrust.api.webtrust.order.AuthDataStatus authDataStatus,
           com.geotrust.api.webtrust.order.AuthenticationComment[] authVettingComments,
           com.geotrust.api.webtrust.order.Contact billingContact) {
           this.geoTrustOrderID = geoTrustOrderID;
           this.partnerOrderID = partnerOrderID;
           this.orderStatus = orderStatus;
           this.authOrderParameters = authOrderParameters;
           this.authDataStatus = authDataStatus;
           this.authVettingComments = authVettingComments;
           this.billingContact = billingContact;
    }


    /**
     * Gets the geoTrustOrderID value for this AuthOrderDataStatus.
     * 
     * @return geoTrustOrderID
     */
    public java.lang.String getGeoTrustOrderID() {
        return geoTrustOrderID;
    }


    /**
     * Sets the geoTrustOrderID value for this AuthOrderDataStatus.
     * 
     * @param geoTrustOrderID
     */
    public void setGeoTrustOrderID(java.lang.String geoTrustOrderID) {
        this.geoTrustOrderID = geoTrustOrderID;
    }


    /**
     * Gets the partnerOrderID value for this AuthOrderDataStatus.
     * 
     * @return partnerOrderID
     */
    public java.lang.String getPartnerOrderID() {
        return partnerOrderID;
    }


    /**
     * Sets the partnerOrderID value for this AuthOrderDataStatus.
     * 
     * @param partnerOrderID
     */
    public void setPartnerOrderID(java.lang.String partnerOrderID) {
        this.partnerOrderID = partnerOrderID;
    }


    /**
     * Gets the orderStatus value for this AuthOrderDataStatus.
     * 
     * @return orderStatus
     */
    public java.lang.String getOrderStatus() {
        return orderStatus;
    }


    /**
     * Sets the orderStatus value for this AuthOrderDataStatus.
     * 
     * @param orderStatus
     */
    public void setOrderStatus(java.lang.String orderStatus) {
        this.orderStatus = orderStatus;
    }


    /**
     * Gets the authOrderParameters value for this AuthOrderDataStatus.
     * 
     * @return authOrderParameters
     */
    public com.geotrust.api.webtrust.order.AuthOrderParameters getAuthOrderParameters() {
        return authOrderParameters;
    }


    /**
     * Sets the authOrderParameters value for this AuthOrderDataStatus.
     * 
     * @param authOrderParameters
     */
    public void setAuthOrderParameters(com.geotrust.api.webtrust.order.AuthOrderParameters authOrderParameters) {
        this.authOrderParameters = authOrderParameters;
    }


    /**
     * Gets the authDataStatus value for this AuthOrderDataStatus.
     * 
     * @return authDataStatus
     */
    public com.geotrust.api.webtrust.order.AuthDataStatus getAuthDataStatus() {
        return authDataStatus;
    }


    /**
     * Sets the authDataStatus value for this AuthOrderDataStatus.
     * 
     * @param authDataStatus
     */
    public void setAuthDataStatus(com.geotrust.api.webtrust.order.AuthDataStatus authDataStatus) {
        this.authDataStatus = authDataStatus;
    }


    /**
     * Gets the authVettingComments value for this AuthOrderDataStatus.
     * 
     * @return authVettingComments
     */
    public com.geotrust.api.webtrust.order.AuthenticationComment[] getAuthVettingComments() {
        return authVettingComments;
    }


    /**
     * Sets the authVettingComments value for this AuthOrderDataStatus.
     * 
     * @param authVettingComments
     */
    public void setAuthVettingComments(com.geotrust.api.webtrust.order.AuthenticationComment[] authVettingComments) {
        this.authVettingComments = authVettingComments;
    }


    /**
     * Gets the billingContact value for this AuthOrderDataStatus.
     * 
     * @return billingContact
     */
    public com.geotrust.api.webtrust.order.Contact getBillingContact() {
        return billingContact;
    }


    /**
     * Sets the billingContact value for this AuthOrderDataStatus.
     * 
     * @param billingContact
     */
    public void setBillingContact(com.geotrust.api.webtrust.order.Contact billingContact) {
        this.billingContact = billingContact;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof AuthOrderDataStatus)) return false;
        AuthOrderDataStatus other = (AuthOrderDataStatus) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.geoTrustOrderID==null && other.getGeoTrustOrderID()==null) || 
             (this.geoTrustOrderID!=null &&
              this.geoTrustOrderID.equals(other.getGeoTrustOrderID()))) &&
            ((this.partnerOrderID==null && other.getPartnerOrderID()==null) || 
             (this.partnerOrderID!=null &&
              this.partnerOrderID.equals(other.getPartnerOrderID()))) &&
            ((this.orderStatus==null && other.getOrderStatus()==null) || 
             (this.orderStatus!=null &&
              this.orderStatus.equals(other.getOrderStatus()))) &&
            ((this.authOrderParameters==null && other.getAuthOrderParameters()==null) || 
             (this.authOrderParameters!=null &&
              this.authOrderParameters.equals(other.getAuthOrderParameters()))) &&
            ((this.authDataStatus==null && other.getAuthDataStatus()==null) || 
             (this.authDataStatus!=null &&
              this.authDataStatus.equals(other.getAuthDataStatus()))) &&
            ((this.authVettingComments==null && other.getAuthVettingComments()==null) || 
             (this.authVettingComments!=null &&
              java.util.Arrays.equals(this.authVettingComments, other.getAuthVettingComments()))) &&
            ((this.billingContact==null && other.getBillingContact()==null) || 
             (this.billingContact!=null &&
              this.billingContact.equals(other.getBillingContact())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getGeoTrustOrderID() != null) {
            _hashCode += getGeoTrustOrderID().hashCode();
        }
        if (getPartnerOrderID() != null) {
            _hashCode += getPartnerOrderID().hashCode();
        }
        if (getOrderStatus() != null) {
            _hashCode += getOrderStatus().hashCode();
        }
        if (getAuthOrderParameters() != null) {
            _hashCode += getAuthOrderParameters().hashCode();
        }
        if (getAuthDataStatus() != null) {
            _hashCode += getAuthDataStatus().hashCode();
        }
        if (getAuthVettingComments() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getAuthVettingComments());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getAuthVettingComments(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getBillingContact() != null) {
            _hashCode += getBillingContact().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(AuthOrderDataStatus.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "AuthOrderDataStatus"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("geoTrustOrderID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "GeoTrustOrderID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("partnerOrderID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "PartnerOrderID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "OrderStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("authOrderParameters");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "AuthOrderParameters"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "AuthOrderParameters"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("authDataStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "AuthDataStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "AuthDataStatus"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("authVettingComments");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "AuthVettingComments"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "AuthenticationComment"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "AuthenticationComment"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("billingContact");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "BillingContact"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Contact"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
