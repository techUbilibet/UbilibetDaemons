/**
 * OrderDetail.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.order;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class OrderDetail  implements java.io.Serializable {
    private com.geotrust.api.webtrust.order.ModificationEvent[] modificationEvents;

    private com.geotrust.api.webtrust.order.OrderInfo orderInfo;

    private com.geotrust.api.webtrust.order.QuickOrderDetail quickOrderDetail;

    private com.geotrust.api.webtrust.order.TrueOrderDetail trueOrderDetail;

    private com.geotrust.api.webtrust.order.OrderContacts orderContacts;

    private com.geotrust.api.webtrust.order.TCOrderDetail TCOrderDetail;

    private com.geotrust.api.webtrust.order.CertificateInfo certificateInfo;

    private com.geotrust.api.webtrust.order.CertificateInfo pendingCertificateInfo;

    private com.geotrust.api.webtrust.order.Fulfillment fulfillment;

    private com.geotrust.api.webtrust.order.CertificateDetail[] certificateSearchResult;

    private com.geotrust.api.webtrust.order.OrderAttribute[] orderAttributes;

    private com.geotrust.api.webtrust.order.AuthenticationComment[] authenticationComments;

    private com.geotrust.api.webtrust.order.AuthenticationStatus[] authenticationStatuses;

    private com.geotrust.api.webtrust.order.SANVettingStatus[] SANVettingStatuses;

    private com.geotrust.api.webtrust.order.TrustServicesDetails trustServicesDetails;

    private com.geotrust.api.webtrust.order.TrialDetails trialDetails;

    private com.geotrust.api.webtrust.order.VulnerabilityScanDetails vulnerabilityScanDetails;

    public OrderDetail() {
    }

    public OrderDetail(
           com.geotrust.api.webtrust.order.ModificationEvent[] modificationEvents,
           com.geotrust.api.webtrust.order.OrderInfo orderInfo,
           com.geotrust.api.webtrust.order.QuickOrderDetail quickOrderDetail,
           com.geotrust.api.webtrust.order.TrueOrderDetail trueOrderDetail,
           com.geotrust.api.webtrust.order.OrderContacts orderContacts,
           com.geotrust.api.webtrust.order.TCOrderDetail TCOrderDetail,
           com.geotrust.api.webtrust.order.CertificateInfo certificateInfo,
           com.geotrust.api.webtrust.order.CertificateInfo pendingCertificateInfo,
           com.geotrust.api.webtrust.order.Fulfillment fulfillment,
           com.geotrust.api.webtrust.order.CertificateDetail[] certificateSearchResult,
           com.geotrust.api.webtrust.order.OrderAttribute[] orderAttributes,
           com.geotrust.api.webtrust.order.AuthenticationComment[] authenticationComments,
           com.geotrust.api.webtrust.order.AuthenticationStatus[] authenticationStatuses,
           com.geotrust.api.webtrust.order.SANVettingStatus[] SANVettingStatuses,
           com.geotrust.api.webtrust.order.TrustServicesDetails trustServicesDetails,
           com.geotrust.api.webtrust.order.TrialDetails trialDetails,
           com.geotrust.api.webtrust.order.VulnerabilityScanDetails vulnerabilityScanDetails) {
           this.modificationEvents = modificationEvents;
           this.orderInfo = orderInfo;
           this.quickOrderDetail = quickOrderDetail;
           this.trueOrderDetail = trueOrderDetail;
           this.orderContacts = orderContacts;
           this.TCOrderDetail = TCOrderDetail;
           this.certificateInfo = certificateInfo;
           this.pendingCertificateInfo = pendingCertificateInfo;
           this.fulfillment = fulfillment;
           this.certificateSearchResult = certificateSearchResult;
           this.orderAttributes = orderAttributes;
           this.authenticationComments = authenticationComments;
           this.authenticationStatuses = authenticationStatuses;
           this.SANVettingStatuses = SANVettingStatuses;
           this.trustServicesDetails = trustServicesDetails;
           this.trialDetails = trialDetails;
           this.vulnerabilityScanDetails = vulnerabilityScanDetails;
    }


    /**
     * Gets the modificationEvents value for this OrderDetail.
     * 
     * @return modificationEvents
     */
    public com.geotrust.api.webtrust.order.ModificationEvent[] getModificationEvents() {
        return modificationEvents;
    }


    /**
     * Sets the modificationEvents value for this OrderDetail.
     * 
     * @param modificationEvents
     */
    public void setModificationEvents(com.geotrust.api.webtrust.order.ModificationEvent[] modificationEvents) {
        this.modificationEvents = modificationEvents;
    }


    /**
     * Gets the orderInfo value for this OrderDetail.
     * 
     * @return orderInfo
     */
    public com.geotrust.api.webtrust.order.OrderInfo getOrderInfo() {
        return orderInfo;
    }


    /**
     * Sets the orderInfo value for this OrderDetail.
     * 
     * @param orderInfo
     */
    public void setOrderInfo(com.geotrust.api.webtrust.order.OrderInfo orderInfo) {
        this.orderInfo = orderInfo;
    }


    /**
     * Gets the quickOrderDetail value for this OrderDetail.
     * 
     * @return quickOrderDetail
     */
    public com.geotrust.api.webtrust.order.QuickOrderDetail getQuickOrderDetail() {
        return quickOrderDetail;
    }


    /**
     * Sets the quickOrderDetail value for this OrderDetail.
     * 
     * @param quickOrderDetail
     */
    public void setQuickOrderDetail(com.geotrust.api.webtrust.order.QuickOrderDetail quickOrderDetail) {
        this.quickOrderDetail = quickOrderDetail;
    }


    /**
     * Gets the trueOrderDetail value for this OrderDetail.
     * 
     * @return trueOrderDetail
     */
    public com.geotrust.api.webtrust.order.TrueOrderDetail getTrueOrderDetail() {
        return trueOrderDetail;
    }


    /**
     * Sets the trueOrderDetail value for this OrderDetail.
     * 
     * @param trueOrderDetail
     */
    public void setTrueOrderDetail(com.geotrust.api.webtrust.order.TrueOrderDetail trueOrderDetail) {
        this.trueOrderDetail = trueOrderDetail;
    }


    /**
     * Gets the orderContacts value for this OrderDetail.
     * 
     * @return orderContacts
     */
    public com.geotrust.api.webtrust.order.OrderContacts getOrderContacts() {
        return orderContacts;
    }


    /**
     * Sets the orderContacts value for this OrderDetail.
     * 
     * @param orderContacts
     */
    public void setOrderContacts(com.geotrust.api.webtrust.order.OrderContacts orderContacts) {
        this.orderContacts = orderContacts;
    }


    /**
     * Gets the TCOrderDetail value for this OrderDetail.
     * 
     * @return TCOrderDetail
     */
    public com.geotrust.api.webtrust.order.TCOrderDetail getTCOrderDetail() {
        return TCOrderDetail;
    }


    /**
     * Sets the TCOrderDetail value for this OrderDetail.
     * 
     * @param TCOrderDetail
     */
    public void setTCOrderDetail(com.geotrust.api.webtrust.order.TCOrderDetail TCOrderDetail) {
        this.TCOrderDetail = TCOrderDetail;
    }


    /**
     * Gets the certificateInfo value for this OrderDetail.
     * 
     * @return certificateInfo
     */
    public com.geotrust.api.webtrust.order.CertificateInfo getCertificateInfo() {
        return certificateInfo;
    }


    /**
     * Sets the certificateInfo value for this OrderDetail.
     * 
     * @param certificateInfo
     */
    public void setCertificateInfo(com.geotrust.api.webtrust.order.CertificateInfo certificateInfo) {
        this.certificateInfo = certificateInfo;
    }


    /**
     * Gets the pendingCertificateInfo value for this OrderDetail.
     * 
     * @return pendingCertificateInfo
     */
    public com.geotrust.api.webtrust.order.CertificateInfo getPendingCertificateInfo() {
        return pendingCertificateInfo;
    }


    /**
     * Sets the pendingCertificateInfo value for this OrderDetail.
     * 
     * @param pendingCertificateInfo
     */
    public void setPendingCertificateInfo(com.geotrust.api.webtrust.order.CertificateInfo pendingCertificateInfo) {
        this.pendingCertificateInfo = pendingCertificateInfo;
    }


    /**
     * Gets the fulfillment value for this OrderDetail.
     * 
     * @return fulfillment
     */
    public com.geotrust.api.webtrust.order.Fulfillment getFulfillment() {
        return fulfillment;
    }


    /**
     * Sets the fulfillment value for this OrderDetail.
     * 
     * @param fulfillment
     */
    public void setFulfillment(com.geotrust.api.webtrust.order.Fulfillment fulfillment) {
        this.fulfillment = fulfillment;
    }


    /**
     * Gets the certificateSearchResult value for this OrderDetail.
     * 
     * @return certificateSearchResult
     */
    public com.geotrust.api.webtrust.order.CertificateDetail[] getCertificateSearchResult() {
        return certificateSearchResult;
    }


    /**
     * Sets the certificateSearchResult value for this OrderDetail.
     * 
     * @param certificateSearchResult
     */
    public void setCertificateSearchResult(com.geotrust.api.webtrust.order.CertificateDetail[] certificateSearchResult) {
        this.certificateSearchResult = certificateSearchResult;
    }


    /**
     * Gets the orderAttributes value for this OrderDetail.
     * 
     * @return orderAttributes
     */
    public com.geotrust.api.webtrust.order.OrderAttribute[] getOrderAttributes() {
        return orderAttributes;
    }


    /**
     * Sets the orderAttributes value for this OrderDetail.
     * 
     * @param orderAttributes
     */
    public void setOrderAttributes(com.geotrust.api.webtrust.order.OrderAttribute[] orderAttributes) {
        this.orderAttributes = orderAttributes;
    }


    /**
     * Gets the authenticationComments value for this OrderDetail.
     * 
     * @return authenticationComments
     */
    public com.geotrust.api.webtrust.order.AuthenticationComment[] getAuthenticationComments() {
        return authenticationComments;
    }


    /**
     * Sets the authenticationComments value for this OrderDetail.
     * 
     * @param authenticationComments
     */
    public void setAuthenticationComments(com.geotrust.api.webtrust.order.AuthenticationComment[] authenticationComments) {
        this.authenticationComments = authenticationComments;
    }


    /**
     * Gets the authenticationStatuses value for this OrderDetail.
     * 
     * @return authenticationStatuses
     */
    public com.geotrust.api.webtrust.order.AuthenticationStatus[] getAuthenticationStatuses() {
        return authenticationStatuses;
    }


    /**
     * Sets the authenticationStatuses value for this OrderDetail.
     * 
     * @param authenticationStatuses
     */
    public void setAuthenticationStatuses(com.geotrust.api.webtrust.order.AuthenticationStatus[] authenticationStatuses) {
        this.authenticationStatuses = authenticationStatuses;
    }


    /**
     * Gets the SANVettingStatuses value for this OrderDetail.
     * 
     * @return SANVettingStatuses
     */
    public com.geotrust.api.webtrust.order.SANVettingStatus[] getSANVettingStatuses() {
        return SANVettingStatuses;
    }


    /**
     * Sets the SANVettingStatuses value for this OrderDetail.
     * 
     * @param SANVettingStatuses
     */
    public void setSANVettingStatuses(com.geotrust.api.webtrust.order.SANVettingStatus[] SANVettingStatuses) {
        this.SANVettingStatuses = SANVettingStatuses;
    }


    /**
     * Gets the trustServicesDetails value for this OrderDetail.
     * 
     * @return trustServicesDetails
     */
    public com.geotrust.api.webtrust.order.TrustServicesDetails getTrustServicesDetails() {
        return trustServicesDetails;
    }


    /**
     * Sets the trustServicesDetails value for this OrderDetail.
     * 
     * @param trustServicesDetails
     */
    public void setTrustServicesDetails(com.geotrust.api.webtrust.order.TrustServicesDetails trustServicesDetails) {
        this.trustServicesDetails = trustServicesDetails;
    }


    /**
     * Gets the trialDetails value for this OrderDetail.
     * 
     * @return trialDetails
     */
    public com.geotrust.api.webtrust.order.TrialDetails getTrialDetails() {
        return trialDetails;
    }


    /**
     * Sets the trialDetails value for this OrderDetail.
     * 
     * @param trialDetails
     */
    public void setTrialDetails(com.geotrust.api.webtrust.order.TrialDetails trialDetails) {
        this.trialDetails = trialDetails;
    }


    /**
     * Gets the vulnerabilityScanDetails value for this OrderDetail.
     * 
     * @return vulnerabilityScanDetails
     */
    public com.geotrust.api.webtrust.order.VulnerabilityScanDetails getVulnerabilityScanDetails() {
        return vulnerabilityScanDetails;
    }


    /**
     * Sets the vulnerabilityScanDetails value for this OrderDetail.
     * 
     * @param vulnerabilityScanDetails
     */
    public void setVulnerabilityScanDetails(com.geotrust.api.webtrust.order.VulnerabilityScanDetails vulnerabilityScanDetails) {
        this.vulnerabilityScanDetails = vulnerabilityScanDetails;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof OrderDetail)) return false;
        OrderDetail other = (OrderDetail) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.modificationEvents==null && other.getModificationEvents()==null) || 
             (this.modificationEvents!=null &&
              java.util.Arrays.equals(this.modificationEvents, other.getModificationEvents()))) &&
            ((this.orderInfo==null && other.getOrderInfo()==null) || 
             (this.orderInfo!=null &&
              this.orderInfo.equals(other.getOrderInfo()))) &&
            ((this.quickOrderDetail==null && other.getQuickOrderDetail()==null) || 
             (this.quickOrderDetail!=null &&
              this.quickOrderDetail.equals(other.getQuickOrderDetail()))) &&
            ((this.trueOrderDetail==null && other.getTrueOrderDetail()==null) || 
             (this.trueOrderDetail!=null &&
              this.trueOrderDetail.equals(other.getTrueOrderDetail()))) &&
            ((this.orderContacts==null && other.getOrderContacts()==null) || 
             (this.orderContacts!=null &&
              this.orderContacts.equals(other.getOrderContacts()))) &&
            ((this.TCOrderDetail==null && other.getTCOrderDetail()==null) || 
             (this.TCOrderDetail!=null &&
              this.TCOrderDetail.equals(other.getTCOrderDetail()))) &&
            ((this.certificateInfo==null && other.getCertificateInfo()==null) || 
             (this.certificateInfo!=null &&
              this.certificateInfo.equals(other.getCertificateInfo()))) &&
            ((this.pendingCertificateInfo==null && other.getPendingCertificateInfo()==null) || 
             (this.pendingCertificateInfo!=null &&
              this.pendingCertificateInfo.equals(other.getPendingCertificateInfo()))) &&
            ((this.fulfillment==null && other.getFulfillment()==null) || 
             (this.fulfillment!=null &&
              this.fulfillment.equals(other.getFulfillment()))) &&
            ((this.certificateSearchResult==null && other.getCertificateSearchResult()==null) || 
             (this.certificateSearchResult!=null &&
              java.util.Arrays.equals(this.certificateSearchResult, other.getCertificateSearchResult()))) &&
            ((this.orderAttributes==null && other.getOrderAttributes()==null) || 
             (this.orderAttributes!=null &&
              java.util.Arrays.equals(this.orderAttributes, other.getOrderAttributes()))) &&
            ((this.authenticationComments==null && other.getAuthenticationComments()==null) || 
             (this.authenticationComments!=null &&
              java.util.Arrays.equals(this.authenticationComments, other.getAuthenticationComments()))) &&
            ((this.authenticationStatuses==null && other.getAuthenticationStatuses()==null) || 
             (this.authenticationStatuses!=null &&
              java.util.Arrays.equals(this.authenticationStatuses, other.getAuthenticationStatuses()))) &&
            ((this.SANVettingStatuses==null && other.getSANVettingStatuses()==null) || 
             (this.SANVettingStatuses!=null &&
              java.util.Arrays.equals(this.SANVettingStatuses, other.getSANVettingStatuses()))) &&
            ((this.trustServicesDetails==null && other.getTrustServicesDetails()==null) || 
             (this.trustServicesDetails!=null &&
              this.trustServicesDetails.equals(other.getTrustServicesDetails()))) &&
            ((this.trialDetails==null && other.getTrialDetails()==null) || 
             (this.trialDetails!=null &&
              this.trialDetails.equals(other.getTrialDetails()))) &&
            ((this.vulnerabilityScanDetails==null && other.getVulnerabilityScanDetails()==null) || 
             (this.vulnerabilityScanDetails!=null &&
              this.vulnerabilityScanDetails.equals(other.getVulnerabilityScanDetails())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getModificationEvents() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getModificationEvents());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getModificationEvents(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getOrderInfo() != null) {
            _hashCode += getOrderInfo().hashCode();
        }
        if (getQuickOrderDetail() != null) {
            _hashCode += getQuickOrderDetail().hashCode();
        }
        if (getTrueOrderDetail() != null) {
            _hashCode += getTrueOrderDetail().hashCode();
        }
        if (getOrderContacts() != null) {
            _hashCode += getOrderContacts().hashCode();
        }
        if (getTCOrderDetail() != null) {
            _hashCode += getTCOrderDetail().hashCode();
        }
        if (getCertificateInfo() != null) {
            _hashCode += getCertificateInfo().hashCode();
        }
        if (getPendingCertificateInfo() != null) {
            _hashCode += getPendingCertificateInfo().hashCode();
        }
        if (getFulfillment() != null) {
            _hashCode += getFulfillment().hashCode();
        }
        if (getCertificateSearchResult() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCertificateSearchResult());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCertificateSearchResult(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getOrderAttributes() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getOrderAttributes());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getOrderAttributes(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getAuthenticationComments() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getAuthenticationComments());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getAuthenticationComments(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getAuthenticationStatuses() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getAuthenticationStatuses());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getAuthenticationStatuses(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getSANVettingStatuses() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getSANVettingStatuses());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getSANVettingStatuses(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getTrustServicesDetails() != null) {
            _hashCode += getTrustServicesDetails().hashCode();
        }
        if (getTrialDetails() != null) {
            _hashCode += getTrialDetails().hashCode();
        }
        if (getVulnerabilityScanDetails() != null) {
            _hashCode += getVulnerabilityScanDetails().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(OrderDetail.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "OrderDetail"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("modificationEvents");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ModificationEvents"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ModificationEvent"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ModificationEvent"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "OrderInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "orderInfo"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("quickOrderDetail");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "QuickOrderDetail"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "quickOrderDetail"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("trueOrderDetail");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "TrueOrderDetail"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "trueOrderDetail"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderContacts");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "OrderContacts"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "orderContacts"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TCOrderDetail");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "TCOrderDetail"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "TCOrderDetail"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("certificateInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "CertificateInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "certificateInfo"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("pendingCertificateInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "PendingCertificateInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "certificateInfo"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fulfillment");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Fulfillment"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "fulfillment"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("certificateSearchResult");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "CertificateSearchResult"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "CertificateDetail"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "CertificateDetail"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderAttributes");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "OrderAttributes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "OrderAttribute"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "OrderAttribute"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("authenticationComments");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "AuthenticationComments"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "AuthenticationComment"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "AuthenticationComment"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("authenticationStatuses");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "AuthenticationStatuses"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "AuthenticationStatus"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "AuthenticationStatus"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SANVettingStatuses");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "SANVettingStatuses"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "SANVettingStatus"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "SANVettingStatus"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("trustServicesDetails");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "TrustServicesDetails"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "trustServicesDetails"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("trialDetails");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "TrialDetails"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "TrialDetails"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("vulnerabilityScanDetails");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "VulnerabilityScanDetails"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "vulnerabilityScanDetails"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
