/**
 * Pin1Request.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.order;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class Pin1Request  implements java.io.Serializable {
    private com.geotrust.api.webtrust.order.OrderRequestHeader orderRequestHeader;

    private com.geotrust.api.webtrust.order.OrganizationInfo organizationInfo;

    private com.geotrust.api.webtrust.order.OrderParameters orderParameters;

    private com.geotrust.api.webtrust.order.Contact adminContact;

    private com.geotrust.api.webtrust.order.Contact techContact;

    private com.geotrust.api.webtrust.order.Contact billingContact;

    private com.geotrust.api.webtrust.order.PaymentInfo paymentInfo;

    private com.geotrust.api.webtrust.order.PartnerTag[] partnerTags;

    private java.lang.Integer inviteDuration;

    private java.lang.Integer chainKeySize;

    private java.lang.Integer reservedSanCount;

    public Pin1Request() {
    }

    public Pin1Request(
           com.geotrust.api.webtrust.order.OrderRequestHeader orderRequestHeader,
           com.geotrust.api.webtrust.order.OrganizationInfo organizationInfo,
           com.geotrust.api.webtrust.order.OrderParameters orderParameters,
           com.geotrust.api.webtrust.order.Contact adminContact,
           com.geotrust.api.webtrust.order.Contact techContact,
           com.geotrust.api.webtrust.order.Contact billingContact,
           com.geotrust.api.webtrust.order.PaymentInfo paymentInfo,
           com.geotrust.api.webtrust.order.PartnerTag[] partnerTags,
           java.lang.Integer inviteDuration,
           java.lang.Integer chainKeySize,
           java.lang.Integer reservedSanCount) {
           this.orderRequestHeader = orderRequestHeader;
           this.organizationInfo = organizationInfo;
           this.orderParameters = orderParameters;
           this.adminContact = adminContact;
           this.techContact = techContact;
           this.billingContact = billingContact;
           this.paymentInfo = paymentInfo;
           this.partnerTags = partnerTags;
           this.inviteDuration = inviteDuration;
           this.chainKeySize = chainKeySize;
           this.reservedSanCount = reservedSanCount;
    }


    /**
     * Gets the orderRequestHeader value for this Pin1Request.
     * 
     * @return orderRequestHeader
     */
    public com.geotrust.api.webtrust.order.OrderRequestHeader getOrderRequestHeader() {
        return orderRequestHeader;
    }


    /**
     * Sets the orderRequestHeader value for this Pin1Request.
     * 
     * @param orderRequestHeader
     */
    public void setOrderRequestHeader(com.geotrust.api.webtrust.order.OrderRequestHeader orderRequestHeader) {
        this.orderRequestHeader = orderRequestHeader;
    }


    /**
     * Gets the organizationInfo value for this Pin1Request.
     * 
     * @return organizationInfo
     */
    public com.geotrust.api.webtrust.order.OrganizationInfo getOrganizationInfo() {
        return organizationInfo;
    }


    /**
     * Sets the organizationInfo value for this Pin1Request.
     * 
     * @param organizationInfo
     */
    public void setOrganizationInfo(com.geotrust.api.webtrust.order.OrganizationInfo organizationInfo) {
        this.organizationInfo = organizationInfo;
    }


    /**
     * Gets the orderParameters value for this Pin1Request.
     * 
     * @return orderParameters
     */
    public com.geotrust.api.webtrust.order.OrderParameters getOrderParameters() {
        return orderParameters;
    }


    /**
     * Sets the orderParameters value for this Pin1Request.
     * 
     * @param orderParameters
     */
    public void setOrderParameters(com.geotrust.api.webtrust.order.OrderParameters orderParameters) {
        this.orderParameters = orderParameters;
    }


    /**
     * Gets the adminContact value for this Pin1Request.
     * 
     * @return adminContact
     */
    public com.geotrust.api.webtrust.order.Contact getAdminContact() {
        return adminContact;
    }


    /**
     * Sets the adminContact value for this Pin1Request.
     * 
     * @param adminContact
     */
    public void setAdminContact(com.geotrust.api.webtrust.order.Contact adminContact) {
        this.adminContact = adminContact;
    }


    /**
     * Gets the techContact value for this Pin1Request.
     * 
     * @return techContact
     */
    public com.geotrust.api.webtrust.order.Contact getTechContact() {
        return techContact;
    }


    /**
     * Sets the techContact value for this Pin1Request.
     * 
     * @param techContact
     */
    public void setTechContact(com.geotrust.api.webtrust.order.Contact techContact) {
        this.techContact = techContact;
    }


    /**
     * Gets the billingContact value for this Pin1Request.
     * 
     * @return billingContact
     */
    public com.geotrust.api.webtrust.order.Contact getBillingContact() {
        return billingContact;
    }


    /**
     * Sets the billingContact value for this Pin1Request.
     * 
     * @param billingContact
     */
    public void setBillingContact(com.geotrust.api.webtrust.order.Contact billingContact) {
        this.billingContact = billingContact;
    }


    /**
     * Gets the paymentInfo value for this Pin1Request.
     * 
     * @return paymentInfo
     */
    public com.geotrust.api.webtrust.order.PaymentInfo getPaymentInfo() {
        return paymentInfo;
    }


    /**
     * Sets the paymentInfo value for this Pin1Request.
     * 
     * @param paymentInfo
     */
    public void setPaymentInfo(com.geotrust.api.webtrust.order.PaymentInfo paymentInfo) {
        this.paymentInfo = paymentInfo;
    }


    /**
     * Gets the partnerTags value for this Pin1Request.
     * 
     * @return partnerTags
     */
    public com.geotrust.api.webtrust.order.PartnerTag[] getPartnerTags() {
        return partnerTags;
    }


    /**
     * Sets the partnerTags value for this Pin1Request.
     * 
     * @param partnerTags
     */
    public void setPartnerTags(com.geotrust.api.webtrust.order.PartnerTag[] partnerTags) {
        this.partnerTags = partnerTags;
    }


    /**
     * Gets the inviteDuration value for this Pin1Request.
     * 
     * @return inviteDuration
     */
    public java.lang.Integer getInviteDuration() {
        return inviteDuration;
    }


    /**
     * Sets the inviteDuration value for this Pin1Request.
     * 
     * @param inviteDuration
     */
    public void setInviteDuration(java.lang.Integer inviteDuration) {
        this.inviteDuration = inviteDuration;
    }


    /**
     * Gets the chainKeySize value for this Pin1Request.
     * 
     * @return chainKeySize
     */
    public java.lang.Integer getChainKeySize() {
        return chainKeySize;
    }


    /**
     * Sets the chainKeySize value for this Pin1Request.
     * 
     * @param chainKeySize
     */
    public void setChainKeySize(java.lang.Integer chainKeySize) {
        this.chainKeySize = chainKeySize;
    }


    /**
     * Gets the reservedSanCount value for this Pin1Request.
     * 
     * @return reservedSanCount
     */
    public java.lang.Integer getReservedSanCount() {
        return reservedSanCount;
    }


    /**
     * Sets the reservedSanCount value for this Pin1Request.
     * 
     * @param reservedSanCount
     */
    public void setReservedSanCount(java.lang.Integer reservedSanCount) {
        this.reservedSanCount = reservedSanCount;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Pin1Request)) return false;
        Pin1Request other = (Pin1Request) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.orderRequestHeader==null && other.getOrderRequestHeader()==null) || 
             (this.orderRequestHeader!=null &&
              this.orderRequestHeader.equals(other.getOrderRequestHeader()))) &&
            ((this.organizationInfo==null && other.getOrganizationInfo()==null) || 
             (this.organizationInfo!=null &&
              this.organizationInfo.equals(other.getOrganizationInfo()))) &&
            ((this.orderParameters==null && other.getOrderParameters()==null) || 
             (this.orderParameters!=null &&
              this.orderParameters.equals(other.getOrderParameters()))) &&
            ((this.adminContact==null && other.getAdminContact()==null) || 
             (this.adminContact!=null &&
              this.adminContact.equals(other.getAdminContact()))) &&
            ((this.techContact==null && other.getTechContact()==null) || 
             (this.techContact!=null &&
              this.techContact.equals(other.getTechContact()))) &&
            ((this.billingContact==null && other.getBillingContact()==null) || 
             (this.billingContact!=null &&
              this.billingContact.equals(other.getBillingContact()))) &&
            ((this.paymentInfo==null && other.getPaymentInfo()==null) || 
             (this.paymentInfo!=null &&
              this.paymentInfo.equals(other.getPaymentInfo()))) &&
            ((this.partnerTags==null && other.getPartnerTags()==null) || 
             (this.partnerTags!=null &&
              java.util.Arrays.equals(this.partnerTags, other.getPartnerTags()))) &&
            ((this.inviteDuration==null && other.getInviteDuration()==null) || 
             (this.inviteDuration!=null &&
              this.inviteDuration.equals(other.getInviteDuration()))) &&
            ((this.chainKeySize==null && other.getChainKeySize()==null) || 
             (this.chainKeySize!=null &&
              this.chainKeySize.equals(other.getChainKeySize()))) &&
            ((this.reservedSanCount==null && other.getReservedSanCount()==null) || 
             (this.reservedSanCount!=null &&
              this.reservedSanCount.equals(other.getReservedSanCount())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getOrderRequestHeader() != null) {
            _hashCode += getOrderRequestHeader().hashCode();
        }
        if (getOrganizationInfo() != null) {
            _hashCode += getOrganizationInfo().hashCode();
        }
        if (getOrderParameters() != null) {
            _hashCode += getOrderParameters().hashCode();
        }
        if (getAdminContact() != null) {
            _hashCode += getAdminContact().hashCode();
        }
        if (getTechContact() != null) {
            _hashCode += getTechContact().hashCode();
        }
        if (getBillingContact() != null) {
            _hashCode += getBillingContact().hashCode();
        }
        if (getPaymentInfo() != null) {
            _hashCode += getPaymentInfo().hashCode();
        }
        if (getPartnerTags() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getPartnerTags());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getPartnerTags(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getInviteDuration() != null) {
            _hashCode += getInviteDuration().hashCode();
        }
        if (getChainKeySize() != null) {
            _hashCode += getChainKeySize().hashCode();
        }
        if (getReservedSanCount() != null) {
            _hashCode += getReservedSanCount().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Pin1Request.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Pin1Request"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderRequestHeader");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "OrderRequestHeader"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "orderRequestHeader"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("organizationInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "OrganizationInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "organizationInfo"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderParameters");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "OrderParameters"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "orderParameters"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("adminContact");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "AdminContact"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Contact"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("techContact");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "TechContact"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Contact"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("billingContact");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "BillingContact"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Contact"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("paymentInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "PaymentInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "paymentInfo"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("partnerTags");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "PartnerTags"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "PartnerTag"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "PartnerTag"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("inviteDuration");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "InviteDuration"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("chainKeySize");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ChainKeySize"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("reservedSanCount");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ReservedSanCount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
