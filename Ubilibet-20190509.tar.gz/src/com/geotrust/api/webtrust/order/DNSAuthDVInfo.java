/**
 * DNSAuthDVInfo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.order;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class DNSAuthDVInfo  implements java.io.Serializable {
    private java.lang.String pollStatus;

    private java.util.Calendar lastPollDate;

    public DNSAuthDVInfo() {
    }

    public DNSAuthDVInfo(
           java.lang.String pollStatus,
           java.util.Calendar lastPollDate) {
           this.pollStatus = pollStatus;
           this.lastPollDate = lastPollDate;
    }


    /**
     * Gets the pollStatus value for this DNSAuthDVInfo.
     * 
     * @return pollStatus
     */
    public java.lang.String getPollStatus() {
        return pollStatus;
    }


    /**
     * Sets the pollStatus value for this DNSAuthDVInfo.
     * 
     * @param pollStatus
     */
    public void setPollStatus(java.lang.String pollStatus) {
        this.pollStatus = pollStatus;
    }


    /**
     * Gets the lastPollDate value for this DNSAuthDVInfo.
     * 
     * @return lastPollDate
     */
    public java.util.Calendar getLastPollDate() {
        return lastPollDate;
    }


    /**
     * Sets the lastPollDate value for this DNSAuthDVInfo.
     * 
     * @param lastPollDate
     */
    public void setLastPollDate(java.util.Calendar lastPollDate) {
        this.lastPollDate = lastPollDate;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof DNSAuthDVInfo)) return false;
        DNSAuthDVInfo other = (DNSAuthDVInfo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.pollStatus==null && other.getPollStatus()==null) || 
             (this.pollStatus!=null &&
              this.pollStatus.equals(other.getPollStatus()))) &&
            ((this.lastPollDate==null && other.getLastPollDate()==null) || 
             (this.lastPollDate!=null &&
              this.lastPollDate.equals(other.getLastPollDate())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getPollStatus() != null) {
            _hashCode += getPollStatus().hashCode();
        }
        if (getLastPollDate() != null) {
            _hashCode += getLastPollDate().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(DNSAuthDVInfo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "DNSAuthDVInfo"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("pollStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "PollStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastPollDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "LastPollDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
