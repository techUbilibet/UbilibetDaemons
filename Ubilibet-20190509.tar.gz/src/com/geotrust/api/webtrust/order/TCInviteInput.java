/**
 * TCInviteInput.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.order;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class TCInviteInput  implements java.io.Serializable {
    private com.geotrust.api.webtrust.order.OrderRequestHeader orderRequestHeader;

    private java.lang.Integer inviteDuration;

    private com.geotrust.api.webtrust.order.TCOrderParameters TCOrderParameters;

    private com.geotrust.api.webtrust.order.OrderAttribute[] orderAttributes;

    public TCInviteInput() {
    }

    public TCInviteInput(
           com.geotrust.api.webtrust.order.OrderRequestHeader orderRequestHeader,
           java.lang.Integer inviteDuration,
           com.geotrust.api.webtrust.order.TCOrderParameters TCOrderParameters,
           com.geotrust.api.webtrust.order.OrderAttribute[] orderAttributes) {
           this.orderRequestHeader = orderRequestHeader;
           this.inviteDuration = inviteDuration;
           this.TCOrderParameters = TCOrderParameters;
           this.orderAttributes = orderAttributes;
    }


    /**
     * Gets the orderRequestHeader value for this TCInviteInput.
     * 
     * @return orderRequestHeader
     */
    public com.geotrust.api.webtrust.order.OrderRequestHeader getOrderRequestHeader() {
        return orderRequestHeader;
    }


    /**
     * Sets the orderRequestHeader value for this TCInviteInput.
     * 
     * @param orderRequestHeader
     */
    public void setOrderRequestHeader(com.geotrust.api.webtrust.order.OrderRequestHeader orderRequestHeader) {
        this.orderRequestHeader = orderRequestHeader;
    }


    /**
     * Gets the inviteDuration value for this TCInviteInput.
     * 
     * @return inviteDuration
     */
    public java.lang.Integer getInviteDuration() {
        return inviteDuration;
    }


    /**
     * Sets the inviteDuration value for this TCInviteInput.
     * 
     * @param inviteDuration
     */
    public void setInviteDuration(java.lang.Integer inviteDuration) {
        this.inviteDuration = inviteDuration;
    }


    /**
     * Gets the TCOrderParameters value for this TCInviteInput.
     * 
     * @return TCOrderParameters
     */
    public com.geotrust.api.webtrust.order.TCOrderParameters getTCOrderParameters() {
        return TCOrderParameters;
    }


    /**
     * Sets the TCOrderParameters value for this TCInviteInput.
     * 
     * @param TCOrderParameters
     */
    public void setTCOrderParameters(com.geotrust.api.webtrust.order.TCOrderParameters TCOrderParameters) {
        this.TCOrderParameters = TCOrderParameters;
    }


    /**
     * Gets the orderAttributes value for this TCInviteInput.
     * 
     * @return orderAttributes
     */
    public com.geotrust.api.webtrust.order.OrderAttribute[] getOrderAttributes() {
        return orderAttributes;
    }


    /**
     * Sets the orderAttributes value for this TCInviteInput.
     * 
     * @param orderAttributes
     */
    public void setOrderAttributes(com.geotrust.api.webtrust.order.OrderAttribute[] orderAttributes) {
        this.orderAttributes = orderAttributes;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof TCInviteInput)) return false;
        TCInviteInput other = (TCInviteInput) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.orderRequestHeader==null && other.getOrderRequestHeader()==null) || 
             (this.orderRequestHeader!=null &&
              this.orderRequestHeader.equals(other.getOrderRequestHeader()))) &&
            ((this.inviteDuration==null && other.getInviteDuration()==null) || 
             (this.inviteDuration!=null &&
              this.inviteDuration.equals(other.getInviteDuration()))) &&
            ((this.TCOrderParameters==null && other.getTCOrderParameters()==null) || 
             (this.TCOrderParameters!=null &&
              this.TCOrderParameters.equals(other.getTCOrderParameters()))) &&
            ((this.orderAttributes==null && other.getOrderAttributes()==null) || 
             (this.orderAttributes!=null &&
              java.util.Arrays.equals(this.orderAttributes, other.getOrderAttributes())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getOrderRequestHeader() != null) {
            _hashCode += getOrderRequestHeader().hashCode();
        }
        if (getInviteDuration() != null) {
            _hashCode += getInviteDuration().hashCode();
        }
        if (getTCOrderParameters() != null) {
            _hashCode += getTCOrderParameters().hashCode();
        }
        if (getOrderAttributes() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getOrderAttributes());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getOrderAttributes(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(TCInviteInput.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "TCInviteInput"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderRequestHeader");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "OrderRequestHeader"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "orderRequestHeader"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("inviteDuration");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "InviteDuration"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TCOrderParameters");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "TCOrderParameters"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "TCOrderParameters"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderAttributes");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "OrderAttributes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "OrderAttribute"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "OrderAttribute"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
