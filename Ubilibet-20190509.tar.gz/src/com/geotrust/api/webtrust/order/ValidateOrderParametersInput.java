/**
 * ValidateOrderParametersInput.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.order;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class ValidateOrderParametersInput  implements java.io.Serializable {
    private com.geotrust.api.webtrust.order.OrderRequestHeader orderRequestHeader;

    private com.geotrust.api.webtrust.order.OrderParameters orderParameters;

    private com.geotrust.api.webtrust.order.ValidationParameters validationParameters;

    private com.geotrust.api.webtrust.order.OrderChange[] orderChanges;

    private com.geotrust.api.webtrust.order.OrganizationInfo organizationInfo;

    private com.geotrust.api.webtrust.order.Contact adminContact;

    private java.lang.Boolean japaneseOrderCheckIndicator;

    public ValidateOrderParametersInput() {
    }

    public ValidateOrderParametersInput(
           com.geotrust.api.webtrust.order.OrderRequestHeader orderRequestHeader,
           com.geotrust.api.webtrust.order.OrderParameters orderParameters,
           com.geotrust.api.webtrust.order.ValidationParameters validationParameters,
           com.geotrust.api.webtrust.order.OrderChange[] orderChanges,
           com.geotrust.api.webtrust.order.OrganizationInfo organizationInfo,
           com.geotrust.api.webtrust.order.Contact adminContact,
           java.lang.Boolean japaneseOrderCheckIndicator) {
           this.orderRequestHeader = orderRequestHeader;
           this.orderParameters = orderParameters;
           this.validationParameters = validationParameters;
           this.orderChanges = orderChanges;
           this.organizationInfo = organizationInfo;
           this.adminContact = adminContact;
           this.japaneseOrderCheckIndicator = japaneseOrderCheckIndicator;
    }


    /**
     * Gets the orderRequestHeader value for this ValidateOrderParametersInput.
     * 
     * @return orderRequestHeader
     */
    public com.geotrust.api.webtrust.order.OrderRequestHeader getOrderRequestHeader() {
        return orderRequestHeader;
    }


    /**
     * Sets the orderRequestHeader value for this ValidateOrderParametersInput.
     * 
     * @param orderRequestHeader
     */
    public void setOrderRequestHeader(com.geotrust.api.webtrust.order.OrderRequestHeader orderRequestHeader) {
        this.orderRequestHeader = orderRequestHeader;
    }


    /**
     * Gets the orderParameters value for this ValidateOrderParametersInput.
     * 
     * @return orderParameters
     */
    public com.geotrust.api.webtrust.order.OrderParameters getOrderParameters() {
        return orderParameters;
    }


    /**
     * Sets the orderParameters value for this ValidateOrderParametersInput.
     * 
     * @param orderParameters
     */
    public void setOrderParameters(com.geotrust.api.webtrust.order.OrderParameters orderParameters) {
        this.orderParameters = orderParameters;
    }


    /**
     * Gets the validationParameters value for this ValidateOrderParametersInput.
     * 
     * @return validationParameters
     */
    public com.geotrust.api.webtrust.order.ValidationParameters getValidationParameters() {
        return validationParameters;
    }


    /**
     * Sets the validationParameters value for this ValidateOrderParametersInput.
     * 
     * @param validationParameters
     */
    public void setValidationParameters(com.geotrust.api.webtrust.order.ValidationParameters validationParameters) {
        this.validationParameters = validationParameters;
    }


    /**
     * Gets the orderChanges value for this ValidateOrderParametersInput.
     * 
     * @return orderChanges
     */
    public com.geotrust.api.webtrust.order.OrderChange[] getOrderChanges() {
        return orderChanges;
    }


    /**
     * Sets the orderChanges value for this ValidateOrderParametersInput.
     * 
     * @param orderChanges
     */
    public void setOrderChanges(com.geotrust.api.webtrust.order.OrderChange[] orderChanges) {
        this.orderChanges = orderChanges;
    }


    /**
     * Gets the organizationInfo value for this ValidateOrderParametersInput.
     * 
     * @return organizationInfo
     */
    public com.geotrust.api.webtrust.order.OrganizationInfo getOrganizationInfo() {
        return organizationInfo;
    }


    /**
     * Sets the organizationInfo value for this ValidateOrderParametersInput.
     * 
     * @param organizationInfo
     */
    public void setOrganizationInfo(com.geotrust.api.webtrust.order.OrganizationInfo organizationInfo) {
        this.organizationInfo = organizationInfo;
    }


    /**
     * Gets the adminContact value for this ValidateOrderParametersInput.
     * 
     * @return adminContact
     */
    public com.geotrust.api.webtrust.order.Contact getAdminContact() {
        return adminContact;
    }


    /**
     * Sets the adminContact value for this ValidateOrderParametersInput.
     * 
     * @param adminContact
     */
    public void setAdminContact(com.geotrust.api.webtrust.order.Contact adminContact) {
        this.adminContact = adminContact;
    }


    /**
     * Gets the japaneseOrderCheckIndicator value for this ValidateOrderParametersInput.
     * 
     * @return japaneseOrderCheckIndicator
     */
    public java.lang.Boolean getJapaneseOrderCheckIndicator() {
        return japaneseOrderCheckIndicator;
    }


    /**
     * Sets the japaneseOrderCheckIndicator value for this ValidateOrderParametersInput.
     * 
     * @param japaneseOrderCheckIndicator
     */
    public void setJapaneseOrderCheckIndicator(java.lang.Boolean japaneseOrderCheckIndicator) {
        this.japaneseOrderCheckIndicator = japaneseOrderCheckIndicator;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ValidateOrderParametersInput)) return false;
        ValidateOrderParametersInput other = (ValidateOrderParametersInput) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.orderRequestHeader==null && other.getOrderRequestHeader()==null) || 
             (this.orderRequestHeader!=null &&
              this.orderRequestHeader.equals(other.getOrderRequestHeader()))) &&
            ((this.orderParameters==null && other.getOrderParameters()==null) || 
             (this.orderParameters!=null &&
              this.orderParameters.equals(other.getOrderParameters()))) &&
            ((this.validationParameters==null && other.getValidationParameters()==null) || 
             (this.validationParameters!=null &&
              this.validationParameters.equals(other.getValidationParameters()))) &&
            ((this.orderChanges==null && other.getOrderChanges()==null) || 
             (this.orderChanges!=null &&
              java.util.Arrays.equals(this.orderChanges, other.getOrderChanges()))) &&
            ((this.organizationInfo==null && other.getOrganizationInfo()==null) || 
             (this.organizationInfo!=null &&
              this.organizationInfo.equals(other.getOrganizationInfo()))) &&
            ((this.adminContact==null && other.getAdminContact()==null) || 
             (this.adminContact!=null &&
              this.adminContact.equals(other.getAdminContact()))) &&
            ((this.japaneseOrderCheckIndicator==null && other.getJapaneseOrderCheckIndicator()==null) || 
             (this.japaneseOrderCheckIndicator!=null &&
              this.japaneseOrderCheckIndicator.equals(other.getJapaneseOrderCheckIndicator())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getOrderRequestHeader() != null) {
            _hashCode += getOrderRequestHeader().hashCode();
        }
        if (getOrderParameters() != null) {
            _hashCode += getOrderParameters().hashCode();
        }
        if (getValidationParameters() != null) {
            _hashCode += getValidationParameters().hashCode();
        }
        if (getOrderChanges() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getOrderChanges());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getOrderChanges(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getOrganizationInfo() != null) {
            _hashCode += getOrganizationInfo().hashCode();
        }
        if (getAdminContact() != null) {
            _hashCode += getAdminContact().hashCode();
        }
        if (getJapaneseOrderCheckIndicator() != null) {
            _hashCode += getJapaneseOrderCheckIndicator().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ValidateOrderParametersInput.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ValidateOrderParametersInput"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderRequestHeader");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "OrderRequestHeader"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "orderRequestHeader"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderParameters");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "OrderParameters"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "orderParameters"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("validationParameters");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ValidationParameters"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "validationParameters"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderChanges");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "OrderChanges"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "OrderChange"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "OrderChange"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("organizationInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "OrganizationInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "organizationInfo"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("adminContact");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "AdminContact"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Contact"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("japaneseOrderCheckIndicator");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "JapaneseOrderCheckIndicator"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
