/**
 * AuthOrderOutput.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.order;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class AuthOrderOutput  implements java.io.Serializable {
    private com.geotrust.api.webtrust.order.OrderResponseHeader authOrderResponseHeader;

    private com.geotrust.api.webtrust.order.AuthOrderDataStatus authOrderData;

    public AuthOrderOutput() {
    }

    public AuthOrderOutput(
           com.geotrust.api.webtrust.order.OrderResponseHeader authOrderResponseHeader,
           com.geotrust.api.webtrust.order.AuthOrderDataStatus authOrderData) {
           this.authOrderResponseHeader = authOrderResponseHeader;
           this.authOrderData = authOrderData;
    }


    /**
     * Gets the authOrderResponseHeader value for this AuthOrderOutput.
     * 
     * @return authOrderResponseHeader
     */
    public com.geotrust.api.webtrust.order.OrderResponseHeader getAuthOrderResponseHeader() {
        return authOrderResponseHeader;
    }


    /**
     * Sets the authOrderResponseHeader value for this AuthOrderOutput.
     * 
     * @param authOrderResponseHeader
     */
    public void setAuthOrderResponseHeader(com.geotrust.api.webtrust.order.OrderResponseHeader authOrderResponseHeader) {
        this.authOrderResponseHeader = authOrderResponseHeader;
    }


    /**
     * Gets the authOrderData value for this AuthOrderOutput.
     * 
     * @return authOrderData
     */
    public com.geotrust.api.webtrust.order.AuthOrderDataStatus getAuthOrderData() {
        return authOrderData;
    }


    /**
     * Sets the authOrderData value for this AuthOrderOutput.
     * 
     * @param authOrderData
     */
    public void setAuthOrderData(com.geotrust.api.webtrust.order.AuthOrderDataStatus authOrderData) {
        this.authOrderData = authOrderData;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof AuthOrderOutput)) return false;
        AuthOrderOutput other = (AuthOrderOutput) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.authOrderResponseHeader==null && other.getAuthOrderResponseHeader()==null) || 
             (this.authOrderResponseHeader!=null &&
              this.authOrderResponseHeader.equals(other.getAuthOrderResponseHeader()))) &&
            ((this.authOrderData==null && other.getAuthOrderData()==null) || 
             (this.authOrderData!=null &&
              this.authOrderData.equals(other.getAuthOrderData())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getAuthOrderResponseHeader() != null) {
            _hashCode += getAuthOrderResponseHeader().hashCode();
        }
        if (getAuthOrderData() != null) {
            _hashCode += getAuthOrderData().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(AuthOrderOutput.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "AuthOrderOutput"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("authOrderResponseHeader");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "AuthOrderResponseHeader"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "orderResponseHeader"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("authOrderData");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "AuthOrderData"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "AuthOrderDataStatus"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
