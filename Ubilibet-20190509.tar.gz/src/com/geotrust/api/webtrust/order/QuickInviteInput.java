/**
 * QuickInviteInput.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.order;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class QuickInviteInput  extends com.geotrust.api.webtrust.order.Pin1Request  implements java.io.Serializable {
    private java.lang.String requestorEmail;

    private java.lang.String[] partnerOrderIDs;

    private java.lang.Integer inviteQuantity;

    private java.lang.String sealPreference;

    public QuickInviteInput() {
    }

    public QuickInviteInput(
           com.geotrust.api.webtrust.order.OrderRequestHeader orderRequestHeader,
           com.geotrust.api.webtrust.order.OrganizationInfo organizationInfo,
           com.geotrust.api.webtrust.order.OrderParameters orderParameters,
           com.geotrust.api.webtrust.order.Contact adminContact,
           com.geotrust.api.webtrust.order.Contact techContact,
           com.geotrust.api.webtrust.order.Contact billingContact,
           com.geotrust.api.webtrust.order.PaymentInfo paymentInfo,
           com.geotrust.api.webtrust.order.PartnerTag[] partnerTags,
           java.lang.Integer inviteDuration,
           java.lang.Integer chainKeySize,
           java.lang.Integer reservedSanCount,
           java.lang.String requestorEmail,
           java.lang.String[] partnerOrderIDs,
           java.lang.Integer inviteQuantity,
           java.lang.String sealPreference) {
        super(
            orderRequestHeader,
            organizationInfo,
            orderParameters,
            adminContact,
            techContact,
            billingContact,
            paymentInfo,
            partnerTags,
            inviteDuration,
            chainKeySize,
            reservedSanCount);
        this.requestorEmail = requestorEmail;
        this.partnerOrderIDs = partnerOrderIDs;
        this.inviteQuantity = inviteQuantity;
        this.sealPreference = sealPreference;
    }


    /**
     * Gets the requestorEmail value for this QuickInviteInput.
     * 
     * @return requestorEmail
     */
    public java.lang.String getRequestorEmail() {
        return requestorEmail;
    }


    /**
     * Sets the requestorEmail value for this QuickInviteInput.
     * 
     * @param requestorEmail
     */
    public void setRequestorEmail(java.lang.String requestorEmail) {
        this.requestorEmail = requestorEmail;
    }


    /**
     * Gets the partnerOrderIDs value for this QuickInviteInput.
     * 
     * @return partnerOrderIDs
     */
    public java.lang.String[] getPartnerOrderIDs() {
        return partnerOrderIDs;
    }


    /**
     * Sets the partnerOrderIDs value for this QuickInviteInput.
     * 
     * @param partnerOrderIDs
     */
    public void setPartnerOrderIDs(java.lang.String[] partnerOrderIDs) {
        this.partnerOrderIDs = partnerOrderIDs;
    }


    /**
     * Gets the inviteQuantity value for this QuickInviteInput.
     * 
     * @return inviteQuantity
     */
    public java.lang.Integer getInviteQuantity() {
        return inviteQuantity;
    }


    /**
     * Sets the inviteQuantity value for this QuickInviteInput.
     * 
     * @param inviteQuantity
     */
    public void setInviteQuantity(java.lang.Integer inviteQuantity) {
        this.inviteQuantity = inviteQuantity;
    }


    /**
     * Gets the sealPreference value for this QuickInviteInput.
     * 
     * @return sealPreference
     */
    public java.lang.String getSealPreference() {
        return sealPreference;
    }


    /**
     * Sets the sealPreference value for this QuickInviteInput.
     * 
     * @param sealPreference
     */
    public void setSealPreference(java.lang.String sealPreference) {
        this.sealPreference = sealPreference;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof QuickInviteInput)) return false;
        QuickInviteInput other = (QuickInviteInput) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.requestorEmail==null && other.getRequestorEmail()==null) || 
             (this.requestorEmail!=null &&
              this.requestorEmail.equals(other.getRequestorEmail()))) &&
            ((this.partnerOrderIDs==null && other.getPartnerOrderIDs()==null) || 
             (this.partnerOrderIDs!=null &&
              java.util.Arrays.equals(this.partnerOrderIDs, other.getPartnerOrderIDs()))) &&
            ((this.inviteQuantity==null && other.getInviteQuantity()==null) || 
             (this.inviteQuantity!=null &&
              this.inviteQuantity.equals(other.getInviteQuantity()))) &&
            ((this.sealPreference==null && other.getSealPreference()==null) || 
             (this.sealPreference!=null &&
              this.sealPreference.equals(other.getSealPreference())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getRequestorEmail() != null) {
            _hashCode += getRequestorEmail().hashCode();
        }
        if (getPartnerOrderIDs() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getPartnerOrderIDs());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getPartnerOrderIDs(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getInviteQuantity() != null) {
            _hashCode += getInviteQuantity().hashCode();
        }
        if (getSealPreference() != null) {
            _hashCode += getSealPreference().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(QuickInviteInput.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "QuickInviteInput"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("requestorEmail");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "RequestorEmail"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("partnerOrderIDs");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "PartnerOrderIDs"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "String"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("inviteQuantity");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "InviteQuantity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sealPreference");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "SealPreference"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
