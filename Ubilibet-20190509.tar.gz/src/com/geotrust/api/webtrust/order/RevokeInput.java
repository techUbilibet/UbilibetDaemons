/**
 * RevokeInput.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.order;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class RevokeInput  implements java.io.Serializable {
    private com.geotrust.api.webtrust.order.OrderRequestHeader orderRequestHeader;

    private java.lang.String serialNumber;

    private java.lang.String certificate;

    private java.lang.String revokeReason;

    private java.lang.String revokeMethod;

    public RevokeInput() {
    }

    public RevokeInput(
           com.geotrust.api.webtrust.order.OrderRequestHeader orderRequestHeader,
           java.lang.String serialNumber,
           java.lang.String certificate,
           java.lang.String revokeReason,
           java.lang.String revokeMethod) {
           this.orderRequestHeader = orderRequestHeader;
           this.serialNumber = serialNumber;
           this.certificate = certificate;
           this.revokeReason = revokeReason;
           this.revokeMethod = revokeMethod;
    }


    /**
     * Gets the orderRequestHeader value for this RevokeInput.
     * 
     * @return orderRequestHeader
     */
    public com.geotrust.api.webtrust.order.OrderRequestHeader getOrderRequestHeader() {
        return orderRequestHeader;
    }


    /**
     * Sets the orderRequestHeader value for this RevokeInput.
     * 
     * @param orderRequestHeader
     */
    public void setOrderRequestHeader(com.geotrust.api.webtrust.order.OrderRequestHeader orderRequestHeader) {
        this.orderRequestHeader = orderRequestHeader;
    }


    /**
     * Gets the serialNumber value for this RevokeInput.
     * 
     * @return serialNumber
     */
    public java.lang.String getSerialNumber() {
        return serialNumber;
    }


    /**
     * Sets the serialNumber value for this RevokeInput.
     * 
     * @param serialNumber
     */
    public void setSerialNumber(java.lang.String serialNumber) {
        this.serialNumber = serialNumber;
    }


    /**
     * Gets the certificate value for this RevokeInput.
     * 
     * @return certificate
     */
    public java.lang.String getCertificate() {
        return certificate;
    }


    /**
     * Sets the certificate value for this RevokeInput.
     * 
     * @param certificate
     */
    public void setCertificate(java.lang.String certificate) {
        this.certificate = certificate;
    }


    /**
     * Gets the revokeReason value for this RevokeInput.
     * 
     * @return revokeReason
     */
    public java.lang.String getRevokeReason() {
        return revokeReason;
    }


    /**
     * Sets the revokeReason value for this RevokeInput.
     * 
     * @param revokeReason
     */
    public void setRevokeReason(java.lang.String revokeReason) {
        this.revokeReason = revokeReason;
    }


    /**
     * Gets the revokeMethod value for this RevokeInput.
     * 
     * @return revokeMethod
     */
    public java.lang.String getRevokeMethod() {
        return revokeMethod;
    }


    /**
     * Sets the revokeMethod value for this RevokeInput.
     * 
     * @param revokeMethod
     */
    public void setRevokeMethod(java.lang.String revokeMethod) {
        this.revokeMethod = revokeMethod;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof RevokeInput)) return false;
        RevokeInput other = (RevokeInput) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.orderRequestHeader==null && other.getOrderRequestHeader()==null) || 
             (this.orderRequestHeader!=null &&
              this.orderRequestHeader.equals(other.getOrderRequestHeader()))) &&
            ((this.serialNumber==null && other.getSerialNumber()==null) || 
             (this.serialNumber!=null &&
              this.serialNumber.equals(other.getSerialNumber()))) &&
            ((this.certificate==null && other.getCertificate()==null) || 
             (this.certificate!=null &&
              this.certificate.equals(other.getCertificate()))) &&
            ((this.revokeReason==null && other.getRevokeReason()==null) || 
             (this.revokeReason!=null &&
              this.revokeReason.equals(other.getRevokeReason()))) &&
            ((this.revokeMethod==null && other.getRevokeMethod()==null) || 
             (this.revokeMethod!=null &&
              this.revokeMethod.equals(other.getRevokeMethod())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getOrderRequestHeader() != null) {
            _hashCode += getOrderRequestHeader().hashCode();
        }
        if (getSerialNumber() != null) {
            _hashCode += getSerialNumber().hashCode();
        }
        if (getCertificate() != null) {
            _hashCode += getCertificate().hashCode();
        }
        if (getRevokeReason() != null) {
            _hashCode += getRevokeReason().hashCode();
        }
        if (getRevokeMethod() != null) {
            _hashCode += getRevokeMethod().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(RevokeInput.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "RevokeInput"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderRequestHeader");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "OrderRequestHeader"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "orderRequestHeader"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("serialNumber");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "SerialNumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("certificate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Certificate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("revokeReason");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "RevokeReason"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("revokeMethod");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "RevokeMethod"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
