/**
 * MerchantAccountInfo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.order;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class MerchantAccountInfo  implements java.io.Serializable {
    private java.lang.String processed_before;

    private java.lang.String processed_with_whom;

    private java.lang.String tax_id;

    private java.lang.String num_of_locations;

    private java.lang.String time_in_biz_months;

    private java.lang.String time_in_biz_yrs;

    private java.lang.String how_long;

    private java.lang.String biz_hours;

    private java.lang.String terminated_by_processor;

    private java.lang.String type_of_ownership;

    private java.lang.String ownership_other;

    private java.lang.String business_type;

    private java.lang.String service_or_product_type;

    private java.lang.String delivery_time;

    private java.lang.String manually_keyed_pct;

    private java.lang.String card_swipe_pct;

    private java.lang.String internet_swipe_pct;

    private java.lang.String anticipated_monthly_volume;

    private java.lang.String average_sale_size;

    private java.lang.String principal_name;

    private java.lang.String principal_title;

    private java.lang.String principal_residence_phone;

    private java.lang.String principal_ssn;

    private java.lang.String principal_pct_ownership;

    private java.lang.String principal_date_of_birth;

    private java.lang.String principal_address;

    private java.lang.String principal_city;

    private java.lang.String principal_state;

    private java.lang.String principal_zip;

    private java.lang.String principal_address_years;

    private java.lang.String principal_address_months;

    private java.lang.String principal_property;

    private java.lang.String principal_drivers_license;

    private java.lang.String principal_license_state;

    private java.lang.String bank_name;

    private java.lang.String bank_account;

    private java.lang.String bank_phone;

    private java.lang.String bank_contact;

    private java.lang.String trade_name;

    private java.lang.String trade_account;

    private java.lang.String trade_phone;

    private java.lang.String trade_contact;

    private java.lang.String trade_name2;

    private java.lang.String trade_account2;

    private java.lang.String trade_phone2;

    private java.lang.String trade_contact2;

    public MerchantAccountInfo() {
    }

    public MerchantAccountInfo(
           java.lang.String processed_before,
           java.lang.String processed_with_whom,
           java.lang.String tax_id,
           java.lang.String num_of_locations,
           java.lang.String time_in_biz_months,
           java.lang.String time_in_biz_yrs,
           java.lang.String how_long,
           java.lang.String biz_hours,
           java.lang.String terminated_by_processor,
           java.lang.String type_of_ownership,
           java.lang.String ownership_other,
           java.lang.String business_type,
           java.lang.String service_or_product_type,
           java.lang.String delivery_time,
           java.lang.String manually_keyed_pct,
           java.lang.String card_swipe_pct,
           java.lang.String internet_swipe_pct,
           java.lang.String anticipated_monthly_volume,
           java.lang.String average_sale_size,
           java.lang.String principal_name,
           java.lang.String principal_title,
           java.lang.String principal_residence_phone,
           java.lang.String principal_ssn,
           java.lang.String principal_pct_ownership,
           java.lang.String principal_date_of_birth,
           java.lang.String principal_address,
           java.lang.String principal_city,
           java.lang.String principal_state,
           java.lang.String principal_zip,
           java.lang.String principal_address_years,
           java.lang.String principal_address_months,
           java.lang.String principal_property,
           java.lang.String principal_drivers_license,
           java.lang.String principal_license_state,
           java.lang.String bank_name,
           java.lang.String bank_account,
           java.lang.String bank_phone,
           java.lang.String bank_contact,
           java.lang.String trade_name,
           java.lang.String trade_account,
           java.lang.String trade_phone,
           java.lang.String trade_contact,
           java.lang.String trade_name2,
           java.lang.String trade_account2,
           java.lang.String trade_phone2,
           java.lang.String trade_contact2) {
           this.processed_before = processed_before;
           this.processed_with_whom = processed_with_whom;
           this.tax_id = tax_id;
           this.num_of_locations = num_of_locations;
           this.time_in_biz_months = time_in_biz_months;
           this.time_in_biz_yrs = time_in_biz_yrs;
           this.how_long = how_long;
           this.biz_hours = biz_hours;
           this.terminated_by_processor = terminated_by_processor;
           this.type_of_ownership = type_of_ownership;
           this.ownership_other = ownership_other;
           this.business_type = business_type;
           this.service_or_product_type = service_or_product_type;
           this.delivery_time = delivery_time;
           this.manually_keyed_pct = manually_keyed_pct;
           this.card_swipe_pct = card_swipe_pct;
           this.internet_swipe_pct = internet_swipe_pct;
           this.anticipated_monthly_volume = anticipated_monthly_volume;
           this.average_sale_size = average_sale_size;
           this.principal_name = principal_name;
           this.principal_title = principal_title;
           this.principal_residence_phone = principal_residence_phone;
           this.principal_ssn = principal_ssn;
           this.principal_pct_ownership = principal_pct_ownership;
           this.principal_date_of_birth = principal_date_of_birth;
           this.principal_address = principal_address;
           this.principal_city = principal_city;
           this.principal_state = principal_state;
           this.principal_zip = principal_zip;
           this.principal_address_years = principal_address_years;
           this.principal_address_months = principal_address_months;
           this.principal_property = principal_property;
           this.principal_drivers_license = principal_drivers_license;
           this.principal_license_state = principal_license_state;
           this.bank_name = bank_name;
           this.bank_account = bank_account;
           this.bank_phone = bank_phone;
           this.bank_contact = bank_contact;
           this.trade_name = trade_name;
           this.trade_account = trade_account;
           this.trade_phone = trade_phone;
           this.trade_contact = trade_contact;
           this.trade_name2 = trade_name2;
           this.trade_account2 = trade_account2;
           this.trade_phone2 = trade_phone2;
           this.trade_contact2 = trade_contact2;
    }


    /**
     * Gets the processed_before value for this MerchantAccountInfo.
     * 
     * @return processed_before
     */
    public java.lang.String getProcessed_before() {
        return processed_before;
    }


    /**
     * Sets the processed_before value for this MerchantAccountInfo.
     * 
     * @param processed_before
     */
    public void setProcessed_before(java.lang.String processed_before) {
        this.processed_before = processed_before;
    }


    /**
     * Gets the processed_with_whom value for this MerchantAccountInfo.
     * 
     * @return processed_with_whom
     */
    public java.lang.String getProcessed_with_whom() {
        return processed_with_whom;
    }


    /**
     * Sets the processed_with_whom value for this MerchantAccountInfo.
     * 
     * @param processed_with_whom
     */
    public void setProcessed_with_whom(java.lang.String processed_with_whom) {
        this.processed_with_whom = processed_with_whom;
    }


    /**
     * Gets the tax_id value for this MerchantAccountInfo.
     * 
     * @return tax_id
     */
    public java.lang.String getTax_id() {
        return tax_id;
    }


    /**
     * Sets the tax_id value for this MerchantAccountInfo.
     * 
     * @param tax_id
     */
    public void setTax_id(java.lang.String tax_id) {
        this.tax_id = tax_id;
    }


    /**
     * Gets the num_of_locations value for this MerchantAccountInfo.
     * 
     * @return num_of_locations
     */
    public java.lang.String getNum_of_locations() {
        return num_of_locations;
    }


    /**
     * Sets the num_of_locations value for this MerchantAccountInfo.
     * 
     * @param num_of_locations
     */
    public void setNum_of_locations(java.lang.String num_of_locations) {
        this.num_of_locations = num_of_locations;
    }


    /**
     * Gets the time_in_biz_months value for this MerchantAccountInfo.
     * 
     * @return time_in_biz_months
     */
    public java.lang.String getTime_in_biz_months() {
        return time_in_biz_months;
    }


    /**
     * Sets the time_in_biz_months value for this MerchantAccountInfo.
     * 
     * @param time_in_biz_months
     */
    public void setTime_in_biz_months(java.lang.String time_in_biz_months) {
        this.time_in_biz_months = time_in_biz_months;
    }


    /**
     * Gets the time_in_biz_yrs value for this MerchantAccountInfo.
     * 
     * @return time_in_biz_yrs
     */
    public java.lang.String getTime_in_biz_yrs() {
        return time_in_biz_yrs;
    }


    /**
     * Sets the time_in_biz_yrs value for this MerchantAccountInfo.
     * 
     * @param time_in_biz_yrs
     */
    public void setTime_in_biz_yrs(java.lang.String time_in_biz_yrs) {
        this.time_in_biz_yrs = time_in_biz_yrs;
    }


    /**
     * Gets the how_long value for this MerchantAccountInfo.
     * 
     * @return how_long
     */
    public java.lang.String getHow_long() {
        return how_long;
    }


    /**
     * Sets the how_long value for this MerchantAccountInfo.
     * 
     * @param how_long
     */
    public void setHow_long(java.lang.String how_long) {
        this.how_long = how_long;
    }


    /**
     * Gets the biz_hours value for this MerchantAccountInfo.
     * 
     * @return biz_hours
     */
    public java.lang.String getBiz_hours() {
        return biz_hours;
    }


    /**
     * Sets the biz_hours value for this MerchantAccountInfo.
     * 
     * @param biz_hours
     */
    public void setBiz_hours(java.lang.String biz_hours) {
        this.biz_hours = biz_hours;
    }


    /**
     * Gets the terminated_by_processor value for this MerchantAccountInfo.
     * 
     * @return terminated_by_processor
     */
    public java.lang.String getTerminated_by_processor() {
        return terminated_by_processor;
    }


    /**
     * Sets the terminated_by_processor value for this MerchantAccountInfo.
     * 
     * @param terminated_by_processor
     */
    public void setTerminated_by_processor(java.lang.String terminated_by_processor) {
        this.terminated_by_processor = terminated_by_processor;
    }


    /**
     * Gets the type_of_ownership value for this MerchantAccountInfo.
     * 
     * @return type_of_ownership
     */
    public java.lang.String getType_of_ownership() {
        return type_of_ownership;
    }


    /**
     * Sets the type_of_ownership value for this MerchantAccountInfo.
     * 
     * @param type_of_ownership
     */
    public void setType_of_ownership(java.lang.String type_of_ownership) {
        this.type_of_ownership = type_of_ownership;
    }


    /**
     * Gets the ownership_other value for this MerchantAccountInfo.
     * 
     * @return ownership_other
     */
    public java.lang.String getOwnership_other() {
        return ownership_other;
    }


    /**
     * Sets the ownership_other value for this MerchantAccountInfo.
     * 
     * @param ownership_other
     */
    public void setOwnership_other(java.lang.String ownership_other) {
        this.ownership_other = ownership_other;
    }


    /**
     * Gets the business_type value for this MerchantAccountInfo.
     * 
     * @return business_type
     */
    public java.lang.String getBusiness_type() {
        return business_type;
    }


    /**
     * Sets the business_type value for this MerchantAccountInfo.
     * 
     * @param business_type
     */
    public void setBusiness_type(java.lang.String business_type) {
        this.business_type = business_type;
    }


    /**
     * Gets the service_or_product_type value for this MerchantAccountInfo.
     * 
     * @return service_or_product_type
     */
    public java.lang.String getService_or_product_type() {
        return service_or_product_type;
    }


    /**
     * Sets the service_or_product_type value for this MerchantAccountInfo.
     * 
     * @param service_or_product_type
     */
    public void setService_or_product_type(java.lang.String service_or_product_type) {
        this.service_or_product_type = service_or_product_type;
    }


    /**
     * Gets the delivery_time value for this MerchantAccountInfo.
     * 
     * @return delivery_time
     */
    public java.lang.String getDelivery_time() {
        return delivery_time;
    }


    /**
     * Sets the delivery_time value for this MerchantAccountInfo.
     * 
     * @param delivery_time
     */
    public void setDelivery_time(java.lang.String delivery_time) {
        this.delivery_time = delivery_time;
    }


    /**
     * Gets the manually_keyed_pct value for this MerchantAccountInfo.
     * 
     * @return manually_keyed_pct
     */
    public java.lang.String getManually_keyed_pct() {
        return manually_keyed_pct;
    }


    /**
     * Sets the manually_keyed_pct value for this MerchantAccountInfo.
     * 
     * @param manually_keyed_pct
     */
    public void setManually_keyed_pct(java.lang.String manually_keyed_pct) {
        this.manually_keyed_pct = manually_keyed_pct;
    }


    /**
     * Gets the card_swipe_pct value for this MerchantAccountInfo.
     * 
     * @return card_swipe_pct
     */
    public java.lang.String getCard_swipe_pct() {
        return card_swipe_pct;
    }


    /**
     * Sets the card_swipe_pct value for this MerchantAccountInfo.
     * 
     * @param card_swipe_pct
     */
    public void setCard_swipe_pct(java.lang.String card_swipe_pct) {
        this.card_swipe_pct = card_swipe_pct;
    }


    /**
     * Gets the internet_swipe_pct value for this MerchantAccountInfo.
     * 
     * @return internet_swipe_pct
     */
    public java.lang.String getInternet_swipe_pct() {
        return internet_swipe_pct;
    }


    /**
     * Sets the internet_swipe_pct value for this MerchantAccountInfo.
     * 
     * @param internet_swipe_pct
     */
    public void setInternet_swipe_pct(java.lang.String internet_swipe_pct) {
        this.internet_swipe_pct = internet_swipe_pct;
    }


    /**
     * Gets the anticipated_monthly_volume value for this MerchantAccountInfo.
     * 
     * @return anticipated_monthly_volume
     */
    public java.lang.String getAnticipated_monthly_volume() {
        return anticipated_monthly_volume;
    }


    /**
     * Sets the anticipated_monthly_volume value for this MerchantAccountInfo.
     * 
     * @param anticipated_monthly_volume
     */
    public void setAnticipated_monthly_volume(java.lang.String anticipated_monthly_volume) {
        this.anticipated_monthly_volume = anticipated_monthly_volume;
    }


    /**
     * Gets the average_sale_size value for this MerchantAccountInfo.
     * 
     * @return average_sale_size
     */
    public java.lang.String getAverage_sale_size() {
        return average_sale_size;
    }


    /**
     * Sets the average_sale_size value for this MerchantAccountInfo.
     * 
     * @param average_sale_size
     */
    public void setAverage_sale_size(java.lang.String average_sale_size) {
        this.average_sale_size = average_sale_size;
    }


    /**
     * Gets the principal_name value for this MerchantAccountInfo.
     * 
     * @return principal_name
     */
    public java.lang.String getPrincipal_name() {
        return principal_name;
    }


    /**
     * Sets the principal_name value for this MerchantAccountInfo.
     * 
     * @param principal_name
     */
    public void setPrincipal_name(java.lang.String principal_name) {
        this.principal_name = principal_name;
    }


    /**
     * Gets the principal_title value for this MerchantAccountInfo.
     * 
     * @return principal_title
     */
    public java.lang.String getPrincipal_title() {
        return principal_title;
    }


    /**
     * Sets the principal_title value for this MerchantAccountInfo.
     * 
     * @param principal_title
     */
    public void setPrincipal_title(java.lang.String principal_title) {
        this.principal_title = principal_title;
    }


    /**
     * Gets the principal_residence_phone value for this MerchantAccountInfo.
     * 
     * @return principal_residence_phone
     */
    public java.lang.String getPrincipal_residence_phone() {
        return principal_residence_phone;
    }


    /**
     * Sets the principal_residence_phone value for this MerchantAccountInfo.
     * 
     * @param principal_residence_phone
     */
    public void setPrincipal_residence_phone(java.lang.String principal_residence_phone) {
        this.principal_residence_phone = principal_residence_phone;
    }


    /**
     * Gets the principal_ssn value for this MerchantAccountInfo.
     * 
     * @return principal_ssn
     */
    public java.lang.String getPrincipal_ssn() {
        return principal_ssn;
    }


    /**
     * Sets the principal_ssn value for this MerchantAccountInfo.
     * 
     * @param principal_ssn
     */
    public void setPrincipal_ssn(java.lang.String principal_ssn) {
        this.principal_ssn = principal_ssn;
    }


    /**
     * Gets the principal_pct_ownership value for this MerchantAccountInfo.
     * 
     * @return principal_pct_ownership
     */
    public java.lang.String getPrincipal_pct_ownership() {
        return principal_pct_ownership;
    }


    /**
     * Sets the principal_pct_ownership value for this MerchantAccountInfo.
     * 
     * @param principal_pct_ownership
     */
    public void setPrincipal_pct_ownership(java.lang.String principal_pct_ownership) {
        this.principal_pct_ownership = principal_pct_ownership;
    }


    /**
     * Gets the principal_date_of_birth value for this MerchantAccountInfo.
     * 
     * @return principal_date_of_birth
     */
    public java.lang.String getPrincipal_date_of_birth() {
        return principal_date_of_birth;
    }


    /**
     * Sets the principal_date_of_birth value for this MerchantAccountInfo.
     * 
     * @param principal_date_of_birth
     */
    public void setPrincipal_date_of_birth(java.lang.String principal_date_of_birth) {
        this.principal_date_of_birth = principal_date_of_birth;
    }


    /**
     * Gets the principal_address value for this MerchantAccountInfo.
     * 
     * @return principal_address
     */
    public java.lang.String getPrincipal_address() {
        return principal_address;
    }


    /**
     * Sets the principal_address value for this MerchantAccountInfo.
     * 
     * @param principal_address
     */
    public void setPrincipal_address(java.lang.String principal_address) {
        this.principal_address = principal_address;
    }


    /**
     * Gets the principal_city value for this MerchantAccountInfo.
     * 
     * @return principal_city
     */
    public java.lang.String getPrincipal_city() {
        return principal_city;
    }


    /**
     * Sets the principal_city value for this MerchantAccountInfo.
     * 
     * @param principal_city
     */
    public void setPrincipal_city(java.lang.String principal_city) {
        this.principal_city = principal_city;
    }


    /**
     * Gets the principal_state value for this MerchantAccountInfo.
     * 
     * @return principal_state
     */
    public java.lang.String getPrincipal_state() {
        return principal_state;
    }


    /**
     * Sets the principal_state value for this MerchantAccountInfo.
     * 
     * @param principal_state
     */
    public void setPrincipal_state(java.lang.String principal_state) {
        this.principal_state = principal_state;
    }


    /**
     * Gets the principal_zip value for this MerchantAccountInfo.
     * 
     * @return principal_zip
     */
    public java.lang.String getPrincipal_zip() {
        return principal_zip;
    }


    /**
     * Sets the principal_zip value for this MerchantAccountInfo.
     * 
     * @param principal_zip
     */
    public void setPrincipal_zip(java.lang.String principal_zip) {
        this.principal_zip = principal_zip;
    }


    /**
     * Gets the principal_address_years value for this MerchantAccountInfo.
     * 
     * @return principal_address_years
     */
    public java.lang.String getPrincipal_address_years() {
        return principal_address_years;
    }


    /**
     * Sets the principal_address_years value for this MerchantAccountInfo.
     * 
     * @param principal_address_years
     */
    public void setPrincipal_address_years(java.lang.String principal_address_years) {
        this.principal_address_years = principal_address_years;
    }


    /**
     * Gets the principal_address_months value for this MerchantAccountInfo.
     * 
     * @return principal_address_months
     */
    public java.lang.String getPrincipal_address_months() {
        return principal_address_months;
    }


    /**
     * Sets the principal_address_months value for this MerchantAccountInfo.
     * 
     * @param principal_address_months
     */
    public void setPrincipal_address_months(java.lang.String principal_address_months) {
        this.principal_address_months = principal_address_months;
    }


    /**
     * Gets the principal_property value for this MerchantAccountInfo.
     * 
     * @return principal_property
     */
    public java.lang.String getPrincipal_property() {
        return principal_property;
    }


    /**
     * Sets the principal_property value for this MerchantAccountInfo.
     * 
     * @param principal_property
     */
    public void setPrincipal_property(java.lang.String principal_property) {
        this.principal_property = principal_property;
    }


    /**
     * Gets the principal_drivers_license value for this MerchantAccountInfo.
     * 
     * @return principal_drivers_license
     */
    public java.lang.String getPrincipal_drivers_license() {
        return principal_drivers_license;
    }


    /**
     * Sets the principal_drivers_license value for this MerchantAccountInfo.
     * 
     * @param principal_drivers_license
     */
    public void setPrincipal_drivers_license(java.lang.String principal_drivers_license) {
        this.principal_drivers_license = principal_drivers_license;
    }


    /**
     * Gets the principal_license_state value for this MerchantAccountInfo.
     * 
     * @return principal_license_state
     */
    public java.lang.String getPrincipal_license_state() {
        return principal_license_state;
    }


    /**
     * Sets the principal_license_state value for this MerchantAccountInfo.
     * 
     * @param principal_license_state
     */
    public void setPrincipal_license_state(java.lang.String principal_license_state) {
        this.principal_license_state = principal_license_state;
    }


    /**
     * Gets the bank_name value for this MerchantAccountInfo.
     * 
     * @return bank_name
     */
    public java.lang.String getBank_name() {
        return bank_name;
    }


    /**
     * Sets the bank_name value for this MerchantAccountInfo.
     * 
     * @param bank_name
     */
    public void setBank_name(java.lang.String bank_name) {
        this.bank_name = bank_name;
    }


    /**
     * Gets the bank_account value for this MerchantAccountInfo.
     * 
     * @return bank_account
     */
    public java.lang.String getBank_account() {
        return bank_account;
    }


    /**
     * Sets the bank_account value for this MerchantAccountInfo.
     * 
     * @param bank_account
     */
    public void setBank_account(java.lang.String bank_account) {
        this.bank_account = bank_account;
    }


    /**
     * Gets the bank_phone value for this MerchantAccountInfo.
     * 
     * @return bank_phone
     */
    public java.lang.String getBank_phone() {
        return bank_phone;
    }


    /**
     * Sets the bank_phone value for this MerchantAccountInfo.
     * 
     * @param bank_phone
     */
    public void setBank_phone(java.lang.String bank_phone) {
        this.bank_phone = bank_phone;
    }


    /**
     * Gets the bank_contact value for this MerchantAccountInfo.
     * 
     * @return bank_contact
     */
    public java.lang.String getBank_contact() {
        return bank_contact;
    }


    /**
     * Sets the bank_contact value for this MerchantAccountInfo.
     * 
     * @param bank_contact
     */
    public void setBank_contact(java.lang.String bank_contact) {
        this.bank_contact = bank_contact;
    }


    /**
     * Gets the trade_name value for this MerchantAccountInfo.
     * 
     * @return trade_name
     */
    public java.lang.String getTrade_name() {
        return trade_name;
    }


    /**
     * Sets the trade_name value for this MerchantAccountInfo.
     * 
     * @param trade_name
     */
    public void setTrade_name(java.lang.String trade_name) {
        this.trade_name = trade_name;
    }


    /**
     * Gets the trade_account value for this MerchantAccountInfo.
     * 
     * @return trade_account
     */
    public java.lang.String getTrade_account() {
        return trade_account;
    }


    /**
     * Sets the trade_account value for this MerchantAccountInfo.
     * 
     * @param trade_account
     */
    public void setTrade_account(java.lang.String trade_account) {
        this.trade_account = trade_account;
    }


    /**
     * Gets the trade_phone value for this MerchantAccountInfo.
     * 
     * @return trade_phone
     */
    public java.lang.String getTrade_phone() {
        return trade_phone;
    }


    /**
     * Sets the trade_phone value for this MerchantAccountInfo.
     * 
     * @param trade_phone
     */
    public void setTrade_phone(java.lang.String trade_phone) {
        this.trade_phone = trade_phone;
    }


    /**
     * Gets the trade_contact value for this MerchantAccountInfo.
     * 
     * @return trade_contact
     */
    public java.lang.String getTrade_contact() {
        return trade_contact;
    }


    /**
     * Sets the trade_contact value for this MerchantAccountInfo.
     * 
     * @param trade_contact
     */
    public void setTrade_contact(java.lang.String trade_contact) {
        this.trade_contact = trade_contact;
    }


    /**
     * Gets the trade_name2 value for this MerchantAccountInfo.
     * 
     * @return trade_name2
     */
    public java.lang.String getTrade_name2() {
        return trade_name2;
    }


    /**
     * Sets the trade_name2 value for this MerchantAccountInfo.
     * 
     * @param trade_name2
     */
    public void setTrade_name2(java.lang.String trade_name2) {
        this.trade_name2 = trade_name2;
    }


    /**
     * Gets the trade_account2 value for this MerchantAccountInfo.
     * 
     * @return trade_account2
     */
    public java.lang.String getTrade_account2() {
        return trade_account2;
    }


    /**
     * Sets the trade_account2 value for this MerchantAccountInfo.
     * 
     * @param trade_account2
     */
    public void setTrade_account2(java.lang.String trade_account2) {
        this.trade_account2 = trade_account2;
    }


    /**
     * Gets the trade_phone2 value for this MerchantAccountInfo.
     * 
     * @return trade_phone2
     */
    public java.lang.String getTrade_phone2() {
        return trade_phone2;
    }


    /**
     * Sets the trade_phone2 value for this MerchantAccountInfo.
     * 
     * @param trade_phone2
     */
    public void setTrade_phone2(java.lang.String trade_phone2) {
        this.trade_phone2 = trade_phone2;
    }


    /**
     * Gets the trade_contact2 value for this MerchantAccountInfo.
     * 
     * @return trade_contact2
     */
    public java.lang.String getTrade_contact2() {
        return trade_contact2;
    }


    /**
     * Sets the trade_contact2 value for this MerchantAccountInfo.
     * 
     * @param trade_contact2
     */
    public void setTrade_contact2(java.lang.String trade_contact2) {
        this.trade_contact2 = trade_contact2;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof MerchantAccountInfo)) return false;
        MerchantAccountInfo other = (MerchantAccountInfo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.processed_before==null && other.getProcessed_before()==null) || 
             (this.processed_before!=null &&
              this.processed_before.equals(other.getProcessed_before()))) &&
            ((this.processed_with_whom==null && other.getProcessed_with_whom()==null) || 
             (this.processed_with_whom!=null &&
              this.processed_with_whom.equals(other.getProcessed_with_whom()))) &&
            ((this.tax_id==null && other.getTax_id()==null) || 
             (this.tax_id!=null &&
              this.tax_id.equals(other.getTax_id()))) &&
            ((this.num_of_locations==null && other.getNum_of_locations()==null) || 
             (this.num_of_locations!=null &&
              this.num_of_locations.equals(other.getNum_of_locations()))) &&
            ((this.time_in_biz_months==null && other.getTime_in_biz_months()==null) || 
             (this.time_in_biz_months!=null &&
              this.time_in_biz_months.equals(other.getTime_in_biz_months()))) &&
            ((this.time_in_biz_yrs==null && other.getTime_in_biz_yrs()==null) || 
             (this.time_in_biz_yrs!=null &&
              this.time_in_biz_yrs.equals(other.getTime_in_biz_yrs()))) &&
            ((this.how_long==null && other.getHow_long()==null) || 
             (this.how_long!=null &&
              this.how_long.equals(other.getHow_long()))) &&
            ((this.biz_hours==null && other.getBiz_hours()==null) || 
             (this.biz_hours!=null &&
              this.biz_hours.equals(other.getBiz_hours()))) &&
            ((this.terminated_by_processor==null && other.getTerminated_by_processor()==null) || 
             (this.terminated_by_processor!=null &&
              this.terminated_by_processor.equals(other.getTerminated_by_processor()))) &&
            ((this.type_of_ownership==null && other.getType_of_ownership()==null) || 
             (this.type_of_ownership!=null &&
              this.type_of_ownership.equals(other.getType_of_ownership()))) &&
            ((this.ownership_other==null && other.getOwnership_other()==null) || 
             (this.ownership_other!=null &&
              this.ownership_other.equals(other.getOwnership_other()))) &&
            ((this.business_type==null && other.getBusiness_type()==null) || 
             (this.business_type!=null &&
              this.business_type.equals(other.getBusiness_type()))) &&
            ((this.service_or_product_type==null && other.getService_or_product_type()==null) || 
             (this.service_or_product_type!=null &&
              this.service_or_product_type.equals(other.getService_or_product_type()))) &&
            ((this.delivery_time==null && other.getDelivery_time()==null) || 
             (this.delivery_time!=null &&
              this.delivery_time.equals(other.getDelivery_time()))) &&
            ((this.manually_keyed_pct==null && other.getManually_keyed_pct()==null) || 
             (this.manually_keyed_pct!=null &&
              this.manually_keyed_pct.equals(other.getManually_keyed_pct()))) &&
            ((this.card_swipe_pct==null && other.getCard_swipe_pct()==null) || 
             (this.card_swipe_pct!=null &&
              this.card_swipe_pct.equals(other.getCard_swipe_pct()))) &&
            ((this.internet_swipe_pct==null && other.getInternet_swipe_pct()==null) || 
             (this.internet_swipe_pct!=null &&
              this.internet_swipe_pct.equals(other.getInternet_swipe_pct()))) &&
            ((this.anticipated_monthly_volume==null && other.getAnticipated_monthly_volume()==null) || 
             (this.anticipated_monthly_volume!=null &&
              this.anticipated_monthly_volume.equals(other.getAnticipated_monthly_volume()))) &&
            ((this.average_sale_size==null && other.getAverage_sale_size()==null) || 
             (this.average_sale_size!=null &&
              this.average_sale_size.equals(other.getAverage_sale_size()))) &&
            ((this.principal_name==null && other.getPrincipal_name()==null) || 
             (this.principal_name!=null &&
              this.principal_name.equals(other.getPrincipal_name()))) &&
            ((this.principal_title==null && other.getPrincipal_title()==null) || 
             (this.principal_title!=null &&
              this.principal_title.equals(other.getPrincipal_title()))) &&
            ((this.principal_residence_phone==null && other.getPrincipal_residence_phone()==null) || 
             (this.principal_residence_phone!=null &&
              this.principal_residence_phone.equals(other.getPrincipal_residence_phone()))) &&
            ((this.principal_ssn==null && other.getPrincipal_ssn()==null) || 
             (this.principal_ssn!=null &&
              this.principal_ssn.equals(other.getPrincipal_ssn()))) &&
            ((this.principal_pct_ownership==null && other.getPrincipal_pct_ownership()==null) || 
             (this.principal_pct_ownership!=null &&
              this.principal_pct_ownership.equals(other.getPrincipal_pct_ownership()))) &&
            ((this.principal_date_of_birth==null && other.getPrincipal_date_of_birth()==null) || 
             (this.principal_date_of_birth!=null &&
              this.principal_date_of_birth.equals(other.getPrincipal_date_of_birth()))) &&
            ((this.principal_address==null && other.getPrincipal_address()==null) || 
             (this.principal_address!=null &&
              this.principal_address.equals(other.getPrincipal_address()))) &&
            ((this.principal_city==null && other.getPrincipal_city()==null) || 
             (this.principal_city!=null &&
              this.principal_city.equals(other.getPrincipal_city()))) &&
            ((this.principal_state==null && other.getPrincipal_state()==null) || 
             (this.principal_state!=null &&
              this.principal_state.equals(other.getPrincipal_state()))) &&
            ((this.principal_zip==null && other.getPrincipal_zip()==null) || 
             (this.principal_zip!=null &&
              this.principal_zip.equals(other.getPrincipal_zip()))) &&
            ((this.principal_address_years==null && other.getPrincipal_address_years()==null) || 
             (this.principal_address_years!=null &&
              this.principal_address_years.equals(other.getPrincipal_address_years()))) &&
            ((this.principal_address_months==null && other.getPrincipal_address_months()==null) || 
             (this.principal_address_months!=null &&
              this.principal_address_months.equals(other.getPrincipal_address_months()))) &&
            ((this.principal_property==null && other.getPrincipal_property()==null) || 
             (this.principal_property!=null &&
              this.principal_property.equals(other.getPrincipal_property()))) &&
            ((this.principal_drivers_license==null && other.getPrincipal_drivers_license()==null) || 
             (this.principal_drivers_license!=null &&
              this.principal_drivers_license.equals(other.getPrincipal_drivers_license()))) &&
            ((this.principal_license_state==null && other.getPrincipal_license_state()==null) || 
             (this.principal_license_state!=null &&
              this.principal_license_state.equals(other.getPrincipal_license_state()))) &&
            ((this.bank_name==null && other.getBank_name()==null) || 
             (this.bank_name!=null &&
              this.bank_name.equals(other.getBank_name()))) &&
            ((this.bank_account==null && other.getBank_account()==null) || 
             (this.bank_account!=null &&
              this.bank_account.equals(other.getBank_account()))) &&
            ((this.bank_phone==null && other.getBank_phone()==null) || 
             (this.bank_phone!=null &&
              this.bank_phone.equals(other.getBank_phone()))) &&
            ((this.bank_contact==null && other.getBank_contact()==null) || 
             (this.bank_contact!=null &&
              this.bank_contact.equals(other.getBank_contact()))) &&
            ((this.trade_name==null && other.getTrade_name()==null) || 
             (this.trade_name!=null &&
              this.trade_name.equals(other.getTrade_name()))) &&
            ((this.trade_account==null && other.getTrade_account()==null) || 
             (this.trade_account!=null &&
              this.trade_account.equals(other.getTrade_account()))) &&
            ((this.trade_phone==null && other.getTrade_phone()==null) || 
             (this.trade_phone!=null &&
              this.trade_phone.equals(other.getTrade_phone()))) &&
            ((this.trade_contact==null && other.getTrade_contact()==null) || 
             (this.trade_contact!=null &&
              this.trade_contact.equals(other.getTrade_contact()))) &&
            ((this.trade_name2==null && other.getTrade_name2()==null) || 
             (this.trade_name2!=null &&
              this.trade_name2.equals(other.getTrade_name2()))) &&
            ((this.trade_account2==null && other.getTrade_account2()==null) || 
             (this.trade_account2!=null &&
              this.trade_account2.equals(other.getTrade_account2()))) &&
            ((this.trade_phone2==null && other.getTrade_phone2()==null) || 
             (this.trade_phone2!=null &&
              this.trade_phone2.equals(other.getTrade_phone2()))) &&
            ((this.trade_contact2==null && other.getTrade_contact2()==null) || 
             (this.trade_contact2!=null &&
              this.trade_contact2.equals(other.getTrade_contact2())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getProcessed_before() != null) {
            _hashCode += getProcessed_before().hashCode();
        }
        if (getProcessed_with_whom() != null) {
            _hashCode += getProcessed_with_whom().hashCode();
        }
        if (getTax_id() != null) {
            _hashCode += getTax_id().hashCode();
        }
        if (getNum_of_locations() != null) {
            _hashCode += getNum_of_locations().hashCode();
        }
        if (getTime_in_biz_months() != null) {
            _hashCode += getTime_in_biz_months().hashCode();
        }
        if (getTime_in_biz_yrs() != null) {
            _hashCode += getTime_in_biz_yrs().hashCode();
        }
        if (getHow_long() != null) {
            _hashCode += getHow_long().hashCode();
        }
        if (getBiz_hours() != null) {
            _hashCode += getBiz_hours().hashCode();
        }
        if (getTerminated_by_processor() != null) {
            _hashCode += getTerminated_by_processor().hashCode();
        }
        if (getType_of_ownership() != null) {
            _hashCode += getType_of_ownership().hashCode();
        }
        if (getOwnership_other() != null) {
            _hashCode += getOwnership_other().hashCode();
        }
        if (getBusiness_type() != null) {
            _hashCode += getBusiness_type().hashCode();
        }
        if (getService_or_product_type() != null) {
            _hashCode += getService_or_product_type().hashCode();
        }
        if (getDelivery_time() != null) {
            _hashCode += getDelivery_time().hashCode();
        }
        if (getManually_keyed_pct() != null) {
            _hashCode += getManually_keyed_pct().hashCode();
        }
        if (getCard_swipe_pct() != null) {
            _hashCode += getCard_swipe_pct().hashCode();
        }
        if (getInternet_swipe_pct() != null) {
            _hashCode += getInternet_swipe_pct().hashCode();
        }
        if (getAnticipated_monthly_volume() != null) {
            _hashCode += getAnticipated_monthly_volume().hashCode();
        }
        if (getAverage_sale_size() != null) {
            _hashCode += getAverage_sale_size().hashCode();
        }
        if (getPrincipal_name() != null) {
            _hashCode += getPrincipal_name().hashCode();
        }
        if (getPrincipal_title() != null) {
            _hashCode += getPrincipal_title().hashCode();
        }
        if (getPrincipal_residence_phone() != null) {
            _hashCode += getPrincipal_residence_phone().hashCode();
        }
        if (getPrincipal_ssn() != null) {
            _hashCode += getPrincipal_ssn().hashCode();
        }
        if (getPrincipal_pct_ownership() != null) {
            _hashCode += getPrincipal_pct_ownership().hashCode();
        }
        if (getPrincipal_date_of_birth() != null) {
            _hashCode += getPrincipal_date_of_birth().hashCode();
        }
        if (getPrincipal_address() != null) {
            _hashCode += getPrincipal_address().hashCode();
        }
        if (getPrincipal_city() != null) {
            _hashCode += getPrincipal_city().hashCode();
        }
        if (getPrincipal_state() != null) {
            _hashCode += getPrincipal_state().hashCode();
        }
        if (getPrincipal_zip() != null) {
            _hashCode += getPrincipal_zip().hashCode();
        }
        if (getPrincipal_address_years() != null) {
            _hashCode += getPrincipal_address_years().hashCode();
        }
        if (getPrincipal_address_months() != null) {
            _hashCode += getPrincipal_address_months().hashCode();
        }
        if (getPrincipal_property() != null) {
            _hashCode += getPrincipal_property().hashCode();
        }
        if (getPrincipal_drivers_license() != null) {
            _hashCode += getPrincipal_drivers_license().hashCode();
        }
        if (getPrincipal_license_state() != null) {
            _hashCode += getPrincipal_license_state().hashCode();
        }
        if (getBank_name() != null) {
            _hashCode += getBank_name().hashCode();
        }
        if (getBank_account() != null) {
            _hashCode += getBank_account().hashCode();
        }
        if (getBank_phone() != null) {
            _hashCode += getBank_phone().hashCode();
        }
        if (getBank_contact() != null) {
            _hashCode += getBank_contact().hashCode();
        }
        if (getTrade_name() != null) {
            _hashCode += getTrade_name().hashCode();
        }
        if (getTrade_account() != null) {
            _hashCode += getTrade_account().hashCode();
        }
        if (getTrade_phone() != null) {
            _hashCode += getTrade_phone().hashCode();
        }
        if (getTrade_contact() != null) {
            _hashCode += getTrade_contact().hashCode();
        }
        if (getTrade_name2() != null) {
            _hashCode += getTrade_name2().hashCode();
        }
        if (getTrade_account2() != null) {
            _hashCode += getTrade_account2().hashCode();
        }
        if (getTrade_phone2() != null) {
            _hashCode += getTrade_phone2().hashCode();
        }
        if (getTrade_contact2() != null) {
            _hashCode += getTrade_contact2().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(MerchantAccountInfo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "merchantAccountInfo"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processed_before");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "processed_before"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processed_with_whom");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "processed_with_whom"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tax_id");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "tax_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("num_of_locations");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "num_of_locations"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("time_in_biz_months");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "time_in_biz_months"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("time_in_biz_yrs");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "time_in_biz_yrs"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("how_long");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "how_long"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("biz_hours");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "biz_hours"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("terminated_by_processor");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "terminated_by_processor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("type_of_ownership");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "type_of_ownership"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ownership_other");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ownership_other"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("business_type");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "business_type"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("service_or_product_type");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "service_or_product_type"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("delivery_time");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "delivery_time"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("manually_keyed_pct");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "manually_keyed_pct"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("card_swipe_pct");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "card_swipe_pct"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("internet_swipe_pct");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "internet_swipe_pct"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("anticipated_monthly_volume");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "anticipated_monthly_volume"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("average_sale_size");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "average_sale_size"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("principal_name");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "principal_name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("principal_title");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "principal_title"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("principal_residence_phone");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "principal_residence_phone"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("principal_ssn");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "principal_ssn"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("principal_pct_ownership");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "principal_pct_ownership"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("principal_date_of_birth");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "principal_date_of_birth"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("principal_address");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "principal_address"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("principal_city");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "principal_city"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("principal_state");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "principal_state"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("principal_zip");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "principal_zip"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("principal_address_years");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "principal_address_years"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("principal_address_months");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "principal_address_months"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("principal_property");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "principal_property"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("principal_drivers_license");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "principal_drivers_license"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("principal_license_state");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "principal_license_state"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bank_name");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "bank_name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bank_account");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "bank_account"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bank_phone");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "bank_phone"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bank_contact");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "bank_contact"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("trade_name");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "trade_name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("trade_account");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "trade_account"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("trade_phone");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "trade_phone"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("trade_contact");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "trade_contact"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("trade_name2");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "trade_name2"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("trade_account2");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "trade_account2"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("trade_phone2");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "trade_phone2"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("trade_contact2");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "trade_contact2"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
