/**
 * AuthOrderInput.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.order;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class AuthOrderInput  implements java.io.Serializable {
    private com.geotrust.api.webtrust.order.OrderRequestHeader orderRequestHeader;

    private com.geotrust.api.webtrust.order.AuthOrderParameters orderParameters;

    private com.geotrust.api.webtrust.order.AuthData authData;

    private com.geotrust.api.webtrust.order.Contact billingContact;

    public AuthOrderInput() {
    }

    public AuthOrderInput(
           com.geotrust.api.webtrust.order.OrderRequestHeader orderRequestHeader,
           com.geotrust.api.webtrust.order.AuthOrderParameters orderParameters,
           com.geotrust.api.webtrust.order.AuthData authData,
           com.geotrust.api.webtrust.order.Contact billingContact) {
           this.orderRequestHeader = orderRequestHeader;
           this.orderParameters = orderParameters;
           this.authData = authData;
           this.billingContact = billingContact;
    }


    /**
     * Gets the orderRequestHeader value for this AuthOrderInput.
     * 
     * @return orderRequestHeader
     */
    public com.geotrust.api.webtrust.order.OrderRequestHeader getOrderRequestHeader() {
        return orderRequestHeader;
    }


    /**
     * Sets the orderRequestHeader value for this AuthOrderInput.
     * 
     * @param orderRequestHeader
     */
    public void setOrderRequestHeader(com.geotrust.api.webtrust.order.OrderRequestHeader orderRequestHeader) {
        this.orderRequestHeader = orderRequestHeader;
    }


    /**
     * Gets the orderParameters value for this AuthOrderInput.
     * 
     * @return orderParameters
     */
    public com.geotrust.api.webtrust.order.AuthOrderParameters getOrderParameters() {
        return orderParameters;
    }


    /**
     * Sets the orderParameters value for this AuthOrderInput.
     * 
     * @param orderParameters
     */
    public void setOrderParameters(com.geotrust.api.webtrust.order.AuthOrderParameters orderParameters) {
        this.orderParameters = orderParameters;
    }


    /**
     * Gets the authData value for this AuthOrderInput.
     * 
     * @return authData
     */
    public com.geotrust.api.webtrust.order.AuthData getAuthData() {
        return authData;
    }


    /**
     * Sets the authData value for this AuthOrderInput.
     * 
     * @param authData
     */
    public void setAuthData(com.geotrust.api.webtrust.order.AuthData authData) {
        this.authData = authData;
    }


    /**
     * Gets the billingContact value for this AuthOrderInput.
     * 
     * @return billingContact
     */
    public com.geotrust.api.webtrust.order.Contact getBillingContact() {
        return billingContact;
    }


    /**
     * Sets the billingContact value for this AuthOrderInput.
     * 
     * @param billingContact
     */
    public void setBillingContact(com.geotrust.api.webtrust.order.Contact billingContact) {
        this.billingContact = billingContact;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof AuthOrderInput)) return false;
        AuthOrderInput other = (AuthOrderInput) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.orderRequestHeader==null && other.getOrderRequestHeader()==null) || 
             (this.orderRequestHeader!=null &&
              this.orderRequestHeader.equals(other.getOrderRequestHeader()))) &&
            ((this.orderParameters==null && other.getOrderParameters()==null) || 
             (this.orderParameters!=null &&
              this.orderParameters.equals(other.getOrderParameters()))) &&
            ((this.authData==null && other.getAuthData()==null) || 
             (this.authData!=null &&
              this.authData.equals(other.getAuthData()))) &&
            ((this.billingContact==null && other.getBillingContact()==null) || 
             (this.billingContact!=null &&
              this.billingContact.equals(other.getBillingContact())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getOrderRequestHeader() != null) {
            _hashCode += getOrderRequestHeader().hashCode();
        }
        if (getOrderParameters() != null) {
            _hashCode += getOrderParameters().hashCode();
        }
        if (getAuthData() != null) {
            _hashCode += getAuthData().hashCode();
        }
        if (getBillingContact() != null) {
            _hashCode += getBillingContact().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(AuthOrderInput.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "AuthOrderInput"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderRequestHeader");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "OrderRequestHeader"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "orderRequestHeader"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderParameters");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "OrderParameters"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "AuthOrderParameters"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("authData");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "AuthData"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "AuthData"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("billingContact");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "BillingContact"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Contact"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
