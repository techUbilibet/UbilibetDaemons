/**
 * CreditCardsAllowed.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.order;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class CreditCardsAllowed  implements java.io.Serializable {
    private boolean allowVisa;

    private boolean allowMC;

    private boolean allowDiscover;

    private boolean allowDiners;

    private boolean allowAmex;

    private boolean allowJCB;

    public CreditCardsAllowed() {
    }

    public CreditCardsAllowed(
           boolean allowVisa,
           boolean allowMC,
           boolean allowDiscover,
           boolean allowDiners,
           boolean allowAmex,
           boolean allowJCB) {
           this.allowVisa = allowVisa;
           this.allowMC = allowMC;
           this.allowDiscover = allowDiscover;
           this.allowDiners = allowDiners;
           this.allowAmex = allowAmex;
           this.allowJCB = allowJCB;
    }


    /**
     * Gets the allowVisa value for this CreditCardsAllowed.
     * 
     * @return allowVisa
     */
    public boolean isAllowVisa() {
        return allowVisa;
    }


    /**
     * Sets the allowVisa value for this CreditCardsAllowed.
     * 
     * @param allowVisa
     */
    public void setAllowVisa(boolean allowVisa) {
        this.allowVisa = allowVisa;
    }


    /**
     * Gets the allowMC value for this CreditCardsAllowed.
     * 
     * @return allowMC
     */
    public boolean isAllowMC() {
        return allowMC;
    }


    /**
     * Sets the allowMC value for this CreditCardsAllowed.
     * 
     * @param allowMC
     */
    public void setAllowMC(boolean allowMC) {
        this.allowMC = allowMC;
    }


    /**
     * Gets the allowDiscover value for this CreditCardsAllowed.
     * 
     * @return allowDiscover
     */
    public boolean isAllowDiscover() {
        return allowDiscover;
    }


    /**
     * Sets the allowDiscover value for this CreditCardsAllowed.
     * 
     * @param allowDiscover
     */
    public void setAllowDiscover(boolean allowDiscover) {
        this.allowDiscover = allowDiscover;
    }


    /**
     * Gets the allowDiners value for this CreditCardsAllowed.
     * 
     * @return allowDiners
     */
    public boolean isAllowDiners() {
        return allowDiners;
    }


    /**
     * Sets the allowDiners value for this CreditCardsAllowed.
     * 
     * @param allowDiners
     */
    public void setAllowDiners(boolean allowDiners) {
        this.allowDiners = allowDiners;
    }


    /**
     * Gets the allowAmex value for this CreditCardsAllowed.
     * 
     * @return allowAmex
     */
    public boolean isAllowAmex() {
        return allowAmex;
    }


    /**
     * Sets the allowAmex value for this CreditCardsAllowed.
     * 
     * @param allowAmex
     */
    public void setAllowAmex(boolean allowAmex) {
        this.allowAmex = allowAmex;
    }


    /**
     * Gets the allowJCB value for this CreditCardsAllowed.
     * 
     * @return allowJCB
     */
    public boolean isAllowJCB() {
        return allowJCB;
    }


    /**
     * Sets the allowJCB value for this CreditCardsAllowed.
     * 
     * @param allowJCB
     */
    public void setAllowJCB(boolean allowJCB) {
        this.allowJCB = allowJCB;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CreditCardsAllowed)) return false;
        CreditCardsAllowed other = (CreditCardsAllowed) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.allowVisa == other.isAllowVisa() &&
            this.allowMC == other.isAllowMC() &&
            this.allowDiscover == other.isAllowDiscover() &&
            this.allowDiners == other.isAllowDiners() &&
            this.allowAmex == other.isAllowAmex() &&
            this.allowJCB == other.isAllowJCB();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += (isAllowVisa() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isAllowMC() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isAllowDiscover() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isAllowDiners() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isAllowAmex() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isAllowJCB() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CreditCardsAllowed.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "creditCardsAllowed"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("allowVisa");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "allowVisa"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("allowMC");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "allowMC"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("allowDiscover");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "allowDiscover"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("allowDiners");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "allowDiners"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("allowAmex");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "allowAmex"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("allowJCB");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "allowJCB"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
