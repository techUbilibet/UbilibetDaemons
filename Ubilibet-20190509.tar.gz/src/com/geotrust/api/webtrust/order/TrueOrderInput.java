/**
 * TrueOrderInput.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.order;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class TrueOrderInput  implements java.io.Serializable {
    private com.geotrust.api.webtrust.order.OrderRequestHeader orderRequestHeader;

    private com.geotrust.api.webtrust.order.OrganizationInfo organizationInfo;

    private com.geotrust.api.webtrust.order.Contact adminContact;

    private com.geotrust.api.webtrust.order.Contact techContact;

    private com.geotrust.api.webtrust.order.Contact billingContact;

    private com.geotrust.api.webtrust.order.PaymentInfo paymentInfo;

    private com.geotrust.api.webtrust.order.PartnerTag[] partnerTags;

    public TrueOrderInput() {
    }

    public TrueOrderInput(
           com.geotrust.api.webtrust.order.OrderRequestHeader orderRequestHeader,
           com.geotrust.api.webtrust.order.OrganizationInfo organizationInfo,
           com.geotrust.api.webtrust.order.Contact adminContact,
           com.geotrust.api.webtrust.order.Contact techContact,
           com.geotrust.api.webtrust.order.Contact billingContact,
           com.geotrust.api.webtrust.order.PaymentInfo paymentInfo,
           com.geotrust.api.webtrust.order.PartnerTag[] partnerTags) {
           this.orderRequestHeader = orderRequestHeader;
           this.organizationInfo = organizationInfo;
           this.adminContact = adminContact;
           this.techContact = techContact;
           this.billingContact = billingContact;
           this.paymentInfo = paymentInfo;
           this.partnerTags = partnerTags;
    }


    /**
     * Gets the orderRequestHeader value for this TrueOrderInput.
     * 
     * @return orderRequestHeader
     */
    public com.geotrust.api.webtrust.order.OrderRequestHeader getOrderRequestHeader() {
        return orderRequestHeader;
    }


    /**
     * Sets the orderRequestHeader value for this TrueOrderInput.
     * 
     * @param orderRequestHeader
     */
    public void setOrderRequestHeader(com.geotrust.api.webtrust.order.OrderRequestHeader orderRequestHeader) {
        this.orderRequestHeader = orderRequestHeader;
    }


    /**
     * Gets the organizationInfo value for this TrueOrderInput.
     * 
     * @return organizationInfo
     */
    public com.geotrust.api.webtrust.order.OrganizationInfo getOrganizationInfo() {
        return organizationInfo;
    }


    /**
     * Sets the organizationInfo value for this TrueOrderInput.
     * 
     * @param organizationInfo
     */
    public void setOrganizationInfo(com.geotrust.api.webtrust.order.OrganizationInfo organizationInfo) {
        this.organizationInfo = organizationInfo;
    }


    /**
     * Gets the adminContact value for this TrueOrderInput.
     * 
     * @return adminContact
     */
    public com.geotrust.api.webtrust.order.Contact getAdminContact() {
        return adminContact;
    }


    /**
     * Sets the adminContact value for this TrueOrderInput.
     * 
     * @param adminContact
     */
    public void setAdminContact(com.geotrust.api.webtrust.order.Contact adminContact) {
        this.adminContact = adminContact;
    }


    /**
     * Gets the techContact value for this TrueOrderInput.
     * 
     * @return techContact
     */
    public com.geotrust.api.webtrust.order.Contact getTechContact() {
        return techContact;
    }


    /**
     * Sets the techContact value for this TrueOrderInput.
     * 
     * @param techContact
     */
    public void setTechContact(com.geotrust.api.webtrust.order.Contact techContact) {
        this.techContact = techContact;
    }


    /**
     * Gets the billingContact value for this TrueOrderInput.
     * 
     * @return billingContact
     */
    public com.geotrust.api.webtrust.order.Contact getBillingContact() {
        return billingContact;
    }


    /**
     * Sets the billingContact value for this TrueOrderInput.
     * 
     * @param billingContact
     */
    public void setBillingContact(com.geotrust.api.webtrust.order.Contact billingContact) {
        this.billingContact = billingContact;
    }


    /**
     * Gets the paymentInfo value for this TrueOrderInput.
     * 
     * @return paymentInfo
     */
    public com.geotrust.api.webtrust.order.PaymentInfo getPaymentInfo() {
        return paymentInfo;
    }


    /**
     * Sets the paymentInfo value for this TrueOrderInput.
     * 
     * @param paymentInfo
     */
    public void setPaymentInfo(com.geotrust.api.webtrust.order.PaymentInfo paymentInfo) {
        this.paymentInfo = paymentInfo;
    }


    /**
     * Gets the partnerTags value for this TrueOrderInput.
     * 
     * @return partnerTags
     */
    public com.geotrust.api.webtrust.order.PartnerTag[] getPartnerTags() {
        return partnerTags;
    }


    /**
     * Sets the partnerTags value for this TrueOrderInput.
     * 
     * @param partnerTags
     */
    public void setPartnerTags(com.geotrust.api.webtrust.order.PartnerTag[] partnerTags) {
        this.partnerTags = partnerTags;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof TrueOrderInput)) return false;
        TrueOrderInput other = (TrueOrderInput) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.orderRequestHeader==null && other.getOrderRequestHeader()==null) || 
             (this.orderRequestHeader!=null &&
              this.orderRequestHeader.equals(other.getOrderRequestHeader()))) &&
            ((this.organizationInfo==null && other.getOrganizationInfo()==null) || 
             (this.organizationInfo!=null &&
              this.organizationInfo.equals(other.getOrganizationInfo()))) &&
            ((this.adminContact==null && other.getAdminContact()==null) || 
             (this.adminContact!=null &&
              this.adminContact.equals(other.getAdminContact()))) &&
            ((this.techContact==null && other.getTechContact()==null) || 
             (this.techContact!=null &&
              this.techContact.equals(other.getTechContact()))) &&
            ((this.billingContact==null && other.getBillingContact()==null) || 
             (this.billingContact!=null &&
              this.billingContact.equals(other.getBillingContact()))) &&
            ((this.paymentInfo==null && other.getPaymentInfo()==null) || 
             (this.paymentInfo!=null &&
              this.paymentInfo.equals(other.getPaymentInfo()))) &&
            ((this.partnerTags==null && other.getPartnerTags()==null) || 
             (this.partnerTags!=null &&
              java.util.Arrays.equals(this.partnerTags, other.getPartnerTags())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getOrderRequestHeader() != null) {
            _hashCode += getOrderRequestHeader().hashCode();
        }
        if (getOrganizationInfo() != null) {
            _hashCode += getOrganizationInfo().hashCode();
        }
        if (getAdminContact() != null) {
            _hashCode += getAdminContact().hashCode();
        }
        if (getTechContact() != null) {
            _hashCode += getTechContact().hashCode();
        }
        if (getBillingContact() != null) {
            _hashCode += getBillingContact().hashCode();
        }
        if (getPaymentInfo() != null) {
            _hashCode += getPaymentInfo().hashCode();
        }
        if (getPartnerTags() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getPartnerTags());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getPartnerTags(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(TrueOrderInput.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "TrueOrderInput"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderRequestHeader");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "OrderRequestHeader"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "orderRequestHeader"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("organizationInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "OrganizationInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "organizationInfo"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("adminContact");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "AdminContact"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Contact"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("techContact");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "TechContact"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Contact"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("billingContact");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "BillingContact"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Contact"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("paymentInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "PaymentInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "paymentInfo"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("partnerTags");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "PartnerTags"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "PartnerTag"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "PartnerTag"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
