/**
 * MerchantBillingContact.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.order;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class MerchantBillingContact  implements java.io.Serializable {
    private java.lang.String billing_address;

    private java.lang.String billing_city;

    private java.lang.String billing_state;

    private java.lang.String billing_zip;

    private java.lang.String billing_country;

    private java.lang.String firstName;

    private java.lang.String lastName;

    private java.lang.String email;

    private java.lang.String phone;

    public MerchantBillingContact() {
    }

    public MerchantBillingContact(
           java.lang.String billing_address,
           java.lang.String billing_city,
           java.lang.String billing_state,
           java.lang.String billing_zip,
           java.lang.String billing_country,
           java.lang.String firstName,
           java.lang.String lastName,
           java.lang.String email,
           java.lang.String phone) {
           this.billing_address = billing_address;
           this.billing_city = billing_city;
           this.billing_state = billing_state;
           this.billing_zip = billing_zip;
           this.billing_country = billing_country;
           this.firstName = firstName;
           this.lastName = lastName;
           this.email = email;
           this.phone = phone;
    }


    /**
     * Gets the billing_address value for this MerchantBillingContact.
     * 
     * @return billing_address
     */
    public java.lang.String getBilling_address() {
        return billing_address;
    }


    /**
     * Sets the billing_address value for this MerchantBillingContact.
     * 
     * @param billing_address
     */
    public void setBilling_address(java.lang.String billing_address) {
        this.billing_address = billing_address;
    }


    /**
     * Gets the billing_city value for this MerchantBillingContact.
     * 
     * @return billing_city
     */
    public java.lang.String getBilling_city() {
        return billing_city;
    }


    /**
     * Sets the billing_city value for this MerchantBillingContact.
     * 
     * @param billing_city
     */
    public void setBilling_city(java.lang.String billing_city) {
        this.billing_city = billing_city;
    }


    /**
     * Gets the billing_state value for this MerchantBillingContact.
     * 
     * @return billing_state
     */
    public java.lang.String getBilling_state() {
        return billing_state;
    }


    /**
     * Sets the billing_state value for this MerchantBillingContact.
     * 
     * @param billing_state
     */
    public void setBilling_state(java.lang.String billing_state) {
        this.billing_state = billing_state;
    }


    /**
     * Gets the billing_zip value for this MerchantBillingContact.
     * 
     * @return billing_zip
     */
    public java.lang.String getBilling_zip() {
        return billing_zip;
    }


    /**
     * Sets the billing_zip value for this MerchantBillingContact.
     * 
     * @param billing_zip
     */
    public void setBilling_zip(java.lang.String billing_zip) {
        this.billing_zip = billing_zip;
    }


    /**
     * Gets the billing_country value for this MerchantBillingContact.
     * 
     * @return billing_country
     */
    public java.lang.String getBilling_country() {
        return billing_country;
    }


    /**
     * Sets the billing_country value for this MerchantBillingContact.
     * 
     * @param billing_country
     */
    public void setBilling_country(java.lang.String billing_country) {
        this.billing_country = billing_country;
    }


    /**
     * Gets the firstName value for this MerchantBillingContact.
     * 
     * @return firstName
     */
    public java.lang.String getFirstName() {
        return firstName;
    }


    /**
     * Sets the firstName value for this MerchantBillingContact.
     * 
     * @param firstName
     */
    public void setFirstName(java.lang.String firstName) {
        this.firstName = firstName;
    }


    /**
     * Gets the lastName value for this MerchantBillingContact.
     * 
     * @return lastName
     */
    public java.lang.String getLastName() {
        return lastName;
    }


    /**
     * Sets the lastName value for this MerchantBillingContact.
     * 
     * @param lastName
     */
    public void setLastName(java.lang.String lastName) {
        this.lastName = lastName;
    }


    /**
     * Gets the email value for this MerchantBillingContact.
     * 
     * @return email
     */
    public java.lang.String getEmail() {
        return email;
    }


    /**
     * Sets the email value for this MerchantBillingContact.
     * 
     * @param email
     */
    public void setEmail(java.lang.String email) {
        this.email = email;
    }


    /**
     * Gets the phone value for this MerchantBillingContact.
     * 
     * @return phone
     */
    public java.lang.String getPhone() {
        return phone;
    }


    /**
     * Sets the phone value for this MerchantBillingContact.
     * 
     * @param phone
     */
    public void setPhone(java.lang.String phone) {
        this.phone = phone;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof MerchantBillingContact)) return false;
        MerchantBillingContact other = (MerchantBillingContact) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.billing_address==null && other.getBilling_address()==null) || 
             (this.billing_address!=null &&
              this.billing_address.equals(other.getBilling_address()))) &&
            ((this.billing_city==null && other.getBilling_city()==null) || 
             (this.billing_city!=null &&
              this.billing_city.equals(other.getBilling_city()))) &&
            ((this.billing_state==null && other.getBilling_state()==null) || 
             (this.billing_state!=null &&
              this.billing_state.equals(other.getBilling_state()))) &&
            ((this.billing_zip==null && other.getBilling_zip()==null) || 
             (this.billing_zip!=null &&
              this.billing_zip.equals(other.getBilling_zip()))) &&
            ((this.billing_country==null && other.getBilling_country()==null) || 
             (this.billing_country!=null &&
              this.billing_country.equals(other.getBilling_country()))) &&
            ((this.firstName==null && other.getFirstName()==null) || 
             (this.firstName!=null &&
              this.firstName.equals(other.getFirstName()))) &&
            ((this.lastName==null && other.getLastName()==null) || 
             (this.lastName!=null &&
              this.lastName.equals(other.getLastName()))) &&
            ((this.email==null && other.getEmail()==null) || 
             (this.email!=null &&
              this.email.equals(other.getEmail()))) &&
            ((this.phone==null && other.getPhone()==null) || 
             (this.phone!=null &&
              this.phone.equals(other.getPhone())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getBilling_address() != null) {
            _hashCode += getBilling_address().hashCode();
        }
        if (getBilling_city() != null) {
            _hashCode += getBilling_city().hashCode();
        }
        if (getBilling_state() != null) {
            _hashCode += getBilling_state().hashCode();
        }
        if (getBilling_zip() != null) {
            _hashCode += getBilling_zip().hashCode();
        }
        if (getBilling_country() != null) {
            _hashCode += getBilling_country().hashCode();
        }
        if (getFirstName() != null) {
            _hashCode += getFirstName().hashCode();
        }
        if (getLastName() != null) {
            _hashCode += getLastName().hashCode();
        }
        if (getEmail() != null) {
            _hashCode += getEmail().hashCode();
        }
        if (getPhone() != null) {
            _hashCode += getPhone().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(MerchantBillingContact.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "merchantBillingContact"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("billing_address");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "billing_address"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("billing_city");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "billing_city"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("billing_state");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "billing_state"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("billing_zip");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "billing_zip"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("billing_country");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "billing_country"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("firstName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "FirstName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "LastName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("email");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Email"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("phone");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Phone"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
