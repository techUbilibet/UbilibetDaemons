/**
 * ValidateAuthDataOutput.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.order;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class ValidateAuthDataOutput  implements java.io.Serializable {
    private com.geotrust.api.webtrust.order.OrderResponseHeader authOrderResponseHeader;

    private com.geotrust.api.webtrust.order.AuthDataStatus authDataStatus;

    public ValidateAuthDataOutput() {
    }

    public ValidateAuthDataOutput(
           com.geotrust.api.webtrust.order.OrderResponseHeader authOrderResponseHeader,
           com.geotrust.api.webtrust.order.AuthDataStatus authDataStatus) {
           this.authOrderResponseHeader = authOrderResponseHeader;
           this.authDataStatus = authDataStatus;
    }


    /**
     * Gets the authOrderResponseHeader value for this ValidateAuthDataOutput.
     * 
     * @return authOrderResponseHeader
     */
    public com.geotrust.api.webtrust.order.OrderResponseHeader getAuthOrderResponseHeader() {
        return authOrderResponseHeader;
    }


    /**
     * Sets the authOrderResponseHeader value for this ValidateAuthDataOutput.
     * 
     * @param authOrderResponseHeader
     */
    public void setAuthOrderResponseHeader(com.geotrust.api.webtrust.order.OrderResponseHeader authOrderResponseHeader) {
        this.authOrderResponseHeader = authOrderResponseHeader;
    }


    /**
     * Gets the authDataStatus value for this ValidateAuthDataOutput.
     * 
     * @return authDataStatus
     */
    public com.geotrust.api.webtrust.order.AuthDataStatus getAuthDataStatus() {
        return authDataStatus;
    }


    /**
     * Sets the authDataStatus value for this ValidateAuthDataOutput.
     * 
     * @param authDataStatus
     */
    public void setAuthDataStatus(com.geotrust.api.webtrust.order.AuthDataStatus authDataStatus) {
        this.authDataStatus = authDataStatus;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ValidateAuthDataOutput)) return false;
        ValidateAuthDataOutput other = (ValidateAuthDataOutput) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.authOrderResponseHeader==null && other.getAuthOrderResponseHeader()==null) || 
             (this.authOrderResponseHeader!=null &&
              this.authOrderResponseHeader.equals(other.getAuthOrderResponseHeader()))) &&
            ((this.authDataStatus==null && other.getAuthDataStatus()==null) || 
             (this.authDataStatus!=null &&
              this.authDataStatus.equals(other.getAuthDataStatus())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getAuthOrderResponseHeader() != null) {
            _hashCode += getAuthOrderResponseHeader().hashCode();
        }
        if (getAuthDataStatus() != null) {
            _hashCode += getAuthDataStatus().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ValidateAuthDataOutput.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ValidateAuthDataOutput"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("authOrderResponseHeader");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "AuthOrderResponseHeader"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "orderResponseHeader"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("authDataStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "AuthDataStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "AuthDataStatus"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
