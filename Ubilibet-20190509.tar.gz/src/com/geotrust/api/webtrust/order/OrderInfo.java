/**
 * OrderInfo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.order;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class OrderInfo  implements java.io.Serializable {
    private java.lang.String partnerOrderID;

    private java.lang.Integer geoTrustOrderID;

    private java.lang.String domainName;

    private java.util.Calendar orderDate;

    private java.util.Calendar orderCompleteDate;

    private java.util.Calendar orderDeactivatedDate;

    private java.lang.String price;

    private java.lang.String method;

    private java.lang.String orderStatusMajor;

    private java.lang.Integer validityPeriod;

    private java.lang.Integer serverCount;

    private java.lang.String renewalInd;

    private java.lang.String CUIndicator;

    private java.lang.String productCode;

    private java.lang.String renewalBehavior;

    private java.lang.String specialInstructions;

    private java.lang.String orderState;

    private com.geotrust.api.webtrust.order.OrderStateReason orderStateReason;

    private java.lang.String resellerApprovalStatus;

    private java.lang.String wstepInd;

    private java.lang.String sealPreference;

    private java.lang.String sealStatus;

    private java.lang.String malwareScanStatus;

    private java.util.Calendar lastScanDate;

    private java.lang.String usageBillingIndicator;

    private java.util.Calendar usageFromDate;

    private java.util.Calendar usageToDate;

    private java.lang.Integer usageHours;

    private com.geotrust.api.webtrust.order.VulnerabilityScanInfo vulnerabilityScanInfo;

    private com.geotrust.api.webtrust.order.FileAuthDVInfo fileAuthDVInfo;

    private com.geotrust.api.webtrust.order.DNSAuthDVInfo DNSAuthDVInfo;

    private java.lang.String subscriptionStatus;

    private java.lang.String renewalEligible;

    private java.util.Calendar subscriptionEndDate;

    public OrderInfo() {
    }

    public OrderInfo(
           java.lang.String partnerOrderID,
           java.lang.Integer geoTrustOrderID,
           java.lang.String domainName,
           java.util.Calendar orderDate,
           java.util.Calendar orderCompleteDate,
           java.util.Calendar orderDeactivatedDate,
           java.lang.String price,
           java.lang.String method,
           java.lang.String orderStatusMajor,
           java.lang.Integer validityPeriod,
           java.lang.Integer serverCount,
           java.lang.String renewalInd,
           java.lang.String CUIndicator,
           java.lang.String productCode,
           java.lang.String renewalBehavior,
           java.lang.String specialInstructions,
           java.lang.String orderState,
           com.geotrust.api.webtrust.order.OrderStateReason orderStateReason,
           java.lang.String resellerApprovalStatus,
           java.lang.String wstepInd,
           java.lang.String sealPreference,
           java.lang.String sealStatus,
           java.lang.String malwareScanStatus,
           java.util.Calendar lastScanDate,
           java.lang.String usageBillingIndicator,
           java.util.Calendar usageFromDate,
           java.util.Calendar usageToDate,
           java.lang.Integer usageHours,
           com.geotrust.api.webtrust.order.VulnerabilityScanInfo vulnerabilityScanInfo,
           com.geotrust.api.webtrust.order.FileAuthDVInfo fileAuthDVInfo,
           com.geotrust.api.webtrust.order.DNSAuthDVInfo DNSAuthDVInfo,
           java.lang.String subscriptionStatus,
           java.lang.String renewalEligible,
           java.util.Calendar subscriptionEndDate) {
           this.partnerOrderID = partnerOrderID;
           this.geoTrustOrderID = geoTrustOrderID;
           this.domainName = domainName;
           this.orderDate = orderDate;
           this.orderCompleteDate = orderCompleteDate;
           this.orderDeactivatedDate = orderDeactivatedDate;
           this.price = price;
           this.method = method;
           this.orderStatusMajor = orderStatusMajor;
           this.validityPeriod = validityPeriod;
           this.serverCount = serverCount;
           this.renewalInd = renewalInd;
           this.CUIndicator = CUIndicator;
           this.productCode = productCode;
           this.renewalBehavior = renewalBehavior;
           this.specialInstructions = specialInstructions;
           this.orderState = orderState;
           this.orderStateReason = orderStateReason;
           this.resellerApprovalStatus = resellerApprovalStatus;
           this.wstepInd = wstepInd;
           this.sealPreference = sealPreference;
           this.sealStatus = sealStatus;
           this.malwareScanStatus = malwareScanStatus;
           this.lastScanDate = lastScanDate;
           this.usageBillingIndicator = usageBillingIndicator;
           this.usageFromDate = usageFromDate;
           this.usageToDate = usageToDate;
           this.usageHours = usageHours;
           this.vulnerabilityScanInfo = vulnerabilityScanInfo;
           this.fileAuthDVInfo = fileAuthDVInfo;
           this.DNSAuthDVInfo = DNSAuthDVInfo;
           this.subscriptionStatus = subscriptionStatus;
           this.renewalEligible = renewalEligible;
           this.subscriptionEndDate = subscriptionEndDate;
    }


    /**
     * Gets the partnerOrderID value for this OrderInfo.
     * 
     * @return partnerOrderID
     */
    public java.lang.String getPartnerOrderID() {
        return partnerOrderID;
    }


    /**
     * Sets the partnerOrderID value for this OrderInfo.
     * 
     * @param partnerOrderID
     */
    public void setPartnerOrderID(java.lang.String partnerOrderID) {
        this.partnerOrderID = partnerOrderID;
    }


    /**
     * Gets the geoTrustOrderID value for this OrderInfo.
     * 
     * @return geoTrustOrderID
     */
    public java.lang.Integer getGeoTrustOrderID() {
        return geoTrustOrderID;
    }


    /**
     * Sets the geoTrustOrderID value for this OrderInfo.
     * 
     * @param geoTrustOrderID
     */
    public void setGeoTrustOrderID(java.lang.Integer geoTrustOrderID) {
        this.geoTrustOrderID = geoTrustOrderID;
    }


    /**
     * Gets the domainName value for this OrderInfo.
     * 
     * @return domainName
     */
    public java.lang.String getDomainName() {
        return domainName;
    }


    /**
     * Sets the domainName value for this OrderInfo.
     * 
     * @param domainName
     */
    public void setDomainName(java.lang.String domainName) {
        this.domainName = domainName;
    }


    /**
     * Gets the orderDate value for this OrderInfo.
     * 
     * @return orderDate
     */
    public java.util.Calendar getOrderDate() {
        return orderDate;
    }


    /**
     * Sets the orderDate value for this OrderInfo.
     * 
     * @param orderDate
     */
    public void setOrderDate(java.util.Calendar orderDate) {
        this.orderDate = orderDate;
    }


    /**
     * Gets the orderCompleteDate value for this OrderInfo.
     * 
     * @return orderCompleteDate
     */
    public java.util.Calendar getOrderCompleteDate() {
        return orderCompleteDate;
    }


    /**
     * Sets the orderCompleteDate value for this OrderInfo.
     * 
     * @param orderCompleteDate
     */
    public void setOrderCompleteDate(java.util.Calendar orderCompleteDate) {
        this.orderCompleteDate = orderCompleteDate;
    }


    /**
     * Gets the orderDeactivatedDate value for this OrderInfo.
     * 
     * @return orderDeactivatedDate
     */
    public java.util.Calendar getOrderDeactivatedDate() {
        return orderDeactivatedDate;
    }


    /**
     * Sets the orderDeactivatedDate value for this OrderInfo.
     * 
     * @param orderDeactivatedDate
     */
    public void setOrderDeactivatedDate(java.util.Calendar orderDeactivatedDate) {
        this.orderDeactivatedDate = orderDeactivatedDate;
    }


    /**
     * Gets the price value for this OrderInfo.
     * 
     * @return price
     */
    public java.lang.String getPrice() {
        return price;
    }


    /**
     * Sets the price value for this OrderInfo.
     * 
     * @param price
     */
    public void setPrice(java.lang.String price) {
        this.price = price;
    }


    /**
     * Gets the method value for this OrderInfo.
     * 
     * @return method
     */
    public java.lang.String getMethod() {
        return method;
    }


    /**
     * Sets the method value for this OrderInfo.
     * 
     * @param method
     */
    public void setMethod(java.lang.String method) {
        this.method = method;
    }


    /**
     * Gets the orderStatusMajor value for this OrderInfo.
     * 
     * @return orderStatusMajor
     */
    public java.lang.String getOrderStatusMajor() {
        return orderStatusMajor;
    }


    /**
     * Sets the orderStatusMajor value for this OrderInfo.
     * 
     * @param orderStatusMajor
     */
    public void setOrderStatusMajor(java.lang.String orderStatusMajor) {
        this.orderStatusMajor = orderStatusMajor;
    }


    /**
     * Gets the validityPeriod value for this OrderInfo.
     * 
     * @return validityPeriod
     */
    public java.lang.Integer getValidityPeriod() {
        return validityPeriod;
    }


    /**
     * Sets the validityPeriod value for this OrderInfo.
     * 
     * @param validityPeriod
     */
    public void setValidityPeriod(java.lang.Integer validityPeriod) {
        this.validityPeriod = validityPeriod;
    }


    /**
     * Gets the serverCount value for this OrderInfo.
     * 
     * @return serverCount
     */
    public java.lang.Integer getServerCount() {
        return serverCount;
    }


    /**
     * Sets the serverCount value for this OrderInfo.
     * 
     * @param serverCount
     */
    public void setServerCount(java.lang.Integer serverCount) {
        this.serverCount = serverCount;
    }


    /**
     * Gets the renewalInd value for this OrderInfo.
     * 
     * @return renewalInd
     */
    public java.lang.String getRenewalInd() {
        return renewalInd;
    }


    /**
     * Sets the renewalInd value for this OrderInfo.
     * 
     * @param renewalInd
     */
    public void setRenewalInd(java.lang.String renewalInd) {
        this.renewalInd = renewalInd;
    }


    /**
     * Gets the CUIndicator value for this OrderInfo.
     * 
     * @return CUIndicator
     */
    public java.lang.String getCUIndicator() {
        return CUIndicator;
    }


    /**
     * Sets the CUIndicator value for this OrderInfo.
     * 
     * @param CUIndicator
     */
    public void setCUIndicator(java.lang.String CUIndicator) {
        this.CUIndicator = CUIndicator;
    }


    /**
     * Gets the productCode value for this OrderInfo.
     * 
     * @return productCode
     */
    public java.lang.String getProductCode() {
        return productCode;
    }


    /**
     * Sets the productCode value for this OrderInfo.
     * 
     * @param productCode
     */
    public void setProductCode(java.lang.String productCode) {
        this.productCode = productCode;
    }


    /**
     * Gets the renewalBehavior value for this OrderInfo.
     * 
     * @return renewalBehavior
     */
    public java.lang.String getRenewalBehavior() {
        return renewalBehavior;
    }


    /**
     * Sets the renewalBehavior value for this OrderInfo.
     * 
     * @param renewalBehavior
     */
    public void setRenewalBehavior(java.lang.String renewalBehavior) {
        this.renewalBehavior = renewalBehavior;
    }


    /**
     * Gets the specialInstructions value for this OrderInfo.
     * 
     * @return specialInstructions
     */
    public java.lang.String getSpecialInstructions() {
        return specialInstructions;
    }


    /**
     * Sets the specialInstructions value for this OrderInfo.
     * 
     * @param specialInstructions
     */
    public void setSpecialInstructions(java.lang.String specialInstructions) {
        this.specialInstructions = specialInstructions;
    }


    /**
     * Gets the orderState value for this OrderInfo.
     * 
     * @return orderState
     */
    public java.lang.String getOrderState() {
        return orderState;
    }


    /**
     * Sets the orderState value for this OrderInfo.
     * 
     * @param orderState
     */
    public void setOrderState(java.lang.String orderState) {
        this.orderState = orderState;
    }


    /**
     * Gets the orderStateReason value for this OrderInfo.
     * 
     * @return orderStateReason
     */
    public com.geotrust.api.webtrust.order.OrderStateReason getOrderStateReason() {
        return orderStateReason;
    }


    /**
     * Sets the orderStateReason value for this OrderInfo.
     * 
     * @param orderStateReason
     */
    public void setOrderStateReason(com.geotrust.api.webtrust.order.OrderStateReason orderStateReason) {
        this.orderStateReason = orderStateReason;
    }


    /**
     * Gets the resellerApprovalStatus value for this OrderInfo.
     * 
     * @return resellerApprovalStatus
     */
    public java.lang.String getResellerApprovalStatus() {
        return resellerApprovalStatus;
    }


    /**
     * Sets the resellerApprovalStatus value for this OrderInfo.
     * 
     * @param resellerApprovalStatus
     */
    public void setResellerApprovalStatus(java.lang.String resellerApprovalStatus) {
        this.resellerApprovalStatus = resellerApprovalStatus;
    }


    /**
     * Gets the wstepInd value for this OrderInfo.
     * 
     * @return wstepInd
     */
    public java.lang.String getWstepInd() {
        return wstepInd;
    }


    /**
     * Sets the wstepInd value for this OrderInfo.
     * 
     * @param wstepInd
     */
    public void setWstepInd(java.lang.String wstepInd) {
        this.wstepInd = wstepInd;
    }


    /**
     * Gets the sealPreference value for this OrderInfo.
     * 
     * @return sealPreference
     */
    public java.lang.String getSealPreference() {
        return sealPreference;
    }


    /**
     * Sets the sealPreference value for this OrderInfo.
     * 
     * @param sealPreference
     */
    public void setSealPreference(java.lang.String sealPreference) {
        this.sealPreference = sealPreference;
    }


    /**
     * Gets the sealStatus value for this OrderInfo.
     * 
     * @return sealStatus
     */
    public java.lang.String getSealStatus() {
        return sealStatus;
    }


    /**
     * Sets the sealStatus value for this OrderInfo.
     * 
     * @param sealStatus
     */
    public void setSealStatus(java.lang.String sealStatus) {
        this.sealStatus = sealStatus;
    }


    /**
     * Gets the malwareScanStatus value for this OrderInfo.
     * 
     * @return malwareScanStatus
     */
    public java.lang.String getMalwareScanStatus() {
        return malwareScanStatus;
    }


    /**
     * Sets the malwareScanStatus value for this OrderInfo.
     * 
     * @param malwareScanStatus
     */
    public void setMalwareScanStatus(java.lang.String malwareScanStatus) {
        this.malwareScanStatus = malwareScanStatus;
    }


    /**
     * Gets the lastScanDate value for this OrderInfo.
     * 
     * @return lastScanDate
     */
    public java.util.Calendar getLastScanDate() {
        return lastScanDate;
    }


    /**
     * Sets the lastScanDate value for this OrderInfo.
     * 
     * @param lastScanDate
     */
    public void setLastScanDate(java.util.Calendar lastScanDate) {
        this.lastScanDate = lastScanDate;
    }


    /**
     * Gets the usageBillingIndicator value for this OrderInfo.
     * 
     * @return usageBillingIndicator
     */
    public java.lang.String getUsageBillingIndicator() {
        return usageBillingIndicator;
    }


    /**
     * Sets the usageBillingIndicator value for this OrderInfo.
     * 
     * @param usageBillingIndicator
     */
    public void setUsageBillingIndicator(java.lang.String usageBillingIndicator) {
        this.usageBillingIndicator = usageBillingIndicator;
    }


    /**
     * Gets the usageFromDate value for this OrderInfo.
     * 
     * @return usageFromDate
     */
    public java.util.Calendar getUsageFromDate() {
        return usageFromDate;
    }


    /**
     * Sets the usageFromDate value for this OrderInfo.
     * 
     * @param usageFromDate
     */
    public void setUsageFromDate(java.util.Calendar usageFromDate) {
        this.usageFromDate = usageFromDate;
    }


    /**
     * Gets the usageToDate value for this OrderInfo.
     * 
     * @return usageToDate
     */
    public java.util.Calendar getUsageToDate() {
        return usageToDate;
    }


    /**
     * Sets the usageToDate value for this OrderInfo.
     * 
     * @param usageToDate
     */
    public void setUsageToDate(java.util.Calendar usageToDate) {
        this.usageToDate = usageToDate;
    }


    /**
     * Gets the usageHours value for this OrderInfo.
     * 
     * @return usageHours
     */
    public java.lang.Integer getUsageHours() {
        return usageHours;
    }


    /**
     * Sets the usageHours value for this OrderInfo.
     * 
     * @param usageHours
     */
    public void setUsageHours(java.lang.Integer usageHours) {
        this.usageHours = usageHours;
    }


    /**
     * Gets the vulnerabilityScanInfo value for this OrderInfo.
     * 
     * @return vulnerabilityScanInfo
     */
    public com.geotrust.api.webtrust.order.VulnerabilityScanInfo getVulnerabilityScanInfo() {
        return vulnerabilityScanInfo;
    }


    /**
     * Sets the vulnerabilityScanInfo value for this OrderInfo.
     * 
     * @param vulnerabilityScanInfo
     */
    public void setVulnerabilityScanInfo(com.geotrust.api.webtrust.order.VulnerabilityScanInfo vulnerabilityScanInfo) {
        this.vulnerabilityScanInfo = vulnerabilityScanInfo;
    }


    /**
     * Gets the fileAuthDVInfo value for this OrderInfo.
     * 
     * @return fileAuthDVInfo
     */
    public com.geotrust.api.webtrust.order.FileAuthDVInfo getFileAuthDVInfo() {
        return fileAuthDVInfo;
    }


    /**
     * Sets the fileAuthDVInfo value for this OrderInfo.
     * 
     * @param fileAuthDVInfo
     */
    public void setFileAuthDVInfo(com.geotrust.api.webtrust.order.FileAuthDVInfo fileAuthDVInfo) {
        this.fileAuthDVInfo = fileAuthDVInfo;
    }


    /**
     * Gets the DNSAuthDVInfo value for this OrderInfo.
     * 
     * @return DNSAuthDVInfo
     */
    public com.geotrust.api.webtrust.order.DNSAuthDVInfo getDNSAuthDVInfo() {
        return DNSAuthDVInfo;
    }


    /**
     * Sets the DNSAuthDVInfo value for this OrderInfo.
     * 
     * @param DNSAuthDVInfo
     */
    public void setDNSAuthDVInfo(com.geotrust.api.webtrust.order.DNSAuthDVInfo DNSAuthDVInfo) {
        this.DNSAuthDVInfo = DNSAuthDVInfo;
    }


    /**
     * Gets the subscriptionStatus value for this OrderInfo.
     * 
     * @return subscriptionStatus
     */
    public java.lang.String getSubscriptionStatus() {
        return subscriptionStatus;
    }


    /**
     * Sets the subscriptionStatus value for this OrderInfo.
     * 
     * @param subscriptionStatus
     */
    public void setSubscriptionStatus(java.lang.String subscriptionStatus) {
        this.subscriptionStatus = subscriptionStatus;
    }


    /**
     * Gets the renewalEligible value for this OrderInfo.
     * 
     * @return renewalEligible
     */
    public java.lang.String getRenewalEligible() {
        return renewalEligible;
    }


    /**
     * Sets the renewalEligible value for this OrderInfo.
     * 
     * @param renewalEligible
     */
    public void setRenewalEligible(java.lang.String renewalEligible) {
        this.renewalEligible = renewalEligible;
    }


    /**
     * Gets the subscriptionEndDate value for this OrderInfo.
     * 
     * @return subscriptionEndDate
     */
    public java.util.Calendar getSubscriptionEndDate() {
        return subscriptionEndDate;
    }


    /**
     * Sets the subscriptionEndDate value for this OrderInfo.
     * 
     * @param subscriptionEndDate
     */
    public void setSubscriptionEndDate(java.util.Calendar subscriptionEndDate) {
        this.subscriptionEndDate = subscriptionEndDate;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof OrderInfo)) return false;
        OrderInfo other = (OrderInfo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.partnerOrderID==null && other.getPartnerOrderID()==null) || 
             (this.partnerOrderID!=null &&
              this.partnerOrderID.equals(other.getPartnerOrderID()))) &&
            ((this.geoTrustOrderID==null && other.getGeoTrustOrderID()==null) || 
             (this.geoTrustOrderID!=null &&
              this.geoTrustOrderID.equals(other.getGeoTrustOrderID()))) &&
            ((this.domainName==null && other.getDomainName()==null) || 
             (this.domainName!=null &&
              this.domainName.equals(other.getDomainName()))) &&
            ((this.orderDate==null && other.getOrderDate()==null) || 
             (this.orderDate!=null &&
              this.orderDate.equals(other.getOrderDate()))) &&
            ((this.orderCompleteDate==null && other.getOrderCompleteDate()==null) || 
             (this.orderCompleteDate!=null &&
              this.orderCompleteDate.equals(other.getOrderCompleteDate()))) &&
            ((this.orderDeactivatedDate==null && other.getOrderDeactivatedDate()==null) || 
             (this.orderDeactivatedDate!=null &&
              this.orderDeactivatedDate.equals(other.getOrderDeactivatedDate()))) &&
            ((this.price==null && other.getPrice()==null) || 
             (this.price!=null &&
              this.price.equals(other.getPrice()))) &&
            ((this.method==null && other.getMethod()==null) || 
             (this.method!=null &&
              this.method.equals(other.getMethod()))) &&
            ((this.orderStatusMajor==null && other.getOrderStatusMajor()==null) || 
             (this.orderStatusMajor!=null &&
              this.orderStatusMajor.equals(other.getOrderStatusMajor()))) &&
            ((this.validityPeriod==null && other.getValidityPeriod()==null) || 
             (this.validityPeriod!=null &&
              this.validityPeriod.equals(other.getValidityPeriod()))) &&
            ((this.serverCount==null && other.getServerCount()==null) || 
             (this.serverCount!=null &&
              this.serverCount.equals(other.getServerCount()))) &&
            ((this.renewalInd==null && other.getRenewalInd()==null) || 
             (this.renewalInd!=null &&
              this.renewalInd.equals(other.getRenewalInd()))) &&
            ((this.CUIndicator==null && other.getCUIndicator()==null) || 
             (this.CUIndicator!=null &&
              this.CUIndicator.equals(other.getCUIndicator()))) &&
            ((this.productCode==null && other.getProductCode()==null) || 
             (this.productCode!=null &&
              this.productCode.equals(other.getProductCode()))) &&
            ((this.renewalBehavior==null && other.getRenewalBehavior()==null) || 
             (this.renewalBehavior!=null &&
              this.renewalBehavior.equals(other.getRenewalBehavior()))) &&
            ((this.specialInstructions==null && other.getSpecialInstructions()==null) || 
             (this.specialInstructions!=null &&
              this.specialInstructions.equals(other.getSpecialInstructions()))) &&
            ((this.orderState==null && other.getOrderState()==null) || 
             (this.orderState!=null &&
              this.orderState.equals(other.getOrderState()))) &&
            ((this.orderStateReason==null && other.getOrderStateReason()==null) || 
             (this.orderStateReason!=null &&
              this.orderStateReason.equals(other.getOrderStateReason()))) &&
            ((this.resellerApprovalStatus==null && other.getResellerApprovalStatus()==null) || 
             (this.resellerApprovalStatus!=null &&
              this.resellerApprovalStatus.equals(other.getResellerApprovalStatus()))) &&
            ((this.wstepInd==null && other.getWstepInd()==null) || 
             (this.wstepInd!=null &&
              this.wstepInd.equals(other.getWstepInd()))) &&
            ((this.sealPreference==null && other.getSealPreference()==null) || 
             (this.sealPreference!=null &&
              this.sealPreference.equals(other.getSealPreference()))) &&
            ((this.sealStatus==null && other.getSealStatus()==null) || 
             (this.sealStatus!=null &&
              this.sealStatus.equals(other.getSealStatus()))) &&
            ((this.malwareScanStatus==null && other.getMalwareScanStatus()==null) || 
             (this.malwareScanStatus!=null &&
              this.malwareScanStatus.equals(other.getMalwareScanStatus()))) &&
            ((this.lastScanDate==null && other.getLastScanDate()==null) || 
             (this.lastScanDate!=null &&
              this.lastScanDate.equals(other.getLastScanDate()))) &&
            ((this.usageBillingIndicator==null && other.getUsageBillingIndicator()==null) || 
             (this.usageBillingIndicator!=null &&
              this.usageBillingIndicator.equals(other.getUsageBillingIndicator()))) &&
            ((this.usageFromDate==null && other.getUsageFromDate()==null) || 
             (this.usageFromDate!=null &&
              this.usageFromDate.equals(other.getUsageFromDate()))) &&
            ((this.usageToDate==null && other.getUsageToDate()==null) || 
             (this.usageToDate!=null &&
              this.usageToDate.equals(other.getUsageToDate()))) &&
            ((this.usageHours==null && other.getUsageHours()==null) || 
             (this.usageHours!=null &&
              this.usageHours.equals(other.getUsageHours()))) &&
            ((this.vulnerabilityScanInfo==null && other.getVulnerabilityScanInfo()==null) || 
             (this.vulnerabilityScanInfo!=null &&
              this.vulnerabilityScanInfo.equals(other.getVulnerabilityScanInfo()))) &&
            ((this.fileAuthDVInfo==null && other.getFileAuthDVInfo()==null) || 
             (this.fileAuthDVInfo!=null &&
              this.fileAuthDVInfo.equals(other.getFileAuthDVInfo()))) &&
            ((this.DNSAuthDVInfo==null && other.getDNSAuthDVInfo()==null) || 
             (this.DNSAuthDVInfo!=null &&
              this.DNSAuthDVInfo.equals(other.getDNSAuthDVInfo()))) &&
            ((this.subscriptionStatus==null && other.getSubscriptionStatus()==null) || 
             (this.subscriptionStatus!=null &&
              this.subscriptionStatus.equals(other.getSubscriptionStatus()))) &&
            ((this.renewalEligible==null && other.getRenewalEligible()==null) || 
             (this.renewalEligible!=null &&
              this.renewalEligible.equals(other.getRenewalEligible()))) &&
            ((this.subscriptionEndDate==null && other.getSubscriptionEndDate()==null) || 
             (this.subscriptionEndDate!=null &&
              this.subscriptionEndDate.equals(other.getSubscriptionEndDate())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getPartnerOrderID() != null) {
            _hashCode += getPartnerOrderID().hashCode();
        }
        if (getGeoTrustOrderID() != null) {
            _hashCode += getGeoTrustOrderID().hashCode();
        }
        if (getDomainName() != null) {
            _hashCode += getDomainName().hashCode();
        }
        if (getOrderDate() != null) {
            _hashCode += getOrderDate().hashCode();
        }
        if (getOrderCompleteDate() != null) {
            _hashCode += getOrderCompleteDate().hashCode();
        }
        if (getOrderDeactivatedDate() != null) {
            _hashCode += getOrderDeactivatedDate().hashCode();
        }
        if (getPrice() != null) {
            _hashCode += getPrice().hashCode();
        }
        if (getMethod() != null) {
            _hashCode += getMethod().hashCode();
        }
        if (getOrderStatusMajor() != null) {
            _hashCode += getOrderStatusMajor().hashCode();
        }
        if (getValidityPeriod() != null) {
            _hashCode += getValidityPeriod().hashCode();
        }
        if (getServerCount() != null) {
            _hashCode += getServerCount().hashCode();
        }
        if (getRenewalInd() != null) {
            _hashCode += getRenewalInd().hashCode();
        }
        if (getCUIndicator() != null) {
            _hashCode += getCUIndicator().hashCode();
        }
        if (getProductCode() != null) {
            _hashCode += getProductCode().hashCode();
        }
        if (getRenewalBehavior() != null) {
            _hashCode += getRenewalBehavior().hashCode();
        }
        if (getSpecialInstructions() != null) {
            _hashCode += getSpecialInstructions().hashCode();
        }
        if (getOrderState() != null) {
            _hashCode += getOrderState().hashCode();
        }
        if (getOrderStateReason() != null) {
            _hashCode += getOrderStateReason().hashCode();
        }
        if (getResellerApprovalStatus() != null) {
            _hashCode += getResellerApprovalStatus().hashCode();
        }
        if (getWstepInd() != null) {
            _hashCode += getWstepInd().hashCode();
        }
        if (getSealPreference() != null) {
            _hashCode += getSealPreference().hashCode();
        }
        if (getSealStatus() != null) {
            _hashCode += getSealStatus().hashCode();
        }
        if (getMalwareScanStatus() != null) {
            _hashCode += getMalwareScanStatus().hashCode();
        }
        if (getLastScanDate() != null) {
            _hashCode += getLastScanDate().hashCode();
        }
        if (getUsageBillingIndicator() != null) {
            _hashCode += getUsageBillingIndicator().hashCode();
        }
        if (getUsageFromDate() != null) {
            _hashCode += getUsageFromDate().hashCode();
        }
        if (getUsageToDate() != null) {
            _hashCode += getUsageToDate().hashCode();
        }
        if (getUsageHours() != null) {
            _hashCode += getUsageHours().hashCode();
        }
        if (getVulnerabilityScanInfo() != null) {
            _hashCode += getVulnerabilityScanInfo().hashCode();
        }
        if (getFileAuthDVInfo() != null) {
            _hashCode += getFileAuthDVInfo().hashCode();
        }
        if (getDNSAuthDVInfo() != null) {
            _hashCode += getDNSAuthDVInfo().hashCode();
        }
        if (getSubscriptionStatus() != null) {
            _hashCode += getSubscriptionStatus().hashCode();
        }
        if (getRenewalEligible() != null) {
            _hashCode += getRenewalEligible().hashCode();
        }
        if (getSubscriptionEndDate() != null) {
            _hashCode += getSubscriptionEndDate().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(OrderInfo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "orderInfo"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("partnerOrderID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "PartnerOrderID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("geoTrustOrderID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "GeoTrustOrderID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("domainName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "DomainName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "OrderDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderCompleteDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "OrderCompleteDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderDeactivatedDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "OrderDeactivatedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("price");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Price"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("method");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Method"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderStatusMajor");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "OrderStatusMajor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("validityPeriod");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ValidityPeriod"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("serverCount");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ServerCount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("renewalInd");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "RenewalInd"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CUIndicator");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "CUIndicator"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("productCode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ProductCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("renewalBehavior");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "RenewalBehavior"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("specialInstructions");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "SpecialInstructions"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderState");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "OrderState"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderStateReason");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "OrderStateReason"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "OrderStateReason"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("resellerApprovalStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ResellerApprovalStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wstepInd");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "WstepInd"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sealPreference");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "SealPreference"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sealStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "SealStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("malwareScanStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "MalwareScanStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastScanDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "LastScanDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("usageBillingIndicator");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "UsageBillingIndicator"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("usageFromDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "UsageFromDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("usageToDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "UsageToDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("usageHours");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "UsageHours"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("vulnerabilityScanInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "VulnerabilityScanInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "vulnerabilityScanInfo"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fileAuthDVInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "FileAuthDVInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "fileAuthDVInfo"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DNSAuthDVInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "DNSAuthDVInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "DNSAuthDVInfo"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("subscriptionStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "SubscriptionStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("renewalEligible");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "RenewalEligible"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("subscriptionEndDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "SubscriptionEndDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
