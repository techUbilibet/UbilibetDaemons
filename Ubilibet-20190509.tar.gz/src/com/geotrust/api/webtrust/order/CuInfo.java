/**
 * CuInfo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.order;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class CuInfo  implements java.io.Serializable {
    private boolean CUIndicator;

    private java.lang.String CUCertificate;

    private int CUMonths;

    private java.lang.String CUSerialNumber;

    private java.lang.String CUExpriationDate;

    private java.lang.String CUIssuer;

    public CuInfo() {
    }

    public CuInfo(
           boolean CUIndicator,
           java.lang.String CUCertificate,
           int CUMonths,
           java.lang.String CUSerialNumber,
           java.lang.String CUExpriationDate,
           java.lang.String CUIssuer) {
           this.CUIndicator = CUIndicator;
           this.CUCertificate = CUCertificate;
           this.CUMonths = CUMonths;
           this.CUSerialNumber = CUSerialNumber;
           this.CUExpriationDate = CUExpriationDate;
           this.CUIssuer = CUIssuer;
    }


    /**
     * Gets the CUIndicator value for this CuInfo.
     * 
     * @return CUIndicator
     */
    public boolean isCUIndicator() {
        return CUIndicator;
    }


    /**
     * Sets the CUIndicator value for this CuInfo.
     * 
     * @param CUIndicator
     */
    public void setCUIndicator(boolean CUIndicator) {
        this.CUIndicator = CUIndicator;
    }


    /**
     * Gets the CUCertificate value for this CuInfo.
     * 
     * @return CUCertificate
     */
    public java.lang.String getCUCertificate() {
        return CUCertificate;
    }


    /**
     * Sets the CUCertificate value for this CuInfo.
     * 
     * @param CUCertificate
     */
    public void setCUCertificate(java.lang.String CUCertificate) {
        this.CUCertificate = CUCertificate;
    }


    /**
     * Gets the CUMonths value for this CuInfo.
     * 
     * @return CUMonths
     */
    public int getCUMonths() {
        return CUMonths;
    }


    /**
     * Sets the CUMonths value for this CuInfo.
     * 
     * @param CUMonths
     */
    public void setCUMonths(int CUMonths) {
        this.CUMonths = CUMonths;
    }


    /**
     * Gets the CUSerialNumber value for this CuInfo.
     * 
     * @return CUSerialNumber
     */
    public java.lang.String getCUSerialNumber() {
        return CUSerialNumber;
    }


    /**
     * Sets the CUSerialNumber value for this CuInfo.
     * 
     * @param CUSerialNumber
     */
    public void setCUSerialNumber(java.lang.String CUSerialNumber) {
        this.CUSerialNumber = CUSerialNumber;
    }


    /**
     * Gets the CUExpriationDate value for this CuInfo.
     * 
     * @return CUExpriationDate
     */
    public java.lang.String getCUExpriationDate() {
        return CUExpriationDate;
    }


    /**
     * Sets the CUExpriationDate value for this CuInfo.
     * 
     * @param CUExpriationDate
     */
    public void setCUExpriationDate(java.lang.String CUExpriationDate) {
        this.CUExpriationDate = CUExpriationDate;
    }


    /**
     * Gets the CUIssuer value for this CuInfo.
     * 
     * @return CUIssuer
     */
    public java.lang.String getCUIssuer() {
        return CUIssuer;
    }


    /**
     * Sets the CUIssuer value for this CuInfo.
     * 
     * @param CUIssuer
     */
    public void setCUIssuer(java.lang.String CUIssuer) {
        this.CUIssuer = CUIssuer;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CuInfo)) return false;
        CuInfo other = (CuInfo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.CUIndicator == other.isCUIndicator() &&
            ((this.CUCertificate==null && other.getCUCertificate()==null) || 
             (this.CUCertificate!=null &&
              this.CUCertificate.equals(other.getCUCertificate()))) &&
            this.CUMonths == other.getCUMonths() &&
            ((this.CUSerialNumber==null && other.getCUSerialNumber()==null) || 
             (this.CUSerialNumber!=null &&
              this.CUSerialNumber.equals(other.getCUSerialNumber()))) &&
            ((this.CUExpriationDate==null && other.getCUExpriationDate()==null) || 
             (this.CUExpriationDate!=null &&
              this.CUExpriationDate.equals(other.getCUExpriationDate()))) &&
            ((this.CUIssuer==null && other.getCUIssuer()==null) || 
             (this.CUIssuer!=null &&
              this.CUIssuer.equals(other.getCUIssuer())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += (isCUIndicator() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getCUCertificate() != null) {
            _hashCode += getCUCertificate().hashCode();
        }
        _hashCode += getCUMonths();
        if (getCUSerialNumber() != null) {
            _hashCode += getCUSerialNumber().hashCode();
        }
        if (getCUExpriationDate() != null) {
            _hashCode += getCUExpriationDate().hashCode();
        }
        if (getCUIssuer() != null) {
            _hashCode += getCUIssuer().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CuInfo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "cuInfo"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CUIndicator");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "CUIndicator"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CUCertificate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "CUCertificate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CUMonths");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "CUMonths"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CUSerialNumber");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "CUSerialNumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CUExpriationDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "CUExpriationDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CUIssuer");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "CUIssuer"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
