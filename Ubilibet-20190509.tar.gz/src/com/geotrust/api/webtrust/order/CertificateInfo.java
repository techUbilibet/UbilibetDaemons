/**
 * CertificateInfo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.order;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class CertificateInfo  implements java.io.Serializable {
    private java.lang.String certificateStatus;

    private java.util.Calendar startDate;

    private java.util.Calendar endDate;

    private java.lang.String commonName;

    private java.lang.String serialNumber;

    private java.lang.String locality;

    private java.lang.String state;

    private java.lang.String organization;

    private java.lang.String country;

    private java.lang.String organizationalUnit;

    private java.lang.String organizationalUnit2;

    private java.lang.String organizationalUnit3;

    private java.lang.String registrationNumber;

    private java.lang.String jurisdictionCity;

    private java.lang.String jurisdictionRegion;

    private java.lang.String jurisdictionCountry;

    private java.lang.String webServerType;

    private java.lang.String DNSNames;

    private java.lang.String UID;

    private com.geotrust.api.webtrust.order.AlgorithmInfo algorithmInfo;

    private com.geotrust.api.webtrust.order.CertTransparency certTransparency;

    public CertificateInfo() {
    }

    public CertificateInfo(
           java.lang.String certificateStatus,
           java.util.Calendar startDate,
           java.util.Calendar endDate,
           java.lang.String commonName,
           java.lang.String serialNumber,
           java.lang.String locality,
           java.lang.String state,
           java.lang.String organization,
           java.lang.String country,
           java.lang.String organizationalUnit,
           java.lang.String organizationalUnit2,
           java.lang.String organizationalUnit3,
           java.lang.String registrationNumber,
           java.lang.String jurisdictionCity,
           java.lang.String jurisdictionRegion,
           java.lang.String jurisdictionCountry,
           java.lang.String webServerType,
           java.lang.String DNSNames,
           java.lang.String UID,
           com.geotrust.api.webtrust.order.AlgorithmInfo algorithmInfo,
           com.geotrust.api.webtrust.order.CertTransparency certTransparency) {
           this.certificateStatus = certificateStatus;
           this.startDate = startDate;
           this.endDate = endDate;
           this.commonName = commonName;
           this.serialNumber = serialNumber;
           this.locality = locality;
           this.state = state;
           this.organization = organization;
           this.country = country;
           this.organizationalUnit = organizationalUnit;
           this.organizationalUnit2 = organizationalUnit2;
           this.organizationalUnit3 = organizationalUnit3;
           this.registrationNumber = registrationNumber;
           this.jurisdictionCity = jurisdictionCity;
           this.jurisdictionRegion = jurisdictionRegion;
           this.jurisdictionCountry = jurisdictionCountry;
           this.webServerType = webServerType;
           this.DNSNames = DNSNames;
           this.UID = UID;
           this.algorithmInfo = algorithmInfo;
           this.certTransparency = certTransparency;
    }


    /**
     * Gets the certificateStatus value for this CertificateInfo.
     * 
     * @return certificateStatus
     */
    public java.lang.String getCertificateStatus() {
        return certificateStatus;
    }


    /**
     * Sets the certificateStatus value for this CertificateInfo.
     * 
     * @param certificateStatus
     */
    public void setCertificateStatus(java.lang.String certificateStatus) {
        this.certificateStatus = certificateStatus;
    }


    /**
     * Gets the startDate value for this CertificateInfo.
     * 
     * @return startDate
     */
    public java.util.Calendar getStartDate() {
        return startDate;
    }


    /**
     * Sets the startDate value for this CertificateInfo.
     * 
     * @param startDate
     */
    public void setStartDate(java.util.Calendar startDate) {
        this.startDate = startDate;
    }


    /**
     * Gets the endDate value for this CertificateInfo.
     * 
     * @return endDate
     */
    public java.util.Calendar getEndDate() {
        return endDate;
    }


    /**
     * Sets the endDate value for this CertificateInfo.
     * 
     * @param endDate
     */
    public void setEndDate(java.util.Calendar endDate) {
        this.endDate = endDate;
    }


    /**
     * Gets the commonName value for this CertificateInfo.
     * 
     * @return commonName
     */
    public java.lang.String getCommonName() {
        return commonName;
    }


    /**
     * Sets the commonName value for this CertificateInfo.
     * 
     * @param commonName
     */
    public void setCommonName(java.lang.String commonName) {
        this.commonName = commonName;
    }


    /**
     * Gets the serialNumber value for this CertificateInfo.
     * 
     * @return serialNumber
     */
    public java.lang.String getSerialNumber() {
        return serialNumber;
    }


    /**
     * Sets the serialNumber value for this CertificateInfo.
     * 
     * @param serialNumber
     */
    public void setSerialNumber(java.lang.String serialNumber) {
        this.serialNumber = serialNumber;
    }


    /**
     * Gets the locality value for this CertificateInfo.
     * 
     * @return locality
     */
    public java.lang.String getLocality() {
        return locality;
    }


    /**
     * Sets the locality value for this CertificateInfo.
     * 
     * @param locality
     */
    public void setLocality(java.lang.String locality) {
        this.locality = locality;
    }


    /**
     * Gets the state value for this CertificateInfo.
     * 
     * @return state
     */
    public java.lang.String getState() {
        return state;
    }


    /**
     * Sets the state value for this CertificateInfo.
     * 
     * @param state
     */
    public void setState(java.lang.String state) {
        this.state = state;
    }


    /**
     * Gets the organization value for this CertificateInfo.
     * 
     * @return organization
     */
    public java.lang.String getOrganization() {
        return organization;
    }


    /**
     * Sets the organization value for this CertificateInfo.
     * 
     * @param organization
     */
    public void setOrganization(java.lang.String organization) {
        this.organization = organization;
    }


    /**
     * Gets the country value for this CertificateInfo.
     * 
     * @return country
     */
    public java.lang.String getCountry() {
        return country;
    }


    /**
     * Sets the country value for this CertificateInfo.
     * 
     * @param country
     */
    public void setCountry(java.lang.String country) {
        this.country = country;
    }


    /**
     * Gets the organizationalUnit value for this CertificateInfo.
     * 
     * @return organizationalUnit
     */
    public java.lang.String getOrganizationalUnit() {
        return organizationalUnit;
    }


    /**
     * Sets the organizationalUnit value for this CertificateInfo.
     * 
     * @param organizationalUnit
     */
    public void setOrganizationalUnit(java.lang.String organizationalUnit) {
        this.organizationalUnit = organizationalUnit;
    }


    /**
     * Gets the organizationalUnit2 value for this CertificateInfo.
     * 
     * @return organizationalUnit2
     */
    public java.lang.String getOrganizationalUnit2() {
        return organizationalUnit2;
    }


    /**
     * Sets the organizationalUnit2 value for this CertificateInfo.
     * 
     * @param organizationalUnit2
     */
    public void setOrganizationalUnit2(java.lang.String organizationalUnit2) {
        this.organizationalUnit2 = organizationalUnit2;
    }


    /**
     * Gets the organizationalUnit3 value for this CertificateInfo.
     * 
     * @return organizationalUnit3
     */
    public java.lang.String getOrganizationalUnit3() {
        return organizationalUnit3;
    }


    /**
     * Sets the organizationalUnit3 value for this CertificateInfo.
     * 
     * @param organizationalUnit3
     */
    public void setOrganizationalUnit3(java.lang.String organizationalUnit3) {
        this.organizationalUnit3 = organizationalUnit3;
    }


    /**
     * Gets the registrationNumber value for this CertificateInfo.
     * 
     * @return registrationNumber
     */
    public java.lang.String getRegistrationNumber() {
        return registrationNumber;
    }


    /**
     * Sets the registrationNumber value for this CertificateInfo.
     * 
     * @param registrationNumber
     */
    public void setRegistrationNumber(java.lang.String registrationNumber) {
        this.registrationNumber = registrationNumber;
    }


    /**
     * Gets the jurisdictionCity value for this CertificateInfo.
     * 
     * @return jurisdictionCity
     */
    public java.lang.String getJurisdictionCity() {
        return jurisdictionCity;
    }


    /**
     * Sets the jurisdictionCity value for this CertificateInfo.
     * 
     * @param jurisdictionCity
     */
    public void setJurisdictionCity(java.lang.String jurisdictionCity) {
        this.jurisdictionCity = jurisdictionCity;
    }


    /**
     * Gets the jurisdictionRegion value for this CertificateInfo.
     * 
     * @return jurisdictionRegion
     */
    public java.lang.String getJurisdictionRegion() {
        return jurisdictionRegion;
    }


    /**
     * Sets the jurisdictionRegion value for this CertificateInfo.
     * 
     * @param jurisdictionRegion
     */
    public void setJurisdictionRegion(java.lang.String jurisdictionRegion) {
        this.jurisdictionRegion = jurisdictionRegion;
    }


    /**
     * Gets the jurisdictionCountry value for this CertificateInfo.
     * 
     * @return jurisdictionCountry
     */
    public java.lang.String getJurisdictionCountry() {
        return jurisdictionCountry;
    }


    /**
     * Sets the jurisdictionCountry value for this CertificateInfo.
     * 
     * @param jurisdictionCountry
     */
    public void setJurisdictionCountry(java.lang.String jurisdictionCountry) {
        this.jurisdictionCountry = jurisdictionCountry;
    }


    /**
     * Gets the webServerType value for this CertificateInfo.
     * 
     * @return webServerType
     */
    public java.lang.String getWebServerType() {
        return webServerType;
    }


    /**
     * Sets the webServerType value for this CertificateInfo.
     * 
     * @param webServerType
     */
    public void setWebServerType(java.lang.String webServerType) {
        this.webServerType = webServerType;
    }


    /**
     * Gets the DNSNames value for this CertificateInfo.
     * 
     * @return DNSNames
     */
    public java.lang.String getDNSNames() {
        return DNSNames;
    }


    /**
     * Sets the DNSNames value for this CertificateInfo.
     * 
     * @param DNSNames
     */
    public void setDNSNames(java.lang.String DNSNames) {
        this.DNSNames = DNSNames;
    }


    /**
     * Gets the UID value for this CertificateInfo.
     * 
     * @return UID
     */
    public java.lang.String getUID() {
        return UID;
    }


    /**
     * Sets the UID value for this CertificateInfo.
     * 
     * @param UID
     */
    public void setUID(java.lang.String UID) {
        this.UID = UID;
    }


    /**
     * Gets the algorithmInfo value for this CertificateInfo.
     * 
     * @return algorithmInfo
     */
    public com.geotrust.api.webtrust.order.AlgorithmInfo getAlgorithmInfo() {
        return algorithmInfo;
    }


    /**
     * Sets the algorithmInfo value for this CertificateInfo.
     * 
     * @param algorithmInfo
     */
    public void setAlgorithmInfo(com.geotrust.api.webtrust.order.AlgorithmInfo algorithmInfo) {
        this.algorithmInfo = algorithmInfo;
    }


    /**
     * Gets the certTransparency value for this CertificateInfo.
     * 
     * @return certTransparency
     */
    public com.geotrust.api.webtrust.order.CertTransparency getCertTransparency() {
        return certTransparency;
    }


    /**
     * Sets the certTransparency value for this CertificateInfo.
     * 
     * @param certTransparency
     */
    public void setCertTransparency(com.geotrust.api.webtrust.order.CertTransparency certTransparency) {
        this.certTransparency = certTransparency;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CertificateInfo)) return false;
        CertificateInfo other = (CertificateInfo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.certificateStatus==null && other.getCertificateStatus()==null) || 
             (this.certificateStatus!=null &&
              this.certificateStatus.equals(other.getCertificateStatus()))) &&
            ((this.startDate==null && other.getStartDate()==null) || 
             (this.startDate!=null &&
              this.startDate.equals(other.getStartDate()))) &&
            ((this.endDate==null && other.getEndDate()==null) || 
             (this.endDate!=null &&
              this.endDate.equals(other.getEndDate()))) &&
            ((this.commonName==null && other.getCommonName()==null) || 
             (this.commonName!=null &&
              this.commonName.equals(other.getCommonName()))) &&
            ((this.serialNumber==null && other.getSerialNumber()==null) || 
             (this.serialNumber!=null &&
              this.serialNumber.equals(other.getSerialNumber()))) &&
            ((this.locality==null && other.getLocality()==null) || 
             (this.locality!=null &&
              this.locality.equals(other.getLocality()))) &&
            ((this.state==null && other.getState()==null) || 
             (this.state!=null &&
              this.state.equals(other.getState()))) &&
            ((this.organization==null && other.getOrganization()==null) || 
             (this.organization!=null &&
              this.organization.equals(other.getOrganization()))) &&
            ((this.country==null && other.getCountry()==null) || 
             (this.country!=null &&
              this.country.equals(other.getCountry()))) &&
            ((this.organizationalUnit==null && other.getOrganizationalUnit()==null) || 
             (this.organizationalUnit!=null &&
              this.organizationalUnit.equals(other.getOrganizationalUnit()))) &&
            ((this.organizationalUnit2==null && other.getOrganizationalUnit2()==null) || 
             (this.organizationalUnit2!=null &&
              this.organizationalUnit2.equals(other.getOrganizationalUnit2()))) &&
            ((this.organizationalUnit3==null && other.getOrganizationalUnit3()==null) || 
             (this.organizationalUnit3!=null &&
              this.organizationalUnit3.equals(other.getOrganizationalUnit3()))) &&
            ((this.registrationNumber==null && other.getRegistrationNumber()==null) || 
             (this.registrationNumber!=null &&
              this.registrationNumber.equals(other.getRegistrationNumber()))) &&
            ((this.jurisdictionCity==null && other.getJurisdictionCity()==null) || 
             (this.jurisdictionCity!=null &&
              this.jurisdictionCity.equals(other.getJurisdictionCity()))) &&
            ((this.jurisdictionRegion==null && other.getJurisdictionRegion()==null) || 
             (this.jurisdictionRegion!=null &&
              this.jurisdictionRegion.equals(other.getJurisdictionRegion()))) &&
            ((this.jurisdictionCountry==null && other.getJurisdictionCountry()==null) || 
             (this.jurisdictionCountry!=null &&
              this.jurisdictionCountry.equals(other.getJurisdictionCountry()))) &&
            ((this.webServerType==null && other.getWebServerType()==null) || 
             (this.webServerType!=null &&
              this.webServerType.equals(other.getWebServerType()))) &&
            ((this.DNSNames==null && other.getDNSNames()==null) || 
             (this.DNSNames!=null &&
              this.DNSNames.equals(other.getDNSNames()))) &&
            ((this.UID==null && other.getUID()==null) || 
             (this.UID!=null &&
              this.UID.equals(other.getUID()))) &&
            ((this.algorithmInfo==null && other.getAlgorithmInfo()==null) || 
             (this.algorithmInfo!=null &&
              this.algorithmInfo.equals(other.getAlgorithmInfo()))) &&
            ((this.certTransparency==null && other.getCertTransparency()==null) || 
             (this.certTransparency!=null &&
              this.certTransparency.equals(other.getCertTransparency())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCertificateStatus() != null) {
            _hashCode += getCertificateStatus().hashCode();
        }
        if (getStartDate() != null) {
            _hashCode += getStartDate().hashCode();
        }
        if (getEndDate() != null) {
            _hashCode += getEndDate().hashCode();
        }
        if (getCommonName() != null) {
            _hashCode += getCommonName().hashCode();
        }
        if (getSerialNumber() != null) {
            _hashCode += getSerialNumber().hashCode();
        }
        if (getLocality() != null) {
            _hashCode += getLocality().hashCode();
        }
        if (getState() != null) {
            _hashCode += getState().hashCode();
        }
        if (getOrganization() != null) {
            _hashCode += getOrganization().hashCode();
        }
        if (getCountry() != null) {
            _hashCode += getCountry().hashCode();
        }
        if (getOrganizationalUnit() != null) {
            _hashCode += getOrganizationalUnit().hashCode();
        }
        if (getOrganizationalUnit2() != null) {
            _hashCode += getOrganizationalUnit2().hashCode();
        }
        if (getOrganizationalUnit3() != null) {
            _hashCode += getOrganizationalUnit3().hashCode();
        }
        if (getRegistrationNumber() != null) {
            _hashCode += getRegistrationNumber().hashCode();
        }
        if (getJurisdictionCity() != null) {
            _hashCode += getJurisdictionCity().hashCode();
        }
        if (getJurisdictionRegion() != null) {
            _hashCode += getJurisdictionRegion().hashCode();
        }
        if (getJurisdictionCountry() != null) {
            _hashCode += getJurisdictionCountry().hashCode();
        }
        if (getWebServerType() != null) {
            _hashCode += getWebServerType().hashCode();
        }
        if (getDNSNames() != null) {
            _hashCode += getDNSNames().hashCode();
        }
        if (getUID() != null) {
            _hashCode += getUID().hashCode();
        }
        if (getAlgorithmInfo() != null) {
            _hashCode += getAlgorithmInfo().hashCode();
        }
        if (getCertTransparency() != null) {
            _hashCode += getCertTransparency().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CertificateInfo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "certificateInfo"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("certificateStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "CertificateStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("startDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "StartDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("endDate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "EndDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("commonName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "CommonName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("serialNumber");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "SerialNumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("locality");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Locality"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("state");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "State"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("organization");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Organization"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("country");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Country"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("organizationalUnit");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "OrganizationalUnit"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("organizationalUnit2");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "OrganizationalUnit2"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("organizationalUnit3");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "OrganizationalUnit3"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("registrationNumber");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "RegistrationNumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("jurisdictionCity");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "JurisdictionCity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("jurisdictionRegion");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "JurisdictionRegion"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("jurisdictionCountry");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "JurisdictionCountry"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("webServerType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "WebServerType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DNSNames");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "DNSNames"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("UID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "UID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("algorithmInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "AlgorithmInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "algorithmInfo"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("certTransparency");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "CertTransparency"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "CertTransparency"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
