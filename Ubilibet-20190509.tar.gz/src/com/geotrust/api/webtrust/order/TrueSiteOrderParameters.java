/**
 * TrueSiteOrderParameters.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.order;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class TrueSiteOrderParameters  implements java.io.Serializable {
    private java.lang.String domainName;

    private java.lang.String method;

    private java.lang.String contractID;

    private java.lang.Boolean renewalIndicator;

    private java.lang.String renewalBehavior;

    private java.lang.String specialInstructions;

    private java.lang.String emailLanguageCode;

    public TrueSiteOrderParameters() {
    }

    public TrueSiteOrderParameters(
           java.lang.String domainName,
           java.lang.String method,
           java.lang.String contractID,
           java.lang.Boolean renewalIndicator,
           java.lang.String renewalBehavior,
           java.lang.String specialInstructions,
           java.lang.String emailLanguageCode) {
           this.domainName = domainName;
           this.method = method;
           this.contractID = contractID;
           this.renewalIndicator = renewalIndicator;
           this.renewalBehavior = renewalBehavior;
           this.specialInstructions = specialInstructions;
           this.emailLanguageCode = emailLanguageCode;
    }


    /**
     * Gets the domainName value for this TrueSiteOrderParameters.
     * 
     * @return domainName
     */
    public java.lang.String getDomainName() {
        return domainName;
    }


    /**
     * Sets the domainName value for this TrueSiteOrderParameters.
     * 
     * @param domainName
     */
    public void setDomainName(java.lang.String domainName) {
        this.domainName = domainName;
    }


    /**
     * Gets the method value for this TrueSiteOrderParameters.
     * 
     * @return method
     */
    public java.lang.String getMethod() {
        return method;
    }


    /**
     * Sets the method value for this TrueSiteOrderParameters.
     * 
     * @param method
     */
    public void setMethod(java.lang.String method) {
        this.method = method;
    }


    /**
     * Gets the contractID value for this TrueSiteOrderParameters.
     * 
     * @return contractID
     */
    public java.lang.String getContractID() {
        return contractID;
    }


    /**
     * Sets the contractID value for this TrueSiteOrderParameters.
     * 
     * @param contractID
     */
    public void setContractID(java.lang.String contractID) {
        this.contractID = contractID;
    }


    /**
     * Gets the renewalIndicator value for this TrueSiteOrderParameters.
     * 
     * @return renewalIndicator
     */
    public java.lang.Boolean getRenewalIndicator() {
        return renewalIndicator;
    }


    /**
     * Sets the renewalIndicator value for this TrueSiteOrderParameters.
     * 
     * @param renewalIndicator
     */
    public void setRenewalIndicator(java.lang.Boolean renewalIndicator) {
        this.renewalIndicator = renewalIndicator;
    }


    /**
     * Gets the renewalBehavior value for this TrueSiteOrderParameters.
     * 
     * @return renewalBehavior
     */
    public java.lang.String getRenewalBehavior() {
        return renewalBehavior;
    }


    /**
     * Sets the renewalBehavior value for this TrueSiteOrderParameters.
     * 
     * @param renewalBehavior
     */
    public void setRenewalBehavior(java.lang.String renewalBehavior) {
        this.renewalBehavior = renewalBehavior;
    }


    /**
     * Gets the specialInstructions value for this TrueSiteOrderParameters.
     * 
     * @return specialInstructions
     */
    public java.lang.String getSpecialInstructions() {
        return specialInstructions;
    }


    /**
     * Sets the specialInstructions value for this TrueSiteOrderParameters.
     * 
     * @param specialInstructions
     */
    public void setSpecialInstructions(java.lang.String specialInstructions) {
        this.specialInstructions = specialInstructions;
    }


    /**
     * Gets the emailLanguageCode value for this TrueSiteOrderParameters.
     * 
     * @return emailLanguageCode
     */
    public java.lang.String getEmailLanguageCode() {
        return emailLanguageCode;
    }


    /**
     * Sets the emailLanguageCode value for this TrueSiteOrderParameters.
     * 
     * @param emailLanguageCode
     */
    public void setEmailLanguageCode(java.lang.String emailLanguageCode) {
        this.emailLanguageCode = emailLanguageCode;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof TrueSiteOrderParameters)) return false;
        TrueSiteOrderParameters other = (TrueSiteOrderParameters) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.domainName==null && other.getDomainName()==null) || 
             (this.domainName!=null &&
              this.domainName.equals(other.getDomainName()))) &&
            ((this.method==null && other.getMethod()==null) || 
             (this.method!=null &&
              this.method.equals(other.getMethod()))) &&
            ((this.contractID==null && other.getContractID()==null) || 
             (this.contractID!=null &&
              this.contractID.equals(other.getContractID()))) &&
            ((this.renewalIndicator==null && other.getRenewalIndicator()==null) || 
             (this.renewalIndicator!=null &&
              this.renewalIndicator.equals(other.getRenewalIndicator()))) &&
            ((this.renewalBehavior==null && other.getRenewalBehavior()==null) || 
             (this.renewalBehavior!=null &&
              this.renewalBehavior.equals(other.getRenewalBehavior()))) &&
            ((this.specialInstructions==null && other.getSpecialInstructions()==null) || 
             (this.specialInstructions!=null &&
              this.specialInstructions.equals(other.getSpecialInstructions()))) &&
            ((this.emailLanguageCode==null && other.getEmailLanguageCode()==null) || 
             (this.emailLanguageCode!=null &&
              this.emailLanguageCode.equals(other.getEmailLanguageCode())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getDomainName() != null) {
            _hashCode += getDomainName().hashCode();
        }
        if (getMethod() != null) {
            _hashCode += getMethod().hashCode();
        }
        if (getContractID() != null) {
            _hashCode += getContractID().hashCode();
        }
        if (getRenewalIndicator() != null) {
            _hashCode += getRenewalIndicator().hashCode();
        }
        if (getRenewalBehavior() != null) {
            _hashCode += getRenewalBehavior().hashCode();
        }
        if (getSpecialInstructions() != null) {
            _hashCode += getSpecialInstructions().hashCode();
        }
        if (getEmailLanguageCode() != null) {
            _hashCode += getEmailLanguageCode().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(TrueSiteOrderParameters.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "trueSiteOrderParameters"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("domainName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "DomainName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("method");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Method"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contractID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ContractID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("renewalIndicator");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "RenewalIndicator"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("renewalBehavior");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "RenewalBehavior"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("specialInstructions");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "SpecialInstructions"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("emailLanguageCode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "EmailLanguageCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
