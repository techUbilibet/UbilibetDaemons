/**
 * OperationData.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.order;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class OperationData  implements java.io.Serializable {
    private java.lang.String sealPreference;

    private com.geotrust.api.webtrust.order.VulnerabilityScanPreferences vulnerabilityScanPreferences;

    private com.geotrust.api.webtrust.order.Contact adminContact;

    private com.geotrust.api.webtrust.order.Contact techContact;

    private java.lang.String DVAuthMethod;

    public OperationData() {
    }

    public OperationData(
           java.lang.String sealPreference,
           com.geotrust.api.webtrust.order.VulnerabilityScanPreferences vulnerabilityScanPreferences,
           com.geotrust.api.webtrust.order.Contact adminContact,
           com.geotrust.api.webtrust.order.Contact techContact,
           java.lang.String DVAuthMethod) {
           this.sealPreference = sealPreference;
           this.vulnerabilityScanPreferences = vulnerabilityScanPreferences;
           this.adminContact = adminContact;
           this.techContact = techContact;
           this.DVAuthMethod = DVAuthMethod;
    }


    /**
     * Gets the sealPreference value for this OperationData.
     * 
     * @return sealPreference
     */
    public java.lang.String getSealPreference() {
        return sealPreference;
    }


    /**
     * Sets the sealPreference value for this OperationData.
     * 
     * @param sealPreference
     */
    public void setSealPreference(java.lang.String sealPreference) {
        this.sealPreference = sealPreference;
    }


    /**
     * Gets the vulnerabilityScanPreferences value for this OperationData.
     * 
     * @return vulnerabilityScanPreferences
     */
    public com.geotrust.api.webtrust.order.VulnerabilityScanPreferences getVulnerabilityScanPreferences() {
        return vulnerabilityScanPreferences;
    }


    /**
     * Sets the vulnerabilityScanPreferences value for this OperationData.
     * 
     * @param vulnerabilityScanPreferences
     */
    public void setVulnerabilityScanPreferences(com.geotrust.api.webtrust.order.VulnerabilityScanPreferences vulnerabilityScanPreferences) {
        this.vulnerabilityScanPreferences = vulnerabilityScanPreferences;
    }


    /**
     * Gets the adminContact value for this OperationData.
     * 
     * @return adminContact
     */
    public com.geotrust.api.webtrust.order.Contact getAdminContact() {
        return adminContact;
    }


    /**
     * Sets the adminContact value for this OperationData.
     * 
     * @param adminContact
     */
    public void setAdminContact(com.geotrust.api.webtrust.order.Contact adminContact) {
        this.adminContact = adminContact;
    }


    /**
     * Gets the techContact value for this OperationData.
     * 
     * @return techContact
     */
    public com.geotrust.api.webtrust.order.Contact getTechContact() {
        return techContact;
    }


    /**
     * Sets the techContact value for this OperationData.
     * 
     * @param techContact
     */
    public void setTechContact(com.geotrust.api.webtrust.order.Contact techContact) {
        this.techContact = techContact;
    }


    /**
     * Gets the DVAuthMethod value for this OperationData.
     * 
     * @return DVAuthMethod
     */
    public java.lang.String getDVAuthMethod() {
        return DVAuthMethod;
    }


    /**
     * Sets the DVAuthMethod value for this OperationData.
     * 
     * @param DVAuthMethod
     */
    public void setDVAuthMethod(java.lang.String DVAuthMethod) {
        this.DVAuthMethod = DVAuthMethod;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof OperationData)) return false;
        OperationData other = (OperationData) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.sealPreference==null && other.getSealPreference()==null) || 
             (this.sealPreference!=null &&
              this.sealPreference.equals(other.getSealPreference()))) &&
            ((this.vulnerabilityScanPreferences==null && other.getVulnerabilityScanPreferences()==null) || 
             (this.vulnerabilityScanPreferences!=null &&
              this.vulnerabilityScanPreferences.equals(other.getVulnerabilityScanPreferences()))) &&
            ((this.adminContact==null && other.getAdminContact()==null) || 
             (this.adminContact!=null &&
              this.adminContact.equals(other.getAdminContact()))) &&
            ((this.techContact==null && other.getTechContact()==null) || 
             (this.techContact!=null &&
              this.techContact.equals(other.getTechContact()))) &&
            ((this.DVAuthMethod==null && other.getDVAuthMethod()==null) || 
             (this.DVAuthMethod!=null &&
              this.DVAuthMethod.equals(other.getDVAuthMethod())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getSealPreference() != null) {
            _hashCode += getSealPreference().hashCode();
        }
        if (getVulnerabilityScanPreferences() != null) {
            _hashCode += getVulnerabilityScanPreferences().hashCode();
        }
        if (getAdminContact() != null) {
            _hashCode += getAdminContact().hashCode();
        }
        if (getTechContact() != null) {
            _hashCode += getTechContact().hashCode();
        }
        if (getDVAuthMethod() != null) {
            _hashCode += getDVAuthMethod().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(OperationData.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "operationData"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sealPreference");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "SealPreference"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("vulnerabilityScanPreferences");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "VulnerabilityScanPreferences"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "vulnerabilityScanPreferences"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("adminContact");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "AdminContact"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Contact"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("techContact");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "TechContact"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "Contact"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DVAuthMethod");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "DVAuthMethod"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
