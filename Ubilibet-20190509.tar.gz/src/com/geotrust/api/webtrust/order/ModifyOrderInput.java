/**
 * ModifyOrderInput.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.geotrust.api.webtrust.order;

@SuppressWarnings({ "serial", "unused", "rawtypes" })
public class ModifyOrderInput  implements java.io.Serializable {
    private com.geotrust.api.webtrust.order.OrderRequestHeader orderRequestHeader;

    private java.lang.String modifyOrderOperation;

    private java.lang.String modifyOrderReasonMessage;

    private java.lang.String requestorEmail;

    private com.geotrust.api.webtrust.order.OperationData operationData;

    public ModifyOrderInput() {
    }

    public ModifyOrderInput(
           com.geotrust.api.webtrust.order.OrderRequestHeader orderRequestHeader,
           java.lang.String modifyOrderOperation,
           java.lang.String modifyOrderReasonMessage,
           java.lang.String requestorEmail,
           com.geotrust.api.webtrust.order.OperationData operationData) {
           this.orderRequestHeader = orderRequestHeader;
           this.modifyOrderOperation = modifyOrderOperation;
           this.modifyOrderReasonMessage = modifyOrderReasonMessage;
           this.requestorEmail = requestorEmail;
           this.operationData = operationData;
    }


    /**
     * Gets the orderRequestHeader value for this ModifyOrderInput.
     * 
     * @return orderRequestHeader
     */
    public com.geotrust.api.webtrust.order.OrderRequestHeader getOrderRequestHeader() {
        return orderRequestHeader;
    }


    /**
     * Sets the orderRequestHeader value for this ModifyOrderInput.
     * 
     * @param orderRequestHeader
     */
    public void setOrderRequestHeader(com.geotrust.api.webtrust.order.OrderRequestHeader orderRequestHeader) {
        this.orderRequestHeader = orderRequestHeader;
    }


    /**
     * Gets the modifyOrderOperation value for this ModifyOrderInput.
     * 
     * @return modifyOrderOperation
     */
    public java.lang.String getModifyOrderOperation() {
        return modifyOrderOperation;
    }


    /**
     * Sets the modifyOrderOperation value for this ModifyOrderInput.
     * 
     * @param modifyOrderOperation
     */
    public void setModifyOrderOperation(java.lang.String modifyOrderOperation) {
        this.modifyOrderOperation = modifyOrderOperation;
    }


    /**
     * Gets the modifyOrderReasonMessage value for this ModifyOrderInput.
     * 
     * @return modifyOrderReasonMessage
     */
    public java.lang.String getModifyOrderReasonMessage() {
        return modifyOrderReasonMessage;
    }


    /**
     * Sets the modifyOrderReasonMessage value for this ModifyOrderInput.
     * 
     * @param modifyOrderReasonMessage
     */
    public void setModifyOrderReasonMessage(java.lang.String modifyOrderReasonMessage) {
        this.modifyOrderReasonMessage = modifyOrderReasonMessage;
    }


    /**
     * Gets the requestorEmail value for this ModifyOrderInput.
     * 
     * @return requestorEmail
     */
    public java.lang.String getRequestorEmail() {
        return requestorEmail;
    }


    /**
     * Sets the requestorEmail value for this ModifyOrderInput.
     * 
     * @param requestorEmail
     */
    public void setRequestorEmail(java.lang.String requestorEmail) {
        this.requestorEmail = requestorEmail;
    }


    /**
     * Gets the operationData value for this ModifyOrderInput.
     * 
     * @return operationData
     */
    public com.geotrust.api.webtrust.order.OperationData getOperationData() {
        return operationData;
    }


    /**
     * Sets the operationData value for this ModifyOrderInput.
     * 
     * @param operationData
     */
    public void setOperationData(com.geotrust.api.webtrust.order.OperationData operationData) {
        this.operationData = operationData;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ModifyOrderInput)) return false;
        ModifyOrderInput other = (ModifyOrderInput) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.orderRequestHeader==null && other.getOrderRequestHeader()==null) || 
             (this.orderRequestHeader!=null &&
              this.orderRequestHeader.equals(other.getOrderRequestHeader()))) &&
            ((this.modifyOrderOperation==null && other.getModifyOrderOperation()==null) || 
             (this.modifyOrderOperation!=null &&
              this.modifyOrderOperation.equals(other.getModifyOrderOperation()))) &&
            ((this.modifyOrderReasonMessage==null && other.getModifyOrderReasonMessage()==null) || 
             (this.modifyOrderReasonMessage!=null &&
              this.modifyOrderReasonMessage.equals(other.getModifyOrderReasonMessage()))) &&
            ((this.requestorEmail==null && other.getRequestorEmail()==null) || 
             (this.requestorEmail!=null &&
              this.requestorEmail.equals(other.getRequestorEmail()))) &&
            ((this.operationData==null && other.getOperationData()==null) || 
             (this.operationData!=null &&
              this.operationData.equals(other.getOperationData())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getOrderRequestHeader() != null) {
            _hashCode += getOrderRequestHeader().hashCode();
        }
        if (getModifyOrderOperation() != null) {
            _hashCode += getModifyOrderOperation().hashCode();
        }
        if (getModifyOrderReasonMessage() != null) {
            _hashCode += getModifyOrderReasonMessage().hashCode();
        }
        if (getRequestorEmail() != null) {
            _hashCode += getRequestorEmail().hashCode();
        }
        if (getOperationData() != null) {
            _hashCode += getOperationData().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ModifyOrderInput.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ModifyOrderInput"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderRequestHeader");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "OrderRequestHeader"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "orderRequestHeader"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("modifyOrderOperation");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ModifyOrderOperation"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("modifyOrderReasonMessage");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "ModifyOrderReasonMessage"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("requestorEmail");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "RequestorEmail"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("operationData");
        elemField.setXmlName(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "OperationData"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.geotrust.com/webtrust/order", "operationData"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
