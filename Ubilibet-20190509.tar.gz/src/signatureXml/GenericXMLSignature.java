package signatureXml;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.security.KeyPair;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.Provider;
import java.security.Security;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.List;

import org.bouncycastle.openssl.PEMReader;
import org.w3c.dom.Document;

import javax.xml.transform.TransformerException;

import es.mityc.firmaJava.libreria.utilidades.UtilidadTratarNodo;
import es.mityc.firmaJava.libreria.xades.DataToSign;
import es.mityc.firmaJava.libreria.xades.FirmaXML;
import es.mityc.javasign.pkstore.CertStoreException;
import es.mityc.javasign.pkstore.IPKStoreManager;

/**
 * <p>
 * Clase base que deberán extender los diferentes ejemplos para realizar
 * firmas XML.
 * </p>
 * 
 * @author Ministerio de Industria, Turismo y Comercio
 * @version 1.0
 */
@SuppressWarnings("javadoc")
public abstract class GenericXMLSignature {

	/**
	 * <p>
	 * Almacén PKCS12 con el que se desea realizar la firma
	 * </p>
	 */

	public GenericXMLSignature() {
	}

	/**
	 * <p>
	 * Constraseña de acceso a la clave privada del usuario
	 * </p>
	 * @throws Exception 
	 */

	public String execute(byte[] inputFileb64) throws Exception {
//	public String execute(String inputFileb64) throws Exception {
		String resultat = "";
		/*
		 * //Obtenim el certificat X509Certificate certificate =
		 * getCertificate(CERT_RESOURCE);
		 * 
		 * if (certificate == null) {
		 * System.err.println("No existe ningún certificado para firmar.");
		 * return resultat; }
		 * 
		 * // Obtención de la clave privada asociada al certificado PrivateKey
		 * privateKey; privateKey = getPrivateKey(PK_RESOURCE);
		 * 
		 * IPKStoreManager storeManager = getPKStoreManager(certificate,
		 * privateKey); if (storeManager == null) {
		 * System.err.println("El gestor de claves no se ha obtenido correctamente."
		 * ); return ""; }
		 * 
		 * 
		 * // Obtención del provider encargado de las labores criptográficas
		 * Provider provider = storeManager.getProvider(certificate);
		 */
		// Obtencion del gestor de claves
		IPKStoreManager storeManager = getPKStoreManager();
		if (storeManager == null) {
			throw new Exception("El gestor de claves no se ha obtenido correctamente.");
		}

		// Obtencion del certificado para firmar. Utilizaremos el primer
		// certificado del almacen.
		X509Certificate certificate = getFirstCertificate(storeManager);
		if (certificate == null) {			
			throw new Exception("No existe ningún certificado para firmar.");
		}

		// Obtención de la clave privada asociada al certificado
		PrivateKey privateKey;
		try {
			privateKey = storeManager.getPrivateKey(certificate);
		} catch (CertStoreException e) {
			throw new Exception("Error al acceder al almacén.");	
		}

		// Obtención del provider encargado de las labores criptográficas
		Provider provider = storeManager.getProvider(certificate);

		//
		// Creación del objeto que contiene tanto los datos a firmar como la
		// configuración del tipo de firma
		//
		DataToSign dataToSign = createDataToSign(inputFileb64);

		// Firmamos el documento
		Document docSigned = null;
		//
		// Creación del objeto encargado de realizar la firma
		//
		FirmaXML firma = createFirmaXML();
		Object[] res = firma.signFile(certificate, dataToSign, privateKey, provider);
		docSigned = (Document) res[0];
		resultat = getStringFromDoc(docSigned);
		

		return resultat;
	}

//	private void saveDocumentToFile(Document document, String pathfile) throws Exception {
//		try {
//			FileOutputStream fos = new FileOutputStream(pathfile);
//			UtilidadTratarNodo.saveDocumentToOutputStream(document, fos, true);
//		} catch (FileNotFoundException e) {
//			throw new Exception("Error desant el document.");			
//		}
//	}

	public String getStringFromDoc(Document doc) throws TransformerException, IOException {

		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		UtilidadTratarNodo.saveDocumentToOutputStream(doc, baos);
		String out = null;
		
		out = baos.toString("UTF-8");//new String(baos..toByteArray());//, "UTF-8");
		baos.close();
		
		return out;
	}

	/**
	 * <p>
	 * Crea el objeto DataToSign que contiene toda la información de la firma
	 * que se desea realizar. Todas las implementaciones deberán proporcionar
	 * una implementación de este método
	 * </p>
	 * 
	 * @return El objeto DataToSign que contiene toda la información de la
	 *         firma a realizar
	 */
	protected abstract DataToSign createDataToSign(byte[] inputFileb64);
//	protected abstract DataToSign createDataToSign(String inputFileb64);


	/**
	 * <p>
	 * Crea el objeto <code>FirmaXML</code> con las configuraciones necesarias
	 * que se encargará de realizar la firma del documento.
	 * </p>
	 * <p>
	 * En el caso más simple no es necesaria ninguna configuración
	 * específica. En otros casos podrá ser necesario por lo que las
	 * implementaciones concretas de las diferentes firmas deberán
	 * sobreescribir este método (por ejemplo para añadir una autoridad de
	 * sello de tiempo en aquellas firmas en las que sea necesario)
	 * <p>
	 * 
	 * 
	 * @return firmaXML Objeto <code>FirmaXML</code> configurado listo para
	 *         usarse
	 */
	protected FirmaXML createFirmaXML() {
		return new FirmaXML();
	}

	protected X509Certificate getCertificate(String path) throws IOException {
		X509Certificate cert = null;
		InputStreamReader inStream = new InputStreamReader(new FileInputStream(path),"UTF-8");
		Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
		PEMReader reader = null;
		reader = new PEMReader(inStream);
		cert = (X509Certificate) reader.readObject();
		reader.close();
		return cert;
	}

	protected PrivateKey getPrivateKey(String path) throws IOException {
		PrivateKey pk = null;
		InputStreamReader inStream = new InputStreamReader(new FileInputStream(path),"UTF-8");
		Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
		PEMReader reader = null;
		reader = new PEMReader(inStream);
		KeyPair kp = (KeyPair) reader.readObject();
		pk = kp.getPrivate();
		reader.close();
		return pk;
	}

	/**
	 * <p>
	 * Devuelve el gestor de claves que se va a utilizar
	 * </p>
	 * 
	 * @return El gestor de claves que se va a utilizar</p>
	 */
	protected abstract IPKStoreManager getPKStoreManager()  throws KeyStoreException, NoSuchAlgorithmException, CertificateException, IOException;

	/**
	 * <p>
	 * Recupera el primero de los certificados del almacén.
	 * </p>
	 * 
	 * @param storeManager
	 *            Interfaz de acceso al almacén
	 * @return Primer certificado disponible en el almacén
	 * @throws Exception 
	 */
	private X509Certificate getFirstCertificate(
			final IPKStoreManager storeManager) throws Exception {
		List<X509Certificate> certs = null;
		try {
			certs = storeManager.getSignCertificates();
		} catch (CertStoreException ex) {
			throw new Exception("Fallo obteniendo listado de certificados");
			
		}
		if ((certs == null) || (certs.size() == 0)) {
			throw new Exception("Lista de certificados vacía");			
		}

		X509Certificate certificate = certs.get(0);
		return certificate;
	}

}