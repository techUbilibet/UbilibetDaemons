package signatureXml;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.Provider;
import java.security.Security;
import java.security.cert.CertificateException;
import java.util.logging.Level;

import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;

import util.Log;
import util.XmlSheet;
import es.mityc.firmaJava.libreria.xades.DataToSign;
import es.mityc.javasign.EnumFormatoFirma;
import es.mityc.firmaJava.libreria.xades.XAdESSchemas;
import es.mityc.javasign.pkstore.IPKStoreManager;
import es.mityc.javasign.pkstore.keystore.KSStore;
import es.mityc.javasign.xml.refs.AllXMLToSign;
import es.mityc.javasign.xml.refs.ObjectToSign;

/**
 * <p>
 * Clase de ejemplo para la firma XAdES-EPES enveloped de un documento. La
 * política a usar es la implícita, pero se especifica de forma explícita.
 * </p>
 * <p>
 * Para realizar la firma se utilizará el almacén PKCS#12 definido en la
 * constante <code>GenericXMLSignature.PKCS12_FILE</code>, al que se accederá
 * mediante la password definida en la constante
 * <code>GenericXMLSignature.PKCS12_PASSWORD</code>. El directorio donde quedará
 * el archivo XML resultante será el indicado en al constante
 * <code>GenericXMLSignature.OUTPUT_DIRECTORY</code>
 * </p>
 * 
 * @author Ministerio de Industria, Turismo y Comercio
 * @version 1.0
 */
public class XmlSignature extends GenericXMLSignature {

	private String KS_RESOURCE = null;
	private String KS_PASSWORD = null;

	@SuppressWarnings("javadoc")
	public XmlSignature() {		
		super();
		try {
			XmlSheet cfg=new XmlSheet("fact/config.xml",XmlSheet.Operations.NONE,"fact");
			KS_RESOURCE = cfg.getField("certs/keystore/file");
			KS_PASSWORD = cfg.getField("certs/keystore/password");
		} catch (Exception e) {
			Log.addlog(Level.SEVERE, "XmlSignature", e.getMessage());
			Log.addlog("XmlSignature", e.getStackTrace());
			e.printStackTrace();
		}
	}

	

	/**
	 * <p>
	 * Clave de la política que se desea aplicar. Dicha política debe estar
	 * definida en el fichero <code>META-INF/xades/policy.properties</code>
	 * </p>
	 */
	private final static String POLICY_TO_APPLY = "facturae31";

//	/**
//	 * <p>
//	 * Punto de entrada al programa
//	 * </p>
//	 * 
//	 * @param args
//	 *            Argumentos del programa
//	 */
//	public static void main(String[] args) {
//
//		// XAdESEPESSignatureUB signature = new XAdESEPESSignatureUB("");
//		// signature.execute();
//
//	}

	@Override
	protected DataToSign createDataToSign(byte[] inputFileb64) {
//	protected DataToSign createDataToSign(String inputFileb64) {
		// Política de firma (Con las librerías JAVA, esto se define en tiempo
		// de ejecución)
		DataToSign dataToSign = new DataToSign();
		dataToSign.setXadesFormat(EnumFormatoFirma.XAdES_BES);// XAdES-EPES
		// dataToSign.setXadesFormat(EnumFormatoFirma.XAdES_XL);//XAdES-X-L
		dataToSign.setEsquema(XAdESSchemas.XAdES_132);
		dataToSign.setPolicyKey(POLICY_TO_APPLY);
		dataToSign.setAddPolicy(true);
		dataToSign.setXMLEncoding("UTF-8");
		dataToSign.setEnveloped(true);
		dataToSign.addObject(new ObjectToSign(new AllXMLToSign(), "Document", null, "text/xml", null));
		Document docToSign = getDocument(inputFileb64);
		dataToSign.setDocument(docToSign);
		return dataToSign;
	}

	

	private Document getDocument(byte[] resource) {
//	private Document getDocument(String resource) {
		Document doc = null;
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		dbf.setNamespaceAware(true);
		try {
//			InputStream inStream = new ByteArrayInputStream(resource.getBytes(Charset.forName("UTF-8")));
			InputStream inStream = new ByteArrayInputStream(resource);
			Log.addlog(Level.INFO, "resource", new String(resource, "UTF-8"));
			doc = dbf.newDocumentBuilder().parse(inStream);
			Log.addlog(Level.INFO, "DOC ENCODING",doc.getInputEncoding());
			
		} catch (Exception e) {
			Log.addlog(Level.SEVERE, "getDocument", e.getMessage());
			Log.addlog("getDocument", e.getStackTrace());
			e.printStackTrace();
			return null;
		}
		return doc;
	}

	/**
	 * <p>
	 * Devuelve el gestor de claves que se va a utilizar
	 * </p>
	 * 
	 * @return El gestor de claves que se va a utilizar</p>
	 * @throws KeyStoreException 
	 * @throws IOException 
	 * @throws CertificateException 
	 * @throws NoSuchAlgorithmException 
	 */
	@Override
	protected IPKStoreManager getPKStoreManager() throws KeyStoreException, NoSuchAlgorithmException, CertificateException, IOException {
		IPKStoreManager storeManager = null;

		
			KeyStore ks = KeyStore.getInstance("pkcs12");
			java.io.FileInputStream fis = null;
			try {
				fis = new java.io.FileInputStream(KS_RESOURCE);
				ks.load(fis, KS_PASSWORD.toCharArray());
			} finally {
				if (fis != null) {
					fis.close();
				}
			}
			Provider provider = Security.getProvider("SunRsaSign");
			storeManager = new KSStore(ks, provider, new PassStoreKS(KS_PASSWORD));

		
		return storeManager;
	}
}
