package mailing;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.TreeMap;
import java.util.logging.Level;

import mailing.Messages;
import util.Arguments;
import util.Log;
import util.MailMessage;

public class Mailing {

	public static void main(String[] args) {
		final String fid="Main"; //$NON-NLS-1$

		Arguments.treatment(args);
		try {
			Log.InitLog("mailing",Arguments.exist(Messages.getString("param.log"))?Arguments.getParam(Messages.getString("param.log")):null);
			for (String param:Arguments.keySet()) {
				Log.addlog(Level.INFO, fid, param, Arguments.getParam(param));  //$NON-NLS-1$//$NON-NLS-2$
			}
			String operacio="mailing/"+Arguments.getParam("op");
			File fn=new File(operacio+".csv");
			if (!fn.exists()) {
				Log.addlog(Level.SEVERE, fid, "Sense llista de destinataris");
				System.exit(100);
			}
			BufferedReader bf=new BufferedReader(new FileReader(fn));
			String line=null;
			ArrayList<String> toSend= new ArrayList<String>();
			while ((line=bf.readLine())!=null) {
				toSend.add(line);
			}
			bf.close();
			fn=new File(operacio+".bck");
			if (!fn.exists()) {
				fn.createNewFile();
				fn.canWrite();
				fn.canRead();
			}
			bf=new BufferedReader(new FileReader(fn));
			TreeMap<String,Boolean> sent= new TreeMap<String, Boolean>();
			while ((line=bf.readLine())!=null) {
				sent.put(line, true);
			}
			bf.close();
			for (String email:toSend) {
				if (sent.containsKey(email)) continue;
				Log.addlog(Level.INFO, fid, "Enviat", email);
				MailMessage msg=new MailMessage(null,operacio);
				msg.addTo(email);
				msg.send();
				sent.put(email, true);
				BufferedWriter bw=new BufferedWriter(new FileWriter(fn, true));
				bw.write(email);
				bw.newLine();
				bw.close();
				sent.put(email, true);
				Calendar end=Calendar.getInstance();
				end.add(Calendar.SECOND, 4);
				while (Calendar.getInstance().getTime().before(end.getTime()));
			}
//			per cada adreça
//				Si no està a adreces enviades
//					Muntar email 
//					Enviar
//					afegir a llista enviades
//			final
		} catch (Exception e) {
			Log.addlog(Level.SEVERE, fid, e.getMessage());
			Log.addlog(fid, e.getStackTrace());
			e.printStackTrace();
		} 
	}

}
