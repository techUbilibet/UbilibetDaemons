#!/bin/bash

CLASSPATH=/usr/share/java/postgresql.jar
CLASSPATH=$CLASSPATH:/usr/share/java/axis-ant.jar:/usr/share/java/axis-jaxrpc.jar:/usr/share/java/axis-saaj.jar:/usr/share/java/axis.jar
CLASSPATH=$CLASSPATH:/usr/share/java/commons-discovery.jar:/usr/share/java/commons-logging.jar
CLASSPATH=$CLASSPATH:/usr/share/java/bcprov.jar:/usr/share/java/bcpkix.jar
CLASSPATH=$CLASSPATH:/usr/share/java/dom4j.jar:/usr/share/java/wsdl4j.jar
CLASSPATH=$CLASSPATH:/usr/share/java/mailapi.jar:/usr/share/java/javax.mail.jar:/usr/share/java/javax.mail-api.jar:/usr/share/java/imap.jar:/usr/share/java/pop3.jar:/usr/share/java/smtp.jar

CLASSPATH=$CLASSPATH:hibernate/lib/required/*:hibernate/lib/optional/c3p0/*:itext/*
CLASSPATH=$CLASSPATH:/usr/lib/jvm/java-8-openjdk

CLASSPATH=$CLASSPATH:bin:xml-hibernate
export CLASSPATH

export LANG=ca_ES.UTF-8

cd /Ubilibet

./back.sh> /dev/null

java facturacio.FacturacioDaemon $@ &> /dev/null
if [ $? == 0 ];
then
        echo "OK"
else
        echo "ERROR"
        if [ $# != 0 ]; then
           echo "Error fact"|mail tech@ubilibet.com -a "Content-type: text/plain; charset=UTF-8" -s "fact.sh"
        fi
fi

for d in fact.warning.log*; do
if [ -s ${d} ]; then
	cat ${d}|mail tech@ubilibet.com -a "Content-type: text/plain; charset=UTF-8" -s "Cron: fact.sh"
	truncate -s 0 ${d}
fi
done
 
cd - >/dev/null

